/**
 * \addtogroup tutorial
 * @{
 * \file tutorial6.cpp
 * \brief Tutorial 6: EEP to GP Gateway
 * \author EnOcean GmbH
 *
 * This Tutorial we will learn in some A5-02 xx Temperature Profile. The learned in Profile  will be added to a Generic Profile.
 * After the learn IN Phase, whenever we receive a Temperature information, the gateway will send a GP message containing
 * all temperatures.
 * */
#define SER_PORT "/dev/ttyUSB0"//! the Serial Port Device
#define LEARN_TIME_S 10 //! allows you to set the time the gateway should stay in learnmode
#include "./eoLink.h"

#include <stdint.h>
#include <stdio.h>
#include <map>

bool openGateway(eoGateway &myGateway)
{
	bool retValue=true;
	eoSerialCommand cmd(&myGateway);
	CO_RD_VERSION_RESPONSE version;
	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		retValue=false;
	}
	if (retValue&&cmd.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		retValue=false;
	}
	return retValue;
}

void learnInMode(eoGateway &myGateway,eoGenericProfile &genericTemperatureProfiles,std::map<uint32_t,uint8_t> &devToID)
{
	//recv stores the return Value of the Gateway
	uint16_t recv;
	//As RPS Telegrams don't have a teach IN Telegram, we need to set the wished profiled for an automated Teach IN
	//Set the learnTime and update the time
	uint32_t learnTime=eoTimer::GetTickCount()+30*1000;
	uint32_t time=eoTimer::GetTickCount();
	//Activate LearnMode
	myGateway.LearnMode=true;

	while(learnTime>time)
	{
		//updates the time, using the HAL getTickCount function
		time=eoTimer::GetTickCount();
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = myGateway.Receive();

		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)
		if ((recv & RECV_TEACHIN))
		{

			eoProfile *profile = myGateway.device->GetProfile();
			if(profile != NULL && profile->rorg == 0xA5 && profile->func == 0x02)
			{
				//add the Source ID to the Normale Mode Filter
				((eoIDFilter*)myGateway.filter)->Add(myGateway.telegram.sourceID);
				//Print out the Message to stdout
				eoDebug::Print(myGateway.telegram);
				//If the TeachIN process was successfull and we got a Profile print out the Message!
				eoChannelInfo* tempChannel=profile->GetChannel(S_TEMP);
				//Outgoing channels need to be added using the .AddChannelOut
				//For the Generic CHannel information we are using the eep informations, we use 10BIt resoluation as
				// the A5-02-xx profiles using maximal 10bits
				genericTemperatureProfiles.AddChannelOut(S_TEMP,GP_RES_10BIT,(int8_t)tempChannel->max,(int8_t)tempChannel->min,GP_SCAL_1,GP_SCAL_1,VAL_CURR);
				devToID[myGateway.device->ID]=devToID.size()-1;
			}
			else //The profile ist not an A5-02-xx, teach it out
			{
				myGateway.TeachInModule->TeachOut(myGateway.device->ID);
			}
		}

	}
	//Create and send a teach In Message
	eoMessage teachMessage(128);
	genericTemperatureProfiles.CreateTeachIN(teachMessage);
	myGateway.Send(teachMessage);
	//Deactivate LearnMode
	myGateway.LearnMode=false;
}

void operatingMode(eoGateway &myGateway,eoGenericProfile &genericTemperatureProfiles,std::map<uint32_t,uint8_t>  &devToID)
{
	uint16_t recv;
	while (1)
	{
		//recv stores the return Value of the Gateway
		recv = myGateway.Receive();
		if (recv & RECV_PROFILE)
		{
			eoDebug::Print(myGateway.message);
			//We received the Profile message and update our Temperature in the gpProfile and send the gpMessage
			eoProfile* tempProfile = myGateway.device->GetProfile();
			float temperature;
			if (tempProfile->GetValue( S_TEMP, temperature) ==EO_OK)
			{
				eoMessage gpMessage(128);
				genericTemperatureProfiles.SetValue(S_TEMP,temperature,devToID[myGateway.device->ID]);
				genericTemperatureProfiles.Create(gpMessage);
				myGateway.Send(gpMessage);
				eoDebug::Print(gpMessage);
			}
		}

	}
}

int main(int argc, const char* argv[]) {
	//First a Gateway and a storageManager will be definied
	eoGateway myGateway;
	//Empty Generic Profile
	eoGenericProfile genericTemperatureProfiles;

	std::map<uint32_t,uint8_t> devToID;
	if(openGateway(myGateway))
	{
		eodBmFilter *  learnFilter = new eodBmFilter();
		myGateway.learnFilter = learnFilter;
		learnFilter->maxdBm=-0;
		learnFilter->mindBm=-60;

		//the eoIDFilter will allow our Gateway application to filter all the unwanted Telegrams
		eoIDFilter * myFilter = new eoIDFilter();
		myGateway.filter=myFilter;

		printf("EnOcean-Link Gateway LearnMode\n");
		learnInMode(myGateway,genericTemperatureProfiles,devToID);
		printf("Learn Mode off\n");
		operatingMode(myGateway,genericTemperatureProfiles,devToID);

		delete learnFilter;
		delete myFilter;
	}
	return 0;
}

/** @}*/
