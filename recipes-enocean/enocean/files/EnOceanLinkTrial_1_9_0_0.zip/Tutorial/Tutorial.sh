#!/bin/bash
mkdir Tutorials
make distclean
cd Tutorials/
../configure LDFLAGS="-static"
if [ "$?" -eq "0" ]; then
	echo "Starting Make process"
else
	echo "Configure failed!"
	exit $?
fi
make clean
make 
if [ "$?" -eq "0" ]; then
        echo "Make Tutorials was sucessfull"
else
        exit $?
fi
