/**
 * \addtogroup tutorial
 * @{
 * \file WatcherMain.cpp
 * \brief Watcher MainClass
 * \author EnOcean GmbH
 *
 * In this Tutorial a Gateway which checks the Temperature of an external Sensors, and sends a warning Messages if we reach over 30°C.
 * As we do not want to learn in Devices, we uses a prepared configuration, and load it after Starting UP.
 * */
#ifdef WIN32
#include <windows.h>
#define SER_PORT "\\\\.\\COM35"  //COM4
#else
#define SER_PORT "/dev/ttyUSB1"//! the Serial Port Device
#endif

#define LEARN_TIME_S 1 //! allows you to set the time the gateway should stay in learnmode

#include <stdint.h>
#include "eoLink.h"

#include <stdio.h>


//Easy Handler for the different Security Issues
void HandleSecResult(EO_SEC_WATCH_RESULT watchRes)
{
	switch(watchRes)
	{
	case(WATCH_OK):
			break;
	case(WATCH_DEVICE_NA):
			break;
	case(WATCH_DEVICE_ALREADY_EXIST):
			break;
	case(WATCH_NOT_SECURE_DEVICE):
			break;
	case(WATCH_NOT_WATCHED_DEVICE):
			break;
	case(WATCH_DOS_ASSUMED):
			printf("Possible DOS detected \n");
			break;
	case(WATCH_TEL_TO_EARLY):
			break;
	case(WATCH_TEL_TO_LATE):
			break;
	case(WATCH_CMAC_OVERFLOW):
			break;
	case(WATCH_RLC_OVERFLOW):
			break;
	case(WATCH_DELAY_ASSUMED):
			printf("A possible delay Attack detected \n");
		break;
		default:
			printf("The Security watcher returned a not valid value!\n");
		break;
	}
}

int main(int argc, const char* argv[])
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	eoGateway myGateway;
	//10 telegrams allowed with less then 100ms between them(maturity time)
	eoWatcher* myWatcher=new eoWatcher(10,100);
	myGateway.secWatcher= myWatcher;
	CO_RD_VERSION_RESPONSE version;
	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return 0;
	}
	printf("EnOcean-Link Gateway LearnMode\n");
	//adding a dBm Filter as learnFilter
	if(myGateway.commands.ReadVersion(version)==EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//recv stores the return Value of the Gateway
	uint16_t recv;

	//As RPS Telegrams don't have a teach IN Telegram, we need to set the wished profiled for an automated Teach IN
	myGateway.TeachInModule->SetRPS(0x02,0x01);
	//Set the learnTime and update the time
	uint32_t learnTime=eoTimer::GetTickCount()+LEARN_TIME_S*10000;
	uint32_t time=eoTimer::GetTickCount();
	//Activate LearnMode
	myGateway.LearnModeOn();
	while(learnTime>time)
	{
		//updates the time, using the HAL getTickCount function
		time=eoTimer::GetTickCount();
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = myGateway.Receive();
		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)
		if (recv & RECV_TEACHIN)
		{
			//Print out the Message to stdout
			eoDebug::Print(myGateway.telegram);
			//If the TeachIN process was successfull and we got a Profile print out the Message!
			eoProfile *profile = myGateway.device->GetProfile();
			if(profile!=NULL)
			{
				printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", myGateway.device->ID, profile->rorg, profile->func, profile->type );

				for (int i = 0; i<profile->GetChannelCount(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
				}
			}
		}
	}
	//We add our example device, which we expect to send every 10sec and at least every 100ms.
	//The device Specific RLC Window is 10, and if we receive 5 Telegrams with a wrong CMAC we get an Error.
	//After each received Telegram the expted tel Period is reseted (Meaning maxPeriodTime and minPeriodTime count from
	//the moment we got this Telegram
	myWatcher->AddDevice(0x0102CD1C,10000,100,10,5,true);
	eoStorageManager myStore;
	myGateway.LearnModeOff();
	std::vector<uint32_t> deadDevices;
	uint32_t lastTick=eoTimer::GetTickCount();;
	while (1)
	{
		time=eoTimer::GetTickCount();
		recv = myGateway.Receive();
		if (recv & RECV_TELEGRAM)
		{
			eoDebug::Print(myGateway.telegram);
			HandleSecResult((EO_SEC_WATCH_RESULT)myGateway.GetSecWatchResult());
		}
		//If we got a valid Profile Telegram which is not a Learn IN we print the received Values
		if (recv & RECV_PROFILE)
		{
			printf("Device %08X\n", myGateway.device->ID);
			eoProfile *profile = myGateway.device->GetProfile();

			float f;
			uint8_t t;
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				//get the channel value if it is a float
				if (profile->GetValue( profile->GetChannel(i)->type, f) ==EO_OK)
					printf("%s %.2f %s\n", profile->GetChannel(i)->ToString(NAME),f,profile->GetChannel(i)->ToString(UNIT));
				//get the channel value if it is an uint
				if (profile->GetValue( profile->GetChannel(i)->type, t) ==EO_OK)
					printf("%s %u \n", profile->GetChannel(i)->ToString(NAME),t);
			}
		}
		//If know for all Devices to have certain Periods, we could also add an CheckForDeadDevice and inform the user
		if((time-lastTick)>1000)
		{

			if(myWatcher->CheckDeadDevices(deadDevices))
			{
				for(std::vector<uint32_t>::const_iterator it = deadDevices.begin(); it != deadDevices.end(); ++it)
				{
					printf("Possible Dead Device %u \n",*it);
				}
			}
			lastTick=time;
		}

	}
	delete myWatcher;
	return 0;
}
/** @}*/
