/**
 * \addtogroup tutorial
 * @{
 * \file eoWatcher.cpp
 * \brief Watcher Class
 * \author EnOcean GmbH
 *
 * An Example Class, which allows the checking of devices.
 * This eoWatcher Class, checks if a received Telegram of an added Device has arrived in the expected Timing.
 * It also tries to guess if the Gateway is under a Denial of Service or Delay Attack.
 * */
#include <stdint.h>
#include "eoWatcher.h"

eoWatcher::eoWatcher(uint32_t denialWarnCount,uint32_t denialTickBetween)
{
	denialCounter=0;
	tickOfLastTelegram=0;
	this->denialWarnCount=denialWarnCount;
	this->denialTickBetween=denialTickBetween;
}

eoWatcher::~eoWatcher()
{
}


;
EO_SEC_WATCH_RESULT eoWatcher::AddDevice(uint32_t const deviceID,uint32_t const maxPerdiodTime,uint32_t minPeriodTime,uint32_t maxRLCDiff,uint32_t maxWrongCmac,bool resetPeriod)
{
	EO_SEC_WATCH_RESULT retValue=WATCH_OK;
	if (watchedMap.find(deviceID) == watchedMap.end())
	{
		WATCH_STRUCT& watchedStruct= watchedMap[deviceID];
		watchedStruct.maxPeriodTime=maxPerdiodTime;
		watchedStruct.minPeriodTime=minPeriodTime;
		watchedStruct.maxRLCDiff=maxRLCDiff;
		watchedStruct.timeLastTelegram=0;
		watchedStruct.wrongCMACUsages=0;
		watchedStruct.maxWrongCmac=maxWrongCmac;
		watchedStruct.resetPeriod=resetPeriod;
	}
	else
	{
		retValue=WATCH_DEVICE_ALREADY_EXIST;
	}
	return retValue;
}
void eoWatcher::RemoveDevice(uint32_t const DeviceID)
{
	watchedMap.erase(DeviceID);
}
EO_SEC_WATCH_RESULT eoWatcher::DeviceCheck(eoDevice const * const device)
{
	EO_SEC_WATCH_RESULT retValue=WATCH_OK;
	uint32_t deviceID=device->ID;
	//check if we are inside of the expected time period
	uint32_t tickDiff=tickOfLastTelegram-watchedMap[deviceID].timeLastTelegram;
	if(watchedMap[deviceID].timeLastTelegram==0)
	{

	}
	else if(tickDiff<watchedMap[deviceID].minPeriodTime && watchedMap[deviceID].minPeriodTime!=0)
	{
		retValue=WATCH_TEL_TO_EARLY;
	}
	else if(tickDiff>watchedMap[deviceID].maxPeriodTime && watchedMap[deviceID].maxPeriodTime!=0)
	{
		uint32_t missedTel=tickDiff/watchedMap[deviceID].maxPeriodTime;
		uint32_t rlcDiff=sec_RLCdiff( device->secIn.rollingCode,  device->secIn.previousRollingCode,  (device->secIn.SLF&0xC0>>6));
		//The diff for a valid one is "1"
		rlcDiff-=1;
		if(rlcDiff>missedTel)
		{
			retValue=WATCH_DELAY_ASSUMED;
		}
		else
		{
			retValue=WATCH_TEL_TO_LATE;
		}
	}
	if(watchedMap[deviceID].resetPeriod)
	{
		watchedMap[deviceID].timeLastTelegram=tickOfLastTelegram;
	}
	else
	{
		if(retValue==WATCH_OK)
		{
			watchedMap[deviceID].timeLastTelegram=tickOfLastTelegram;
		}
		else if(retValue==WATCH_TEL_TO_LATE)
		{
			//As we are too late, update Time Diff to give us the possibility to resychronize
			uint32_t missedTel=tickDiff/watchedMap[deviceID].maxPeriodTime;
			watchedMap[deviceID].timeLastTelegram+=missedTel*watchedMap[deviceID].maxPeriodTime;
		}
	}
	//Get SLF
	if(retValue==WATCH_OK && device->secIn.SLF==0)
	{
		retValue=WATCH_NOT_SECURE_DEVICE;
	}

	if(retValue==WATCH_OK)
	{
		//If your Device uses Rolling Code check the window
		if((device->secIn.SLF&0xC0)!=SLF_RLC_ALGO_OFF)
		{
			uint32_t rlcDiff=sec_RLCdiff( device->secIn.rollingCode,  device->secIn.previousRollingCode,  (device->secIn.SLF&0xC0>>6));
			if(rlcDiff>watchedMap[deviceID].maxRLCDiff &&watchedMap[deviceID].maxRLCDiff!=0 )
			{
				retValue=WATCH_RLC_OVERFLOW;
			}
		}

		if((device->secIn.SLF&0x18)!=SLF_MAC_OFF && device->secIn.securityResult==SEC_CMAC_WRONG)
		{
			watchedMap[deviceID].wrongCMACUsages++;
			if(watchedMap[deviceID].wrongCMACUsages>watchedMap[deviceID].maxWrongCmac)
			{
				return WATCH_CMAC_OVERFLOW;
			}

		}
	}

	return retValue;
}
EO_SEC_WATCH_RESULT eoWatcher::CheckSecurity(eoDevice const * const device,eoTelegram const &msg)
{
	EO_SEC_WATCH_RESULT retValue=WATCH_OK;
	uint32_t deviceID=0;
	//get Devivce ID
	if(device==NULL)
	{
		retValue=WATCH_DEVICE_NA;
	}
	else
	{
		deviceID = device->ID;
	}
	//First check for possible General Denial of service
	if(tickOfLastTelegram!=0)
	{
		uint32_t tickDiff=eoTimer::GetTickCount()-tickOfLastTelegram;
		if(tickDiff>denialTickBetween)
		{
			denialCounter++;
			if(denialCounter>denialWarnCount)
				retValue=WATCH_DOS_ASSUMED;
		}
		else
		{
			uint32_t devicesToRemove=tickDiff/denialTickBetween;
			if(devicesToRemove>denialCounter)
			{
				denialCounter=0;
			}
			else
			{
				denialCounter-=devicesToRemove;
			}
		}
	}
	else
	{
		tickOfLastTelegram=eoTimer::GetTickCount();
	}


	if(retValue==WATCH_OK)
	{
		if (watchedMap.find(deviceID) == watchedMap.end())
		{
			retValue=WATCH_DEVICE_NA;
		}
	}

	if(retValue==WATCH_OK)
	{
		retValue=DeviceCheck(device);
	}

	//"Here be dragons "
	return retValue;
}

EO_SEC_WATCH_RESULT eoWatcher::UpdateDevice(uint32_t const DeviceID,uint32_t const maxPerdiodTime,uint32_t  const minPeriodTime,uint32_t const  maxRLCDiff,uint32_t const maxWrongCmac,bool resetPeriod)
{
	EO_SEC_WATCH_RESULT retValue=WATCH_OK;
	if (watchedMap.find(DeviceID) != watchedMap.end())
	{
		WATCH_STRUCT& watchedStruct= watchedMap[DeviceID];
		watchedStruct.maxPeriodTime=maxPerdiodTime;
		watchedStruct.minPeriodTime=minPeriodTime;
		watchedStruct.maxRLCDiff=maxRLCDiff;
		watchedStruct.maxWrongCmac=maxWrongCmac;
		watchedStruct.resetPeriod=resetPeriod;
	}
	else
	{
		retValue=WATCH_DEVICE_NA;
	}
	return retValue;
}
EO_SEC_WATCH_RESULT eoWatcher::Reset(uint32_t const DeviceID)
{
	EO_SEC_WATCH_RESULT retValue=WATCH_OK;
	if (watchedMap.find(DeviceID) != watchedMap.end())
	{
		WATCH_STRUCT& watchedStruct= watchedMap[DeviceID];
		watchedStruct.timeLastTelegram=0;
		watchedStruct.wrongCMACUsages=0;
	}
	else
	{
		retValue=WATCH_DEVICE_NA;
	}
	return retValue;
}
/** @}*/
