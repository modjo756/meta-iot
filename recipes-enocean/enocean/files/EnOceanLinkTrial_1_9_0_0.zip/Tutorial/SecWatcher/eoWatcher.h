/**
 * \addtogroup tutorial
 * @{
 * \file eoWatcher.h
 * \brief Watcher Header File
 * \author EnOcean GmbH
 *
 * An Example Class Header, which allows the security checking of Devices.
 * */
#include "eoLink.h"
#ifndef EOWATCHER_H_
#define EOWATCHER_H_
#include <map>
#include <stdint.h>
//! Security Watch Result
typedef enum
{
	//! Device is watched and no security issues
	WATCH_OK = 0,
	//! Device does not exist
	WATCH_DEVICE_NA,
	//! Device duplicated
	WATCH_DEVICE_ALREADY_EXIST,
	//! You tried to added a non secure device or the watched device does not have valid security information
	WATCH_NOT_SECURE_DEVICE,
	//! The processed device&message is not watched
	WATCH_NOT_WATCHED_DEVICE,
	//! A denial of service is assumed
	WATCH_DOS_ASSUMED,
	//! A Delay attack is assumed
	WATCH_DELAY_ASSUMED,
	//! The telegram of the watched device came to early
	WATCH_TEL_TO_EARLY,
	//! The telegram of the watched device came to late
	WATCH_TEL_TO_LATE,
	//! The counter of maximal allowed telegrams with wrong cmacs has been reached
	WATCH_CMAC_OVERFLOW,
	//! The Difference RLC of the last and current has reached the allowed one
	WATCH_RLC_OVERFLOW

} EO_SEC_WATCH_RESULT;


//! Watch  structure.
typedef struct
{
	//!Warns if the RLC is to different!
	uint32_t maxRLCDiff;
	//! min Time before a Telegram is expected
	uint32_t minPeriodTime;
	//! max Time where a telegram is expected
	uint32_t maxPeriodTime;
	//! tick count of the last handled Telegram
	uint32_t timeLastTelegram;
	//! current wrong cmac
	uint32_t wrongCMACUsages;
	//! maximal allowed wrong CMAC for the device
	uint32_t maxWrongCmac;
	//! Reset Period after every Received Telegram
	bool resetPeriod;
} WATCH_STRUCT;

typedef std::map<uint32_t, WATCH_STRUCT> watcher_id_map;
/**
 * @class eoWatcher
 * @brief an example implementation of an Security Watcher Class which tries to predict DOS and Delay Attacks.
 *
 * This class allows to add Devices to watch for Security problems. The following scenarios are supported:
 * 	- Denial of Service, to many telegrams are sent in a certain time period
 * 	- Delay attack, for a periodically sending device the telegrams are arriving to late.
 * 	- We got to many telegrams with a wrong cmac
 * 	- The difference of the Last Rolling Code counter and the current Rolling Code counter is to high (User definied,
 * 	the security api already allows a maximal difference of 64! )
 *
 */
class eoWatcher
{
public:
	/**
	 * Constructor of the eoWatcher Helper class.
	 *
	 * @param deviceManagerToWatch the deviceManager which contains the handled devices
	 * @param denialWarnCount How many telegrams are allowed to arrive maximal with a the definied tickCount between before a DOS is created.
	 * If = 0 the function is deactivated.
	 * @param denialTickBetween If the tick count between 2 telegrams is smaller then this count, the denialCounter gets increased.
	 * If = 0 the function is deactivated.
	 */
	eoWatcher(uint32_t denialWarnCount,uint32_t denialTickBetween);
	/**
	 * @brief Adds a Device to watch.
	 *
	 * @details Adds an unique device to the watcher. For periodic device a min and max Period Time should be defined.
	 * For all secure device the maximal amount of telegrams with wrong CMAC can be definied. The user can also define the maximal
	 * difference between the last and current RLC
	 *
	 * If the device is not secure it will be added but no security features will be probably supported. If the device already exist
	 * nothing happens. If the device does not exist in the Device manager it will not be added.
	 *
	 * @param DeviceID  the id of the device to watch
	 * @param maxPerdiodTime max Time(in ms) between 2 telegrams,=0 no max time
	 * @param minPeriodTime min Time(in ms) between 2 telegrams;=0 no min time
	 * @param maxRLCDiff max rlc difference allowed (64 is the enocen link one!)
	 * @param maxWrongCmac maximal number of telegrams with wrong cmac
	 * @param resetPeriod If true, after a Telegram has been received the period will be reset.
	 * If false the period is always extended for a valid Telegram.
	 * @return WATCH_NOT_SECURE_DEVICE or WATCH_OK or WATCH_DEVICE_ALREADY_EXIST or WATCH_DEVICE_NA
	 */
	EO_SEC_WATCH_RESULT AddDevice(uint32_t const DeviceID,uint32_t const maxPerdiodTime,uint32_t const minPeriodTime,uint32_t const maxRLCDiff,uint32_t  const maxWrongCmac,bool resetPeriod);
	/**
	* Updates a device, if the device does not exist nothing happens.
	*
	 * @param DeviceID  the id of the device to update
	 * @param maxPerdiodTime max Time(in ms) between 2 telegrams,=0 no max time
	 * @param minPeriodTime min Time(in ms) between 2 telegrams;=0 no min time
	 * @param maxRLCDiff max rlc difference allowed (64 is the enocen link one!)
	 * @param maxWrongCmac maximal number of telegrams with wrong cmac
	 * @param resetPeriod If true, after a Telegram has been received the period will be reset.
	 * If false the period is always extended for a valid Telegram.
	 * @return WATCH_OK  or WATCH_DEVICE_NA
	 */
	EO_SEC_WATCH_RESULT UpdateDevice(uint32_t const DeviceID,uint32_t const maxPerdiodTime,uint32_t  const minPeriodTime,uint32_t const  maxRLCDiff,uint32_t const maxWrongCmac,bool resetPeriod);
	/**
	 * Removes a device from the watch list
	 * @param DeviceID
	 */
	void RemoveDevice(uint32_t const DeviceID);
	/**
	 * @brief checks the Security of a Device after Receiving a telegram.
	 *
	 * This function has to be called always after receiving a telegram!
	 *
	 * @param pointer to Device to Check
	 * @param tel last received telegram
	 * @return
	 */
	EO_SEC_WATCH_RESULT CheckSecurity(eoDevice const * const  device,eoTelegram const &tel);

	/**
	 * Resets security check parameter (RLC count and CMAC wrong trie count
	 * @param DeviceID device id
	 * @return WATCH_OK  or WATCH_DEVICE_NA
	 */
	EO_SEC_WATCH_RESULT Reset(uint32_t const DeviceID);
	virtual ~eoWatcher();
private:
	//! Internal variable, counts the sucessive telegrams which sent faster then the denialTickBetween
	uint32_t denialCounter;
	//! tickCount of the last processed telegram in ms
	uint32_t tickOfLastTelegram;

	//! Internal Variable to represent at wich numbers of telegrams sent a DDoS is assumed
	uint32_t denialWarnCount;
	//! The tick between 2 telegrams to decrease the counter in ms
	uint32_t denialTickBetween;
	//! Map of watchedDevices
	watcher_id_map watchedMap;
	/**
	 * Checks a device for security issues
	 * @param device
	 * @return
	 */
	EO_SEC_WATCH_RESULT DeviceCheck(eoDevice const * const device);
};

#endif /* EOWATCHER_H_ */
/** @}*/
