#!/bin/sh
echo "Changes script rights"
chmod 777 ./*.sh
cd ./EOLink/
chmod 777 ./*.sh
chmod 777 ./configure
cd ../Tutorial/
chmod 777 ./*.sh
chmod 777 ./configure
cd ../examples/
chmod 777 ./*.sh
chmod 777 ./configure

