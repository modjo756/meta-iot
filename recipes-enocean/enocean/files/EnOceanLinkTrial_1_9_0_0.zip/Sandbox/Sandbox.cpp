// Sandbox.cpp : Defines the entry point for the console application.
//
#include <iostream>
#include <memory>

#include "stdafx.h"
#include "eoLink.h"
#include "Profiles\eoEEP_A538xx.h"
#include <csignal>
#include <typeinfo>
//a Sandbox to play arroung
#ifdef WIN32
#include <windows.h>
#define SER_PORT "\\\\.\\COM7"  //COM4
#else
#define SER_PORT "/dev/ttyUSB0"//! the Serial Port Device
#endif


#define LOAD_CONFIG "./learned.txt" //! where to store the gateway Configuration
#define LEARN_TIME_S 1 //! allows you to set the time the gateway should stay in learnmode
#include "eoLink.h"
#include <stdio.h>
int recomTest()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);

	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT) != EO_OK)
	{
		printf("Failed to open USB300\n");
		return 0;
	}

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
			version.appDescription,
			version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
			version.chipID,
			SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return 0;
	}
	eoTimer::Sleep(1000);
	eoReCom recom(&myGateway);
	eoReManMessage answear(512);
	std::vector<DEVICE_CONFIG> sendConfig;
	sendConfig.push_back({ 0, 2, 2 });
	recom.SetDeviceConfig(sendConfig,0);
	sendConfig.push_back({ 256, 4, 0x00010203 });
	recom.SetShallBeRepeated(true);
	recom.SetDeviceConfig(sendConfig, 0);
	recom.GetDeviceConfig({ 0, 0, 0 }, 0x010021F7);

	uint16_t recv;
	while (1)
	{
		recv = myGateway.Receive();
		if (recv & RECV_TELEGRAM)
		{
			eoDebug::Print(myGateway.telegram);

		}
		if (recv & RECV_REMAN)
		{
			eoDebug::Print(myGateway.reManMessage);
			switch (myGateway.reManMessage.fnCode)
			{
			case FN_RECOM_GET_METADATA:
			{
				answear.fnCode = FN_RECOM_GET_METADATA_RESPONSE;
				answear.dataLength = 0x5;
				answear.manufacturerID = 0x7ff;
				uint8_t metaDataResponse[] = { 0xF0, 0x03, 0x03, 0x03, 0x03 };
				memcpy(answear.data, metaDataResponse, 5);
				myGateway.Send(answear);
			}
			break;
			case FN_RECOM_GET_PRODUCT_ID:
			{
				answear.fnCode = 0x827;
				answear.dataLength = 0x6;
				answear.manufacturerID = 0x7ff;
				uint8_t productIdResponseData[] = { 0x12, 0x34, 0xA1, 0xA2, 0x35, 0x54 };
				memcpy(answear.data, productIdResponseData, 6);
				myGateway.Send(answear);
			}
			break;
			case  FN_RECOM_GET_DEVICE_CONFIG_RESPONSE:
			{
				std::vector<DEVICE_CONFIG> deviceConf;
				eoReturn recomResponse = recom.ParseDeviceConfigResponse(deviceConf);
				std::cout << recomResponse << std::endl;
			}

			}
		}
		eoTimer::Sleep(10);
	}

	return 1;
}


int vld_example() {
	eoGateway gateway; //= eoGateway();
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	printf("bla");
	//adding eoIDFilter to the gateWay
	if (gateway.Open(SER_PORT) != EO_OK)
	{
		printf("Failed to open USB300\n");
		return -1;
	}

	uint16_t recv;

	gateway.LearnMode = true;
	while (1)
	{
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = gateway.Receive();
		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)
		if (recv & RECV_TEACHIN)
		{
			//Print out the Message to stdout
			eoDebug::Print(gateway.telegram);
			//If the TeachIN process was successfull and we got a Profile print out the Message!
			eoProfile *profile = gateway.device->GetProfile();
			if (profile != NULL)
			{
				printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", gateway.device->ID, profile->rorg, profile->func, profile->type);

				for (int i = 0; i<profile->GetChannelCount(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
				}
			}

			//If incoming telegram is UTE telegram
			if (gateway.telegram.RORG == RORG_UTE)
			{
				//Creating the UTE response depending on the incoming teachIN telegram
				eoMessage response = eoMessage(7);
				auto uteQuery = gateway.TeachInModule->GetUTEQuery();
				eoUTEHelper::CreateUTEResponseFromQuery(uteQuery,response, TEACH_IN_ACCEPTED, UTE_DIRECTION_BIDIRECTIONAL);
				response.destinationID = gateway.telegram.sourceID;
				eoDebug::Print(response);
				//Send the UTE response
				gateway.Send(response);
			}
		}
		if (recv & RECV_PROFILE)
		{
			printf("Device %08X\n", gateway.device->ID);
			eoProfile *profile = gateway.device->GetProfile();

			float f;
			uint8_t t;
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				if (profile->GetValue(profile->GetChannel(i)->type, f) == EO_OK)
					printf("%s %.2f %s\n", profile->GetChannel(i)->ToString(NAME), f, profile->GetChannel(i)->ToString(UNIT));
				if (profile->GetValue(profile->GetChannel(i)->type, t) == EO_OK)
					printf("%s %u \n", profile->GetChannel(i)->ToString(NAME), t);

			}
			eoProfile *sendProf = eoProfileFactory::CreateProfile(0xD2, 0xA0, 0x01);
			//Parse our Message
			eoMessage mytel = eoMessage(2);
			sendProf->SetValue(E_DIRECTION, (uint8_t)CONTROLLER_TO_VALVE);
			sendProf->SetValue(E_STATE, (uint8_t)VALVE_REQUEST_OPEN);

			sendProf->Create(mytel);
			mytel.destinationID = 0x87BD91;
			gateway.Send(mytel);
		}
	}

	return 0;
}
int win32Test()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	std::string serialPort(SER_PORT);
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);
	eoStorageManager myStore;
	myStore.addObject("Gateway", &myGateway);
	myGateway.TeachInModule->SetRPS(0x02, 0x01);
	printf("Opening Connection to USB300 \n");
	while (myGateway.Open(serialPort.c_str()) != EO_OK)
	{
		std::cout << "Failed to open USB300" << std::endl;
		std::cout << "Please enter an alternative port (e.g." << SER_PORT << ")" << std::endl;
		std::getline(cin, serialPort);
	}

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
			version.appDescription,
			version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
			version.chipID,
			SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return 0;
	}

	eoTimer::Sleep(1000);
	printf("EnOcean-Link Gateway LearnMode\n");
	//adding a dBm Filter as learnFilter

	//the eoIDFilter will allow our Gateway application to filter all the unwanted Telegrams
	eoIDFilter * myFilter = new eoIDFilter();
	myGateway.filter = myFilter;

	//recv stores the return Value of the Gateway
	uint16_t recv;
	//As RPS Telegrams don't have a teach IN Telegram, we need to set the wished profiled for an automated Teach IN
	myGateway.TeachInModule->Set1BS(0x00, 0x01);
	myGateway.TeachInModule->Set4BS(0x12, 0x04);
	myGateway.TeachInModule->SetRPS(0x02, 0x01);
	//Set the learnTime and update the time
	//Activate LearnMode
	myGateway.LearnMode = true;

	while (1)
	{

		recv = myGateway.Receive();
		if (recv & RECV_TELEGRAM)
		{
			eoDebug::Print(myGateway.telegram);
		}

		if ((recv & RECV_TEACHIN))
		{
			eoProfile *profile = myGateway.device->GetProfile();
			printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", myGateway.device->ID, profile->rorg, profile->func, profile->type);


			myStore.Save("saved.txt");
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
			}
			if (typeid(*profile) == typeid(eoGenericProfile))
			{
				printf("Outbound Channels gpProfile:");
				eoGenericProfile * gpProfile = (eoGenericProfile *)profile;
				for (int i = 0; i<gpProfile->GetChannelCountOut(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", gpProfile->GetChannelOut(i)->ToString(NAME), gpProfile->GetChannelOut(i)->min, gpProfile->GetChannelOut(i)->max, gpProfile->GetChannelOut(i)->ToString(UNIT));

				}
			}
			//If incoming telegram is UTE telegram
			if (myGateway.telegram.RORG == RORG_UTE)
			{
				//Creating the UTE response depending on the incoming teachIN telegram
				eoMessage response = eoMessage(7);
				auto uteQuery = myGateway.TeachInModule->GetUTEQuery();
				eoUTEHelper::CreateUTEResponseFromQuery(uteQuery, response, TEACH_IN_ACCEPTED, UTE_DIRECTION_BIDIRECTIONAL);
				response.destinationID = myGateway.telegram.sourceID;
				eoDebug::Print(response);
				//Send the UTE response
				myGateway.Send(response);
			}

		}

		if (recv & RECV_PROFILE)
		{
			printf("Device %08X\n", myGateway.device->ID);
			eoProfile *profile = myGateway.device->GetProfile();

			float f;
			uint8_t t;
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				if (profile->GetValue(profile->GetChannel(i)->type, f) == EO_OK)
					printf("%s %.2f %s\n", profile->GetChannel(i)->ToString(NAME), f, profile->GetChannel(i)->ToString(UNIT));
				if (profile->GetValue(profile->GetChannel(i)->type, t) == EO_OK)
					printf("%s %u \n", profile->GetChannel(i)->ToString(NAME), t);

			}
		}
	}
	return 0;
}

int mainTest()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	std::string serialPort(SER_PORT);
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);
	eoRemoteManager reman(&myGateway);
	eoReCom recom(&myGateway);
	printf("Opening Connection to USB300 \n");
	while (myGateway.Open(serialPort.c_str()) != EO_OK)
	{
		std::cout << "Failed to open USB300" << std::endl;
		std::cout << "Please enter an alternative port (e.g." << SER_PORT << ")" << std::endl;
		std::getline(cin, serialPort);
	}

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
			version.appDescription,
			version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
			version.chipID,
			SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return 0;
	}
	eoMessage msg(255);
	eoProfile * profile = eoProfileFactory::CreateProfile(0xA5, 02, 05);
	eoProfile * profile2 = eoProfileFactory::CreateProfile(0xD5, 00, 01);
	profile->CreateTeachIN(msg);
	myGateway.Send(msg);

	profile->SetValue(S_TEMP, (float)20.0);
	profile->Create(msg);
	myGateway.Send(msg);
	profile->SetValue(S_TEMP, (float)30.0);
	profile->Create(msg);

	msg.RORG = RORG_VLD;


	myGateway.Send(msg);

	
	
}


int main(int argc, const char* argv[])
{
	recomTest();
	eoProfile * testProfile = eoProfileFactory::CreateProfile(0xD2, 0x01, 0x05);
	/*
	((eoEEP_D230xx*)testProfile)->SetCommand(3);
	 testProfile->SetValue(S_VALUE, 0.0F);
	testProfile->SetValue(E_ERROR_STATE, (uint8_t)0, MSR_CHANNEL_ERROR);
	testProfile->SetValue(S_TEMP, 0.0F, MSR_CHANNEL_RETURN_TEMP);
	testProfile->SetValue(S_TEMP, 0.0F, MSR_CHANNEL_SUPPLY_TEMP);
	testProfile->SetValue(S_PERCENTAGE, 0.0F);
	eoMessage msg(10);
	testProfile->Create(msg);
	eoDebug::Print(msg);
	*/
	eoMessage msg(4);
	msg.RORG = 0xD2;
	msg.data[0] = 0x02;
	msg.data[1] = 0x00;
	msg.data[2] = 0x00;
	msg.data[3] = 0x00;
	testProfile->Parse(msg);
	uint8_t u8Test;
	testProfile->GetValue(E_STATE, u8Test);
	//testProfile->SetValue(S_RELHUM, 50.0F);
	//mainTest();
	//vld_example();
	//recomTest();
	//win32Test();
}