#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA538xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x38, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA538xxTest,eepA53808Command1ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_TIME
	// Min
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x01, 0x7F, 0xFF, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(3276.7, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(6553.5, fGetValue, 0.5);

	// F_ON_OFF - CC_LOCK_UNLOCK
	// Enum - 0
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_LOCK_UNLOCK);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_LOCK_UNLOCK);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CC_DELAY_DURATION
	// Enum - 0
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_DELAY_DURATION);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_DELAY_DURATION);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CC_SWITCHING_COMMAND
	// Enum - 0
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_SWITCHING_COMMAND);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x0A9},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_SWITCHING_COMMAND);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA538xxTest,eepA53808Command1ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_TIME
	// Min
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(S_TIME,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(S_TIME,(float)3276);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x7F, 0xF8, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(S_TIME,(float)6553);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0xFF, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_LOCK_UNLOCK
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_LOCK_UNLOCK);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_LOCK_UNLOCK);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_DELAY_DURATION
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_DELAY_DURATION);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_DELAY_DURATION);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_SWITCHING_COMMAND
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_SWITCHING_COMMAND);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_SWITCHING_COMMAND);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}

TEST_F(profileA538xxTest,eepA53808Command2ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_DIMMING
	// Min
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x02, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TIME
	// Min
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x02, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// F_ON_OFF - CC_DIMMING_RANGE
	// Enum - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_DIMMING_RANGE);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_DIMMING_RANGE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CC_STORE_FINAL_VAL
	// Enum - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_STORE_FINAL_VAL);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_STORE_FINAL_VAL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CC_SWITCHING_COMMAND
	// Enum - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_SWITCHING_COMMAND);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x0A9},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_SWITCHING_COMMAND);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA538xxTest,eepA53808Command2ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_DIMMING
	// Min
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(S_DIMMING,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(S_DIMMING,(float)50);
	myProf->Create(*msg);
	uint8_t data2[] = {0x02, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(S_DIMMING,(float)100);
	myProf->Create(*msg);
	uint8_t data3[] = {0x02, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TIME
	// Min
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(S_TIME,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(S_TIME,(float)127);
	myProf->Create(*msg);
	uint8_t data5[] = {0x02, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(S_TIME,(float)255);
	myProf->Create(*msg);
	uint8_t data6[] = {0x02, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_DIMMING_RANGE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_DIMMING_RANGE);
	myProf->Create(*msg);
	uint8_t data7[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_DIMMING_RANGE);
	myProf->Create(*msg);
	uint8_t data8[] = {0x02, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_STORE_FINAL_VAL
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_STORE_FINAL_VAL);
	myProf->Create(*msg);
	uint8_t data9[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_STORE_FINAL_VAL);
	myProf->Create(*msg);
	uint8_t data10[] = {0x02, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_SWITCHING_COMMAND
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_SWITCHING_COMMAND);
	myProf->Create(*msg);
	uint8_t data11[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)2);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_SWITCHING_COMMAND);
	myProf->Create(*msg);
	uint8_t data12[] = {0x02, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA538xxTest,eepA53808Command3ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_SETPOINT
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(-12.7, fGetValue,0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(0.05, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(12.8, fGetValue, 0.5);
}

TEST_F(profileA538xxTest,eepA53808Command3ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_SETPOINT
	// Min
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)3);
	myProf->SetValue(S_SETPOINT,(float)-12.7);
	myProf->Create(*msg);
	uint8_t data1[] = {0x03, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)3);
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);

	EXPECT_EQ(0x03,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_NEAR(0x7F,msg->data[2],1);
	EXPECT_EQ(0x08,msg->data[3]);


	// Max
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)3);
	myProf->SetValue(S_SETPOINT,(float)12.8);
	myProf->Create(*msg);
	uint8_t data3[] = {0x03, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA538xxTest,eepA53808Command4ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x04, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Median
	ParseRawDate({0x04, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(25.6, fGetValue, 0.5);

	// Max
	ParseRawDate({0x04, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(51.2, fGetValue, 0.5);
}

TEST_F(profileA538xxTest,eepA53808Command4ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_TEMP_ABS
	// Min
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)4);
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x04, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)4);
	myProf->SetValue(S_TEMP_ABS,(float)25.6);
	myProf->Create(*msg);
	uint8_t data2[] = {0x04, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)4);
	myProf->SetValue(S_TEMP_ABS,(float)51.2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x04, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA538xxTest,eepA53808Command5ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_SETPOINT
	// Min
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// E_CONTROLLER_MODE
	// Enum - 0
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x05, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x05, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x05, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// F_ON_OFF - CC_CONTROLLER_STATE
	// Enum - 0
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_CONTROLLER_STATE);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x05, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_CONTROLLER_STATE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CC_ENERGY_HOLDOFF
	// Enum - 0
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_ENERGY_HOLDOFF);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x05, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, CC_ENERGY_HOLDOFF);
	EXPECT_EQ(1, u8GetValue);

	// E_OCCUPANCY
	// Enum - 0
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x05, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x05, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(2, u8GetValue);
}

TEST_F(profileA538xxTest,eepA53808Command5ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_SETPOINT
	// Min
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(S_SETPOINT,(float)50);
	myProf->Create(*msg);
	uint8_t data2[] = {0x05, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(S_SETPOINT,(float)100);
	myProf->Create(*msg);
	uint8_t data3[] = {0x05, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// E_CONTROLLER_MODE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x05, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data6[] = {0x05, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data7[] = {0x05, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_CONTROLLER_STATE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_CONTROLLER_STATE);
	myProf->Create(*msg);
	uint8_t data8[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_CONTROLLER_STATE);
	myProf->Create(*msg);
	uint8_t data9[] = {0x05, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF - CC_ENERGY_HOLDOFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CC_ENERGY_HOLDOFF);
	myProf->Create(*msg);
	uint8_t data10[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CC_ENERGY_HOLDOFF);
	myProf->Create(*msg);
	uint8_t data11[] = {0x05, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// E_OCCUPANCY
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_OCCUPANCY,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_OCCUPANCY,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)5);
	myProf->SetValue(E_OCCUPANCY,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);
}

TEST_F(profileA538xxTest,eepA53808Command6ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// E_FANSPEED
	// Enum - 0
	ParseRawDate({0x06, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x06, 0x00, 0x01, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x06, 0x00, 0x02, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x06, 0x00, 0x03, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 255
	ParseRawDate({0x06, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(255, u8GetValue);
}

TEST_F(profileA538xxTest,eepA53808Command6ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Pointless as command is set later!
	//Check that all in Channels exist
	//EXPECT_TRUE(ChannelExist(S_TIME));
	//EXPECT_TRUE(ChannelExist(S_DIMMING));
	//EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// E_FANSPEED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)6);
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x06, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)6);
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x06, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)6);
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x06, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)6);
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x06, 0x00, 0x03, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)6);
	myProf->SetValue(E_FANSPEED,(uint8_t)255);
	myProf->Create(*msg);
	uint8_t data5[] = {0x06, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);
}
