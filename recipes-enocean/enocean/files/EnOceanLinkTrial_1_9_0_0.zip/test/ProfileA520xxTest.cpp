/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Profiles/eoEEP_A520xx.h"
struct eepHelperItem
{
	CHANNEL_TYPE type;
	uint8_t index;
	uint8_t offset;
	uint8_t size;
	bool floatingValue;
	uint16_t bitoffs;
	uint16_t bitsize;
	uint32_t rangeMin;
	uint32_t rangeMax;
	float scaleMin;
	float scaleMax;
};
//Helper function for A5
class profileA520xxTest : public ProfileFixture
{
	/** */
	protected:
	bool OutChannelExist(CHANNEL_TYPE type)
	{
		eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)((eoEEP_A520xx*)myProf)->GetOutChannel(type);
		return(myChan!=NULL);
	}
	bool OutChannelExist(CHANNEL_TYPE type,uint8_t index)
	{
		eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)((eoEEP_A520xx*)myProf)->GetOutChannel(type,index);
		return(myChan!=NULL);
	}
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x20, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};
//A5-20-01 controller...
TEST_F(profileA520xxTest,eepA52001ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x01);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)1);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SERVICE_ON));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, ENERGY_INPUT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, ENERGY_STORAGE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, BATTERY_CAPACITY));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, CONTACT_COVER ));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, TEMPERATURE_FAIL));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, WINDOW_DETECTION));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, ACTUATOR_OBSTRUCTED));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_SETPOINT
	// Min - 0
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( S_SETPOINT, fGetValue);
	EXPECT_NEAR(0, fGetValue, 1);

	// Median - 50
	ParseRawDate({0x32, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( S_SETPOINT, fGetValue);
	EXPECT_NEAR(50, fGetValue, 1);

	// Max - 100
	ParseRawDate({0x64, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( S_SETPOINT, fGetValue);
	EXPECT_NEAR(100, fGetValue, 1);

	// F_ON_OFF -  SERVICE_ON
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  SERVICE_ON );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x80, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  SERVICE_ON );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  ENERGY_INPUT
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  ENERGY_INPUT );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x40, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  ENERGY_INPUT );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  ENERGY_STORAGE
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  ENERGY_STORAGE );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x20, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  ENERGY_STORAGE );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  BATTERY_CAPACITY
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  BATTERY_CAPACITY );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x10, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  BATTERY_CAPACITY );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  CONTACT_COVER
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  CONTACT_COVER );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x8, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  CONTACT_COVER );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  TEMPERATURE_FAIL
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  TEMPERATURE_FAIL );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x4, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  TEMPERATURE_FAIL );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  WINDOW_DETECTION
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  WINDOW_DETECTION );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x2, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  WINDOW_DETECTION );
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF -  ACTUATOR_OBSTRUCTED
	// False
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  ACTUATOR_OBSTRUCTED );
	EXPECT_EQ(0, u8GetValue);

	// True
	ParseRawDate({0x0, 0x1, 0x0, 0x8 },4);
	myProf->GetValue( F_ON_OFF, u8GetValue,  ACTUATOR_OBSTRUCTED );
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min - 0
	ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
	myProf->GetValue( S_TEMP, fGetValue);
	EXPECT_NEAR(0, fGetValue, 1);

	// Median - 20
	ParseRawDate({0x0, 0x0, 0x7F, 0x8 },4);
	myProf->GetValue( S_TEMP, fGetValue);
	EXPECT_NEAR(20, fGetValue, 1);

	// Max - 40
	ParseRawDate({0x0, 0x0, 0xFF, 0x8 },4);
	myProf->GetValue( S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 1);
}

TEST_F(profileA520xxTest,eepA52001ControllerSendData)
{
	//Setup the test
	Init(0x01);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)1);

	//Check that all out channels exist
	EXPECT_TRUE(OutChannelExist(S_SETPOINT));
	EXPECT_TRUE(OutChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(OutChannelExist(S_TEMP));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, RUN_INTI_SEQ));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, LIFT_SET));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, VALVE_OPEN));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, VALVE_CLOSED));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SUMMER_BIT));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SET_POINT_SELECTION));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SET_POINT_INVERSE));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SELECT_FUNCTION));

	// S_SETPOINT
	// Min - 0
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median - 50
	myProf->SetValue(S_SETPOINT,(float)50);
	myProf->Create(*msg);
	uint8_t data2[] = {0x32, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max - 100
	myProf->SetValue(S_SETPOINT,(float)100);
	myProf->Create(*msg);
	uint8_t data3[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP_ABS
	// Min - 0
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median - 20
	myProf->SetValue(S_TEMP_ABS,(float)20);
	myProf->Create(*msg);
	uint8_t data5[] = {0x7F, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max - 40
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data6[] = {0xFF, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TEMP
	// Min - 0
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0xFF, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median - 20
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data8[] = {0xFF, 0x7F, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max - 40
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data9[] = {0xFF, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF - RUN_INTI_SEQ
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RUN_INTI_SEQ);
	myProf->Create(*msg);
	uint8_t data10[] = {0xFF, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RUN_INTI_SEQ);
	myProf->Create(*msg);
	uint8_t data11[] = {0xFF, 0x00, 0x84, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_ON_OFF - LIFT_SET
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, LIFT_SET);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFF, 0x00, 0x84, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, LIFT_SET);
	myProf->Create(*msg);
	uint8_t data13[] = {0xFF, 0x00, 0xC4, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// F_ON_OFF - VALVE_OPEN
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VALVE_OPEN);
	myProf->Create(*msg);
	uint8_t data14[] = {0xFF, 0x00, 0xC4, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VALVE_OPEN);
	myProf->Create(*msg);
	uint8_t data15[] = {0xFF, 0x00, 0xE4, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// F_ON_OFF - VALVE_CLOSED
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VALVE_CLOSED);
	myProf->Create(*msg);
	uint8_t data16[] = {0xFF, 0x00, 0xE4, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VALVE_CLOSED);
	myProf->Create(*msg);
	uint8_t data17[] = {0xFF, 0x00, 0xF4, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// F_ON_OFF - SUMMER_BIT
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SUMMER_BIT);
	myProf->Create(*msg);
	uint8_t data18[] = {0xFF, 0x00, 0xF4, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SUMMER_BIT);
	myProf->Create(*msg);
	uint8_t data19[] = {0xFF, 0x00, 0xFC, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// F_ON_OFF - SET_POINT_INVERSE
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SET_POINT_INVERSE);
	myProf->Create(*msg);
	uint8_t data20[] = {0xFF, 0x00, 0xFC, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SET_POINT_INVERSE);
	myProf->Create(*msg);
	uint8_t data21[] = {0xFF, 0x00, 0xFE, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// F_ON_OFF - SELECT_FUNCTION
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SELECT_FUNCTION);
	myProf->Create(*msg);
	uint8_t data22[] = {0xFF, 0x00, 0xFE, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SELECT_FUNCTION);
	myProf->Create(*msg);
	uint8_t data23[] = {0xFF, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);
}

TEST_F(profileA520xxTest,eepA52001ActuratorReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x01);
	//Change Direction
	this->myProf->SetValue(E_DIRECTION, (uint8_t)0);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, RUN_INTI_SEQ));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, LIFT_SET));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, VALVE_OPEN));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, VALVE_CLOSED));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SUMMER_BIT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SET_POINT_SELECTION));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SET_POINT_INVERSE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SELECT_FUNCTION));

	// S_SETPOINT
	// Min - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);

	// Median - 50
	ParseRawDate({0x32, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 50.0,fGetValue,1);

	// Max - 100
	ParseRawDate({0x64, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 100.0,fGetValue,1);

	// S_TEMP_ABS
	// Min - 0
	ParseRawDate({0x00, 0x00, 0x04, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);

	// Median - 20
	ParseRawDate({0x7F, 0x00, 0x04, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 20.0,fGetValue,1);

	// Max - 40
	ParseRawDate({0xFF, 0x00, 0x04, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 40.0,fGetValue,1);

	// S_TEMP
	// Min - 0
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);

	// Median - 20
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 20.0,fGetValue,1);

	// Max - 40
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 40.0,fGetValue,1);

	// F_ON_OFF - RUN_INTI_SEQ
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RUN_INTI_SEQ);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x80, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RUN_INTI_SEQ);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - LIFT_SET
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LIFT_SET);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x40, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LIFT_SET);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VALVE_OPEN
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, VALVE_OPEN);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x20, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, VALVE_OPEN);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VALVE_CLOSED
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, VALVE_CLOSED);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x10, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, VALVE_CLOSED);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - SUMMER_BIT
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SUMMER_BIT);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x08, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SUMMER_BIT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - SET_POINT_INVERSE
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SET_POINT_INVERSE);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SET_POINT_INVERSE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - SELECT_FUNCTION
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SELECT_FUNCTION);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SELECT_FUNCTION);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA520xxTest,eepA52001ActuratorSendData)
{
	//Setup the test
	Init(0x01);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)0);
	//Check that all out channels exist
	EXPECT_TRUE(OutChannelExist(S_SETPOINT));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SERVICE_ON));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, ENERGY_INPUT));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, ENERGY_STORAGE));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, BATTERY_CAPACITY));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, CONTACT_COVER ));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, TEMPERATURE_FAIL));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, WINDOW_DETECTION));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, ACTUATOR_OBSTRUCTED));
	EXPECT_TRUE(OutChannelExist(S_TEMP));

	// S_SETPOINT
	// Min - 0
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Median - 50
	myProf->SetValue(S_SETPOINT,(float)50);
	myProf->Create(*msg);
	uint8_t data1[] = {0x32, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max - 100
	myProf->SetValue(S_SETPOINT,(float)100);
	myProf->Create(*msg);
	uint8_t data2[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// F_ON_OFF - SERVICE_ON
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SERVICE_ON);
	myProf->Create(*msg);
	uint8_t data3[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SERVICE_ON);
	myProf->Create(*msg);
	uint8_t data4[] = {0x64, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// F_ON_OFF - ENERGY_INPUT
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, ENERGY_INPUT);
	myProf->Create(*msg);
	uint8_t data5[] = {0x64, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, ENERGY_INPUT);
	myProf->Create(*msg);
	uint8_t data6[] = {0x64, 0xC0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// F_ON_OFF - ENERGY_STORAGE
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, ENERGY_STORAGE);
	myProf->Create(*msg);
	uint8_t data7[] = {0x64, 0xC0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, ENERGY_STORAGE);
	myProf->Create(*msg);
	uint8_t data8[] = {0x64, 0xE0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// F_ON_OFF - BATTERY_CAPACITY
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, BATTERY_CAPACITY);
	myProf->Create(*msg);
	uint8_t data9[] = {0x64, 0xE0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, BATTERY_CAPACITY);
	myProf->Create(*msg);
	uint8_t data10[] = {0x64, 0xF0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// F_ON_OFF - CONTACT_COVER
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CONTACT_COVER);
	myProf->Create(*msg);
	uint8_t data11[] = {0x64, 0xF0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CONTACT_COVER);
	myProf->Create(*msg);
	uint8_t data12[] = {0x64, 0xF8, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// F_ON_OFF - TEMPERATURE_FAIL
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TEMPERATURE_FAIL);
	myProf->Create(*msg);
	uint8_t data13[] = {0x64, 0xF8, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TEMPERATURE_FAIL);
	myProf->Create(*msg);
	uint8_t data14[] = {0x64, 0xFC, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_ON_OFF - WINDOW_DETECTION
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, WINDOW_DETECTION);
	myProf->Create(*msg);
	uint8_t data15[] = {0x64, 0xFC, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, WINDOW_DETECTION);
	myProf->Create(*msg);
	uint8_t data16[] = {0x64, 0xFE, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// F_ON_OFF - ACTUATOR_OBSTRUCTED
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, ACTUATOR_OBSTRUCTED);
	myProf->Create(*msg);
	uint8_t data17[] = {0x64, 0xFE, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, ACTUATOR_OBSTRUCTED);
	myProf->Create(*msg);
	uint8_t data18[] = {0x64, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// S_TEMP
	// Min - 0
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data19[] = {0x64, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Median - 20
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data20[] = {0x64, 0xFF, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Max - 40
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data21[] = {0x64, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);
}

TEST_F(profileA520xxTest,eepA52002ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x02);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)1);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SET_POINT_INVERSE));

	// S_PERCENTAGE
	// Min - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);

	// Median - 50
	ParseRawDate({0x32, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 50.0,fGetValue,1);

	// Max - 100
	ParseRawDate({0x64, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 100.0,fGetValue,1);

	// F_ON_OFF - SET_POINT_INVERSE
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SET_POINT_INVERSE);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SET_POINT_INVERSE);
	EXPECT_EQ(1, u8GetValue);
}
TEST_F(profileA520xxTest,eepA52002ControllerSendData)
{
	//Setup the test
	Init(0x02);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)0);
	//Check that all in Channels exist
	EXPECT_TRUE(OutChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SET_POINT_INVERSE));

	// S_PERCENTAGE
	// Min - 0
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Median - 50
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data1[] = {0x32, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max - 100
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data2[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// F_ON_OFF - SET_POINT_INVERSE
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SET_POINT_INVERSE);
	myProf->Create(*msg);
	uint8_t data3[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SET_POINT_INVERSE);
	myProf->Create(*msg);
	uint8_t data4[] = {0x64, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);
}

TEST_F(profileA520xxTest,eepA52002ActuratorReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x02);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)0);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SET_POINT_INVERSE));

	// S_SETPOINT
	// Min - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);

	// Median - 50
	ParseRawDate({0x32, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 50.0,fGetValue,1);

	// Max - 100
	ParseRawDate({0x64, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 100.0,fGetValue,1);

	// F_ON_OFF - SET_POINT_INVERSE
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SET_POINT_INVERSE);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SET_POINT_INVERSE);
	EXPECT_EQ(1, u8GetValue);
}
TEST_F(profileA520xxTest,eepA52002ActuratorSendData)
{
	//Setup the test
	Init(0x02);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)1);
	//Check that all in Channels exist
	EXPECT_TRUE(OutChannelExist(S_SETPOINT));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SET_POINT_INVERSE));

	// S_SETPOINT
	// Min - 0
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Median - 50
	myProf->SetValue(S_SETPOINT,(float)50);
	myProf->Create(*msg);
	uint8_t data1[] = {0x32, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max - 100
	myProf->SetValue(S_SETPOINT,(float)100);
	myProf->Create(*msg);
	uint8_t data2[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// F_ON_OFF - SET_POINT_INVERSE
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SET_POINT_INVERSE);
	myProf->Create(*msg);
	uint8_t data3[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SET_POINT_INVERSE);
	myProf->Create(*msg);
	uint8_t data4[] = {0x64, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);
}

TEST_F(profileA520xxTest,eepA52003ControllerReceiveData)
{
	float fGetValue;
	//Setup the test
	Init(0x03);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	//Min
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,0.08);
	//med
	ParseRawDate({50, 0x00,0x7F, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 50.0,fGetValue,1);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 20.0,fGetValue,0.08);
	//max
	ParseRawDate({100, 0x00,0xFF, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 100.0,fGetValue,1);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 40.0,fGetValue,0.08);
}

TEST_F(profileA520xxTest,eepA52003ControllerSendData)
{
	//Setup the test
	Init(0x03);
	//Check that all in Channels exist
	EXPECT_TRUE(OutChannelExist(S_SETPOINT));
	EXPECT_TRUE(OutChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(OutChannelExist(S_TEMP));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SET_POINT_SELECTION));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF, SET_POINT_INVERSE));
	//Min
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0.0);
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Set temp
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x04,msg->data[2]&0x04);
	EXPECT_EQ(0x08,msg->data[3]);

	//Medium
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)50.0);
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	EXPECT_EQ(50,msg->data[0]);
	EXPECT_EQ(0x7F,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Set temp
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)20.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x7F,msg->data[0]);
	EXPECT_EQ(0x04,msg->data[2]&0x04);
	EXPECT_EQ(0x08,msg->data[3]);


	//Max
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)100.0);
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	EXPECT_EQ(100,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Set temp
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)40.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0x04,msg->data[2]&0x04);
	EXPECT_EQ(0x08,msg->data[3]);

	//Flag not set
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0,SET_POINT_INVERSE);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Flag set
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1,SET_POINT_INVERSE);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x02,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
}

TEST_F(profileA520xxTest,eepA52003ActuratorReceiveData)
{
	float fGetValue;
	uint8_t u8GetValue;
	//Setup the test
	Init(0x03);
	((eoEEP_A520xx*)myProf)->SetDirection(eoActuator);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SET_POINT_SELECTION));
	EXPECT_TRUE(ChannelExist(F_ON_OFF, SET_POINT_INVERSE));
	//Min for temp
	ParseRawDate({0x00, 0xFF,0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);
	//Med for temp
	ParseRawDate({0x00, 0x7F,0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 20.0,fGetValue,1);
	//max for temp
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR( 40.0,fGetValue,1);

	//CHeck for S_SETPOINT
	//Min
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP_ABS, fGetValue));
	//Med
	ParseRawDate({50, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 50.0,fGetValue,1);
	//max
	ParseRawDate({100, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR( 100.0,fGetValue,1);
	//S_TEMP_ABS
	//Min
	ParseRawDate({0x00, 0x00,0x04, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_SETPOINT, fGetValue));
	//Med
	ParseRawDate({0x7F, 0x00,0x04, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 20.0,fGetValue,1);
	//max
	ParseRawDate({0xFF, 0x00,0x04, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 40.0,fGetValue,1);
	//flag
	ParseRawDate({0x00, 0x00,0x02, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,SET_POINT_INVERSE);
	EXPECT_EQ(1,u8GetValue);

	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,SET_POINT_INVERSE);
	EXPECT_EQ(0,u8GetValue);
}
TEST_F(profileA520xxTest,eepA52003ActuratorSendData)
{
	//Setup the test
	Init(0x03);

	((eoEEP_A520xx*)myProf)->SetDirection(eoActuator);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	//Min
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0.0);
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	//Medium
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)50.0);
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	EXPECT_EQ(50,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x7F,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Max
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)100.0);
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	EXPECT_EQ(100,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0xFF,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
}

TEST_F(profileA520xxTest,eepA52004ControllerReceiveData)
{
	float fGetValue;
	uint8_t u8GetValue;
	//Setup the test
	Init(0x04);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));//CP
	EXPECT_TRUE(ChannelExist(S_TEMP,FEED_TEMP));//FTS
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));//FTS- with DB0.1
	EXPECT_TRUE(ChannelExist(S_TEMP,CURRENT_TEMP));//TMPFC
	//Can also be error code
	EXPECT_TRUE(ChannelExist(E_ERROR_STATE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF,MEASUREMENT_STATUS));
	EXPECT_TRUE(ChannelExist(F_ON_OFF,STATUS_REQUEST));
	EXPECT_TRUE(ChannelExist(F_ON_OFF,BUTTON_LOCK));
	EXPECT_TRUE(ChannelExist(F_ON_OFF,TEMP_SELECTION));
	EXPECT_TRUE(ChannelExist(F_ON_OFF,FAILURE));
	//Current Position indepenedt from other channels..
	//MIN
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 0.0,fGetValue,1);
	//Med
	ParseRawDate({50, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 50.0,fGetValue,1);
	//Max
	ParseRawDate({100, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 100.0,fGetValue,1);
	//FTS - S_TEMP!
	//MIN
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP_ABS, fGetValue));
	myProf->GetValue(S_TEMP, fGetValue,FEED_TEMP);
	EXPECT_NEAR( 20.0,fGetValue,0.3);
	//Med
	ParseRawDate({0, 0x7F,0x00, 0x08},4);

	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP_ABS, fGetValue));
	myProf->GetValue(S_TEMP, fGetValue,FEED_TEMP);
	EXPECT_NEAR( 50.0,fGetValue,0.3);
	//Max
	ParseRawDate({100, 0xFF,0x00, 0x08},4);

	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP_ABS, fGetValue));
	myProf->GetValue(S_TEMP, fGetValue,FEED_TEMP);
	EXPECT_NEAR( 80.0,fGetValue,0.3);
	//FTS . Set Point
	//Min
	ParseRawDate({0x00, 0x00,0x00, 0x0A},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP, fGetValue,FEED_TEMP));
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 10.0,fGetValue,0.3);
	//Med
	ParseRawDate({0x00, 0x7F,0x00, 0x0A},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP, fGetValue,FEED_TEMP));
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 20.0,fGetValue,0.3);
	//Max
	ParseRawDate({0x00, 0xFF,0x00, 0x0A},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP, fGetValue,FEED_TEMP));
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(30.0,fGetValue,0.3);
	//Room temperature - TMPFC
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(E_ERROR_STATE, u8GetValue));
	myProf->GetValue(S_TEMP, fGetValue,CURRENT_TEMP);
	EXPECT_NEAR( 10.0,fGetValue,0.3);
	//Med
	ParseRawDate({0x00,0x00, 0x7F, 0x08},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(E_ERROR_STATE, u8GetValue));
	myProf->GetValue(S_TEMP, fGetValue,CURRENT_TEMP);
	EXPECT_NEAR( 20.0,fGetValue,0.3);
	//Max
	ParseRawDate({0x00, 0x00,0xFF, 0x08},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(E_ERROR_STATE, u8GetValue));
	myProf->GetValue(S_TEMP, fGetValue,CURRENT_TEMP);
	EXPECT_NEAR(30.0,fGetValue,0.3);
	//error states...
	ParseRawDate({0x00, 0x00,0x00, 0x09},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP, fGetValue,CURRENT_TEMP));
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ( 0.0,u8GetValue);
	//med
	ParseRawDate({0x00, 0x00,0x7F, 0x09},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP, fGetValue,CURRENT_TEMP));
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ( 0x7F,u8GetValue);
	//max
	ParseRawDate({0x00, 0x00,0xFF, 0x09},4);
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_TEMP, fGetValue,CURRENT_TEMP));
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ( 0xFF,u8GetValue);
	//Flag tests
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,MEASUREMENT_STATUS);
	EXPECT_EQ( 0,u8GetValue);
	ParseRawDate({0x00, 0x00,0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,MEASUREMENT_STATUS);
	EXPECT_EQ( 1,u8GetValue);

	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,STATUS_REQUEST);
	EXPECT_EQ( 0,u8GetValue);
	ParseRawDate({0x00, 0x00,0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,STATUS_REQUEST);
	EXPECT_EQ( 1,u8GetValue);


	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,BUTTON_LOCK);
	EXPECT_EQ( 0,u8GetValue);
	ParseRawDate({0x00, 0x00,0x00, 0x0C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,BUTTON_LOCK);
	EXPECT_EQ( 1,u8GetValue);
}

TEST_F(profileA520xxTest,eepA52004ControllerSendData)
{
	//Setup the test
	Init(0x04);
	//Check that all in Channels exist
	EXPECT_TRUE(OutChannelExist(S_PERCENTAGE));//POS
	EXPECT_TRUE(OutChannelExist(S_TEMP_ABS));//TSP
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,MEASUREMENT_CONTROL));//MC
	EXPECT_TRUE(OutChannelExist(E_STATE,WAKEUP_CYCLE));//WUC
	EXPECT_TRUE(OutChannelExist(E_STATE,DISPLAY_ORIENTATION));//DSO
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,BUTTON_LOCK));//BLC
	EXPECT_TRUE(OutChannelExist(E_COMMAND));//SER
	//0
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)0.0);
	myProf->SetValue(S_TEMP_ABS,(float)0.0);
	myProf->SetValue(F_ON_OFF,(uint8_t)0,MEASUREMENT_CONTROL);
	myProf->SetValue(F_ON_OFF,(uint8_t)0,BUTTON_LOCK);
	myProf->SetValue(E_STATE,(uint8_t)0,WAKEUP_CYCLE);
	myProf->SetValue(E_STATE,(uint8_t)0,DISPLAY_ORIENTATION);
	myProf->SetValue(E_COMMAND,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Max for different channels....
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)100.0);
	myProf->Create(*msg);
	EXPECT_EQ(100,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)30.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1,MEASUREMENT_CONTROL);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x40,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1,BUTTON_LOCK);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x0C,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)63,WAKEUP_CYCLE);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x3F,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);


	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3,DISPLAY_ORIENTATION);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x38,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_COMMAND,(uint8_t)3);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x0B,msg->data[3]);

	//Medium test...
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)50.0);
	myProf->SetValue(S_TEMP_ABS,(float)20.0);
	myProf->SetValue(F_ON_OFF,(uint8_t)0,MEASUREMENT_CONTROL);
	myProf->SetValue(F_ON_OFF,(uint8_t)0,BUTTON_LOCK);
	myProf->SetValue(E_STATE,(uint8_t)31,WAKEUP_CYCLE);
	myProf->SetValue(E_STATE,(uint8_t)1,DISPLAY_ORIENTATION);
	myProf->SetValue(E_COMMAND,(uint8_t)1);
	myProf->Create(*msg);
	EXPECT_EQ(50,msg->data[0]);
	EXPECT_EQ(0x7F,msg->data[1]);
	EXPECT_EQ(0x1F,msg->data[2]);
	EXPECT_EQ(0x19,msg->data[3]);
}

TEST_F(profileA520xxTest,eepA52004ActuratorReceiveData)
{
	//Setup the test
	Init(0x04);
	uint8_t u8GetValue;
	float fGetValue;
	((eoEEP_A520xx*)myProf)->SetDirection(eoActuator);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));//POS
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));//TSP
	EXPECT_TRUE(ChannelExist(F_ON_OFF,MEASUREMENT_CONTROL));//MC
	EXPECT_TRUE(ChannelExist(E_STATE,WAKEUP_CYCLE));//WUC
	EXPECT_TRUE(ChannelExist(E_STATE,DISPLAY_ORIENTATION));//DSO
	EXPECT_TRUE(ChannelExist(F_ON_OFF,BUTTON_LOCK));//BLC
	EXPECT_TRUE(ChannelExist(E_COMMAND));//SER
	ParseRawDate({0x00, 0x00,0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 0,fGetValue,1);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 10,fGetValue,0.3);
	myProf->GetValue(F_ON_OFF, u8GetValue,MEASUREMENT_CONTROL);
	EXPECT_EQ( 0,u8GetValue);
	myProf->GetValue(F_ON_OFF, u8GetValue,BUTTON_LOCK);
	EXPECT_EQ( 0,u8GetValue);
	myProf->GetValue(E_STATE, u8GetValue,WAKEUP_CYCLE);
	EXPECT_EQ( 0,u8GetValue);
	myProf->GetValue(E_STATE, u8GetValue,DISPLAY_ORIENTATION);
	EXPECT_EQ( 0,u8GetValue);
	myProf->GetValue(E_COMMAND, u8GetValue);
	EXPECT_EQ( 0,u8GetValue);
	//max check
	ParseRawDate({100, 0xFF,0x7F, 0x3F},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 100,fGetValue,1);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 30,fGetValue,0.3);
	myProf->GetValue(F_ON_OFF, u8GetValue,MEASUREMENT_CONTROL);
	EXPECT_EQ( 1,u8GetValue);
	myProf->GetValue(F_ON_OFF, u8GetValue,BUTTON_LOCK);
	EXPECT_EQ( 1,u8GetValue);
	myProf->GetValue(E_STATE, u8GetValue,WAKEUP_CYCLE);
	EXPECT_EQ( 63,u8GetValue);
	myProf->GetValue(E_STATE, u8GetValue,DISPLAY_ORIENTATION);
	EXPECT_EQ( 3,u8GetValue);
	myProf->GetValue(E_COMMAND, u8GetValue);
	EXPECT_EQ( 3,u8GetValue);
	//medium check
	ParseRawDate({50, 0x7F,31, 0x3F},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR( 50,fGetValue,1);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR( 20,fGetValue,0.3);
	myProf->GetValue(F_ON_OFF, u8GetValue,MEASUREMENT_CONTROL);
	EXPECT_EQ( 0,u8GetValue);
	myProf->GetValue(F_ON_OFF, u8GetValue,BUTTON_LOCK);
	EXPECT_EQ( 1,u8GetValue);
	myProf->GetValue(E_STATE, u8GetValue,WAKEUP_CYCLE);
	EXPECT_EQ( 31,u8GetValue);
	myProf->GetValue(E_STATE, u8GetValue,DISPLAY_ORIENTATION);
	EXPECT_EQ( 3,u8GetValue);
	myProf->GetValue(E_COMMAND, u8GetValue);
	EXPECT_EQ( 3,u8GetValue);
}

TEST_F(profileA520xxTest,eepA52004ActuratorSendData)
{
	//Setup the test
	Init(0x04);
	((eoEEP_A520xx*)myProf)->SetDirection(eoActuator);
	//Check that all in Channels exist
	EXPECT_TRUE(OutChannelExist(S_PERCENTAGE));//CP
	EXPECT_TRUE(OutChannelExist(S_TEMP,FEED_TEMP));//FTS
	EXPECT_TRUE(OutChannelExist(S_TEMP_ABS));//FTS- with DB0.1
	EXPECT_TRUE(OutChannelExist(S_TEMP,CURRENT_TEMP));//TMPFC
	//Can also be error code
	EXPECT_TRUE(OutChannelExist(E_ERROR_STATE));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,MEASUREMENT_STATUS));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,STATUS_REQUEST));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,BUTTON_LOCK));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,TEMP_SELECTION));
	EXPECT_TRUE(OutChannelExist(F_ON_OFF,FAILURE));
	//Percentage always okay!
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)50.0);
	myProf->Create(*msg);
	EXPECT_EQ(50,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)100.0);
	myProf->Create(*msg);
	EXPECT_EQ(100,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//Feed Temperature...
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0,FEED_TEMP);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0,FEED_TEMP);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x7F,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)80.0,FEED_TEMP);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//FTS . Set Pont...
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)10.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x0A,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)20.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x7F,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x0A,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)30.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x0A,msg->data[3]);
	//TMPFC - room temperatur
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0,CURRENT_TEMP);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0,CURRENT_TEMP);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x7F,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0,CURRENT_TEMP);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0xFF,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);
	//TMPFC - error code
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)MEASUREMENT_ERROR);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(17,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);
	//
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)BATTERY_EMPTY);
	myProf->Create(*msg);
	EXPECT_EQ(18,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)FROST_PROTECTION);
	myProf->Create(*msg);
	EXPECT_EQ(20,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)BLOCKED_VALVE);
	myProf->Create(*msg);
	EXPECT_EQ(33,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)END_POINT_DETECTION);
	myProf->Create(*msg);
	EXPECT_EQ(36,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)NO_VALVE);
	myProf->Create(*msg);
	EXPECT_EQ(40,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)NOT_TEACHED_IN);
	myProf->Create(*msg);
	EXPECT_EQ(49,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)NO_RESPONSE_FROM_CONTROLLER);
	myProf->Create(*msg);
	EXPECT_EQ(53,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);


	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)TEACH_IN_ERROR);
	myProf->Create(*msg);
	EXPECT_EQ(54,msg->data[2]);
	EXPECT_EQ(0x09,msg->data[3]);
	//
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0,MEASUREMENT_STATUS);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1,MEASUREMENT_STATUS);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x88,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0,STATUS_REQUEST);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1,STATUS_REQUEST);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x48,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0,BUTTON_LOCK);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x08,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1,BUTTON_LOCK);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x0C,msg->data[3]);
}
//TODO: 10,11,12...

TEST_F(profileA520xxTest,eepA52005Dir0SendData)
{
	uint8_t u8GetValue;
	float fGetValue;

	Init(0x05);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)1);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));

	// E_FANSPEED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x20, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x40, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x60, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x80, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0xA0, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// E_STATE
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x04, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x08, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x0C, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x10, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x14, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x18, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x1C, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// F_ON_OFF - NODE_LOW_BATTERY
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, NODE_LOW_BATTERY);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x10, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, NODE_LOW_BATTERY);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - NODE_EXT_COMM_ERROR
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, NODE_EXT_COMM_ERROR);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x08, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, NODE_EXT_COMM_ERROR);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - INTERNAL_SENSOR_ERROR
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, INTERNAL_SENSOR_ERROR);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x04, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, INTERNAL_SENSOR_ERROR);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - FAN_SPEED_ERROR
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, FAN_SPEED_ERROR);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x02, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, FAN_SPEED_ERROR);
	EXPECT_EQ(1, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x04, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, INTERNAL_SENSOR_ERROR);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - GENERAL_ERROR
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, GENERAL_ERROR);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x01, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, GENERAL_ERROR);
	EXPECT_EQ(1, u8GetValue);

	// S_PERCENTAGE
	// Min - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median - 100
	ParseRawDate({0x00, 0x00, 0x64, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// Max - 255
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_ON_OFF - AUTO_SPEED_SUPPORT
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, AUTO_SPEED_SUPPORT);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, AUTO_SPEED_SUPPORT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - SUMMER_BYPASS
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SUMMER_BYPASS);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SUMMER_BYPASS);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - FROST_PROTECTION_ACTIVE
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, FROST_PROTECTION_ACTIVE);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, FROST_PROTECTION_ACTIVE);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA520xxTest,eepA52005Dir0ReceiveData)
{
	//Setup the test
	Init(0x05);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)0);

	// E_FANSPEED
	// Enum - 0
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x20, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x40, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x60, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x80, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0xA0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// E_STATE
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0xA0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data7[] = {0xA4, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data8[] = {0xA8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data9[] = {0xAC, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->SetValue(E_STATE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data10[] = {0xB0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->SetValue(E_STATE,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data11[] = {0xB4, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->SetValue(E_STATE,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data12[] = {0xB8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->SetValue(E_STATE,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data13[] = {0xBC, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// F_ON_OFF - NODE_LOW_BATTERY
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, NODE_LOW_BATTERY);
	myProf->Create(*msg);
	uint8_t data14[] = {0xBC, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, NODE_LOW_BATTERY);
	myProf->Create(*msg);
	uint8_t data15[] = {0xBC, 0x10, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// F_ON_OFF - NODE_EXT_COMM_ERROR
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, NODE_EXT_COMM_ERROR);
	myProf->Create(*msg);
	uint8_t data16[] = {0xBC, 0x10, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, NODE_EXT_COMM_ERROR);
	myProf->Create(*msg);
	uint8_t data17[] = {0xBC, 0x18, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// F_ON_OFF - INTERNAL_SENSOR_ERROR
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, INTERNAL_SENSOR_ERROR);
	myProf->Create(*msg);
	uint8_t data18[] = {0xBC, 0x18, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, INTERNAL_SENSOR_ERROR);
	myProf->Create(*msg);
	uint8_t data19[] = {0xBC, 0x1C, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// F_ON_OFF - FAN_SPEED_ERROR
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, FAN_SPEED_ERROR);
	myProf->Create(*msg);
	uint8_t data20[] = {0xBC, 0x1C, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, FAN_SPEED_ERROR);
	myProf->Create(*msg);
	uint8_t data21[] = {0xBC, 0x1E, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// F_ON_OFF - GENERAL_ERROR
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, GENERAL_ERROR);
	myProf->Create(*msg);
	uint8_t data22[] = {0xBC, 0x1E, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, GENERAL_ERROR);
	myProf->Create(*msg);
	uint8_t data23[] = {0xBC, 0x1F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// S_PERCENTAGE
	// Min - 0
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data24[] = {0xBC, 0x1F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Median - 100
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data25[] = {0xBC, 0x1F, 0x64, 0x08};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// Max - 255
	myProf->SetValue(S_PERCENTAGE,(float)255);
	myProf->Create(*msg);
	uint8_t data26[] = {0xBC, 0x1F, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// F_ON_OFF - AUTO_SPEED_SUPPORT
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, AUTO_SPEED_SUPPORT);
	myProf->Create(*msg);
	uint8_t data27[] = {0xBC, 0x1F, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, AUTO_SPEED_SUPPORT);
	myProf->Create(*msg);
	uint8_t data28[] = {0xBC, 0x1F, 0xFF, 0x88};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// F_ON_OFF - SUMMER_BYPASS
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SUMMER_BYPASS);
	myProf->Create(*msg);
	uint8_t data29[] = {0xBC, 0x1F, 0xFF, 0x88};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SUMMER_BYPASS);
	myProf->Create(*msg);
	uint8_t data30[] = {0xBC, 0x1F, 0xFF, 0xC8};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],4),0);

	// F_ON_OFF - FROST_PROTECTION_ACTIVE
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, FROST_PROTECTION_ACTIVE);
	myProf->Create(*msg);
	uint8_t data31[] = {0xBC, 0x1F, 0xFF, 0xC8};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, FROST_PROTECTION_ACTIVE);
	myProf->Create(*msg);
	uint8_t data32[] = {0xBC, 0x1F, 0xFF, 0xE8};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],4),0);
}

TEST_F(profileA520xxTest,eepA52005Dir1SendData)
{
	uint8_t u8GetValue;
	float fGetValue;

	Init(0x05);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)0);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// E_FANSPEED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x20, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x40, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x60, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x80, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0xA0, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0xC0, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0xE0, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// E_STATE
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x03, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x04, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x06, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x07, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x08, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x09, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x0A, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(10, u8GetValue);

	// Enum - 11
	ParseRawDate({0x0B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(11, u8GetValue);

	// Enum - 12
	ParseRawDate({0x0C, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// Enum - 13
	ParseRawDate({0x0D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(13, u8GetValue);

	// Enum - 14
	ParseRawDate({0x0E, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(14, u8GetValue);

	// Enum - 15
	ParseRawDate({0x0F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Enum - 16
	ParseRawDate({0x10, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(16, u8GetValue);

	// Enum - 17
	ParseRawDate({0x11, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(17, u8GetValue);

	// Enum - 18
	ParseRawDate({0x12, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(18, u8GetValue);

	// Enum - 19
	ParseRawDate({0x13, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(19, u8GetValue);

	// Enum - 20
	ParseRawDate({0x14, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(20, u8GetValue);

	// Enum - 21
	ParseRawDate({0x15, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(21, u8GetValue);

	// Enum - 22
	ParseRawDate({0x16, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(22, u8GetValue);

	// Enum - 23
	ParseRawDate({0x17, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(23, u8GetValue);

	// Enum - 24
	ParseRawDate({0x18, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(24, u8GetValue);

	// Enum - 25
	ParseRawDate({0x19, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(25, u8GetValue);

	// Enum - 26
	ParseRawDate({0x1A, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(26, u8GetValue);

	// Enum - 27
	ParseRawDate({0x1B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(27, u8GetValue);

	// Enum - 28
	ParseRawDate({0x1C, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(28, u8GetValue);

	// Enum - 29
	ParseRawDate({0x1D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(29, u8GetValue);

	// F_ON_OFF - RESET_ERROR
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_ERROR);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_ERROR);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_FILTER_TIMER
	// Off - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_FILTER_TIMER);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_FILTER_TIMER);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA520xxTest,eepA52005Dir1ReceiveData)
{
	//Setup the test
	Init(0x05);
	this->myProf->SetValue(E_DIRECTION, (uint8_t)1);

	// E_FANSPEED
	// Enum - 0
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x20, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x40, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x60, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x80, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0xA0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0xC0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0xE0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// E_STATE
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0xE0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0xE1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data10[] = {0xE2, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data11[] = {0xE3, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->SetValue(E_STATE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data12[] = {0xE4, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->SetValue(E_STATE,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data13[] = {0xE5, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->SetValue(E_STATE,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data14[] = {0xE6, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->SetValue(E_STATE,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data15[] = {0xE7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->SetValue(E_STATE,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data16[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->SetValue(E_STATE,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data17[] = {0xE9, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->SetValue(E_STATE,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data18[] = {0xEA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->SetValue(E_STATE,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data19[] = {0xEB, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 12
	myProf->SetValue(E_STATE,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t data20[] = {0xEC, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 13
	myProf->SetValue(E_STATE,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t data21[] = {0xED, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 14
	myProf->SetValue(E_STATE,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t data22[] = {0xEE, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Enum - 15
	myProf->SetValue(E_STATE,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data23[] = {0xEF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Enum - 16
	myProf->SetValue(E_STATE,(uint8_t)16);
	myProf->Create(*msg);
	uint8_t data24[] = {0xF0, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Enum - 17
	myProf->SetValue(E_STATE,(uint8_t)17);
	myProf->Create(*msg);
	uint8_t data25[] = {0xF1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// Enum - 18
	myProf->SetValue(E_STATE,(uint8_t)18);
	myProf->Create(*msg);
	uint8_t data26[] = {0xF2, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Enum - 19
	myProf->SetValue(E_STATE,(uint8_t)19);
	myProf->Create(*msg);
	uint8_t data27[] = {0xF3, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// Enum - 20
	myProf->SetValue(E_STATE,(uint8_t)20);
	myProf->Create(*msg);
	uint8_t data28[] = {0xF4, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// Enum - 21
	myProf->SetValue(E_STATE,(uint8_t)21);
	myProf->Create(*msg);
	uint8_t data29[] = {0xF5, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],4),0);

	// Enum - 22
	myProf->SetValue(E_STATE,(uint8_t)22);
	myProf->Create(*msg);
	uint8_t data30[] = {0xF6, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],4),0);

	// Enum - 23
	myProf->SetValue(E_STATE,(uint8_t)23);
	myProf->Create(*msg);
	uint8_t data31[] = {0xF7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],4),0);

	// Enum - 24
	myProf->SetValue(E_STATE,(uint8_t)24);
	myProf->Create(*msg);
	uint8_t data32[] = {0xF8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],4),0);

	// Enum - 25
	myProf->SetValue(E_STATE,(uint8_t)25);
	myProf->Create(*msg);
	uint8_t data33[] = {0xF9, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);

	// Enum - 26
	myProf->SetValue(E_STATE,(uint8_t)26);
	myProf->Create(*msg);
	uint8_t data34[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],4),0);

	// Enum - 27
	myProf->SetValue(E_STATE,(uint8_t)27);
	myProf->Create(*msg);
	uint8_t data35[] = {0xFB, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],4),0);

	// Enum - 28
	myProf->SetValue(E_STATE,(uint8_t)28);
	myProf->Create(*msg);
	uint8_t data36[] = {0xFC, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],4),0);

	// Enum - 29
	myProf->SetValue(E_STATE,(uint8_t)29);
	myProf->Create(*msg);
	uint8_t data37[] = {0xFD, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],4),0);

	// F_ON_OFF - NODE_LOW_BATTERY
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_ERROR);
	myProf->Create(*msg);
	uint8_t data38[] = {0xFD, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_ERROR);
	myProf->Create(*msg);
	uint8_t data39[] = {0xFD, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],4),0);

	// F_ON_OFF - RESET_FILTER_TIMER
	// Off - 0
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_FILTER_TIMER);
	myProf->Create(*msg);
	uint8_t data40[] = {0xFD, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data40[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_FILTER_TIMER);
	myProf->Create(*msg);
	uint8_t data41[] = {0xFD, 0x00, 0x00, 0xC8};
	EXPECT_EQ(memcmp(&data41[0],&msg->data[0],4),0);
}
