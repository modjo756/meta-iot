#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA504xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x04, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA504xxTest,eepA0401ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_RELHUM
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7D, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFA, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);
}

TEST_F(profileA504xxTest,eepA04501ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_RELHUM
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x7D, 0x0A};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFA, 0x0A};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);
}

TEST_F(profileA504xxTest,eepA0402ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_RELHUM
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(-20, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7D, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFA, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60, fGetValue, 0.5);
}

TEST_F(profileA504xxTest,eepA04502ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_RELHUM
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x7D, 0x0A};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFA, 0x0A};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);
}

TEST_F(profileA504xxTest,eepA0403ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_RELHUM
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(-20, fGetValue);

	// Median
	ParseRawDate({0x00, 0x01, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x03, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60, fGetValue, 0.5);

	// F_ON_OFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA504xxTest,eepA04503ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_RELHUM
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x01, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x03, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);
}
