#include "eoLink.h"

#include <gtest/gtest.h>
#include "GatewayFixture.h"
#include "ChainedTelegramGenerator.h"

#define TELEGRAMLENGTH 14
#define MAXTELEGRAMCOUNT 63
#define MAXPAYLOADDATALENGTH 817

ChainedTelegramGenerator::~ChainedTelegramGenerator()
{
	delete[] payloadData;
}

ChainedTelegramGenerator::ChainedTelegramGenerator(uint16_t length,uint32_t sourceID)
{

	if (length > MAXPAYLOADDATALENGTH || length < 14 )
	{
		return;
	}
	telCount=0;
	payloadDataLength = length;
	telLength = TELEGRAMLENGTH;
	payloadData = new uint8_t[length];
	uint8_t seq = 0;

	srand(3);//choosen by fair dice

	for (size_t i = 0; i < length; i++)
	{
		payloadData[i] = (unsigned char) rand();
	}

	uint16_t offset = 0;
	bool finished=false;
	while(!finished)
	{
		eoTelegram tel(14);
		tel.RORG=RORG_CDM;
		tel.sourceID = sourceID;
		tel.data[0] = (seq & 0xC0) | (telCount & 0x3F);
		size_t j=1;
		if(telCount==0)
		{
			tel.data[1] = (length >> 8) & 0xFF;
			tel.data[2] = length & 0xFF;
			tel.data[3] = GP_CD;
			j=4;
		}
		bool continueLoop=true;
		for (; j < tel.dataLength&&continueLoop; j++)
		{
			if (offset < length)
				tel.data[j] = payloadData[offset];
			else
			{
				tel.dataLength=j;
				continueLoop=false;
				finished=true;
			}
			offset++;
		}
		telCount++;
		telegrams.push_back(tel);
	}
}

