#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA505xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x05, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA505xxTest,eepA0501ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PRESSURE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_PRESSURE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PRESSURE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.1);

	// Median
	ParseRawDate({0x01, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_PRESSURE, fGetValue);
	EXPECT_NEAR(8.25, fGetValue, 0.1);

	// Max
	ParseRawDate({0x03, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_PRESSURE, fGetValue);
	EXPECT_NEAR(11.5, fGetValue, 0.1);

	// F_ON_OFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA505xxTest,eepA0501ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PRESSURE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_PRESSURE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_PRESSURE,(float)5);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_PRESSURE,(float)8.25);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_PRESSURE,(float)11.5);
	myProf->Create(*msg);
	uint8_t data3[] = {0x03, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);
}
