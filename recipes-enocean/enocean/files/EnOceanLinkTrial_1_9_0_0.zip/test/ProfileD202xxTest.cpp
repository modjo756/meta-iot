/*
 * ProfileD202Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileD202xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(6);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x02, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileD202xxTest,eepD20200ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x00);

	// E_STATE
	// No smoke - 0
	ParseRawDate({0x01, 0x60, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(0, u8GetValue);

	// Smoke ionization - 1
	ParseRawDate({0x01, 0x60, 0x00, 0x01},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(1, u8GetValue);

	// Smoke optical - 2
	ParseRawDate({0x01, 0x60, 0x00, 0x02},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(2, u8GetValue);

	// Smoke both - 3
	ParseRawDate({0x01, 0x60, 0x00, 0x03},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(3, u8GetValue);

	// S_TEMP
	// Min
	ParseRawDate({0x01, 0x00, 0x00, 0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x7F, 0xFF},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0xFF, 0xFF},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(120, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x01, 0x20, 0x00, 0x00},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x20, 0x7F, 0xFF},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1023, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x20, 0xFF, 0xFF},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(2047, fGetValue, 0.5);

	// F_OCCUPIED
	// Off
	ParseRawDate({0x01, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x01, 0x40, 0x00, 0x01},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_SELF_TEST
	// Off
	ParseRawDate({0x02, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_SELF_TEST);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_SELF_TEST);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_TRIGGER_ALARM
	// Off
	ParseRawDate({0x02, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_TRIGGER_ALARM);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x40},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_TRIGGER_ALARM);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x03, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(-40.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0xF0, 0x7F, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0xF0, 0xFF, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(120, fGetValue, 0.5);

	// S_LUMINANCE_ABS
	// Min
	ParseRawDate({0x03, 0x00, 0x01, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0xF1, 0x7F, 0x00, 0x00},6);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_NEAR(1023, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0xF1, 0xFF, 0x00, 0x00},6);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_NEAR(2047, fGetValue, 0.5);

	// S_TIME - VLD_MAX_TIME
	// Min
	ParseRawDate({0x03, 0x00, 0x01, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(1280, fGetValue, 5);

	// Max
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(2550, fGetValue, 5);

	// S_TIME - VLD_MAX_TIME
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// E_STATE
	// Query temperature - 0
	ParseRawDate({0x04, 0x00},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(0, u8GetValue);

	// Query illumination - 1
	ParseRawDate({0x04, 0x20},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(1, u8GetValue);

	// Query occupancy - 2
	ParseRawDate({0x04, 0x40},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(2, u8GetValue);

	// Query smoke - 3
	ParseRawDate({0x04, 0x60},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileD202xxTest,eepD20200ControllerSendData)
{
	// Setup the test
	Init(0x00);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// S_TEMP
	// Min
	myProf->SetValue(S_TEMP,(float)-40);
	myProf->Create(*msg);
	uint8_t data0[] = {0x01, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x7F, 0xFF};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TEMP,(float)120);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_LUMINANCE,(float)1023);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x20, 0x7F, 0xEF};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_LUMINANCE,(float)2047);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x20, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// E_STATE - VLD_SMOKE_DETECTION
	// No smoke - 0
	myProf->SetValue(E_STATE,(uint8_t)0, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x60, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Ionization smoke - 1
	myProf->SetValue(E_STATE,(uint8_t)1, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x60, 0x00, 0x01};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Optical smoke - 2
	myProf->SetValue(E_STATE,(uint8_t)2, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x60, 0x00, 0x02};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Both - 3
	myProf->SetValue(E_STATE,(uint8_t)3, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x60, 0x00, 0x03};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// No smoke - 0
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x40, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Ionization smoke - 1
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x40, 0x00, 0x01};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - VLD_SELF_TEST
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_SELF_TEST);
	myProf->Create(*msg);
	uint8_t data12[] = {0x02, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_SELF_TEST);
	myProf->Create(*msg);
	uint8_t data13[] = {0x02, 0x80};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],2),0);

	// F_ON_OFF - VLD_TRIGGER_ALARM
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_TRIGGER_ALARM);
	myProf->Create(*msg);
	uint8_t data14[] = {0x02, 0x80};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_TRIGGER_ALARM);
	myProf->Create(*msg);
	uint8_t data15[] = {0x02, 0xC0};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x03);

	// F_ON_OFF - VLD_REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data16[] = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data17[] = {0x03, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],6),0);

	// S_TEMP_ABS
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x03, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data19[] = {0x03, 0x80, 0xF0, 0x7F, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)120);
	myProf->Create(*msg);
	uint8_t data20[] = {0x03, 0x80, 0xF0, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_LUMINANCE_ABS
	// Min
	myProf->SetValue(S_LUMINANCE_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data21[] = {0x03, 0x80, 0x01, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_LUMINANCE_ABS,(float)1023);
	myProf->Create(*msg);
	uint8_t data22[] = {0x03, 0x80, 0xE1, 0x7F, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_LUMINANCE_ABS,(float)2047);
	myProf->Create(*msg);
	uint8_t data23[] = {0x03, 0x80, 0xF1, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_TIME - VLD_MAX_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data24[] = {0x03, 0x80, 0xF1, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1275, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data25[] = {0x03, 0x80, 0xF1, 0xFF, 0x7E, 0x00};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data26[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_TIME - VLD_MIN_TIME
	// Min
	myProf->SetValue(S_TIME,(float)0, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data27[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data28[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data29[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// E_STATE - VLD_REPORT_MEASUREMENT
	// Query temperature - 0
	myProf->SetValue(E_STATE,(uint8_t)0, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data30[] = {0x04, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],2),0);

	// Query illumination - 1
	myProf->SetValue(E_STATE,(uint8_t)1, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data31[] = {0x04, 0x20};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],2),0);

	// Query occupancy - 2
	myProf->SetValue(E_STATE,(uint8_t)2, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data32[] = {0x04, 0x40};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],2),0);

	// Query smoke - 2
	myProf->SetValue(E_STATE,(uint8_t)3, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data33[] = {0x04, 0x60};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],2),0);
}

TEST_F(profileD202xxTest,eepD20201ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	// E_STATE
	// No smoke - 0
	ParseRawDate({0x01, 0x60, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(0, u8GetValue);

	// Smoke ionization - 1
	ParseRawDate({0x01, 0x60, 0x00, 0x01},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(1, u8GetValue);

	// Smoke optical - 2
	ParseRawDate({0x01, 0x60, 0x00, 0x02},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(2, u8GetValue);

	// Smoke both - 3
	ParseRawDate({0x01, 0x60, 0x00, 0x03},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(3, u8GetValue);

	// S_TEMP
	// Min
	ParseRawDate({0x01, 0x00, 0x00, 0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x7F, 0xFF},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0xFF, 0xFF},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(120, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x01, 0x20, 0x00, 0x00},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x20, 0x7F, 0xFF},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1023, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x20, 0xFF, 0xFF},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(2047, fGetValue, 0.5);

	// F_ON_OFF - VLD_SELF_TEST
	// Off
	ParseRawDate({0x02, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_SELF_TEST);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_SELF_TEST);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_TRIGGER_ALARM
	// Off
	ParseRawDate({0x02, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_TRIGGER_ALARM);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x40},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_TRIGGER_ALARM);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x03, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(-40.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0xF0, 0x7F, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0xF0, 0xFF, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(120, fGetValue, 0.5);

	// S_LUMINANCE_ABS
	// Min
	ParseRawDate({0x03, 0x00, 0x01, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0xF1, 0x7F, 0x00, 0x00},6);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_NEAR(1023, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0xF1, 0xFF, 0x00, 0x00},6);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_NEAR(2047, fGetValue, 0.5);

	// S_TIME - VLD_MAX_TIME
	// Min
	ParseRawDate({0x03, 0x00, 0x01, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(1280, fGetValue, 5);

	// Max
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(2550, fGetValue, 5);

	// S_TIME - VLD_MAX_TIME
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// E_STATE
	// Query temperature - 0
	ParseRawDate({0x04, 0x00},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(0, u8GetValue);

	// Query illumination - 1
	ParseRawDate({0x04, 0x20},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(1, u8GetValue);

	// Query occupancy - 2
	ParseRawDate({0x04, 0x40},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(2, u8GetValue);

	// Query smoke - 3
	ParseRawDate({0x04, 0x60},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileD202xxTest,eepD20201ControllerSendData)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// S_TEMP
	// Min
	myProf->SetValue(S_TEMP,(float)-40);
	myProf->Create(*msg);
	uint8_t data0[] = {0x01, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x7F, 0xFF};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TEMP,(float)120);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_LUMINANCE,(float)1023);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x20, 0x7F, 0xEF};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_LUMINANCE,(float)2047);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x20, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// E_STATE - VLD_SMOKE_DETECTION
	// No smoke - 0
	myProf->SetValue(E_STATE,(uint8_t)0, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x60, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Ionization smoke - 1
	myProf->SetValue(E_STATE,(uint8_t)1, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x60, 0x00, 0x01};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Optical smoke - 2
	myProf->SetValue(E_STATE,(uint8_t)2, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x60, 0x00, 0x02};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Both - 3
	myProf->SetValue(E_STATE,(uint8_t)3, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x60, 0x00, 0x03};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - VLD_SELF_TEST
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_SELF_TEST);
	myProf->Create(*msg);
	uint8_t data12[] = {0x02, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_SELF_TEST);
	myProf->Create(*msg);
	uint8_t data13[] = {0x02, 0x80};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],2),0);

	// F_ON_OFF - VLD_TRIGGER_ALARM
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_TRIGGER_ALARM);
	myProf->Create(*msg);
	uint8_t data14[] = {0x02, 0x80};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_TRIGGER_ALARM);
	myProf->Create(*msg);
	uint8_t data15[] = {0x02, 0xC0};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x03);

	// F_ON_OFF - VLD_REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data16[] = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data17[] = {0x03, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],6),0);

	// S_TEMP_ABS
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x03, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data19[] = {0x03, 0x80, 0xF0, 0x7F, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)120);
	myProf->Create(*msg);
	uint8_t data20[] = {0x03, 0x80, 0xF0, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_LUMINANCE_ABS
	// Min
	myProf->SetValue(S_LUMINANCE_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data21[] = {0x03, 0x80, 0x01, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_LUMINANCE_ABS,(float)1023);
	myProf->Create(*msg);
	uint8_t data22[] = {0x03, 0x80, 0xE1, 0x7F, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_LUMINANCE_ABS,(float)2047);
	myProf->Create(*msg);
	uint8_t data23[] = {0x03, 0x80, 0xF1, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_TIME - VLD_MAX_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data24[] = {0x03, 0x80, 0xF1, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1275, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data25[] = {0x03, 0x80, 0xF1, 0xFF, 0x7E, 0x00};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data26[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_TIME - VLD_MIN_TIME
	// Min
	myProf->SetValue(S_TIME,(float)0, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data27[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data28[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data29[] = {0x03, 0x80, 0xF1, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// E_STATE - VLD_REPORT_MEASUREMENT
	// Query temperature - 0
	myProf->SetValue(E_STATE,(uint8_t)0, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data30[] = {0x04, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],2),0);

	// Query illumination - 1
	myProf->SetValue(E_STATE,(uint8_t)1, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data31[] = {0x04, 0x20};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],2),0);

	// Query occupancy - 2
	myProf->SetValue(E_STATE,(uint8_t)2, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data32[] = {0x04, 0x40};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],2),0);

	// Query smoke - 2
	myProf->SetValue(E_STATE,(uint8_t)3, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data33[] = {0x04, 0x60};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],2),0);
}

TEST_F(profileD202xxTest,eepD20202ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	// E_STATE
	// No smoke - 0
	ParseRawDate({0x01, 0x60, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(0, u8GetValue);

	// Smoke ionization - 1
	ParseRawDate({0x01, 0x60, 0x00, 0x01},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(1, u8GetValue);

	// Smoke optical - 2
	ParseRawDate({0x01, 0x60, 0x00, 0x02},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(2, u8GetValue);

	// Smoke both - 3
	ParseRawDate({0x01, 0x60, 0x00, 0x03},4);
	myProf->GetValue(E_STATE, u8GetValue, VLD_SMOKE_DETECTION);
	EXPECT_EQ(3, u8GetValue);

	// S_TEMP
	// Min
	ParseRawDate({0x01, 0x00, 0x00, 0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x7F, 0xFF},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0xFF, 0xFF},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(120, fGetValue, 0.5);

	// F_ON_OFF - VLD_SELF_TEST
	// Off
	ParseRawDate({0x02, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_SELF_TEST);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_SELF_TEST);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_TRIGGER_ALARM
	// Off
	ParseRawDate({0x02, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_TRIGGER_ALARM);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x40},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_TRIGGER_ALARM);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - VLD_REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x03, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, VLD_REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(-40.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0xF0, 0x7F, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0xF0, 0xFF, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(120, fGetValue, 0.5);

	// S_TIME - VLD_MAX_TIME
	// Min
	ParseRawDate({0x03, 0x00, 0x01, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(1280, fGetValue, 5);

	// Max
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MAX_TIME);
	EXPECT_NEAR(2550, fGetValue, 5);

	// S_TIME - VLD_MAX_TIME
	// Min
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, VLD_MIN_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// E_STATE
	// Query temperature - 0
	ParseRawDate({0x04, 0x00},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(0, u8GetValue);

	// Query illumination - 1
	ParseRawDate({0x04, 0x20},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(1, u8GetValue);

	// Query occupancy - 2
	ParseRawDate({0x04, 0x40},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(2, u8GetValue);

	// Query smoke - 3
	ParseRawDate({0x04, 0x60},2);
	myProf->GetValue(E_STATE, u8GetValue, VLD_QUERY);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileD202xxTest,eepD20202ControllerSendData)
{
	// Setup the test
	Init(0x02);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// S_TEMP
	// Min
	myProf->SetValue(S_TEMP,(float)-40);
	myProf->Create(*msg);
	uint8_t data0[] = {0x01, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x7F, 0xFF};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TEMP,(float)120);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// E_STATE - VLD_SMOKE_DETECTION
	// No smoke - 0
	myProf->SetValue(E_STATE,(uint8_t)0, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x60, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Ionization smoke - 1
	myProf->SetValue(E_STATE,(uint8_t)1, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x60, 0x00, 0x01};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Optical smoke - 2
	myProf->SetValue(E_STATE,(uint8_t)2, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x60, 0x00, 0x02};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Both - 3
	myProf->SetValue(E_STATE,(uint8_t)3, VLD_SMOKE_DETECTION);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x60, 0x00, 0x03};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - VLD_SELF_TEST
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_SELF_TEST);
	myProf->Create(*msg);
	uint8_t data12[] = {0x02, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_SELF_TEST);
	myProf->Create(*msg);
	uint8_t data13[] = {0x02, 0x80};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],2),0);

	// F_ON_OFF - VLD_TRIGGER_ALARM
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_TRIGGER_ALARM);
	myProf->Create(*msg);
	uint8_t data14[] = {0x02, 0x80};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_TRIGGER_ALARM);
	myProf->Create(*msg);
	uint8_t data15[] = {0x02, 0xC0};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x03);

	// F_ON_OFF - VLD_REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, VLD_REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data16[] = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, VLD_REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data17[] = {0x03, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],6),0);

	// S_TEMP_ABS
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x03, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data19[] = {0x03, 0x80, 0xF0, 0x7F, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)120);
	myProf->Create(*msg);
	uint8_t data20[] = {0x03, 0x80, 0xF0, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_TIME - VLD_MAX_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data24[] = {0x03, 0x80, 0xF0, 0xFF, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1275, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data25[] = {0x03, 0x80, 0xF0, 0xFF, 0x7E, 0x00};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, VLD_MAX_TIME);
	myProf->Create(*msg);
	uint8_t data26[] = {0x03, 0x80, 0xF0, 0xFF, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_TIME - VLD_MIN_TIME
	// Min
	myProf->SetValue(S_TIME,(float)0, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data27[] = {0x03, 0x80, 0xF0, 0xFF, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data28[] = {0x03, 0x80, 0xF0, 0xFF, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, VLD_MIN_TIME);
	myProf->Create(*msg);
	uint8_t data29[] = {0x03, 0x80, 0xF0, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// E_STATE - VLD_REPORT_MEASUREMENT
	// Query temperature - 0
	myProf->SetValue(E_STATE,(uint8_t)0, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data30[] = {0x04, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],2),0);

	// Query illumination - 1
	myProf->SetValue(E_STATE,(uint8_t)1, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data31[] = {0x04, 0x20};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],2),0);

	// Query occupancy - 2
	myProf->SetValue(E_STATE,(uint8_t)2, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data32[] = {0x04, 0x40};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],2),0);

	// Query smoke - 2
	myProf->SetValue(E_STATE,(uint8_t)3, VLD_QUERY);
	myProf->Create(*msg);
	uint8_t data33[] = {0x04, 0x60};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],2),0);
}
