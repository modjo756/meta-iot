/*
 * deviceTest.cpp
 *
 *  Created on: 27.06.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include <string.h>
#include "eoLink.h"
TEST(eoDeviceManager, DeviceCreation)
{
	eoDevice *myDev;
	uint32_t id;
	eoDeviceManager myDeviceManager = eoDeviceManager();
	for(id=0;id<0x0000FFFF;id++)
	{
		myDev=myDeviceManager.Add(id);
		EXPECT_EQ(myDev->ID,id);
	}
	EXPECT_EQ(myDeviceManager.Size(),(uint32_t)0x0000FFFF);
	id=0xFFFFFFFF;
	myDev=myDeviceManager.Add(id);
	EXPECT_EQ(myDev->ID,id);
}

TEST(eoDeviceManager, getDevice)
{
	eoDevice *myDev;
	uint32_t id;
	eoDeviceManager myDeviceManager = eoDeviceManager();
	//Getting empty Device
	id=42;
	myDev=myDeviceManager.Get(id);
	EXPECT_TRUE(myDev == NULL);
	myDev=myDeviceManager.Add(id);
	EXPECT_TRUE(myDev != NULL);
}

TEST(eoDeviceManager, removeDevice)
{
	eoDevice *myDev;
	uint32_t id;
	eoDeviceManager myDeviceManager = eoDeviceManager();
	//Getting empty Device
	id=42;
	myDev=myDeviceManager.Add(id);
	EXPECT_TRUE(myDev != NULL);
	myDeviceManager.Remove(id);
	myDev=myDeviceManager.Get(id);
	EXPECT_TRUE(myDev == NULL);
}
