/*
 * profileFixture.h
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#ifndef GATEWAYFIXTURE_H_
#define GATEWAYFIXTURE_H_

#include <gtest/gtest.h>
#include "eoLink.h"

class GatewayFixture: public eoGateway {

public:
	virtual eoReturn Send(const eoReManMessage &reMsg,bool shallBeRepeated);

	virtual eoReturn Send(const eoPacket &p);
};

#endif /* PROFILEFIXTURE_H_ */
