/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>
#include "GatewayFixture.h"
//

TEST(eoProfile,RLCStore)
{
	uint32_t rlc;
	uint8_t ret;

	eoRollingCodeStorage storage;

	storage.SetRLC (0x12345678, 0x87654321);
	storage.SetRLC (0x12345678, 0x87654322);
	storage.SetRLC (0x12345678, 0x87654323);
	storage.SetRLC (0x12345678, 0x87654324);

	storage.SetRLC (0x12345677, 0x87654322);
	storage.SetRLC (0x12345676, 0x87654323);
	storage.SetRLC (0x12345675, 0x87654324);
	storage.SetRLC (0x11111111, 0x00000000);
	storage.SetRLC (0x12222222, 0x11111112);
	storage.SetRLC (0x12333333, 0x22222222);

	ret = storage.GetRLC (0x12345678, rlc);
	EXPECT_EQ(ret, EO_OK);
	EXPECT_EQ(rlc, 0x87654324);

	ret = storage.RemoveID (0x12345676);
	EXPECT_EQ(ret, EO_OK);

	ret = storage.GetRLC (0x12345676, rlc);
	EXPECT_EQ(ret, NOT_SUPPORTED);

	ret = storage.Save("test.bin");
	EXPECT_EQ(ret, EO_OK);

	storage.Load("test.bin");
	EXPECT_EQ(ret, EO_OK);

	ret = storage.GetRLC (0x12345678, rlc);
	EXPECT_EQ(ret, EO_OK);
	EXPECT_EQ(rlc, 0x87654324);
}
