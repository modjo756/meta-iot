/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>

TEST(eoProfile,eepF61000)
{
	eoProfile* myProf= eoProfileFactory::CreateProfile(0xF6,0x10,0x00);
	eoMessage *msg = new eoMessage(1);
	msg->RORG=RORG_RPS;
	uint8_t rocker1, ret;
	//NR1
	msg->data[0]=0xE7;
	msg->status=0x03;

	myProf->Parse(*msg);
	myProf->GetValue(E_WINDOWHANDLE,rocker1);
	EXPECT_EQ(rocker1,0x01);

	uint8_t data = 0xE0;

	ret = myProf->SetValue(E_WINDOWHANDLE, (uint8_t)1);
	EXPECT_EQ(ret, EO_OK);

	myProf->Create(*msg);
	EXPECT_EQ(msg->data[0], data);
	delete msg;
}
