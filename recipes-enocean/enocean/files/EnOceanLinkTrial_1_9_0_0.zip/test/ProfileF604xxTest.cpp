/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>


TEST(eoProfile,eepF60401)
{
	eoProfile* myProf= eoProfileFactory::CreateProfile(0xF6,0x04,0x01);
	eoMessage *msg = new eoMessage(1);
	uint8_t rocker1;
	//NR1
	msg->RORG=RORG_RPS;
	msg->data[0]=0x70;
	msg->status=0x03;

	myProf->Parse(*msg);
	myProf->GetValue(F_ON_OFF,rocker1);
	EXPECT_EQ(rocker1,1);

	//NR2
	msg->data[0]=0x00;
	msg->status=0x02;

	myProf->Parse(*msg);
	myProf->GetValue(F_ON_OFF,rocker1);
	EXPECT_EQ(rocker1,0);

	rocker1 = myProf->SetValue(F_ON_OFF, (uint8_t)1);
	EXPECT_EQ(rocker1, EO_OK);

	uint8_t data0 = 0x70;
	myProf->Create(*msg);
	EXPECT_EQ(msg->data[0], data0);
	delete myProf;
	delete msg;
}
