/*
 * ProfileD202Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
class profileD240xxTest : public ProfileFixture
{
public:
	void Init(uint8_t type)
	{
		msg = new eoMessage(5);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x40, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};
TEST_F(profileD240xxTest,eepD24000)
{
	uint8_t ret, getValue2;
	float getValue;

	Init(0x00);

	uint8_t data0[] = {0xB4, 0x96};
	memcpy(msg->data, data0, 2);

	msg->RORG=0xD2;
	msg->dataLength=2;

	myProf->Parse(*msg);

	//NR1
	ret = myProf->GetValue(F_ON_OFF, getValue2, DRIVING_LED);
	EXPECT_EQ(getValue2, DRIVING_ENABLED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,RESPONSE_MODE);
	EXPECT_EQ(getValue2, D240_FALSE);
	ret = myProf->GetValue(F_ON_OFF, getValue2,DAYLIGH_HARVEST);
	EXPECT_EQ(getValue2, D240_TRUE);
	ret = myProf->GetValue(E_OCCUPANCY, getValue2);
	EXPECT_EQ(getValue2, D240_UNKNOWN);
	ret = myProf->GetValue(F_ON_OFF, getValue2,STATUS_REASON);
	EXPECT_EQ(getValue2, HEARTBEAT);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_MONO);
	EXPECT_NEAR(getValue, 75, 2);

	//NR2
	uint8_t data1[] = {0x40, 0x00};
	memcpy(msg->data, data1, 2);
	myProf->Parse(*msg);

	ret = myProf->GetValue(F_ON_OFF, getValue2, DRIVING_LED);
	EXPECT_EQ(getValue2, DRIVING_DISABLED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,RESPONSE_MODE);
	EXPECT_EQ(getValue2, D240_TRUE);
	ret = myProf->GetValue(F_ON_OFF, getValue2,DAYLIGH_HARVEST);
	EXPECT_EQ(getValue2, D240_FALSE);
	ret = myProf->GetValue(E_OCCUPANCY, getValue2);
	EXPECT_EQ(getValue2, D240_NOT_OCCUPIED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,STATUS_REASON);
	EXPECT_EQ(getValue2, OTHER_REASON);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_MONO);
	EXPECT_NEAR(getValue, 0, 2);

	//NR3
	uint8_t data2[] = {0xEC, 0xC8};
	memcpy(msg->data, data2, 2);
	myProf->Parse(*msg);

	ret = myProf->GetValue(F_ON_OFF, getValue2, DRIVING_LED);
	EXPECT_EQ(getValue2, DRIVING_ENABLED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,RESPONSE_MODE);
	EXPECT_EQ(getValue2, D240_TRUE);
	ret = myProf->GetValue(F_ON_OFF, getValue2,DAYLIGH_HARVEST);
	EXPECT_EQ(getValue2, D240_TRUE);
	ret = myProf->GetValue(E_OCCUPANCY, getValue2);
	EXPECT_EQ(getValue2, D240_OCCUPIED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,STATUS_REASON);
	EXPECT_EQ(getValue2, HEARTBEAT);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_MONO);
	EXPECT_NEAR(getValue, 100, 2);

	// Negative tests
	ret = myProf->GetValue(S_PERCENTAGE,getValue,DIM_LEVEL_BLUE);
	EXPECT_EQ(ret, NOT_SUPPORTED);
	ret = myProf->GetValue(S_PERCENTAGE,getValue,DIM_LEVEL_RED);
	EXPECT_EQ(ret, NOT_SUPPORTED);
	ret = myProf->GetValue(S_PERCENTAGE,getValue,DIM_LEVEL_GREEN);
	EXPECT_EQ(ret, NOT_SUPPORTED);
}

TEST_F(profileD240xxTest,eepD24001)
{
	uint8_t ret, getValue2;
	float getValue;

	Init(0x01);
	uint8_t data0[] = {0xF5, 0x00, 0x00, 0x00};
	memcpy(msg->data, data0, 4);

	msg->RORG=0xD2;
	msg->dataLength=4;

	myProf->Parse(*msg);

	//NR1
	ret = myProf->GetValue(F_ON_OFF, getValue2, DRIVING_LED);
	EXPECT_EQ(getValue2, DRIVING_ENABLED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,RESPONSE_MODE);
	EXPECT_EQ(getValue2, D240_TRUE);
	ret = myProf->GetValue(F_ON_OFF, getValue2,DAYLIGH_HARVEST);
	EXPECT_EQ(getValue2, D240_TRUE);
	ret = myProf->GetValue(E_OCCUPANCY, getValue2);
	EXPECT_EQ(getValue2, D240_UNKNOWN);
	ret = myProf->GetValue(F_ON_OFF, getValue2,STATUS_REASON);
	EXPECT_EQ(getValue2, HEARTBEAT);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_RED);
	EXPECT_NEAR(getValue, 0, 2);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_GREEN);
	EXPECT_NEAR(getValue, 0, 2);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_BLUE);
	EXPECT_NEAR(getValue, 0, 2);

	//NR2
	uint8_t data1[] = {0x01, 0xC8, 0xC8, 0xC8};
	memcpy(msg->data, data1, 4);
	myProf->Parse(*msg);

	ret = myProf->GetValue(F_ON_OFF, getValue2, DRIVING_LED);
	EXPECT_EQ(getValue2, DRIVING_DISABLED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,RESPONSE_MODE);
	EXPECT_EQ(getValue2, D240_FALSE);
	ret = myProf->GetValue(F_ON_OFF, getValue2,DAYLIGH_HARVEST);
	EXPECT_EQ(getValue2, D240_FALSE);
	ret = myProf->GetValue(E_OCCUPANCY, getValue2);
	EXPECT_EQ(getValue2, D240_NOT_OCCUPIED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,STATUS_REASON);
	EXPECT_EQ(getValue2, OTHER_REASON);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_RED);
	EXPECT_NEAR(getValue, 100, 2);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_GREEN);
	EXPECT_NEAR(getValue, 100, 2);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_BLUE);
	EXPECT_NEAR(getValue, 100, 2);

	//NR3
	uint8_t data2[] = {0x01, 0x96, 0x96, 0x96};
	memcpy(msg->data, data2, 4);
	myProf->Parse(*msg);

	ret = myProf->GetValue(F_ON_OFF, getValue2, DRIVING_LED);
	EXPECT_EQ(getValue2, DRIVING_DISABLED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,RESPONSE_MODE);
	EXPECT_EQ(getValue2, D240_FALSE);
	ret = myProf->GetValue(F_ON_OFF, getValue2,DAYLIGH_HARVEST);
	EXPECT_EQ(getValue2, D240_FALSE);
	ret = myProf->GetValue(E_OCCUPANCY, getValue2);
	EXPECT_EQ(getValue2, D240_NOT_OCCUPIED);
	ret = myProf->GetValue(F_ON_OFF, getValue2,STATUS_REASON);
	EXPECT_EQ(getValue2, OTHER_REASON);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_RED);
	EXPECT_NEAR(getValue, 75, 2);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_GREEN);
	EXPECT_NEAR(getValue, 75, 2);
	ret = myProf->GetValue(S_PERCENTAGE, getValue,DIM_LEVEL_BLUE);
	EXPECT_NEAR(getValue, 75, 2);

	// Negative tests
	ret = myProf->GetValue(S_PERCENTAGE,getValue,DIM_LEVEL_MONO);
	EXPECT_EQ(ret, NOT_SUPPORTED);
}
