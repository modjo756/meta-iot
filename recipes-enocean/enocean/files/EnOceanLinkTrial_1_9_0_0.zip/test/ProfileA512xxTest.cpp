/*
 * ProfileA512Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA512xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x12, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};

TEST_F(profileA512xxTest,eepA51200ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x00);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_COUNTER));
	EXPECT_TRUE(ChannelExist(S_VOLUME));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_COUNTER - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_COUNTER - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_COUNTER - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_COUNTER - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// S_VOLUME - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_VOLUME - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0D},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_VOLUME - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0E},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_VOLUME - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(4, u8GetValue, 5);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(5, u8GetValue, 5);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(7, u8GetValue, 5);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(8, u8GetValue, 5);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x00, 0x98},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x00, 0xA8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(10, u8GetValue, 5);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x00, 0xB8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(11, u8GetValue, 5);

	// Enum - 12
	ParseRawDate({0x00, 0x00, 0x00, 0xC8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// Enum - 13
	ParseRawDate({0x00, 0x00, 0x00, 0xD8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(13, u8GetValue, 5);

	// Enum - 14
	ParseRawDate({0x00, 0x00, 0x00, 0xE8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(14, u8GetValue, 5);

	// Enum - 15
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(15, u8GetValue, 5);
}

TEST_F(profileA512xxTest,eepA51200ControllerSendData)
{
	// Setup the test
	Init(0x00);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_COUNTER));
	EXPECT_TRUE(ChannelExist(S_VOLUME));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_COUNTER - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)820.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x0C, 0x83, 0x20, 0x0B};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)16800.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x19, 0xA2, 0x80, 0x0A};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)167780.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x19, 0x99, 0xE8, 0x09};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)1677730.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x19, 0x99, 0xA2, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0xFF, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_VOLUME - /1
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)820.0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x0C, 0x83, 0x20, 0x0F};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)16800.0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x19, 0xA2, 0x80, 0x0E};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)167780.0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x19, 0x99, 0xE8, 0x0D};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)1677730.0);
	myProf->Create(*msg);
	uint8_t data11[] = {0x19, 0x99, 0xA2, 0x0C};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFF, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);


	// E_TARIFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t dataE7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&dataE7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t dataE8[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&dataE8[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t dataE9[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&dataE9[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t dataE10[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&dataE10[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t dataE11[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&dataE11[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t dataE12[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&dataE12[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t dataE13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&dataE13[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t dataE14[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&dataE14[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t dataE15[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&dataE15[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t dataE16[] = {0x00, 0x00, 0x00, 0x98};
	EXPECT_EQ(memcmp(&dataE16[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t dataE17[] = {0x00, 0x00, 0x00, 0xA8};
	EXPECT_EQ(memcmp(&dataE17[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t dataE18[] = {0x00, 0x00, 0x00, 0xB8};
	EXPECT_EQ(memcmp(&dataE18[0],&msg->data[0],4),0);

	// Enum - 12
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t dataE19[] = {0x00, 0x00, 0x00, 0xC8};
	EXPECT_EQ(memcmp(&dataE19[0],&msg->data[0],4),0);

	// Enum - 13
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t dataE20[] = {0x00, 0x00, 0x00, 0xD8};
	EXPECT_EQ(memcmp(&dataE20[0],&msg->data[0],4),0);

	// Enum - 14
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t dataE21[] = {0x00, 0x00, 0x00, 0xE8};
	EXPECT_EQ(memcmp(&dataE21[0],&msg->data[0],4),0);

	// Enum - 15
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t dataE22[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&dataE22[0],&msg->data[0],4),0);
}

TEST_F(profileA512xxTest,eepA51201ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ENERGY));
	EXPECT_TRUE(ChannelExist(S_POWER));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_COUNTER - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_COUNTER - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_COUNTER - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_COUNTER - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_ENERGY, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// S_VOLUME - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_VOLUME - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0D},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_VOLUME - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0E},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_VOLUME - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_POWER, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(4, u8GetValue, 5);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(5, u8GetValue, 5);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(7, u8GetValue, 5);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(8, u8GetValue, 5);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x00, 0x98},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x00, 0xA8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(10, u8GetValue, 5);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x00, 0xB8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(11, u8GetValue, 5);

	// Enum - 12
	ParseRawDate({0x00, 0x00, 0x00, 0xC8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// Enum - 13
	ParseRawDate({0x00, 0x00, 0x00, 0xD8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(13, u8GetValue, 5);

	// Enum - 14
	ParseRawDate({0x00, 0x00, 0x00, 0xE8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(14, u8GetValue, 5);

	// Enum - 15
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(15, u8GetValue, 5);
}

TEST_F(profileA512xxTest,eepA51201ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ENERGY));
	EXPECT_TRUE(ChannelExist(S_POWER));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_ENERGY - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ENERGY,(float)0.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ENERGY,(float)8388607.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ENERGY,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_ENERGY - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ENERGY,(float)0.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ENERGY,(float)838860.5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x7F, 0xFF, 0xFD, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_POWER - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_POWER,(float)0.0);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_POWER,(float)8388607.0);
	myProf->Create(*msg);
	uint8_t data24[] = {0x7F, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_POWER,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data25[] = {0xFF, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// S_POWER - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_POWER,(float)0);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_POWER,(float)838860.5);
	myProf->Create(*msg);
	uint8_t data27[] = {0x7F, 0xFF, 0xFD, 0x0D};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_POWER,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data28[] = {0xFF, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// E_TARIFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x98};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0xA8};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0xB8};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 12
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0xC8};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 13
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0xD8};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 14
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x00, 0xE8};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 15
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);
}

TEST_F(profileA512xxTest,eepA51202ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLFLOW));
	EXPECT_TRUE(ChannelExist(S_VOLUME));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_COUNTER - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_COUNTER - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_COUNTER - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0E},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_COUNTER - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// S_VOLUME - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_VOLUME - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_VOLUME - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_VOLUME - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(4, u8GetValue, 5);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(5, u8GetValue, 5);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(7, u8GetValue, 5);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(8, u8GetValue, 5);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x00, 0x98},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x00, 0xA8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(10, u8GetValue, 5);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x00, 0xB8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(11, u8GetValue, 5);

	// Enum - 12
	ParseRawDate({0x00, 0x00, 0x00, 0xC8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// Enum - 13
	ParseRawDate({0x00, 0x00, 0x00, 0xD8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(13, u8GetValue, 5);

	// Enum - 14
	ParseRawDate({0x00, 0x00, 0x00, 0xE8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(14, u8GetValue, 5);

	// Enum - 15
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(15, u8GetValue, 5);
}

TEST_F(profileA512xxTest,eepA51202ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLFLOW));
	EXPECT_TRUE(ChannelExist(S_VOLUME));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_VOLUME - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)8388607.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_VOLUME - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)838860.5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x7F, 0xFF, 0xFD, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_VOLFLOW - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)0);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)8388.607);
	myProf->Create(*msg);
	uint8_t data24[] = {0x7F, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)16777.215);
	myProf->Create(*msg);
	uint8_t data25[] = {0xFF, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// S_VOLFLOW - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)0);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)838.8605);
	myProf->Create(*msg);
	uint8_t data27[] = {0x7F, 0xFF, 0xFD, 0x0D};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)1677.7215);
	myProf->Create(*msg);
	uint8_t data28[] = {0x19, 0x99, 0x99, 0x0C};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// E_TARIFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x98};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0xA8};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0xB8};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 12
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0xC8};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 13
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0xD8};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 14
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x00, 0xE8};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 15
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);
}

TEST_F(profileA512xxTest,eepA51203ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLFLOW));
	EXPECT_TRUE(ChannelExist(S_VOLUME));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_VOLUME - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_VOLUME - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_VOLUME - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_VOLUME - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_VOLUME, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// S_VOLFLOW - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_VOLFLOW - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0D},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_VOLFLOW - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0E},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_VOLFLOW - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_VOLFLOW, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(4, u8GetValue, 5);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(5, u8GetValue, 5);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(7, u8GetValue, 5);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(8, u8GetValue, 5);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x00, 0x98},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x00, 0xA8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(10, u8GetValue, 5);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x00, 0xB8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(11, u8GetValue, 5);

	// Enum - 12
	ParseRawDate({0x00, 0x00, 0x00, 0xC8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// Enum - 13
	ParseRawDate({0x00, 0x00, 0x00, 0xD8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(13, u8GetValue, 5);

	// Enum - 14
	ParseRawDate({0x00, 0x00, 0x00, 0xE8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(14, u8GetValue, 5);

	// Enum - 15
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(15, u8GetValue, 5);
}

TEST_F(profileA512xxTest,eepA51203ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLFLOW));
	EXPECT_TRUE(ChannelExist(S_VOLUME));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_VOLUME - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)8388607.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_VOLUME - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLUME,(float)838860.5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x7F, 0xFF, 0xFD, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_VOLFLOW - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)0);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)8388.607);
	myProf->Create(*msg);
	uint8_t data24[] = {0x7F, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)16777.215);
	myProf->Create(*msg);
	uint8_t data25[] = {0xFF, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// S_VOLFLOW - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)0);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)83.88605);
	myProf->Create(*msg);
	uint8_t data27[] = {0x7F, 0xFF, 0xFC, 0x0E};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLFLOW,(float)167.77215);
	myProf->Create(*msg);
	uint8_t data28[] = {0x19, 0x99, 0x99, 0x0d};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// E_TARIFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x98};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0xA8};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0xB8};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 12
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0xC8};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 13
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0xD8};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 14
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x00, 0xE8};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 15
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);
}

TEST_F(profileA512xxTest,eepA51204ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_MASS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_STATE));

	// S_MASS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_MASS, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFC, 0x00, 0x08},4);
	myProf->GetValue(S_MASS, fGetValue);
	EXPECT_NEAR(8.191, fGetValue, 1);

	// Max value
	ParseRawDate({0xFF, 0xFC, 0x00, 0x08},4);
	myProf->GetValue(S_MASS, fGetValue);
	EXPECT_NEAR(16.383, fGetValue, 5);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x09},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x09},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 0.5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileA512xxTest,eepA51204ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_MASS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_STATE));

	// S_MASS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_MASS,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_MASS,(float)8.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_MASS,(float)16.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// E_STATE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);
}

TEST_F(profileA512xxTest,eepA51205ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_STATE));

	// F_ON_OFF - POSITION_LOCATION_0
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_0);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_0);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_1
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_1);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x40, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_1);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_2
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_2);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x20, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_2);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_3
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_3);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x10, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_3);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_4
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_4);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x08, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_4);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_5
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_5);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x04, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_5);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_6
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_6);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_6);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_7
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_7);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_7);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_8
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_8);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x80, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_8);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - POSITION_LOCATION_9
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_9);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x40, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, POSITION_LOCATION_9);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x09},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x09},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 0.5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileA512xxTest,eepA51205ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_STATE));

	// F_ON_OFF - POSITION_LOCATION_0
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x80, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_1
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_1);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x40, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_2
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_2);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_2);
	myProf->Create(*msg);
	uint8_t data6[] = {0x20, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_3
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_3);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_3);
	myProf->Create(*msg);
	uint8_t data8[] = {0x10, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_4
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_4);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_4);
	myProf->Create(*msg);
	uint8_t data10[] = {0x08, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_5
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_5);
	myProf->Create(*msg);
	uint8_t data12[] = {0x04, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_6
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_6);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_6);
	myProf->Create(*msg);
	uint8_t data14[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_7
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_7);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_7);
	myProf->Create(*msg);
	uint8_t data16[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_8
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_8);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_8);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// F_ON_OFF - POSITION_LOCATION_9
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, POSITION_LOCATION_9);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, POSITION_LOCATION_9);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x40, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// E_STATE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data24[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data25[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data27[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);
}

TEST_F(profileA512xxTest,eepA51210ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_AMPER_PER_HOUR));
	EXPECT_TRUE(ChannelExist(S_CURRENT));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_AMPER_PER_HOUR - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_AMPER_PER_HOUR - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x09},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_AMPER_PER_HOUR - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0A},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_AMPER_PER_HOUR - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0B},4);
	myProf->GetValue(S_AMPER_PER_HOUR, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// S_CURRENT - /1
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(8388607.0, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0C},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(16777215.0, fGetValue, 5);

	// S_CURRENT - /10
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0D},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(838860.7, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0D},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(1677721.5, fGetValue, 5);

	// S_CURRENT - /100
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0E},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(83886.07, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0E},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(167772.15, fGetValue, 5);

	// S_CURRENT - /1000
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(8388.607, fGetValue, 5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0xFF, 0x0F},4);
	myProf->GetValue(S_CURRENT, fGetValue);
	EXPECT_NEAR(16777.215, fGetValue, 5);

	// E_TARIFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(1, u8GetValue, 5);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(2, u8GetValue, 5);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(4, u8GetValue, 5);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(5, u8GetValue, 5);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(7, u8GetValue, 5);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(8, u8GetValue, 5);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x00, 0x98},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x00, 0xA8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(10, u8GetValue, 5);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x00, 0xB8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(11, u8GetValue, 5);

	// Enum - 12
	ParseRawDate({0x00, 0x00, 0x00, 0xC8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// Enum - 13
	ParseRawDate({0x00, 0x00, 0x00, 0xD8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(13, u8GetValue, 5);

	// Enum - 14
	ParseRawDate({0x00, 0x00, 0x00, 0xE8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(14, u8GetValue, 5);

	// Enum - 15
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(E_TARIFF, u8GetValue);
	EXPECT_NEAR(15, u8GetValue, 5);
}

TEST_F(profileA512xxTest,eepA51210ControllerSendData)
{
	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_AMPER_PER_HOUR));
	EXPECT_TRUE(ChannelExist(S_CURRENT));
	EXPECT_TRUE(ChannelExist(E_TARIFF));

	// S_AMPER_PER_HOUR - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_AMPER_PER_HOUR,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_AMPER_PER_HOUR,(float)8388607.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_AMPER_PER_HOUR,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_AMPER_PER_HOUR - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_AMPER_PER_HOUR,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_AMPER_PER_HOUR,(float)838860.5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x7F, 0xFF, 0xFD, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_AMPER_PER_HOUR,(float)1677721.5);
	myProf->Create(*msg);
	uint8_t data6[] = {0x19, 0x99, 0x99, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_CURRENT - /1
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_CURRENT,(float)0);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_CURRENT,(float)8388607.0);
	myProf->Create(*msg);
	uint8_t data24[] = {0x7F, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_CURRENT,(float)16777215.0);
	myProf->Create(*msg);
	uint8_t data25[] = {0xFF, 0xFF, 0xFF, 0x0C};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// S_CURRENT - /10
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_CURRENT,(float)0);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x00, 0x0F};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_CURRENT,(float)838860.5);
	myProf->Create(*msg);
	uint8_t data27[] = {0x7F, 0xFF, 0xFD, 0x0D};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_CURRENT,(float)1677721.5);
	myProf->Create(*msg);
	uint8_t data28[] = {0x19, 0x99, 0x99, 0x0C};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// E_TARIFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x98};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0xA8};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0xB8};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 12
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0xC8};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 13
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0xD8};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 14
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x00, 0xE8};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 15
	myProf->ClearValues();
	myProf->SetValue(E_TARIFF,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);
}
