/*
 * ChainedTelegramGenerator.h
 *
 *  Created on: Dec 18, 2012
 *      Author: marco
 */

#include <Includes/eoTelegram.h>
#ifndef CHAINEDTELEGRAM_H_
#define CHAINEDTELEGRAM_H_

class ChainedTelegramGenerator
{
	public:
	uint8_t telCount;
	uint8_t telLength;
	uint8_t *payloadData;
	uint16_t payloadDataLength;

	std::vector<eoTelegram> telegrams;
	ChainedTelegramGenerator(uint16_t length,uint32_t sourceID);
	~ChainedTelegramGenerator();
};



#endif /* CHAINEDTELEGRAM_H_ */
