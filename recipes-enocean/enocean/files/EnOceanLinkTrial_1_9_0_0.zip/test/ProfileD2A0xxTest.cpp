/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Profiles/eoEEP_D2A0xx.h"
//Helper function for A5
class profileD2A0xxTest : public ProfileFixture
{
	/** */
	protected:
	bool OutChannelExist(CHANNEL_TYPE type)
	{
		eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)((eoEEP_D2A0xx*)myProf)->GetOutChannel(type);
		return(myChan!=NULL);
	}

	void Init(uint8_t type,SIMPLE_DIRECTION direction)
	{
		msg = new eoMessage(1);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0xA0, type);
		ASSERT_TRUE(myProf!=NULL);
		((eoEEP_D2A0xx*)myProf)->SetDirection(direction);
	}

};

TEST_F(profileD2A0xxTest,eepD2A001ControllerReceiveData)
{
	uint8_t u8GetValue;
	//Setup the test
	Init(0x01,eoController);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));

	//Enum tests - 0
	ParseRawDate({0x00},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	//Enum tests - 1
	ParseRawDate({0x01},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1,u8GetValue);
	//Enum tests - 2
	ParseRawDate({0x02},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2,u8GetValue);
	//Enum tests - 3
	ParseRawDate({0x03},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3,u8GetValue);


}

TEST_F(profileD2A0xxTest,eepDA201ControllerSendData)
{

	//Setup the test
	Init(0x01,eoController);
	//Check that all out channels exist
	EXPECT_TRUE(OutChannelExist(E_STATE));

	//Enums
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	//enum 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);

	//enum 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	EXPECT_EQ(0x02,msg->data[0]);

	//enum 3
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	EXPECT_EQ(0x03,msg->data[0]);
}

TEST_F(profileD2A0xxTest,eepD2A001ActuatorReceiveData)
{
	uint8_t u8GetValue;
	//Setup the test
	Init(0x01,eoActuator);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));

	//Enum tests - 0
	ParseRawDate({0x00},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	//Enum tests - 1
	ParseRawDate({0x01},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1,u8GetValue);
	//Enum tests - 2
	ParseRawDate({0x02},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2,u8GetValue);
	//Enum tests - 3
	ParseRawDate({0x03},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3,u8GetValue);


}

TEST_F(profileD2A0xxTest,eepDA201ActuatorSendData)
{

	//Setup the test
	Init(0x01,eoActuator);
	//Check that all out channels exist
	EXPECT_TRUE(OutChannelExist(E_STATE));

	//Enums
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	//enum 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);

	//enum 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	EXPECT_EQ(0x02,msg->data[0]);

	//enum 3
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	EXPECT_EQ(0x03,msg->data[0]);
}
