#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA508xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x08, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA508xxTest,eepA0801ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.55, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.1, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(255, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(510, fGetValue, 2);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(25.5, fGetValue, 1);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(51, fGetValue, 1);

	// F_OCCUPIED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_BTN_PRESS
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA508xxTest,eepA0801ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.55);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.1);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)255);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)510);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)25.5);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)51);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA508xxTest,eepA0802ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.55, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.1, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(510, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1020, fGetValue, 2);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(25.5, fGetValue, 1);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(51, fGetValue, 1);

	// F_OCCUPIED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_BTN_PRESS
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA508xxTest,eepA0802ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.55);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.1);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)510);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1020);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)25.5);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)51);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA508xxTest,eepA0803ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.55, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.1, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(765, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1530, fGetValue, 2);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(-30.0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(10.0, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 2);

	// F_OCCUPIED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_BTN_PRESS
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA508xxTest,eepA0803ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.55);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.1);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)765);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1530);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-30.0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}
