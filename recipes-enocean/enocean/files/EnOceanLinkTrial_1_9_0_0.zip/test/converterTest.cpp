#include <gtest/gtest.h>
#include <string.h>
#include "eoConverter.h"
#include "eoTelegramERP2.h"
#include "eoDebug.h"
TEST(converterTest,packetToRadio)
{
	uint8_t testData1[17] ={0xA5,0xAA,0xBB,0xCC,0xDD,0x12,0x34,0x56,0x78,0x00,0x03,0xFF,0xFF,0xFF,0xFF,0xFF,0x00};
	eoPacket testPacket(testData1,17);
	testPacket.type=PACKET_RADIO;
	testPacket.dataLength=10;
	testPacket.optionalLength=7;
	eoTelegram testTelegram(4);
	EXPECT_EQ(EO_OK,eoConverter::packetToRadio(testPacket,testTelegram));
	EXPECT_EQ(4,testTelegram.dataLength);

	EXPECT_EQ(0xFFFFFFFF,testTelegram.destinationID);
	EXPECT_EQ(0xAA,testTelegram.data[0]);
	EXPECT_EQ(0xBB,testTelegram.data[1]);
	EXPECT_EQ(0xCC,testTelegram.data[2]);
	EXPECT_EQ(0xDD,testTelegram.data[3]);
	//negativ
	testPacket.type=PACKET_COMMON_COMMAND;
	EXPECT_EQ(WRONG_PARAM,eoConverter::packetToRadio(testPacket,testTelegram));
	//Out of range
	testPacket.type=PACKET_RADIO;
	testPacket.dataLength=12;
	EXPECT_EQ(WRONG_PARAM,eoConverter::packetToRadio(testPacket,testTelegram));
}
TEST(converterTest,packetToAdvancedRadio)
{
	//testmessage
	eoMessage msg(4);
	msg.RORG=0xA5;
	msg.data[0]=0x00;
	msg.data[1]=0x01;
	msg.data[2]=0x02;
	msg.data[3]=0xFF;
	msg.sourceID=0x0;
	msg.destinationID=0xAABBCCDD;
	eoPacket packet;
	EXPECT_EQ(EO_OK,eoConverter::packetToAdvancedRadio(msg,packet));
	EXPECT_EQ(packet.type,PACKET_RADIO_ADVANCED);
	EXPECT_EQ(packet.dataLength,14);
	EXPECT_EQ(packet.optionalLength,0);
	EXPECT_EQ(0x42,packet.data[0]);
	EXPECT_EQ(0x00,packet.data[1]);
	EXPECT_EQ(0x00,packet.data[2]);
	EXPECT_EQ(0x00,packet.data[3]);
	EXPECT_EQ(0x00,packet.data[4]);
	EXPECT_EQ(0xAA,packet.data[5]);
	EXPECT_EQ(0xBB,packet.data[6]);
	EXPECT_EQ(0xCC,packet.data[7]);
	EXPECT_EQ(0xDD,packet.data[8]);
	EXPECT_EQ(0x00,packet.data[9]);
	EXPECT_EQ(0x01,packet.data[10]);
	EXPECT_EQ(0x02,packet.data[11]);
	EXPECT_EQ(0xFF,packet.data[12]);
	EXPECT_EQ(0x00,packet.data[13]);

}

TEST(converterTest,radioToPacket)
{
	//testmessage
	eoMessage msg(4);
	msg.RORG=0xA5;
	msg.data[0]=0x00;
	msg.data[1]=0x01;
	msg.data[2]=0x02;
	msg.data[3]=0xFF;
	msg.sourceID=0x0;
	msg.destinationID=0xAABBCCDD;
	eoPacket packet;
	EXPECT_EQ(EO_OK,eoConverter::radioToPacket(msg,packet));
	EXPECT_EQ(packet.type,PACKET_RADIO);
	EXPECT_EQ(packet.dataLength,10);
	EXPECT_EQ(packet.optionalLength,7);
	EXPECT_EQ(0xA5,packet.data[0]);
	EXPECT_EQ(0x00,packet.data[1]);
	EXPECT_EQ(0x01,packet.data[2]);
	EXPECT_EQ(0x02,packet.data[3]);
	EXPECT_EQ(0xFF,packet.data[4]);
	EXPECT_EQ(0x00,packet.data[5]);
	EXPECT_EQ(0x00,packet.data[6]);
	EXPECT_EQ(0x00,packet.data[7]);
	EXPECT_EQ(0x00,packet.data[8]);
	EXPECT_EQ(0x00,packet.data[9]);
	EXPECT_EQ(0x03,packet.data[10]);
	EXPECT_EQ(0xAA,packet.data[11]);
	EXPECT_EQ(0xBB,packet.data[12]);
	EXPECT_EQ(0xCC,packet.data[13]);
	EXPECT_EQ(0xDD,packet.data[14]);
	EXPECT_EQ(0xFF,packet.data[15]);
	EXPECT_EQ(0x00,packet.data[16]);
}
TEST(converterTest,remanToPacket)
{
	eoReManMessage msg(3);
	msg.fnCode = 4;
	msg.sourceID=0;
	msg.destinationID=0xFFFFFFFF;
	msg.manufacturerID=0x07FF;
	eoPacket packet;
	EXPECT_EQ(EO_OK,eoConverter::remanToPacket(msg,packet));
	EXPECT_EQ(packet.type,PACKET_REMOTE_MAN_COMMAND);
	EXPECT_EQ(packet.dataLength,7);
	EXPECT_EQ(packet.optionalLength,10);
	EXPECT_EQ(0x00,packet.data[0]);
	EXPECT_EQ(0x04,packet.data[1]);
	EXPECT_EQ(0x07,packet.data[2]);
	EXPECT_EQ(0xFF,packet.data[3]);
	EXPECT_EQ(0x00,packet.data[4]);
	EXPECT_EQ(0x00,packet.data[5]);
	EXPECT_EQ(0x00,packet.data[6]);
	EXPECT_EQ(0xFF,packet.data[7]);
	EXPECT_EQ(0xFF,packet.data[8]);
	EXPECT_EQ(0xFF,packet.data[9]);
	EXPECT_EQ(0xFF,packet.data[10]);
	EXPECT_EQ(0x00,packet.data[11]);
	EXPECT_EQ(0x00,packet.data[12]);
	EXPECT_EQ(0x00,packet.data[13]);
	EXPECT_EQ(0x00,packet.data[14]);
	EXPECT_EQ(0xFF,packet.data[15]);
	EXPECT_EQ(0x00,packet.data[16]);
}
TEST(converterTest,packetToReman)
{
	uint8_t remanData[]={0x00,0x04,0x07,0xFF,0x00,0x00,0x00,0xFF,0xFF,0xFF,0xFF,
	0x00,0x00,0x00,0x00,0xFF,0x00};
	eoReManMessage msg(4);
	eoPacket packet(remanData,17);
	packet.type=PACKET_REMOTE_MAN_COMMAND;
	packet.dataLength=7;
	packet.optionalLength=10;
	EXPECT_EQ(EO_OK,eoConverter::packetToReman(packet,msg));
	EXPECT_EQ(4,msg.fnCode);
	EXPECT_EQ(0,msg.sourceID);
	EXPECT_EQ(0xFFFFFFFF,msg.destinationID);
	EXPECT_EQ(0x07FF,msg.manufacturerID);

}

TEST(converterTest,erp2PacketToERP2SourceID24Bit)
{
	uint8_t packet24Bit[17] ={0x04,0x11,0x22,0x33,0x01,0x02,0x03,0x04,0x05,0x06,0x07
			,0x08,0x09,0x10,0x00,0x01,0x02};
	eoPacket packet(packet24Bit,14);
	packet.type = PACKET_RADIO_ADVANCED;
	packet.dataLength=15;
	packet.optionalLength=2;
	eoTelegramERP2 erp2Telegram(255);

	EXPECT_EQ(EO_OK,eoConverter::advancedPacketToRadio(packet,erp2Telegram));
	EXPECT_EQ(RORG_VLD,erp2Telegram.RORG);
	EXPECT_EQ(0x00112233,erp2Telegram.sourceID);
	EXPECT_EQ(0xFFFFFFFF,erp2Telegram.destinationID);
	EXPECT_EQ(10,erp2Telegram.dataLength);
	EXPECT_EQ(0,memcmp(&packet24Bit[4],erp2Telegram.data,erp2Telegram.dataLength));
}

TEST(converterTest,erp2PacketToERP2SourceID32Bit)
{
	uint8_t packet32Bit[20] ={0x3F,0x02,0x03,0xAA,0xBB,0xCC,0xDD,0x11,0x22,0x33,0x44
			,0x55,0x66,0x77,0x88,0x11,0x22,0x00,0x01,0x02};
	eoPacket packet(packet32Bit,20);
	packet.type = PACKET_RADIO_ADVANCED;
	packet.dataLength=18;
	packet.optionalLength=2;
	eoTelegramERP2 erp2Telegram(255);

	EXPECT_EQ(EO_OK,eoConverter::advancedPacketToRadio(packet,erp2Telegram));
	EXPECT_EQ(RORG_CDM,erp2Telegram.RORG);
	EXPECT_EQ(0xAABBCCDD,erp2Telegram.sourceID);
	EXPECT_EQ(0xFFFFFFFF,erp2Telegram.destinationID);
	EXPECT_EQ(8,erp2Telegram.dataLength);
	EXPECT_EQ(0,memcmp(&packet32Bit[7],erp2Telegram.data,erp2Telegram.dataLength));
	EXPECT_EQ(2,erp2Telegram.GetOptionalDataLength());
	EXPECT_EQ(0,memcmp(&packet32Bit[15],erp2Telegram.optionalData,erp2Telegram.GetOptionalDataLength()));
}

TEST(converterTest,erp2PacketToERP2SourceID32BitDest32Bit)
{
	uint8_t packet32Bit[16] ={0x42,0xAA,0xBB,0xCC,0xDD,0x12,0x34,0x56,0x78,0x11,0x22,0x33,0x44,0x00,0x01,0x02};
	eoPacket packet(packet32Bit,16);
	packet.type = PACKET_RADIO_ADVANCED;
	packet.dataLength=14;
	packet.optionalLength=2;
	eoTelegramERP2 erp2Telegram(255);

	EXPECT_EQ(EO_OK,eoConverter::advancedPacketToRadio(packet,erp2Telegram));
	EXPECT_EQ(RORG_4BS,erp2Telegram.RORG);
	EXPECT_EQ(0xAABBCCDD,erp2Telegram.sourceID);
	EXPECT_EQ(0x12345678,erp2Telegram.destinationID);
	EXPECT_EQ(4,erp2Telegram.dataLength);
	EXPECT_EQ(0,memcmp(&packet32Bit[9],erp2Telegram.data,erp2Telegram.dataLength));
}

TEST(converterTest,erp2PacketToERP2SourceID48Bit)
{
	uint8_t packet48Bit[20] ={0x65,0x11,0x22,0xAA,0xBB,0xCC,0xDD,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,
			0x99,0xAA,0x00,0x01,0x02};
	eoPacket packet(packet48Bit,20);
	packet.type = PACKET_RADIO_ADVANCED;
	packet.dataLength=18;
	packet.optionalLength=2;
	eoTelegramERP2 erp2Telegram(255);

	EXPECT_EQ(EO_OK,eoConverter::advancedPacketToRadio(packet,erp2Telegram));
	EXPECT_EQ(RORG_UTE,erp2Telegram.RORG);
	EXPECT_EQ(0x1122,erp2Telegram.sourceIDMSB);
	EXPECT_EQ(0xAABBCCDD,erp2Telegram.sourceID);
	EXPECT_EQ(0xFFFFFFFF,erp2Telegram.destinationID);
	EXPECT_EQ(10,erp2Telegram.dataLength);
	EXPECT_EQ(0,memcmp(&packet48Bit[7],erp2Telegram.data,erp2Telegram.dataLength));
}
