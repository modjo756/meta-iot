/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>
#include "GatewayFixture.h"
TEST(reManRPC,ping)
{
	GatewayFixture gateway;
	eoRemoteManager reman (&gateway);
	eoReManMessage message(20);
	reman.Action (0x010021F7);

	EXPECT_EQ(gateway.reManMessage.dataLength, 0);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x005);

	reman.Ping(0x010021F7);

	EXPECT_EQ(gateway.reManMessage.dataLength, 0);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x006);

	PING_RESPONSE ping;
	uint8_t pingData [] = {0xFF, 0x44, 0x88, 0x12};
	memcpy (gateway.reManMessage.data, pingData, 4);
	gateway.reManMessage.fnCode = 0x606;
	gateway.reManMessage.dataLength = 4;

	reman.ParsePingAnswer(ping);
	EXPECT_EQ(ping.rorg, 0xFF);
	EXPECT_EQ(ping.func, 0x11);
	EXPECT_EQ(ping.type, 0x11);
	EXPECT_EQ(ping.rssi, 0x12);
}
TEST(reManRPC,query)
{

	GatewayFixture gateway;
	eoRemoteManager reman (&gateway);
	eoReManMessage message(20);
	QUERY_ID query, query2;
	query.rorg = 0xFF;
	query.func = 0x11;
	query.type = 0x11;

	uint8_t parseData0[] = {0xFF, 0x44, 0x88};
	reman.QueryID (query);
	EXPECT_EQ(gateway.reManMessage.dataLength, 3);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, parseData0, 3), 0);

	memcpy(gateway.reManMessage.data, parseData0, 3);
	gateway.reManMessage.fnCode = 0x604;
	gateway.reManMessage.dataLength = 3;
	reman.ParseQueryIDAnswer(query2);

	EXPECT_EQ(query2.rorg, query.rorg);
	EXPECT_EQ(query2.func, query.func);
	EXPECT_EQ(query2.type, query.type);

	reman.QueryFunction(0x010021F7);

	EXPECT_EQ(gateway.reManMessage.dataLength, 0);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x007);

	QUERY_FUNCTION_RESPONSE queryFunction[1];
	uint8_t number;
	uint8_t parseData1 [] = {0x05, 0x12, 0x04, 0x11};
	memcpy(gateway.reManMessage.data, parseData1, 4);
	gateway.reManMessage.fnCode = 0x607;
	gateway.reManMessage.dataLength = 4;
	reman.ParseQueryFunctionAnswer (queryFunction, 1, number);

	EXPECT_EQ(number, 1);
	EXPECT_EQ(queryFunction[0].functionNum, 0x512);
	EXPECT_EQ(queryFunction[0].manufaturerID, 0x411);

	reman.QueryStatus(0x010021F7);

	EXPECT_EQ(gateway.reManMessage.dataLength, 0);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x008);

	QUERY_STATUS_RESPONSE queryStatus;
	uint8_t parseData2[] = {0x82, 0x02, 0x44, 0x89};
	memcpy(gateway.reManMessage.data, parseData2, 4);
	gateway.reManMessage.dataLength = 4;
	gateway.reManMessage.fnCode = 0x608;
	reman.ParseQueryStatusAnswer (queryStatus);

	EXPECT_EQ(queryStatus.codeSetFlag, 1);
	EXPECT_EQ(queryStatus.lastSEQ, 2);
	EXPECT_EQ(queryStatus.lastFunc, 0x244);
	EXPECT_EQ(queryStatus.lastFuncRet,0x89);
}
TEST(reManRPC,remotelearnin)
{
	GatewayFixture gateway;
	eoRemoteManager reman (&gateway);
	eoReManMessage message(20);
	reman.RemoteLearnIn(0x010021F7, R_S_STOP_LEARN);

	EXPECT_EQ(gateway.reManMessage.dataLength, 4);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x201);


}
TEST(reManRPC,flashread)
{
	GatewayFixture gateway;
	eoRemoteManager reman (&gateway);
	eoReManMessage message(20);
	uint16_t number;
	uint8_t data = 0xAB;
	uint16_t memoryAddress = 0x7D00;
	uint8_t remanData[] = {0x7D, 0x00, 0x00, 0x01, 0xAB};

	reman.RemoteFlashWrite(0x010021F7, memoryAddress, 1, &data);

	EXPECT_EQ(gateway.reManMessage.dataLength, 5);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x203);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData, 5), 0);
	uint8_t remanData2 [] = {0x7D, 0x00, 0x00, 0x01};

	reman.RemoteFlashRead (0x010021F7, memoryAddress, 1);

	EXPECT_EQ(gateway.reManMessage.dataLength, 4);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x204);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData2, 4), 0);

	FLASH_READ_RESPONSE read[3];
	uint8_t parseData3 [] = {0x11, 0x22, 0x33};
	memcpy(gateway.reManMessage.data, parseData3, 3);
	gateway.reManMessage.dataLength = 3;
	gateway.reManMessage.fnCode = 0x804;
	reman.ParseRemoteFlashReadAnswer (read, &number, 3);

	EXPECT_EQ(number, 3);
	EXPECT_EQ(read[0].data, 0x11);
	EXPECT_EQ(read[1].data, 0x22);
	EXPECT_EQ(read[2].data, 0x33);
}
TEST(reManRPC,smartmailbox)
{
	GatewayFixture gateway;
	eoRemoteManager reman (&gateway);
	eoReManMessage message(20);

	reman.RemoteSmartReadMailboxSettings (0x010021F7);

	uint8_t remanData3[] = {0x01};

	EXPECT_EQ(gateway.reManMessage.dataLength, 1);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x205);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData3, 1), 0);

	MAILBOX_SETTINGS_RESPONSE mailbox;
	uint8_t parseData4[] = {0x11, 0x22, 0x33, 0x44};
	memcpy(gateway.reManMessage.data, parseData4, 4);
	gateway.reManMessage.dataLength = 4;
	gateway.reManMessage.fnCode = 0x805;
	reman.ParseRemoteSmartReadMailboxSettingsAnswer (mailbox);

	EXPECT_EQ(mailbox.flashAddress, 0x1122);
	EXPECT_EQ(mailbox.mailboxCount, 0x3344);
	reman.RemoteSmartAddMailbox (0x010021F7, 0x01, 0x11223344, 0x55667788);

	uint8_t remanData4 [] = {0x01, 0x01, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};

	EXPECT_EQ(gateway.reManMessage.dataLength, 10);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x206);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData4, 10), 0);

	reman.RemoteSmartDeleteMailbox (0x010021F7, 0x01);

	uint8_t remanData5 [] = {0x02, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

	EXPECT_EQ(gateway.reManMessage.dataLength, 10);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x206);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData5, 10), 0);

}
TEST(reManRPC,smartsensor)
{
	GatewayFixture gateway;
	eoRemoteManager reman (&gateway);
	eoReManMessage message(20);
	reman.RemoteSmartReadLearnedSensors (0x010021F7);

	uint8_t remanData31[] = {0x02};

	EXPECT_EQ(gateway.reManMessage.dataLength, 1);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x205);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData31, 1), 0);

	LEARNED_SENSOR_RESPONSE learned[2];
	uint8_t number;
	uint8_t parseData5[] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0x00, 0xFF, 0x00, 0x11};
	memcpy(gateway.reManMessage.data, parseData5, 18);
	gateway.reManMessage.dataLength = 18;
	gateway.reManMessage.fnCode = 0x806;
	reman.ParseRemoteSmartReadLearnedSensors(learned, &number, 2);

	EXPECT_EQ(number, 2);
	EXPECT_EQ(learned[0].sensorID, 0x11223344);
	EXPECT_EQ(learned[1].sensorID, 0xAABBCCDD);
	EXPECT_EQ(learned[0].controllerID, 0x55667788);
	EXPECT_EQ(learned[1].controllerID, 0xEE00FF00);
	EXPECT_EQ(learned[0].learnedCount, 0x99);
	EXPECT_EQ(learned[1].learnedCount, 0x11);


	reman.RemoteSmartLearnIn (0x010021F7, 0x01, 0x11223344, 0x55667788);

	uint8_t remanData6 [] = {0x03, 0x01, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};

	EXPECT_EQ(gateway.reManMessage.dataLength, 10);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x206);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData6, 10), 0);

	reman.RemoteSmartLearnOut(0x010021F7, 0x01, 0x11223344, 0x55667788);

	uint8_t remanData7 [] = {0x04, 0x01, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88};

	EXPECT_EQ(gateway.reManMessage.dataLength, 10);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x010021F7);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x206);
	EXPECT_EQ(memcmp (gateway.reManMessage.data, remanData7, 10), 0);

}

