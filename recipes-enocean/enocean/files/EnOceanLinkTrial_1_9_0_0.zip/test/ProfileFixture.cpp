/*
 * profileFixture.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */


#include "ProfileFixture.h"
#include "stdlib.h"
ProfileFixture::~ProfileFixture()
{
	if(myProf!=NULL)
		delete myProf;
	myProf=NULL;
	if(msg!=NULL)
		delete msg;
	msg=NULL;
}

ProfileFixture::ProfileFixture()
{
	myProf=NULL;
	msg=NULL;
}
void ProfileFixture::Init(uint8_t rorg,uint8_t func,uint8_t type)
{

	msg = new eoMessage(128);
	msg->data[0]=(func<<2)|(type>>5);
	msg->data[1]=((type&0x1F)<<3);
	msg->data[2]=0;
	msg->data[3]=0x80;//LEARN_IN

	msg->RORG=rorg;
	msg->dataLength=4;
	myProf = eoProfileFactory::CreateProfile(*msg);
	ASSERT_TRUE(myProf!=NULL);

}

void ProfileFixture::CheckValue(CHANNEL_TYPE type,double Value)
{
	CheckValue(type,(float)Value);
}

void ProfileFixture::CheckValue(CHANNEL_TYPE type,float Value)
{
	float getValue;
	double absErr;
	ASSERT_TRUE(myProf!=NULL);
	eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)myProf->GetChannel(type);
	ASSERT_TRUE(myChan!=NULL);
	absErr=5*((myChan->max - myChan->min)/ (abs((long int)(myChan->eepItem->rangeMax - myChan->eepItem->rangeMin))));
	ASSERT_EQ(EO_OK,myProf->SetValue(type,Value));
	ASSERT_EQ(EO_OK,myProf->GetValue(type,getValue));
	EXPECT_NEAR(Value,getValue,absErr);
}

void ProfileFixture::CheckValue(CHANNEL_TYPE type,int Value)
{
	CheckValue(type,(uint8_t) Value);
}

void ProfileFixture::CheckValue(CHANNEL_TYPE type,uint8_t Value)
{
	uint8_t getValue;
	//float absErr;
	ASSERT_TRUE(myProf!=NULL);
	//ChannelInfo * myChan = myProf->getChannel(type);
	//absErr=5*((myChan->max - myChan->min)/ (abs(myChan->eepItem->rangeMax - myChan->eepItem->rangeMin)));
	ASSERT_EQ(EO_OK,myProf->SetValue(type,Value));
	ASSERT_EQ(EO_OK,myProf->GetValue(type,getValue));
	EXPECT_EQ(Value,getValue);
}

void ProfileFixture::CheckChannel(CHANNEL_TYPE type)
{
	ASSERT_TRUE(myProf!=NULL);
	eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)myProf->GetChannel(type);
	ASSERT_TRUE(myChan!=NULL);

	if (((myChan->type >= T_FLAG) && (myChan->type < SP_ABS)) || (myChan->type >= T_ENUM))
	{
		uint8_t maxValue;
		uint8_t minValue;
		minValue=myChan->min-1.0;
		maxValue=myChan->max+1.0;
		if(maxValue==0||minValue==255)
			return;
		//EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(type,maxValue));
		EXPECT_EQ(OUT_OF_RANGE,myProf->SetValue(type,maxValue));
		EXPECT_EQ(OUT_OF_RANGE,myProf->SetValue(type,minValue));
		CheckValue(type,myChan->max-(myChan->max-myChan->min)/2);
	}
	else
	{
		float maxValue;
		float minValue;
		minValue=myChan->min-1.0;
		maxValue=myChan->max+1.0;
		//EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(type,maxValue));
		EXPECT_EQ(OUT_OF_RANGE,myProf->SetValue(type,maxValue));
		EXPECT_EQ(OUT_OF_RANGE,myProf->SetValue(type,minValue));
		CheckValue(type,maxValue-(maxValue-minValue)/2);
	}

}

bool  ProfileFixture::ChannelExist(CHANNEL_TYPE type)
{
	eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)myProf->GetChannel(type);
	return myChan != NULL;
}
bool  ProfileFixture::ChannelExist(CHANNEL_TYPE type,uint8_t index)
{
	eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)myProf->GetChannel(type,index);
	return myChan != NULL;
}

void ProfileFixture::ParseRawDate(std::initializer_list<uint8_t> rawData,uint8_t length)
{
	std::copy(rawData.begin(),rawData.end(),msg->data);
	msg->dataLength=length;
	myProf->Parse(*msg);
}

