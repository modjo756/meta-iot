#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA506xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x06, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA506xxTest,eepA0601ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.55, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.1, fGetValue, 0.5);

	// S_LUMINANCE - DB_1
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(600, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(29700, fGetValue, 500);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(60000, fGetValue, 500);

	// S_LUMINANCE - DB_2
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(300, fGetValue);

	// Median
	ParseRawDate({0x00, 0x07F, 0x00, 0x09},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(14850, fGetValue, 500);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x09},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(30000, fGetValue, 500);
}

TEST_F(profileA506xxTest,eepA0601ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.55);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.1);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)600);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)29700);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x7C, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)60000);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)300);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	/*myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)14850);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)30000);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);*/
}

TEST_F(profileA506xxTest,eepA0602ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.55, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.1, fGetValue, 0.5);

	// S_LUMINANCE - DB_1
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(510, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1020, fGetValue, 5);

	// S_LUMINANCE - DB_2
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x07F, 0x00, 0x09},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(255, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x09},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(510, fGetValue, 2);
}

TEST_F(profileA506xxTest,eepA0602ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.55);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.1);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)510);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1020);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	/*myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)14850);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)30000);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);*/
}

TEST_F(profileA506xxTest,eepA0603ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.0, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(500, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 0.5);
}

TEST_F(profileA506xxTest,eepA0603ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);
}

TEST_F(profileA506xxTest,eepA0604ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(-20.0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0xFF, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(32767, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(65535, fGetValue, 0.5);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x00, 0x79},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0x00, 0xF9},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100.0, fGetValue, 5);
}

TEST_F(profileA506xxTest,eepA0604ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)32767);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)65535);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_PERCENTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)50.0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x79};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)100.0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0xF9};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}
