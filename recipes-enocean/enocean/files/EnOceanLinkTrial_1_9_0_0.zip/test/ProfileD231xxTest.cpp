/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Profiles/eoEEP_D231xx.h"
//Helper function for A5
class profileD231xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t command)
	{
		msg = new eoMessage(9);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x31, 0x00);
		ASSERT_TRUE(myProf!=NULL);
		((eoEEP_D231xx*)myProf)->SetCommand(command);
	}

};
TEST_F(profileD231xxTest,eepD23100Command6Receive)
{
	uint8_t u8GetValue;
	float fGetValue;
	Init(0x06);
	EXPECT_TRUE(ChannelExist( E_STATE, MSR_CHANNEL_REPORT_TIME));
	EXPECT_TRUE(ChannelExist(  E_STATE, MSR_CHANNEL_METER_TYPE));
	EXPECT_TRUE(ChannelExist( S_VALUE));
	EXPECT_TRUE(ChannelExist( E_UNITS, MSR_CHANNEL_METER_1));
	EXPECT_TRUE(ChannelExist( E_UNITS, MSR_CHANNEL_METER_2));
	EXPECT_TRUE(ChannelExist(  S_VALUE, MSR_CHANNEL_PRIMARY_ADDR));
	EXPECT_TRUE(ChannelExist( E_UNITS, MSR_CHANNEL_PULSES_FACTOR));
	EXPECT_TRUE(ChannelExist( S_VALUE, MSR_CHANNEL_NUM_OF_PULSES));
	EXPECT_TRUE(ChannelExist( S_VALUE, MSR_CHANNEL_PRESET_VALUE));
	EXPECT_TRUE(ChannelExist(  E_STATE, MSR_CHANNEL_PROTOCOL));
	ParseRawDate({0x06,0x20,0,1,0,0,0,0,0},9);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_REPORT_TIME));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(1,u8GetValue);//MBUS...
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue, MSR_CHANNEL_METER_1));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue, MSR_CHANNEL_METER_2));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_PRIMARY_ADDR));
	EXPECT_EQ(1,fGetValue);
	//other not exist...
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_NUM_OF_PULSES));
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_PRESET_VALUE));
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_PROTOCOL));
	//DBUS 2
	ParseRawDate({0x06,0x40,0,0,0,0,0,0,0},9);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_REPORT_TIME));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(2,u8GetValue);//MBUS...
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue, MSR_CHANNEL_METER_1));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue, MSR_CHANNEL_METER_2));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_NUM_OF_PULSES));
	EXPECT_NEAR(0,fGetValue,1);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_PRESET_VALUE));
	EXPECT_EQ(0,fGetValue);
	//other not exist...
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_PROTOCOL));
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_PRIMARY_ADDR));
	//DBUS 3
	ParseRawDate({0x06,0x60,0,0,0,0,0,0,0},9);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_REPORT_TIME));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(3,u8GetValue);//MBUS...
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue, MSR_CHANNEL_METER_1));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue, MSR_CHANNEL_METER_2));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_PROTOCOL));
	EXPECT_EQ(0,u8GetValue);
	//other not exist...
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_NUM_OF_PULSES));
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_PRESET_VALUE));
	EXPECT_EQ(NOT_SUPPORTED,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_PRIMARY_ADDR));
	//TODO: channel range checks...
}
//todo: 06- send...

TEST_F(profileD231xxTest,eepD23100Command7Receive)
{
	uint8_t u8GetValue;
	float fGetValue;
	Init(0x07);
	EXPECT_TRUE(ChannelExist( E_STATE));
	EXPECT_TRUE(ChannelExist( S_VALUE));
	ParseRawDate({0x07,0x00},2);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue));
	EXPECT_EQ(0,fGetValue);
	ParseRawDate({0x07,0x7F},2);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue));
	EXPECT_EQ(31,fGetValue);
	ParseRawDate({0x07,0x27},2);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue));
	EXPECT_EQ(1,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue));
	EXPECT_EQ(7,fGetValue);
}

TEST_F(profileD231xxTest,eepD23100Command7Send)
{
	Init(0x07);
	myProf->ClearValues();
	((eoEEP_D231xx*)myProf)->SetCommand(7);
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,0.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0));
	myProf->Create(*msg);
	EXPECT_EQ(0xD2,msg->RORG);
	EXPECT_EQ(2,msg->dataLength);
	EXPECT_EQ(0x07,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);

	myProf->ClearValues();
	((eoEEP_D231xx*)myProf)->SetCommand(7);
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,31.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)3));
	myProf->Create(*msg);
	EXPECT_EQ(0xD2,msg->RORG);
	EXPECT_EQ(2,msg->dataLength);
	EXPECT_EQ(0x07,msg->data[0]);
	EXPECT_EQ(0x7F,msg->data[1]);

	myProf->ClearValues();
	((eoEEP_D231xx*)myProf)->SetCommand(7);
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,7.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)1));
	myProf->Create(*msg);
	EXPECT_EQ(0xD2,msg->RORG);
	EXPECT_EQ(2,msg->dataLength);
	EXPECT_EQ(0x07,msg->data[0]);
	EXPECT_EQ(0x27,msg->data[1]);
}

TEST_F(profileD231xxTest,eepD23100Command8Receive)
{
	uint8_t u8GetValue;
	float fGetValue;
	Init(0x08);
	EXPECT_TRUE(ChannelExist(E_STATE, MSR_CHANNEL_METER_ERROR));
	EXPECT_TRUE(ChannelExist(E_STATE, MSR_CHANNEL_METER_TYPE));
	EXPECT_TRUE(ChannelExist(S_VALUE, MSR_CHANNEL_METER_CHANNEL));
	EXPECT_TRUE(ChannelExist(S_VALUE, MSR_CHANNEL_METER_1));
	EXPECT_TRUE(ChannelExist(E_UNITS));
	ParseRawDate({0x08,0x00,0x00,0x00,0x00,0x00,0x00},7);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_ERROR));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_METER_CHANNEL));
	EXPECT_EQ(0,fGetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_METER_1));
	EXPECT_EQ(0,fGetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	//max
	ParseRawDate({0x78,0x7E,0x1F,0xFF,0xFF,0xFF,0xFF},7);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_ERROR));
	EXPECT_EQ(7,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_METER_CHANNEL));
	EXPECT_EQ(30,fGetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_UNITS, u8GetValue));
	EXPECT_EQ(7,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_VALUE, fGetValue, MSR_CHANNEL_METER_1));
	EXPECT_NEAR(4294967295,fGetValue,1000);
}
TEST_F(profileD231xxTest,eepD23100Command8Send)
{
	Init(0x08);
	myProf->ClearValues();
	((eoEEP_D231xx*)myProf)->SetCommand(8);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0, MSR_CHANNEL_METER_ERROR));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,0.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_UNITS,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,0.0F, MSR_CHANNEL_METER_1));
	myProf->Create(*msg);
	EXPECT_EQ(0xD2,msg->RORG);
	EXPECT_EQ(7,msg->dataLength);
	EXPECT_EQ(0x08,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	EXPECT_EQ(0x00,msg->data[4]);
	EXPECT_EQ(0x00,msg->data[5]);
	EXPECT_EQ(0x00,msg->data[6]);
	//max values...
	myProf->ClearValues();
	((eoEEP_D231xx*)myProf)->SetCommand(8);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)7, MSR_CHANNEL_METER_ERROR));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)3, MSR_CHANNEL_METER_TYPE));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,30.0F, MSR_CHANNEL_METER_CHANNEL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_UNITS,(uint8_t)7));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)3, MSR_CHANNEL_VALUE_SELECTION ));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_VALUE,4294967295.0F, MSR_CHANNEL_METER_1));
	myProf->Create(*msg);
	EXPECT_EQ(0xD2,msg->RORG);
	EXPECT_EQ(7,msg->dataLength);
	EXPECT_EQ(0x78,msg->data[0]);
	EXPECT_EQ(0x7E,msg->data[1]);
	EXPECT_EQ(0x1F,msg->data[2]);
	EXPECT_EQ(0xFF,msg->data[3]);
	EXPECT_EQ(0xFF,msg->data[4]);
	EXPECT_EQ(0xFF,msg->data[5]);
	EXPECT_EQ(0xFF,msg->data[6]);
}
