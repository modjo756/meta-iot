/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Profiles/eoEEP_D220xx.h"
//Helper function for A5
class profileD220xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x20, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};

TEST_F(profileD220xxTest,eepD22000ReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x00);
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE, OP_MODE));
	EXPECT_TRUE(ChannelExist(E_STATE, TEMP_LEVEL));
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE, RELHUM_CONTROL));
	EXPECT_TRUE(ChannelExist(E_STATE, ROOM_SIZE_REFERENCE));
	EXPECT_TRUE(ChannelExist(E_ROOM_SIZE));
	EXPECT_TRUE(ChannelExist(E_STATE, RELHUM_THRESHOLD));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	myProf->SetValue(E_DIRECTION, (uint8_t)1);
	EXPECT_TRUE(ChannelExist(E_STATE, SERVICE_INFO));

	//Fan Control Message
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue,OP_MODE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,TEMP_LEVEL));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue,RELHUM_CONTROL));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_RELHUM,fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_STATE,u8GetValue, RELHUM_THRESHOLD));
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	//Fan Control Message 2
	ParseRawDate({0xF6,0xFF,0xFF,0xFF},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue,OP_MODE));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,TEMP_LEVEL));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue,RELHUM_CONTROL));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_RELHUM,fGetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue, RELHUM_THRESHOLD));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(255,u8GetValue);
	//Fan Control Message 3
	ParseRawDate({0x00,0x00,100,100},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_RELHUM,fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_STATE,u8GetValue, RELHUM_THRESHOLD));
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
	//Fan Status Message
	ParseRawDate({0x01,0x00,0x00,0x00},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue,OP_MODE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,SERVICE_INFO));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_STATE, u8GetValue,RELHUM_THRESHOLD));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_RELHUM, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, ROOM_SIZE_REFERENCE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);
	ParseRawDate({0xFF,0xFF,0xFF,0xFF},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue,OP_MODE));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,SERVICE_INFO));
	EXPECT_EQ(7,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,RELHUM_THRESHOLD));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_RELHUM, fGetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue, ROOM_SIZE_REFERENCE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	ParseRawDate({0x01,0x00,100,100},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(S_RELHUM,fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_STATE,u8GetValue, RELHUM_THRESHOLD));
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
}

TEST_F(profileD220xxTest,eepD22000SendData)
{
	Init(0x00);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)0,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE, (uint8_t)0,TEMP_LEVEL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE, (uint8_t)0,RELHUM_CONTROL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)0,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_RELHUM,0.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,0.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	//Direction 2
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0,SERVICE_INFO));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)0,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)0,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_RELHUM,0.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,0.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	myProf->ClearValues();
	//Check direction 1, max settings...
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)15,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE, (uint8_t)3,TEMP_LEVEL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE, (uint8_t)3,RELHUM_CONTROL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)3,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)15));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_RELHUM,100.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,100.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0xF6,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(100,msg->data[2]);
	EXPECT_EQ(100,msg->data[3]);
	//direction 1, e_state instead of percentage...
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)255, RELHUM_THRESHOLD));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED,(uint8_t)255));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(255,msg->data[2]);
	EXPECT_EQ(255,msg->data[3]);
	//direction 1, e_state instead of percentage...
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)253, RELHUM_THRESHOLD));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED,(uint8_t)253));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(253,msg->data[2]);
	EXPECT_EQ(253,msg->data[3]);
	//Check direction 2, max settings...
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)7,SERVICE_INFO));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)15,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)3,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)3, RELHUM_CONTROL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)15));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_RELHUM,100.0F));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,100.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(100,msg->data[2]);
	EXPECT_EQ(100,msg->data[3]);
	//direction 2, e_state instead of percentage...
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)255, RELHUM_THRESHOLD));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED,(uint8_t)255));
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(255,msg->data[2]);
	EXPECT_EQ(255,msg->data[3]);
}
TEST_F(profileD220xxTest,eepD22001ReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x01);
	EXPECT_TRUE(ChannelExist(E_STATE, ROOM_SIZE_REFERENCE));
	EXPECT_TRUE(ChannelExist(E_ROOM_SIZE));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(E_DIRECTION));
	myProf->SetValue(E_DIRECTION, (uint8_t)1);
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE, OP_MODE));
	//Fan Control Message
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);

	ParseRawDate({0x00,0x3F,0x00,0xFF},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	//check the E_FANSPEED CHANNEL
	ParseRawDate({0x00,0x00,0x00,253},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(253,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	ParseRawDate({0x00,0x00,0x00,100},4);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(100,fGetValue,1);

	//Direction 2
	ParseRawDate({0x01,0x00,0x00,0x00},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue, OP_MODE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);

    ParseRawDate({0xF1,0x3F,0x00,0xFF},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue, OP_MODE));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	//check the E_FANSPEED CHANNEL
	ParseRawDate({0x01,0x00,0x00,100},4);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
}

TEST_F(profileD220xxTest,eepD22001SendData)
{
	Init(0x01);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)0,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,0.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	//Direction 2
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)0,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)0,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,0.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	//Direction 1: MAX
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)3,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)15));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED, (uint8_t)255));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x3F,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(255,msg->data[3]);
	//
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,100.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(100,msg->data[3]);

	//Direction 2 - MAX
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)15,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)3,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)15));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED, (uint8_t)255));
	myProf->Create(*msg);
	EXPECT_EQ(0xF1,msg->data[0]);
	EXPECT_EQ(0x3F,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(255,msg->data[3]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,100.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(100,msg->data[3]);
}

TEST_F(profileD220xxTest,eepD22002ReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x02);
	EXPECT_TRUE(ChannelExist(E_STATE, ROOM_SIZE_REFERENCE));
	EXPECT_TRUE(ChannelExist(E_ROOM_SIZE));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(E_DIRECTION));
	myProf->SetValue(E_DIRECTION, (uint8_t)1);
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE, OP_MODE));
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE, RELHUM_CONTROL));

	//Fan Control Message - 00
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);

	ParseRawDate({0x00,0x3F,0x00,0xFF},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	//check the E_FANSPEED CHANNEL
	ParseRawDate({0x00,0x00,0x00,253},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(253,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	ParseRawDate({0x00,0x00,0x00,100},4);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
	//Direction 2
	ParseRawDate({0x01,0x00,0x00,0x00},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue, OP_MODE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue, RELHUM_CONTROL));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(0,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(0,fGetValue,1);

    ParseRawDate({0xF1,0xFF,0x00,0xFF},4);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue, OP_MODE));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_CONTROLLER_MODE, u8GetValue, RELHUM_CONTROL));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE, u8GetValue,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(3,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROOM_SIZE, u8GetValue));
	EXPECT_EQ(15,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(255,u8GetValue);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(S_PERCENTAGE, fGetValue));
	//check the E_FANSPEED CHANNEL
	ParseRawDate({0x01,0x00,0x00,100},4);
	EXPECT_EQ(OUT_OF_RANGE,myProf->GetValue(E_FANSPEED, u8GetValue));
	EXPECT_EQ(EO_OK,myProf->GetValue(S_PERCENTAGE, fGetValue));
	EXPECT_NEAR(100,fGetValue,1);
}

TEST_F(profileD220xxTest,eepD22002SendData)
{
	Init(0x02);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)0,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,0.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	//Direction 2
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)0,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)0,RELHUM_CONTROL));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)0,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,0.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);
	//Direction 1: MAX
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)3,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)15));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED, (uint8_t)255));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x3F,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(255,msg->data[3]);
	//
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,100.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(100,msg->data[3]);

	//Direction 2 - MAX
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)15,OP_MODE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,  (uint8_t)3,ROOM_SIZE_REFERENCE));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROOM_SIZE,  (uint8_t)15));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_FANSPEED, (uint8_t)255));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)3,RELHUM_CONTROL));
	myProf->Create(*msg);
	EXPECT_EQ(0xF1,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(255,msg->data[3]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(E_DIRECTION,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_PERCENTAGE,100.0F));
	myProf->Create(*msg);
	EXPECT_EQ(0x01,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(100,msg->data[3]);
}
