/*
 * ProfileD205Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

TEST_F(ProfileFixture,eepD210xx)
{
	eoProfile * prof00 = eoProfileFactory::CreateProfile(0xD2,0x10,0x00);
	eoProfile * prof01 = eoProfileFactory::CreateProfile(0xD2,0x10,0x01);
	eoProfile * prof02 = eoProfileFactory::CreateProfile(0xD2,0x10,0x02);

	eoMessage msg(256);
	uint8_t uVal;
	float fVal;
	Init(0xD2,0x10,00);
	Init(0xD2,0x10,01);
	Init(0xD2,0x10,02);

	msg.RORG = RORG_VLD;

	//////////////////////
	// General Message Test
	//////////////////////
	uint8_t generalMsgData0 [] = { 0x02, 0x1B };

	msg.dataLength = 0x02;

	memcpy(&msg.data[0],&generalMsgData0[0],2);

	prof00->Parse(msg);
	prof01->Parse(msg);
	prof02->Parse(msg);

	// Message continuation
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_AUTO_CONTROL,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_AUTO_CONTROL,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_AUTO_CONTROL,uVal);

	// Information request classifier
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,INFO_REQUEST_CLASS));
	EXPECT_EQ(ROOM_CONTROL_REQUEST,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,INFO_REQUEST_CLASS));
	EXPECT_EQ(ROOM_CONTROL_REQUEST,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,INFO_REQUEST_CLASS));
	EXPECT_EQ(ROOM_CONTROL_REQUEST,uVal);

	// Feedback classifier
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,FEEDBACK_CLASS));
	EXPECT_EQ(TEL_REPETITION_FEEDBACK,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,FEEDBACK_CLASS));
	EXPECT_EQ(TEL_REPETITION_FEEDBACK,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,FEEDBACK_CLASS));
	EXPECT_EQ(TEL_REPETITION_FEEDBACK,uVal);

	// General message type
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,GENERAL_MSG_TYPE));
	EXPECT_EQ(MSG_TYPE_INFO_REQUEST,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,GENERAL_MSG_TYPE));
	EXPECT_EQ(MSG_TYPE_INFO_REQUEST,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,GENERAL_MSG_TYPE));
	EXPECT_EQ(MSG_TYPE_INFO_REQUEST,uVal);

	//////////////////////
	// Data Message Test
	//////////////////////
	uint8_t dataMsgData0 [] = { 0x21, 0x6B, 0x95, 0x56, 0x39, 0xDA, 0xBA, 0x33 };

	msg.dataLength = 0x08;

	memcpy(&msg.data[0],&dataMsgData0[0],8);

	prof00->Parse(msg);
	prof01->Parse(msg);
	prof02->Parse(msg);

	// Message continuation
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_INCOMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_INCOMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_INCOMPLETE,uVal);

	// Humidity
	EXPECT_EQ(EO_OK,prof00->GetValue(S_RELHUM,fVal));
	EXPECT_NEAR(41.9,fVal,0.5);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(S_RELHUM,fVal));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_RELHUM,fVal));

	// Humidity validity
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,RELHUM_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,RELHUM_VALIDITY));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,RELHUM_VALIDITY));

	// Fan speed
	EXPECT_EQ(EO_OK,prof00->GetValue(S_VALUE,fVal));
	EXPECT_NEAR(21,fVal,0.5);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(S_VALUE,fVal));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_VALUE,fVal));

	// Fan speed validity
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,FANSPEED_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,FANSPEED_VALIDITY));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,FANSPEED_VALIDITY));

	// Fan speed mode
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,FANSPEED_MODE));
	EXPECT_EQ(FAN_SPEED_INDIVIDUAL_CONTROL,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,FANSPEED_MODE));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,FANSPEED_MODE));

	// Custom warning 2
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,CUSTOM_WARNING_2));
	EXPECT_EQ(true,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,CUSTOM_WARNING_2));
	EXPECT_EQ(true,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,CUSTOM_WARNING_2));
	EXPECT_EQ(true,uVal);

	// Custom warning 1
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,CUSTOM_WARNING_1));
	EXPECT_EQ(false,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,CUSTOM_WARNING_1));
	EXPECT_EQ(false,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,CUSTOM_WARNING_1));
	EXPECT_EQ(false,uVal);

	// Mold warning
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,MOLD_WARNING));
	EXPECT_EQ(true,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,MOLD_WARNING));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,MOLD_WARNING));

	// Window open detection
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,WINDOW_OPEN_DETECTION));
	EXPECT_EQ(WINDOW_OPEN,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,WINDOW_OPEN_DETECTION));
	EXPECT_EQ(WINDOW_OPEN,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,WINDOW_OPEN_DETECTION));
	EXPECT_EQ(WINDOW_OPEN,uVal);

	// Battery status
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,BATTERY_STATUS));
	EXPECT_EQ(BATTERY_VLD_GOOD,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,BATTERY_STATUS));
	EXPECT_EQ(BATTERY_VLD_GOOD,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,BATTERY_STATUS));
	EXPECT_EQ(BATTERY_VLD_GOOD,uVal);

	// Solar powered status
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,SOLAR_POWERED_STATUS));
	EXPECT_EQ(NOT_SOLAR_POWERED,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,SOLAR_POWERED_STATUS));

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,SOLAR_POWERED_STATUS));
	EXPECT_EQ(NOT_SOLAR_POWERED,uVal);

	// PIR status
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,PIR_STATUS));
	EXPECT_EQ(PIR_MOVEMENT,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(E_STATE,uVal,PIR_STATUS));

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,PIR_STATUS));
	EXPECT_EQ(PIR_MOVEMENT,uVal);

	// Occupancy status status
	EXPECT_EQ(EO_OK,prof00->GetValue(E_OCCUPANCY,uVal));
	EXPECT_EQ(OCCUPANCY_PRESSED_OCCUPIED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_OCCUPANCY,uVal));
	EXPECT_EQ(OCCUPANCY_PRESSED_OCCUPIED,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_OCCUPANCY,uVal));
	EXPECT_EQ(OCCUPANCY_PRESSED_OCCUPIED,uVal);

	// Cooling operation status
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,COOLING_STATUS));
	EXPECT_EQ(COOLING_HEATING_AUTO,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(E_STATE,uVal,COOLING_STATUS));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(E_STATE,uVal,COOLING_STATUS));

	// Heating operation status
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,HEATING_STATUS));
	EXPECT_EQ(COOLING_HEATING_ON,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(E_STATE,uVal,HEATING_STATUS));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(E_STATE,uVal,HEATING_STATUS));

	// Room control mode
	EXPECT_EQ(EO_OK,prof00->GetValue(E_CONTROLLER_MODE,uVal));
	EXPECT_EQ(ROOM_CONTROL_PRECOMFORT,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_CONTROLLER_MODE,uVal));
	EXPECT_EQ(ROOM_CONTROL_PRECOMFORT,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_CONTROLLER_MODE,uVal));
	EXPECT_EQ(ROOM_CONTROL_PRECOMFORT,uVal);

	// Temperature set point validity
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	// Temperature validity
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,TEMP_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,TEMP_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,TEMP_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	// Temperature set point
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TEMP_ABS,fVal,RECENT_TEMP_SETPOINT));
	EXPECT_NEAR(29.2,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TEMP_ABS,fVal,RECENT_TEMP_SETPOINT));
	EXPECT_NEAR(29.2,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TEMP_ABS,fVal,RECENT_TEMP_SETPOINT));
	EXPECT_NEAR(29.2,fVal,0.5);

	// Temperature
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TEMP,fVal));
	EXPECT_NEAR(8,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TEMP,fVal));
	EXPECT_NEAR(8,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TEMP,fVal));
	EXPECT_NEAR(8,fVal,0.5);

	//////////////////////
	// Configuration Message Test
	//////////////////////
	uint8_t configMsgData0 [] = { 0x40, 0x55, 0xF8, 0x93, 0xC0, 0x8E, 0xE4, 0x69 };

	msg.dataLength = 0x08;

	memcpy(&msg.data[0],&configMsgData0[0],8);

	prof00->Parse(msg);
	prof01->Parse(msg);
	prof02->Parse(msg);

	// Message continuation
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	// PIR status lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,PIR_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,PIR_LOCK));

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,PIR_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	// Temperature scale lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,TEMP_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,TEMP_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,TEMP_LOCK));

	// Display content lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,DISPLAY_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,DISPLAY_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,DISPLAY_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	// Date / time lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,DATE_TIME_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,DATE_TIME_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,DATE_TIME_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	// Time program lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,TIME_PROG_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,TIME_PROG_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,TIME_PROG_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	// Occupancy button lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,OCCUPANCY_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,OCCUPANCY_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,OCCUPANCY_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	// Temperature set point lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,TEMP_SETPOINT_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,TEMP_SETPOINT_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,TEMP_SETPOINT_LOCK));

	// Fan speed lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,FAN_SPEED_LOCK));
	EXPECT_EQ(UNLOCKED,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,FAN_SPEED_LOCK));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,FAN_SPEED_LOCK));

	// Radio communication interval
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,RADIO_COM_INTERVAL));
	EXPECT_EQ(RADIO_12_HOURS_INTERVAL,fVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,RADIO_COM_INTERVAL));
	EXPECT_EQ(RADIO_12_HOURS_INTERVAL,fVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TIME,fVal,RADIO_COM_INTERVAL));
	EXPECT_EQ(RADIO_12_HOURS_INTERVAL,fVal);

	// Key lock
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,KEY_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,KEY_LOCK));
	EXPECT_EQ(LOCKED,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,KEY_LOCK));

	// Display content
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,DISPLAY_CONTENT));
	EXPECT_EQ(DISPLAY_EXTERNAL_TEMP,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,DISPLAY_CONTENT));
	EXPECT_EQ(DISPLAY_EXTERNAL_TEMP,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,DISPLAY_CONTENT));
	EXPECT_EQ(DISPLAY_EXTERNAL_TEMP,uVal);

	// Temperature scale
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,TEMP_SCALE));
	EXPECT_EQ(TEMP_SCALE_CELSIUS,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,TEMP_SCALE));
	EXPECT_EQ(TEMP_SCALE_CELSIUS,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,TEMP_SCALE));
	EXPECT_EQ(TEMP_SCALE_CELSIUS,uVal);

	// Daylight saving time
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,DAYLIGHT_SAVE));
	EXPECT_EQ(DAYLIGHT_SUPPORTED,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,DAYLIGHT_SAVE));
	EXPECT_EQ(DAYLIGHT_SUPPORTED,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,DAYLIGHT_SAVE));
	EXPECT_EQ(DAYLIGHT_SUPPORTED,uVal);

	// Time notation
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,TIME_NOTATION));
	EXPECT_EQ(TIME_NOTATION_12_HOURS,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,TIME_NOTATION));
	EXPECT_EQ(TIME_NOTATION_12_HOURS,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,TIME_NOTATION));
	EXPECT_EQ(TIME_NOTATION_12_HOURS,uVal);

	// Day
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,TIME_CURRENT_DAY));
	EXPECT_NEAR(24,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,TIME_CURRENT_DAY));
	EXPECT_NEAR(24,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TIME,fVal,TIME_CURRENT_DAY));
	EXPECT_NEAR(24,fVal,0.5);

	// Month
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,TIME_CURRENT_MONTH));
	EXPECT_NEAR(1,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,TIME_CURRENT_MONTH));
	EXPECT_NEAR(1,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TIME,fVal,TIME_CURRENT_MONTH));
	EXPECT_NEAR(1,fVal,0.5);

	// Year
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,TIME_CURRENT_YEAR));
	EXPECT_NEAR(2014,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,TIME_CURRENT_YEAR));
	EXPECT_NEAR(2014,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TIME,fVal,TIME_CURRENT_YEAR));
	EXPECT_NEAR(2014,fVal,0.5);

	// Minute
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,TIME_CURRENT_MINUTE));
	EXPECT_NEAR(57,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,TIME_CURRENT_MINUTE));
	EXPECT_NEAR(57,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TIME,fVal,TIME_CURRENT_MINUTE));
	EXPECT_NEAR(57,fVal,0.5);

	// Hour
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,TIME_CURRENT_HOUR));
	EXPECT_NEAR(13,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,TIME_CURRENT_HOUR));
	EXPECT_NEAR(13,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TIME,fVal,TIME_CURRENT_HOUR));
	EXPECT_NEAR(13,fVal,0.5);

	// Date / time update flag
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,DATE_TIME_UPDATE_FLAG));
	EXPECT_EQ(DATE_TIME_UPDATE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,DATE_TIME_UPDATE_FLAG));
	EXPECT_EQ(DATE_TIME_UPDATE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,DATE_TIME_UPDATE_FLAG));
	EXPECT_EQ(DATE_TIME_UPDATE,uVal);

	//////////////////////
	// Room Control Setup
	//////////////////////
	uint8_t roomControlMsgData0 [] = { 0x60, 0xA7, 0xEC, 0x9B, 0xFF, 0x05 };

	msg.dataLength = 0x06;

	memcpy(&msg.data[0],&roomControlMsgData0[0],6);

	prof00->Parse(msg);
	prof01->Parse(msg);
	prof02->Parse(msg);

	// Message continuation
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	// Temperature set point building protection
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TEMP_ABS,fVal,BUILDING_PROTECT_TEMP_SETPOINT));
	EXPECT_NEAR(26.2,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TEMP_ABS,fVal,BUILDING_PROTECT_TEMP_SETPOINT));
	EXPECT_NEAR(26.2,fVal,0.5);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_TEMP_ABS,fVal,BUILDING_PROTECT_TEMP_SETPOINT));

	// Temperature set point precomfort
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TEMP_ABS,fVal,PRECOMFORT_TEMP_SETPOINT));
	EXPECT_NEAR(37,fVal,0.5);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(S_TEMP_ABS,fVal,PRECOMFORT_TEMP_SETPOINT));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_TEMP_ABS,fVal,PRECOMFORT_TEMP_SETPOINT));

	// Temperature set point economy
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TEMP_ABS,fVal,ECONOMY_TEMP_SETPOINT));
	EXPECT_NEAR(24.3,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TEMP_ABS,fVal,ECONOMY_TEMP_SETPOINT));
	EXPECT_NEAR(24.3,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TEMP_ABS,fVal,ECONOMY_TEMP_SETPOINT));
	EXPECT_NEAR(24.3,fVal,0.5);

	// Temperature set point comfort
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TEMP_ABS,fVal,COMFORT_TEMP_SETPOINT));
	EXPECT_NEAR(40,fVal,0.5);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TEMP_ABS,fVal,COMFORT_TEMP_SETPOINT));
	EXPECT_NEAR(40,fVal,0.5);

	EXPECT_EQ(EO_OK,prof02->GetValue(S_TEMP_ABS,fVal,COMFORT_TEMP_SETPOINT));
	EXPECT_NEAR(40,fVal,0.5);

	// Temperature set point building comfort protection
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));

	// Temperature set point precomfort protection
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,PRECOMFORT_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof01->GetValue(F_ON_OFF,uVal,PRECOMFORT_TEMP_SETPOINT_VALIDITY));

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,PRECOMFORT_TEMP_SETPOINT_VALIDITY));

	// Temperature set point economy protection
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_NO_CHANGE,uVal);

	// Temperature set point comfort protection
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,COMFORT_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,COMFORT_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(F_ON_OFF,uVal,COMFORT_TEMP_SETPOINT_VALIDITY));
	EXPECT_EQ(VALIDITY_VALID_VALUE,uVal);

	//////////////////////
	// Time Program Setup
	//////////////////////
	uint8_t timeProgramMsgData0 [] = { 0x80, 0x0B, 0x0F, 0x3B, 0x17, 0xC0 };

	msg.dataLength = 0x06;

	memcpy(&msg.data[0],&timeProgramMsgData0[0],6);

	prof00->Parse(msg);
	prof01->Parse(msg);
	prof02->Parse(msg);

	// Message continuation
	EXPECT_EQ(EO_OK,prof00->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	EXPECT_EQ(EO_OK,prof02->GetValue(E_STATE,uVal,MSG_CONTINUATION));
	EXPECT_EQ(MSG_COMPLETE,uVal);

	// End time: Minute
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,END_TIME_MINUTE));
	EXPECT_EQ(11,fVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,END_TIME_MINUTE));
	EXPECT_EQ(11,fVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_TIME,fVal,END_TIME_MINUTE));

	// End time: Hour
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,END_TIME_HOUR));
	EXPECT_EQ(15,fVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,END_TIME_HOUR));
	EXPECT_EQ(15,fVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_TIME,fVal,END_TIME_HOUR));

	// Start time: Minute
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,START_TIME_MINUTE));
	EXPECT_EQ(59,fVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,START_TIME_MINUTE));
	EXPECT_EQ(59,fVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_TIME,fVal,START_TIME_MINUTE));

	// Start time: Hour
	EXPECT_EQ(EO_OK,prof00->GetValue(S_TIME,fVal,START_TIME_HOUR));
	EXPECT_EQ(23,fVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(S_TIME,fVal,START_TIME_HOUR));
	EXPECT_EQ(23,fVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(S_TIME,fVal,START_TIME_HOUR));

	// Period
	EXPECT_EQ(EO_OK,prof00->GetValue(E_DAYS,uVal));
	EXPECT_EQ(PERIOD_WEDNESDAY_FRIDAY,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_DAYS,uVal));
	EXPECT_EQ(PERIOD_WEDNESDAY_FRIDAY,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(E_DAYS,uVal));

	// Room control mode
	EXPECT_EQ(EO_OK,prof00->GetValue(E_CONTROLLER_MODE,uVal));
	EXPECT_EQ(ROOM_CONTROL_COMFORT,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(E_CONTROLLER_MODE,uVal));
	EXPECT_EQ(ROOM_CONTROL_COMFORT,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(E_CONTROLLER_MODE,uVal));

	// Time program deletion
	EXPECT_EQ(EO_OK,prof00->GetValue(F_ON_OFF,uVal,TIME_PROG_DELETION));
	EXPECT_EQ(TIME_PROG_NO_DELETE,uVal);

	EXPECT_EQ(EO_OK,prof01->GetValue(F_ON_OFF,uVal,TIME_PROG_DELETION));
	EXPECT_EQ(TIME_PROG_NO_DELETE,uVal);

	EXPECT_EQ(NOT_SUPPORTED,prof02->GetValue(F_ON_OFF,uVal,TIME_PROG_DELETION));

	eoMessage msg00(256);
	eoMessage msg01(256);
	eoMessage msg02(256);

	// Testing General Message
	EXPECT_EQ(EO_OK,prof00->SetValue(E_COMMAND,(uint8_t)GENERAL_MSG));

	EXPECT_EQ(EO_OK,prof01->SetValue(E_COMMAND,(uint8_t)GENERAL_MSG));

	EXPECT_EQ(EO_OK,prof02->SetValue(E_COMMAND,(uint8_t)GENERAL_MSG));

	uint8_t generalMsgData [] = {0x00, 0x00};
	uint8_t i;

	////////////
	// Message Continuation
	////////////
	for ( i = 0; i <= MSG_AUTO_CONTROL; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,(uint8_t)i,MSG_CONTINUATION));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,(uint8_t)i,MSG_CONTINUATION));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,(uint8_t)i,MSG_CONTINUATION));

		prof00->Create(msg00);
		prof01->Create(msg01);
		prof02->Create(msg02);

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg00.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg01.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg02.data[0],2));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof02->SetValue(E_STATE,(uint8_t)(i+4),MSG_CONTINUATION));

		generalMsgData[0] = i + 1;
	}

	generalMsgData[0] = i - 1;


	////////////
	// Information request classifier
	////////////
	for ( i = 0; i <= TIME_PROG_REQUEST; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,(uint8_t)i,INFO_REQUEST_CLASS));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,(uint8_t)i,INFO_REQUEST_CLASS));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,(uint8_t)i,INFO_REQUEST_CLASS));

		prof00->Create(msg00);
		prof01->Create(msg01);
		prof02->Create(msg02);

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg00.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg01.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg02.data[0],2));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof02->SetValue(E_STATE,(uint8_t)(i+5),INFO_REQUEST_CLASS));

		generalMsgData[1] = (i + 1) << 3;
	}

	generalMsgData[1] = (i - 1) << 3;


	////////////
	// Feedback classifier
	////////////
	for ( i = 0; i <= MSG_REPETITION_FEEDBACK; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,(uint8_t)i,FEEDBACK_CLASS));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,(uint8_t)i,FEEDBACK_CLASS));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,(uint8_t)i,FEEDBACK_CLASS));

		prof00->Create(msg00);
		prof01->Create(msg01);
		prof02->Create(msg02);

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg00.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg01.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg02.data[0],2));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof02->SetValue(E_STATE,(uint8_t)(i+5),FEEDBACK_CLASS));

		generalMsgData[1] = 0x20;
		generalMsgData[1] |= (i+1) << 1;
	}

	generalMsgData[1] = 0x20;
	generalMsgData[1] |= (i-1) << 1;


	////////////
	// General message type
	////////////
	for ( i = 0; i <= MSG_TYPE_INFO_REQUEST; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,GENERAL_MSG_TYPE));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,GENERAL_MSG_TYPE));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,GENERAL_MSG_TYPE));

		prof00->Create(msg00);
		prof01->Create(msg01);
		prof02->Create(msg02);

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg00.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg01.data[0],2));

		EXPECT_EQ(EO_OK,memcmp(&generalMsgData[0],&msg02.data[0],2));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof02->SetValue(F_ON_OFF,(uint8_t)(i + 2),GENERAL_MSG_TYPE));

		generalMsgData[1] |= i+1;
	}

	//////////////////////
	//Testing Data Message
	//////////////////////
	EXPECT_EQ(EO_OK,prof00->SetValue(E_COMMAND,(uint8_t)DATA_MSG));

	EXPECT_EQ(EO_OK,prof01->SetValue(E_COMMAND,(uint8_t)DATA_MSG));

	EXPECT_EQ(EO_OK,prof02->SetValue(E_COMMAND,(uint8_t)DATA_MSG));

	uint8_t dataMsgData [] = {0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	////////////
	// Humidity
	////////////
	EXPECT_EQ(EO_OK,prof00->SetValue(S_RELHUM,(float)0));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_RELHUM,(float)100));

	prof00->Create(msg00);
	dataMsgData[1] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_RELHUM,(float)62));

	prof00->Create(msg00);
	dataMsgData[1] = 158;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_RELHUM,(float)81));

	prof00->Create(msg00);
	dataMsgData[1] = 206;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(S_RELHUM,(float)81));

	EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_RELHUM,(float)81));
	////////////
	// Humidity validity flag
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,RELHUM_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,RELHUM_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,RELHUM_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),RELHUM_VALIDITY));

		dataMsgData[2] |= (i+1) << 7;
	}

	dataMsgData[2] |= (i-1) << 7;

	////////////
	// Fan speed control
	////////////
	EXPECT_EQ(EO_OK,prof00->SetValue(S_VALUE,(float)0));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_VALUE,(float)100));

	prof00->Create(msg00);
	dataMsgData[2] = 0xE4;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_VALUE,(float)62));

	prof00->Create(msg00);
	dataMsgData[2] = 0xBE;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_VALUE,(float)81));

	prof00->Create(msg00);
	dataMsgData[2] = 0xD1;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(S_VALUE,(float)81));

	EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_VALUE,(float)81));

	////////////
	// Fan speed validity flag
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,FANSPEED_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,FANSPEED_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,FANSPEED_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),FANSPEED_VALIDITY));

		dataMsgData[3] |= (i+1) << 7;
	}
	dataMsgData[3] |= (i-1) << 7;

	////////////
	// Fan speed mode
	////////////
	for ( i = 0; i <= FAN_SPEED_INDIVIDUAL_CONTROL; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,FANSPEED_MODE));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,FANSPEED_MODE));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,FANSPEED_MODE));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),FANSPEED_MODE));

		dataMsgData[3] |= (i+1) << 6;
	}

	dataMsgData[3] |= (i-1) << 6;

	////////////
	// Custom warning 1
	////////////
	for ( i = 0; i <= 1; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,CUSTOM_WARNING_1));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,CUSTOM_WARNING_1));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,CUSTOM_WARNING_1));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),CUSTOM_WARNING_1));

		dataMsgData[3] |= (i+1) << 3;
	}
	dataMsgData[3] ^= 1 << 4;
	dataMsgData[3] |= (i-1) << 3;

	////////////
	// Custom warning 2
	////////////
	for ( i = 0; i <= 1; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,CUSTOM_WARNING_2));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,CUSTOM_WARNING_2));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,CUSTOM_WARNING_2));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),CUSTOM_WARNING_2));

		dataMsgData[3] |= (i+1) << 4;
	}
	dataMsgData[3] ^= 1 << 5;
	dataMsgData[3] |= (i-1) << 4;

	////////////
	// Mold warning
	////////////
	for ( i = 0; i <= 1; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,MOLD_WARNING));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,MOLD_WARNING));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,MOLD_WARNING));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),MOLD_WARNING));

		dataMsgData[3] |= (i+1) << 2;
	}
	dataMsgData[3] |= (i-1) << 2;

	////////////
	// Window open detection
	////////////
	for ( i = 0; i <= WINDOW_OPEN; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,WINDOW_OPEN_DETECTION));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,i,WINDOW_OPEN_DETECTION));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,i,WINDOW_OPEN_DETECTION));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),WINDOW_OPEN_DETECTION));

		dataMsgData[3] &= ~(3);
		dataMsgData[3] |= (i+1);
	}
	dataMsgData[3] &= ~(3);
	dataMsgData[3] |= (i-1);

	////////////
	// Battery status
	////////////
	for ( i = 0; i <= BATTERY_VLD_CRITICAL; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,BATTERY_STATUS));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,i,BATTERY_STATUS));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,i,BATTERY_STATUS));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),BATTERY_STATUS));

		dataMsgData[4] = (i+1) << 5;
	}
	dataMsgData[4] = (i-1) << 5;

	////////////
	// Solar powered status
	////////////
	for ( i = 0; i <= NOT_SOLAR_POWERED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,SOLAR_POWERED_STATUS));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,SOLAR_POWERED_STATUS));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,SOLAR_POWERED_STATUS));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 4),SOLAR_POWERED_STATUS));

		dataMsgData[4] |= (i+1) << 4;
	}
	dataMsgData[4] |= (i-1) << 4;

	////////////
	// PIR status
	////////////
	for ( i = 0; i <= PIR_LOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,PIR_STATUS));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(E_STATE,i,PIR_STATUS));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,i,PIR_STATUS));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),PIR_STATUS));

		dataMsgData[4] &= 0xF3;
		dataMsgData[4] |= (i+1) << 2;
	}
	dataMsgData[4] &= 0xF3;
	dataMsgData[4] |= (i-1) << 2;

	////////////
	// Occupancy button status
	////////////
	for ( i = 0; i <= OCCUPANCY_PRESSED_UNOCCUPIED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_OCCUPANCY,i));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_OCCUPANCY,i));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_OCCUPANCY,i));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_OCCUPANCY,(uint8_t)(i + 4)));

		dataMsgData[4] &= 0xFC;
		dataMsgData[4] |= (i+1);
	}
	dataMsgData[4] &= 0xFC;
	dataMsgData[4] |= (i-1);

	////////////
	// Cooling operation status
	////////////
	for ( i = 0; i <= COOLING_HEATING_AUTO; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,COOLING_STATUS));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(E_STATE,i,COOLING_STATUS));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(E_STATE,i,COOLING_STATUS));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),COOLING_STATUS));

		dataMsgData[5] = (i + 1) << 6;
	}
	dataMsgData[5] = (i - 1) << 6;

	////////////
	// Heating operation status
	////////////
	for ( i = 0; i <= COOLING_HEATING_AUTO; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,HEATING_STATUS));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(E_STATE,i,HEATING_STATUS));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(E_STATE,i,HEATING_STATUS));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),HEATING_STATUS));

		dataMsgData[5] &= 0xCF;
		dataMsgData[5] |= (i + 1) << 4;
	}
	dataMsgData[5] &= 0xCF;
	dataMsgData[5] |= (i - 1) << 4;

	////////////
	// Room control mode
	////////////
	for ( i = 0; i <= ROOM_CONTROL_BUILDING_PROTECT; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_CONTROLLER_MODE,i));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_CONTROLLER_MODE,i));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_CONTROLLER_MODE,i));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_CONTROLLER_MODE,(uint8_t)(i + 4)));

		dataMsgData[5] &= 0xF3;
		dataMsgData[5] |= (i + 1) << 2;
	}
	dataMsgData[5] &= 0xF3;
	dataMsgData[5] |= (i - 1) << 2;

	////////////
	// Temperature set point validity flag
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,TEMP_SETPOINT_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),TEMP_SETPOINT_VALIDITY));

		dataMsgData[5] |= (i+1) << 1;
	}
	dataMsgData[5] |= (i-1) << 1;

	////////////
	// Temperature validity flag
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,TEMP_VALIDITY));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,TEMP_VALIDITY));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,TEMP_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),TEMP_VALIDITY));

		dataMsgData[5] |= i+1;
	}
	dataMsgData[5] |= i-1;

	////////////
	// Temperature set point
	////////////
	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)0,RECENT_TEMP_SETPOINT));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)17,RECENT_TEMP_SETPOINT));

	prof00->Create(msg00);
	dataMsgData[6] = 108;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)36,RECENT_TEMP_SETPOINT));

	prof00->Create(msg00);
	dataMsgData[6] = 229;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)40,RECENT_TEMP_SETPOINT));

	prof00->Create(msg00);
	dataMsgData[6] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	////////////
	// Temperature
	////////////
	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP,(float)0));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP,(float)17));

	prof00->Create(msg00);
	dataMsgData[7] = 108;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP,(float)36));

	prof00->Create(msg00);
	dataMsgData[7] = 229;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP,(float)40));

	prof00->Create(msg00);
	dataMsgData[7] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&dataMsgData[0],&msg00.data[0],8));

	/////////////////////////////////
	//Testing Configuration Message
	/////////////////////////////////
	EXPECT_EQ(EO_OK,prof00->SetValue(E_COMMAND,(uint8_t)CONFIG_MSG));

	EXPECT_EQ(EO_OK,prof01->SetValue(E_COMMAND,(uint8_t)CONFIG_MSG));

	EXPECT_EQ(EO_OK,prof02->SetValue(E_COMMAND,(uint8_t)CONFIG_MSG));

	uint8_t configMsgData [] = {0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

	////////////
	// PIR status lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,PIR_LOCK));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,PIR_LOCK));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,PIR_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),PIR_LOCK));

		configMsgData[1] = (i+1) << 7;
	}
	configMsgData[1] = (i-1) << 7;

	////////////
	// Temperature scale lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,TEMP_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,TEMP_LOCK));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,TEMP_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),TEMP_LOCK));

		configMsgData[1] &= 0xBF;
		configMsgData[1] |= (i+1) << 6;
	}
	configMsgData[1] &= 0xBF;
	configMsgData[1] |= (i-1) << 6;

	////////////
	// Display content lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,DISPLAY_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,DISPLAY_LOCK));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,DISPLAY_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),DISPLAY_LOCK));

		configMsgData[1] &= 0xDF;
		configMsgData[1] |= (i+1) << 5;
	}
	configMsgData[1] &= 0xDF;
	configMsgData[1] |= (i-1) << 5;

	////////////
	// Date / time lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,DATE_TIME_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,DATE_TIME_LOCK));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,DATE_TIME_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),DATE_TIME_LOCK));

		configMsgData[1] &= 0xEF;
		configMsgData[1] |= (i+1) << 4;
	}
	configMsgData[1] &= 0xEF;
	configMsgData[1] |= (i-1) << 4;

	////////////
	// Time program lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,TIME_PROG_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,TIME_PROG_LOCK));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,TIME_PROG_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),TIME_PROG_LOCK));

		configMsgData[1] &= 0xF7;
		configMsgData[1] |= (i+1) << 3;
	}
	configMsgData[1] &= 0xF7;
	configMsgData[1] |= (i-1) << 3;

	////////////
	// Occupancy button lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,OCCUPANCY_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,OCCUPANCY_LOCK));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,OCCUPANCY_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),OCCUPANCY_LOCK));

		configMsgData[1] &= 0xFB;
		configMsgData[1] |= (i+1) << 2;
	}
	configMsgData[1] &= 0xFB;
	configMsgData[1] |= (i-1) << 2;

	////////////
	// Temperature set point lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,TEMP_SETPOINT_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,TEMP_SETPOINT_LOCK));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,TEMP_SETPOINT_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),TEMP_SETPOINT_LOCK));

		configMsgData[1] &= 0xFD;
		configMsgData[1] |= (i+1) << 1;
	}
	configMsgData[1] &= 0xFD;
	configMsgData[1] |= (i-1) << 1;

	////////////
	// Fan speed lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,FAN_SPEED_LOCK));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,FAN_SPEED_LOCK));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,FAN_SPEED_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),FAN_SPEED_LOCK));

		configMsgData[1] &= 0xFE;
		configMsgData[1] |= i+1;
	}
	configMsgData[1] &= 0xFE;
	configMsgData[1] |= i-1;

	////////////
	// Radio communication interval
	////////////
	for ( i = 0; i <= RADIO_24_HOURS_INTERVAL; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,RADIO_COM_INTERVAL));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,RADIO_COM_INTERVAL));

		EXPECT_EQ(EO_OK,prof02->SetValue(S_TIME,(float)i,RADIO_COM_INTERVAL));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 64),RADIO_COM_INTERVAL));

		configMsgData[2] = (i+1) << 2;
	}
	configMsgData[2] = (i-1) << 2;

	////////////
	// Key lock
	////////////
	for ( i = 0; i <= UNLOCKED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,KEY_LOCK));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,KEY_LOCK));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,KEY_LOCK));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),KEY_LOCK));

		configMsgData[2] &= 0xFD;
		configMsgData[2] |= (i+1) << 1;
	}
	configMsgData[2] &= 0xFD;
	configMsgData[2] |= (i-1) << 1;

	////////////
	// Display content
	////////////
	for ( i = 0; i <= DISPLAY_HUMIDITY; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,DISPLAY_CONTENT));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,i,DISPLAY_CONTENT));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,i,DISPLAY_CONTENT));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 8),DISPLAY_CONTENT));

		configMsgData[3] = (i+1) << 5;
	}
	configMsgData[3] = (i-1) << 5;

	////////////
	// Temperature scale
	////////////
	for ( i = 0; i <= TEMP_SCALE_FAHRENHEIT; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,TEMP_SCALE));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,i,TEMP_SCALE));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,i,TEMP_SCALE));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),TEMP_SCALE));

		configMsgData[3] &= 0xE7;
		configMsgData[3] |= (i+1) << 3;
	}
	configMsgData[3] &= 0xE7;
	configMsgData[3] |= (i-1) << 3;

	////////////
	// Daylight saving time flag
	////////////
	for ( i = 0; i <= DAYLIGHT_NOT_SUPPORTED; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,DAYLIGHT_SAVE));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,DAYLIGHT_SAVE));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,DAYLIGHT_SAVE));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),DAYLIGHT_SAVE));

		configMsgData[3] &= 0xFB;
		configMsgData[3] |= (i+1) << 2;
	}
	configMsgData[3] &= 0xFB;
	configMsgData[3] |= (i-1) << 2;

	////////////
	// Time notation
	////////////
	for ( i = 0; i <= TIME_NOTATION_12_HOURS; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_STATE,i,TIME_NOTATION));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_STATE,i,TIME_NOTATION));

		EXPECT_EQ(EO_OK,prof02->SetValue(E_STATE,i,TIME_NOTATION));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_STATE,(uint8_t)(i + 4),TIME_NOTATION));

		configMsgData[3] &= 0xFC;
		configMsgData[3] |= i+1;
	}
	configMsgData[3] &= 0xFC;
	configMsgData[3] |= i-1;

	////////////
	// Day
	////////////
	configMsgData[4] = 1 << 3;
	for ( i = 1; i <= 31; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,TIME_CURRENT_DAY));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,TIME_CURRENT_DAY));

		EXPECT_EQ(EO_OK,prof02->SetValue(S_TIME,(float)i,TIME_CURRENT_DAY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 32),TIME_CURRENT_DAY));

		configMsgData[4] = (i+1) << 3;
	}
	configMsgData[4] = (i-1) << 3;

	////////////
	// Month
	////////////
	configMsgData[5] = 1 << 7;
	for ( i = 1; i <= 12; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,TIME_CURRENT_MONTH));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,TIME_CURRENT_MONTH));

		EXPECT_EQ(EO_OK,prof02->SetValue(S_TIME,(float)i,TIME_CURRENT_MONTH));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 13),TIME_CURRENT_MONTH));

		configMsgData[4] &= 0xF8;
		configMsgData[4] |= ((i+1) >> 1) & 0x07;
		configMsgData[5] = ((i+1) & 0x01) << 7;
	}
	configMsgData[4] &= 0xF8;
	configMsgData[4] |= ((i-1) >> 1) & 0x07;
	configMsgData[5] = ((i-1) & 0x01) << 7;

	////////////
	// Year
	////////////
	for ( i = 0; i <= 127; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)(i + 2000),TIME_CURRENT_YEAR));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)(i + 2000),TIME_CURRENT_YEAR));

		EXPECT_EQ(EO_OK,prof02->SetValue(S_TIME,(float)(i + 2000),TIME_CURRENT_YEAR));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 2128),TIME_CURRENT_YEAR));

		configMsgData[5] &= 0x80;
		configMsgData[5] |= (i+1) & 0x7F;
	}
	configMsgData[5] &= 0x80;
	configMsgData[5] |= (i-1) & 0x7F;

	////////////
	// Minute
	////////////
	for ( i = 0; i <= 59; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,TIME_CURRENT_MINUTE));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,TIME_CURRENT_MINUTE));

		EXPECT_EQ(EO_OK,prof02->SetValue(S_TIME,(float)i,TIME_CURRENT_MINUTE));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 60),TIME_CURRENT_YEAR));

		configMsgData[6] = (i+1) << 2;
	}
	configMsgData[6] = (i-1) << 2;

	////////////
	// Hour
	////////////
	for ( i = 0; i <= 23; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,TIME_CURRENT_HOUR));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,TIME_CURRENT_HOUR));

		EXPECT_EQ(EO_OK,prof02->SetValue(S_TIME,(float)i,TIME_CURRENT_HOUR));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 24),TIME_CURRENT_YEAR));

		configMsgData[7] = (i+1) << 3;
	}
	configMsgData[7] = (i-1) << 3;

	////////////
	// Date / time update flag
	////////////
	for ( i = 0; i <= DATE_TIME_UPDATE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,DATE_TIME_UPDATE_FLAG));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,DATE_TIME_UPDATE_FLAG));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,DATE_TIME_UPDATE_FLAG));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&configMsgData[0],&msg00.data[0],8));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),DATE_TIME_UPDATE_FLAG));

		configMsgData[7] &= 0xFE;
		configMsgData[7] |= i+1;
	}
	configMsgData[7] &= 0xFE;
	configMsgData[7] |= i+1;

	/////////////////////////////////////
	//Testing Room Control Setup Message
	/////////////////////////////////////

	EXPECT_EQ(EO_OK,prof00->SetValue(E_COMMAND,(uint8_t)ROOM_CONTROL_MSG));

	EXPECT_EQ(EO_OK,prof01->SetValue(E_COMMAND,(uint8_t)ROOM_CONTROL_MSG));

	EXPECT_EQ(EO_OK,prof02->SetValue(E_COMMAND,(uint8_t)ROOM_CONTROL_MSG));

	uint8_t roomControlMsgData [] = {0x60,0x00,0x00,0x00,0x00,0x00};

	////////////
	// Temperature set point - building protection mode
	////////////

	// Negative test
	EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_TEMP_ABS,(float)0,BUILDING_PROTECT_TEMP_SETPOINT));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)0,BUILDING_PROTECT_TEMP_SETPOINT));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)17,BUILDING_PROTECT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[1] = 108;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)36,BUILDING_PROTECT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[1] = 229;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)40,BUILDING_PROTECT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[1] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	////////////
	// Temperature set point - precomfort mode
	////////////

	// Negative test
	EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(S_TEMP_ABS,(float)0,PRECOMFORT_TEMP_SETPOINT));
	// Negative test
	EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_TEMP_ABS,(float)0,PRECOMFORT_TEMP_SETPOINT));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)0,PRECOMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)17,PRECOMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[2] = 108;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)36,PRECOMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[2] = 229;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)40,PRECOMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[2] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	////////////
	// Temperature set point - economy mode
	////////////

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)0,ECONOMY_TEMP_SETPOINT));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)17,ECONOMY_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[3] = 108;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)36,ECONOMY_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[3] = 229;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)40,ECONOMY_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[3] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	////////////
	// Temperature set point - comfort mode
	////////////

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)0,COMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)17,COMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[4] = 108;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)36,COMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[4] = 229;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	EXPECT_EQ(EO_OK,prof00->SetValue(S_TEMP_ABS,(float)40,COMFORT_TEMP_SETPOINT));

	prof00->Create(msg00);
	roomControlMsgData[4] = 0xFF;

	EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

	////////////
	// Temperature set point - building protection validity
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY));

		roomControlMsgData[5] = (i+1) << 3;
	}
	roomControlMsgData[5] = (i-1) << 3;

	////////////
	// Temperature set point - precomfort validity
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,PRECOMFORT_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof01->SetValue(F_ON_OFF,i,PRECOMFORT_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,PRECOMFORT_TEMP_SETPOINT_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),PRECOMFORT_TEMP_SETPOINT_VALIDITY));

		roomControlMsgData[5] &= 0xFB;
		roomControlMsgData[5] |= (i+1) << 2;
	}
	roomControlMsgData[5] &= 0xFB;
	roomControlMsgData[5] |= (i-1) << 2;

	////////////
	// Temperature set point - economy validity
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY));

		roomControlMsgData[5] &= 0xFD;
		roomControlMsgData[5] |= (i+1) << 1;
	}
	roomControlMsgData[5] &= 0xFD;
	roomControlMsgData[5] |= (i-1) << 1;

	////////////
	// Temperature set point - comfort validity
	////////////
	for ( i = 0; i <= VALIDITY_VALID_VALUE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,COMFORT_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,COMFORT_TEMP_SETPOINT_VALIDITY));

		EXPECT_EQ(EO_OK,prof02->SetValue(F_ON_OFF,i,COMFORT_TEMP_SETPOINT_VALIDITY));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&roomControlMsgData[0],&msg00.data[0],5));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),COMFORT_TEMP_SETPOINT_VALIDITY));

		roomControlMsgData[5] &= 0xFE;
		roomControlMsgData[5] |= (i+1);
	}
	roomControlMsgData[5] &= 0xFE;
	roomControlMsgData[5] |= (i-1);

	/////////////////////////////////////
	//Testing Time Program Setup Message
	/////////////////////////////////////

	EXPECT_EQ(EO_OK,prof00->SetValue(E_COMMAND,(uint8_t)TIME_PROG_MSG));

	EXPECT_EQ(EO_OK,prof01->SetValue(E_COMMAND,(uint8_t)TIME_PROG_MSG));

	EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(E_COMMAND,(uint8_t)TIME_PROG_MSG));

	uint8_t timeProgramMsgData [] = {0x80,0x00,0x00,0x00,0x00,0x00};

	////////////
	// Start Minute
	////////////
	for ( i = 0; i <= 59; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,END_TIME_MINUTE));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,END_TIME_MINUTE));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_TIME,(float)i,END_TIME_MINUTE));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 60),END_TIME_MINUTE));

		timeProgramMsgData[1] = (i+1) & 0x3F;
	}
	timeProgramMsgData[1] = (i-1) & 0x3F;

	////////////
	// Start Hour
	////////////
	for ( i = 0; i <= 23; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,END_TIME_HOUR));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,END_TIME_HOUR));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_TIME,(float)i,END_TIME_HOUR));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 24),END_TIME_HOUR));

		timeProgramMsgData[2] = (i+1) & 0x1F;
	}
	timeProgramMsgData[2] = (i-1) & 0x1F;

	////////////
	// End Minute
	////////////
	for ( i = 0; i <= 59; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,START_TIME_MINUTE));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,START_TIME_MINUTE));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_TIME,(float)i,START_TIME_MINUTE));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 60),START_TIME_MINUTE));

		timeProgramMsgData[3] = (i+1) & 0x3F;
	}
	timeProgramMsgData[3] = (i-1) & 0x3F;

	////////////
	// End Hour
	////////////
	for ( i = 0; i <= 23; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(S_TIME,(float)i,START_TIME_HOUR));

		EXPECT_EQ(EO_OK,prof01->SetValue(S_TIME,(float)i,START_TIME_HOUR));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(S_TIME,(float)i,START_TIME_HOUR));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(S_TIME,(float)(i + 24),START_TIME_HOUR));

		timeProgramMsgData[4] = (i+1) & 0x1F;
	}
	timeProgramMsgData[4] = (i-1) & 0x1F;

	////////////
	// Period
	////////////
	for ( i = 0; i <= PERIOD_FRIDAY_MONDAY; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_DAYS,(uint8_t)i));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_DAYS,(uint8_t)i));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(E_DAYS,(uint8_t)i));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_DAYS,(uint8_t)(i + 16)));

		timeProgramMsgData[5] = (i+1) << 4;
	}
	timeProgramMsgData[5] = (i-1) << 4;

	////////////
	// Room control mode
	////////////
	for ( i = 0; i <= ROOM_CONTROL_BUILDING_PROTECT; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(E_CONTROLLER_MODE,(uint8_t)i));

		EXPECT_EQ(EO_OK,prof01->SetValue(E_CONTROLLER_MODE,(uint8_t)i));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(E_CONTROLLER_MODE,(uint8_t)i));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(E_CONTROLLER_MODE,(uint8_t)(i + 4)));

		timeProgramMsgData[5] &= 0xF3;
		timeProgramMsgData[5] |= (i+1) << 2;
	}
	timeProgramMsgData[5] &= 0xF3;
	timeProgramMsgData[5] |= (i-1) << 2;

	////////////
	// Time program deletion
	////////////
	for ( i = 0; i <= TIME_PROG_DELETE; i++)
	{
		EXPECT_EQ(EO_OK,prof00->SetValue(F_ON_OFF,i,TIME_PROG_DELETION));

		EXPECT_EQ(EO_OK,prof01->SetValue(F_ON_OFF,i,TIME_PROG_DELETION));

		EXPECT_EQ(NOT_SUPPORTED,prof02->SetValue(F_ON_OFF,i,TIME_PROG_DELETION));

		prof00->Create(msg00);

		EXPECT_EQ(EO_OK,memcmp(&timeProgramMsgData[0],&msg00.data[0],6));

		//Negative test
		EXPECT_EQ(OUT_OF_RANGE,prof00->SetValue(F_ON_OFF,(uint8_t)(i + 2),TIME_PROG_DELETION));

		timeProgramMsgData[5] &= 0xFE;
		timeProgramMsgData[5] |= (i+1);
	}
	timeProgramMsgData[5] &= 0xFE;
	timeProgramMsgData[5] |= (i-1);
}
