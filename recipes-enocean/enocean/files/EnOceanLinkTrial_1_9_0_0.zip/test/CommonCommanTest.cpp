/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "eoMockPacketStream.h"
#include "GatewayFixture.h"
//

TEST(commandTest,ComCommand)
{
	GatewayFixture gateway;
	delete gateway.stream;
	gateway.stream = new eoMockPacketStream();
	eoPacket serialPacket(512);
	eoSerialCommand reman (&gateway);

	reman.Sleep (0x00223344);
	reman.GetSerialPacket().copyTo(serialPacket);
	uint8_t packetData1 [] = {0x01, 0x00, 0x22, 0x33, 0x44};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 5);
	EXPECT_EQ(memcmp(serialPacket.data, packetData1, serialPacket.dataLength), 0);

	reman.Reset();
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData2 [] = {0x02};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData2, serialPacket.dataLength), 0);

	CO_RD_VERSION_RESPONSE version;
	reman.ReadVersion(version);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData6 [] = {0x03};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData6, serialPacket.dataLength), 0);

	reman.BIST();
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData7 [] = {0x06};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData7, serialPacket.dataLength), 0);

	reman.WriteIDBase(0xFF801234);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData8 [] = {0x07, 0xFF, 0x80, 0x12, 0x34};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 5);
	EXPECT_EQ(memcmp(serialPacket.data, packetData8, serialPacket.dataLength), 0);

	CO_RD_IDBASE_RESPONSE response0;
	reman.ReadIDBase (response0);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData9[] = {0x08};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData9, serialPacket.dataLength), 0);

	reman.WriteRepeater(true, 0x01);
	reman.GetSerialPacket().copyTo(serialPacket);


	uint8_t packetData10 [] = {0x09, 0x01, 0x01};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 3);
	EXPECT_EQ(memcmp(serialPacket.data, packetData10, serialPacket.dataLength), 0);

	CO_RD_REPEATER_RESPONSE response1;
	reman.ReadRepeater(response1);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData11 [] = {0x0A};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData11, serialPacket.dataLength), 0);

	reman.AddFilter(SOURCE_ID, 0x11223344,BLOCK_RADIO);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData12 [] = {0x0B, 0x00, 0x11, 0x22, 0x33, 0x44,0x00};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 7);
	EXPECT_EQ(memcmp(serialPacket.data, packetData12, serialPacket.dataLength), 0);

	reman.DeleteFilter(SOURCE_ID, 0x11223344);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData13 [] = {0x0C, 0x00, 0x11, 0x22, 0x33, 0x44};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 6);
	EXPECT_EQ(memcmp(serialPacket.data, packetData13, serialPacket.dataLength), 0);

	reman.DeleteAllFilter();
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData14 [] = {0x0D};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData14, serialPacket.dataLength), 0);

	reman.EnableFilter(true, OR);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData15 [] = {0x0E, 0x01, 0x00};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 3);
	EXPECT_EQ(memcmp(serialPacket.data, packetData15, serialPacket.dataLength), 0);

	CO_RD_FILTER_RESPONSE filter;
	uint8_t filterCount = 5, max=5;
	reman.ReadFilter(&filter, &filterCount, max);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData16 [] = {0x0F};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData16, serialPacket.dataLength), 0);

	reman.WaitMaturity(false);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData17 [] = {0x10, 0x00};

	EXPECT_EQ(serialPacket.type, 5);
	EXPECT_EQ(serialPacket.dataLength, 2);
	EXPECT_EQ(memcmp(serialPacket.data, packetData17, serialPacket.dataLength), 0);

	reman.DutyCycleLimit(CO_DUTYCYCLE_LIMIT_REACHED);
	reman.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData18 [] = {0x06, 0x01};

	EXPECT_EQ(serialPacket.type, 4);
	EXPECT_EQ(serialPacket.dataLength, 2);
	EXPECT_EQ(memcmp(serialPacket.data, packetData18, serialPacket.dataLength), 0);
}

