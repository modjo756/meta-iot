/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>
TEST(eoProfile,eep320201)
{
	/*
	eoProfile* myProf= eoProfileFactory::CreateProfile(RORG_SECD,0x02,0x01);
	eoMessage *msg = new eoMessage(1);
	uint8_t rocker1;
	uint8_t rocker2;
	uint8_t eBow;
	uint8_t mPres;
	uint8_t ret;
	//NR1
	msg->data[0] = 0x05;
	myProf->Parse(*msg);

	myProf->GetValue(E_ROCKER_A, rocker1);
	myProf->GetValue(E_ROCKER_B, rocker2);
	myProf->GetValue(E_ENERGYBOW, eBow);
	myProf->GetValue(E_MULTIPRESS, mPres);

	EXPECT_EQ(rocker1, 0);
	EXPECT_EQ(rocker2, 1);
	EXPECT_EQ(eBow, 1);
	EXPECT_EQ(mPres, 0);

	myProf->ClearValues();

	//Set value test
	ret = myProf->SetValue(E_ROCKER_A, (uint8_t) 0);
	EXPECT_EQ(ret, EO_OK);
	ret = myProf->SetValue(E_ROCKER_B, (uint8_t) 1);
	EXPECT_EQ(ret, EO_OK);
	ret = myProf->SetValue(E_ENERGYBOW, (uint8_t) 1);
	EXPECT_EQ(ret, EO_OK);
	ret = myProf->SetValue(E_MULTIPRESS, (uint8_t) 0);
	EXPECT_EQ(ret, EO_OK);

	myProf->Create(*msg);
	EXPECT_EQ(msg->data[0], 0x05);
	*/
}
