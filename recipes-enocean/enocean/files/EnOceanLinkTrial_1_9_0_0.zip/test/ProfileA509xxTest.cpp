#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA509xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x09, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA509xxTest,eepA0902ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.6, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.1, fGetValue, 0.5);

	// S_CONC
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(510, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1020, fGetValue, 5);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(25.5, fGetValue, 1);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(51, fGetValue, 1);
}

TEST_F(profileA509xxTest,eepA0902ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.55);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.1);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)510);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1020);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)25.5);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x0A};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)51);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x0A};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA0904ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_RELHUM
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x64, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0xC8, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_CONC
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1275, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(2550, fGetValue, 5);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(25.5, fGetValue, 1);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(51, fGetValue, 1);
}

TEST_F(profileA509xxTest,eepA0904ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_RELHUM
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data2[] = {0x64, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC8, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1275);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2550);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)25.5);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x0A};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)51);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x0A};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA0905ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(E_VOC));

	// S_CONC - x1
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0xFF, 0x00, 0x0A},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(32767, fGetValue, 2);

	// Max
	ParseRawDate({0xFF, 0xFF, 0x00, 0x0A},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(65535, fGetValue, 2);

	// E_VOC
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x03, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x04, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x05, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x06, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x07, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x08, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x09, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x0A, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(10, u8GetValue);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x0B, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(11, u8GetValue);

	// Enum - 255
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(255, u8GetValue);
}

TEST_F(profileA509xxTest,eepA0905ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(E_VOC));

	// S_CONC - x1
	// Min
	/*myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)32767);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)65535);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);*/

	// E_VOC
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x03, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x05, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x06, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x07, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x08, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x09, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x0A, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x0B, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 255
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)255);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA0906ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RADON_ACTIVITY));

	// S_RADON_ACTIVITY
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RADON_ACTIVITY, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0xC0, 0x00, 0x08},4);
	myProf->GetValue(S_RADON_ACTIVITY, fGetValue);
	EXPECT_NEAR(512, fGetValue, 2);

	// Max
	ParseRawDate({0xFF, 0xC0, 0x00, 0x08},4);
	myProf->GetValue(S_RADON_ACTIVITY, fGetValue);
	EXPECT_NEAR(1023, fGetValue, 2);
}

TEST_F(profileA509xxTest,eepA0906ControllerSendData)
{
	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RADON_ACTIVITY));

	// S_RADON_ACTIVITY
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_RADON_ACTIVITY,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_RADON_ACTIVITY,(float)513);
	myProf->Create(*msg);
	uint8_t data2[] = {0x80, 0x40, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_RADON_ACTIVITY,(float)1023);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xC0, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA0907ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PARTICLES));

	// S_PARTICLES - PM10
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM10);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x80, 0x00, 0x0C},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM10);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x80, 0x00, 0x0C},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM10);
	EXPECT_NEAR(511, fGetValue, 0.5);

	// S_PARTICLES - PM2_5
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM2_5);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x3F, 0xC0, 0x0A},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM2_5);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x7F, 0xC0, 0x0A},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM2_5);
	EXPECT_NEAR(511, fGetValue, 0.5);

	// S_PARTICLES - PM1
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM1);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x1F, 0xE9},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM1);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0x3F, 0xE9},4);
	myProf->GetValue(S_PARTICLES, fGetValue, PM1);
	EXPECT_NEAR(511, fGetValue, 0.5);
}

TEST_F(profileA509xxTest,eepA0907ControllerSendData)
{
	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PARTICLES));

	// S_PARTICLES - PM10
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)0, PM10);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)255, PM10);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)511, PM10);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_PARTICLES - PM2_5
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)0, PM2_5);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)255, PM2_5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x3F, 0xC0, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)511, PM2_5);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0xC0, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_PARTICLES - PM2_5
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)0, PM1);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)255, PM1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x1F, 0xE8};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_PARTICLES,(float)511, PM1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x3F, 0xE8};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA09078ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));

	// S_CONC
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(2000, fGetValue, 5);
}

TEST_F(profileA509xxTest,eepA0908ControllerSendData)
{
	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1000);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA09079ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x09);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(F_POWERALARM));

	// S_CONC
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(2000, fGetValue, 5);

	// F_POWERALARM
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA509xxTest,eepA0909ControllerSendData)
{
	// Setup the test
	Init(0x09);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(F_POWERALARM));

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1000);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_POWERALARM
	// Min
	myProf->ClearValues();
	myProf->SetValue(F_POWERALARM,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(F_POWERALARM,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA0907AControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));

	// S_CONC
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(32767, fGetValue, 1);

	// Max
	ParseRawDate({0xFF, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(65535, fGetValue, 1);

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-20.0, fGetValue, 2);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x0A},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 2);

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(2.0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x00, 0x79},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(3.5, fGetValue, 1);

	// Max
	ParseRawDate({0xFF, 0xFF, 0x00, 0xF9},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.0, fGetValue, 1);
}

TEST_F(profileA509xxTest,eepA090AControllerSendData)
{
	// Setup the test
	Init(0x0A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));

	// S_CONC
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)32767);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)65535);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x7F, 0x0A};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0xFF, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)3.5);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x79};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0xF9};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);
}

TEST_F(profileA509xxTest,eepA090CControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0C);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(E_VOC));

	// S_CONC - x1
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0xFF, 0x00, 0x0A},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(32767, fGetValue, 2);

	// Max
	ParseRawDate({0xFF, 0xFF, 0x00, 0x0A},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(65535, fGetValue, 2);

	// E_VOC
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x03, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x04, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x05, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x06, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x07, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x08, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x09, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum - 10
	ParseRawDate({0x00, 0x00, 0x0A, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(10, u8GetValue);

	// Enum - 11
	ParseRawDate({0x00, 0x00, 0x0B, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(11, u8GetValue);

	// Enum - 255
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(E_VOC, u8GetValue);
	EXPECT_EQ(255, u8GetValue);

	// E_UNITS
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA509xxTest,eepA090CControllerSendData)
{
	// Setup the test
	Init(0x0C);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(E_VOC));

	// S_CONC - x1
	// Min
	/*myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)32767);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)65535);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);*/

	// E_VOC
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x03, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x05, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x06, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x07, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x08, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x09, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum - 10
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x0A, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 11
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x0B, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 255
	myProf->ClearValues();
	myProf->SetValue(E_VOC,(uint8_t)255);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// E_UNITS
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}
