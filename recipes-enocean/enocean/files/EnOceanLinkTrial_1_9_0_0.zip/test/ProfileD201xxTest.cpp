/*
 * ProfileD201Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileD201xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(6);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x01, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileD201xxTest,eepD20100ControllerReceiveData01)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x00);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);
}

TEST_F(profileD201xxTest,eepD20100ControllerSendData)
{
	// Setup the test
	Init(0x00);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);
}

TEST_F(profileD201xxTest,eepD20101ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);
}

TEST_F(profileD201xxTest,eepD20101ControllerSendData)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD20102ControllerReceiveData01)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);
}

TEST_F(profileD201xxTest,eepD20102ControllerSendData)
{
	// Setup the test
	Init(0x02);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);
}

TEST_F(profileD201xxTest,eepD20103ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);
}

TEST_F(profileD201xxTest,eepD20103ControllerSendData)
{
	// Setup the test
	Init(0x03);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD20104ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TIME - DIMMING_MEDIUM
	// Min
	ParseRawDate({0x02, 0x00, 0x10, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x70, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0xF0, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// S_TIME - DIMMING_SLOW
	// Min
	ParseRawDate({0x02, 0x00, 0x01, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x07, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0x0F, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// S_TIME - DIMMING_FAST
	// Min
	ParseRawDate({0x02, 0x00, 0x00, 0x01},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x00, 0x07},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x20, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_OVER_CURRENT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_OVER_CURRENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_OVER_CURRENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileD201xxTest,eepD20104ControllerSendData)
{
	// Setup the test
	Init(0x04);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// S_TIME - DIMMING_MEDIUM
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data33[] = {0x02, 0x00, 0x10, 0x00};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data34[] = {0x02, 0x00, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data35[] = {0x02, 0x00, 0xF0, 0x00};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],4),0);

	// S_TIME - DIMMING_SLOW
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data36[] = {0x02, 0x00, 0xF1, 0x00};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data37[] = {0x02, 0x00, 0xF8, 0x00};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data38[] = {0x02, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],4),0);

	// S_TIME - DIMMING_FAST
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data39[] = {0x02, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data40[] = {0x02, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data40[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data41[] = {0x02, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data41[0],&msg->data[0],4),0);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data42[] = {0x02, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data43[] = {0x02, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],4),0);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x82, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data46[] = {0x82, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data46[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data47[] = {0x82, 0xA0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],4),0);

	// F_ON_OFF - RESET_OVER_CURRENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_OVER_CURRENT);
	myProf->Create(*msg);
	uint8_t data48[] = {0x82, 0xA0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data48[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_OVER_CURRENT);
	myProf->Create(*msg);
	uint8_t data49[] = {0x82, 0xE0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data49[0],&msg->data[0],4),0);
}

TEST_F(profileD201xxTest,eepD20105ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TIME - DIMMING_MEDIUM
	// Min
	ParseRawDate({0x02, 0x00, 0x10, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x70, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0xF0, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// S_TIME - DIMMING_SLOW
	// Min
	ParseRawDate({0x02, 0x00, 0x01, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x07, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0x0F, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// S_TIME - DIMMING_FAST
	// Min
	ParseRawDate({0x02, 0x00, 0x00, 0x01},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x00, 0x07},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x20, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_OVER_CURRENT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_OVER_CURRENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_OVER_CURRENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - USER_INDICATION
	// Off
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x80},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// 0% - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 100% - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Remember previous - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// E_ERROR_STATE
	// Ok - 0
	ParseRawDate({0x04, 0x00, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Warning - 1
	ParseRawDate({0x04, 0x20, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Error - 2
	ParseRawDate({0x04, 0x40, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// S_TIME - MAX_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(1270, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(2550, fGetValue, 0.5);

	// S_TIME - MIN_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x01},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileD201xxTest,eepD20105ControllerSendData)
{
	// Setup the test
	Init(0x05);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// S_TIME - MAX_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data16a[] = {0x05, 0xC0, 0x00, 0x00, 0x01, 0x00};
	EXPECT_EQ(memcmp(&data16a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1270, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data17a[] = {0x05, 0xC0, 0x00, 0x00, 0x7F, 0x00};
	EXPECT_EQ(memcmp(&data17a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data18a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data18a[0],&msg->data[0],6),0);

	// S_TIME - MIN_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)1, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data19a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data19a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data20a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data20a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data21a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data21a[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// S_TIME - DIMMING_MEDIUM
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data33[] = {0x02, 0x00, 0x10, 0x00};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data34[] = {0x02, 0x00, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data35[] = {0x02, 0x00, 0xF0, 0x00};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],4),0);

	// S_TIME - DIMMING_SLOW
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data36[] = {0x02, 0x00, 0xF1, 0x00};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data37[] = {0x02, 0x00, 0xF8, 0x00};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data38[] = {0x02, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],4),0);

	// S_TIME - DIMMING_FAST
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data39[] = {0x02, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data40[] = {0x02, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data40[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data41[] = {0x02, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data41[0],&msg->data[0],4),0);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data42[] = {0x02, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data43[] = {0x02, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],4),0);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x82, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data46[] = {0x82, 0x20, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data46[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data47[] = {0x82, 0xA0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],4),0);

	// F_ON_OFF - RESET_OVER_CURRENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_OVER_CURRENT);
	myProf->Create(*msg);
	uint8_t data48[] = {0x82, 0xA0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data48[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_OVER_CURRENT);
	myProf->Create(*msg);
	uint8_t data49[] = {0x82, 0xE0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data49[0],&msg->data[0],4),0);

	// F_ON_OFF - USER_INDICATION
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data50[] = {0x82, 0xE0, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data50[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data51[] = {0x82, 0xE0, 0xFF, 0x8F};
	EXPECT_EQ(memcmp(&data51[0],&msg->data[0],4),0);

	// E_STATE
	// Off - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x82, 0xE0, 0xFF, 0x8F};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data53[] = {0x82, 0xE0, 0xFF, 0x9F};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// Previous state - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data54[] = {0x82, 0xE0, 0xFF, 0xAF};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// E_ERROR_STATE
	// Off - 0
	myProf->SetValue(E_ERROR_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data55[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],3),0);

	// On - 1
	myProf->SetValue(E_ERROR_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data56[] = {0x04, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],3),0);

	// Previous state - 2
	myProf->SetValue(E_ERROR_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data57[] = {0x04, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD20106ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);
}

TEST_F(profileD201xxTest,eepD20106ControllerSendData)
{
	// Setup the test
	Init(0x06);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);
}

TEST_F(profileD201xxTest,eepD20107ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x07);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);
}

TEST_F(profileD201xxTest,eepD20107ControllerSendData)
{
	// Setup the test
	Init(0x07);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD20108ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x20, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_OVER_CURRENT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_OVER_CURRENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_OVER_CURRENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - USER_INDICATION
	// Off
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x80},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// 0% - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 100% - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Remember previous - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// E_ERROR_STATE
	// Ok - 0
	ParseRawDate({0x04, 0x00, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Warning - 1
	ParseRawDate({0x04, 0x20, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Error - 2
	ParseRawDate({0x04, 0x40, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// S_TIME - MAX_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(1270, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(2550, fGetValue, 0.5);

	// S_TIME - MIN_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x01},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileD201xxTest,eepD20108ControllerSendData)
{
	// Setup the test
	Init(0x08);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// S_TIME - MAX_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data16a[] = {0x05, 0xC0, 0x00, 0x00, 0x01, 0x00};
	EXPECT_EQ(memcmp(&data16a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1270, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data17a[] = {0x05, 0xC0, 0x00, 0x00, 0x7F, 0x00};
	EXPECT_EQ(memcmp(&data17a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data18a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data18a[0],&msg->data[0],6),0);

	// S_TIME - MIN_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)1, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data19a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data19a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data20a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data20a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data21a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data21a[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data42[] = {0x02, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data43[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],4),0);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x82, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data46[] = {0x82, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data46[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data47[] = {0x82, 0xA0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],4),0);

	// F_ON_OFF - RESET_OVER_CURRENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_OVER_CURRENT);
	myProf->Create(*msg);
	uint8_t data48[] = {0x82, 0xA0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data48[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_OVER_CURRENT);
	myProf->Create(*msg);
	uint8_t data49[] = {0x82, 0xE0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data49[0],&msg->data[0],4),0);

	// F_ON_OFF - USER_INDICATION
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data50[] = {0x82, 0xE0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data50[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data51[] = {0x82, 0xE0, 0x00, 0x80};
	EXPECT_EQ(memcmp(&data51[0],&msg->data[0],4),0);

	// E_STATE
	// Off - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x82, 0xE0, 0x00, 0x80};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data53[] = {0x82, 0xE0, 0x00, 0x90};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// Previous state - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data54[] = {0x82, 0xE0, 0x00, 0xA0};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// E_ERROR_STATE
	// Off - 0
	myProf->SetValue(E_ERROR_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data55[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],3),0);

	// On - 1
	myProf->SetValue(E_ERROR_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data56[] = {0x04, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],3),0);

	// Previous state - 2
	myProf->SetValue(E_ERROR_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data57[] = {0x04, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD20109ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x09);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TIME - DIMMING_MEDIUM
	// Min
	ParseRawDate({0x02, 0x00, 0x10, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x70, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0xF0, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_MEDIUM);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// S_TIME - DIMMING_SLOW
	// Min
	ParseRawDate({0x02, 0x00, 0x01, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x07, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0x0F, 0x00},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_SLOW);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// S_TIME - DIMMING_FAST
	// Min
	ParseRawDate({0x02, 0x00, 0x00, 0x01},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(0.0f, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x00, 0x00, 0x07},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(4.0f, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x00, 0x00, 0x0F},4);
	myProf->GetValue(S_TIME, fGetValue, DIMMING_FAST);
	EXPECT_NEAR(7.5f, fGetValue, 0.5);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x80, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, OVER_CURRENT_SHUT);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// 0% - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 100% - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Remember previous - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// E_ERROR_STATE
	// Ok - 0
	ParseRawDate({0x04, 0x00, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Warning - 1
	ParseRawDate({0x04, 0x20, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Error - 2
	ParseRawDate({0x04, 0x40, 0x00},3);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// S_TIME - MAX_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(1270, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(2550, fGetValue, 0.5);

	// S_TIME - MIN_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x01},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileD201xxTest,eepD20109ControllerSendData)
{
	// Setup the test
	Init(0x09);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// S_TIME - MAX_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data16a[] = {0x05, 0xC0, 0x00, 0x00, 0x01, 0x00};
	EXPECT_EQ(memcmp(&data16a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1270, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data17a[] = {0x05, 0xC0, 0x00, 0x00, 0x7F, 0x00};
	EXPECT_EQ(memcmp(&data17a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data18a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data18a[0],&msg->data[0],6),0);

	// S_TIME - MIN_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)1, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data19a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data19a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data20a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data20a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data21a[] = {0x05, 0xC0, 0x00, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data21a[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// S_TIME - DIMMING_MEDIUM
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data33[] = {0x02, 0x00, 0x10, 0x00};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data34[] = {0x02, 0x00, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_MEDIUM);
	myProf->Create(*msg);
	uint8_t data35[] = {0x02, 0x00, 0xF0, 0x00};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],4),0);

	// S_TIME - DIMMING_SLOW
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data36[] = {0x02, 0x00, 0xF1, 0x00};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data37[] = {0x02, 0x00, 0xF8, 0x00};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_SLOW);
	myProf->Create(*msg);
	uint8_t data38[] = {0x02, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],4),0);

	// S_TIME - DIMMING_FAST
	// Min
	myProf->SetValue(S_TIME,(float)0.5, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data39[] = {0x02, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TIME,(float)4, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data40[] = {0x02, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data40[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TIME,(float)7.5, DIMMING_FAST);
	myProf->Create(*msg);
	uint8_t data41[] = {0x02, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data41[0],&msg->data[0],4),0);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x82, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// F_ON_OFF - OVER_CURRENT_SHUT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data46[] = {0x82, 0x00, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data46[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, OVER_CURRENT_SHUT);
	myProf->Create(*msg);
	uint8_t data47[] = {0x82, 0x80, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],4),0);

	// E_STATE
	// Off - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x82, 0x80, 0xFF, 0x0F};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data53[] = {0x82, 0x80, 0xFF, 0x1F};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// Previous state - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data54[] = {0x82, 0x80, 0xFF, 0x2F};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// E_ERROR_STATE
	// Off - 0
	myProf->SetValue(E_ERROR_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data55[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],3),0);

	// On - 1
	myProf->SetValue(E_ERROR_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data56[] = {0x04, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],3),0);

	// Previous state - 2
	myProf->SetValue(E_ERROR_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data57[] = {0x04, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD2010AControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0A);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x20, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - USER_INDICATION
	// Off
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x80},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// 0% - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 100% - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Remember previous - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// F_ON_OFF - PWR_FAILURE
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PWR_FAILURE);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x40},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PWR_FAILURE);
	EXPECT_EQ(1, u8GetValue);

	// F_POWERALARM
	// Off
	ParseRawDate({0x04, 0x00, 0x00},3);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x44, 0x00, 0x00},3);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileD201xxTest,eepD2010AControllerSendData)
{
	// Setup the test
	Init(0x0A);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x0F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x1F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data42[] = {0x02, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data43[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],4),0);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x82, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// F_ON_OFF - USER_INDICATION
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data50[] = {0x82, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data50[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data51[] = {0x82, 0x20, 0x00, 0x80};
	EXPECT_EQ(memcmp(&data51[0],&msg->data[0],4),0);

	// E_STATE
	// Off - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x82, 0x20, 0x00, 0x80};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data53[] = {0x82, 0x20, 0x00, 0x90};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// Previous state - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data54[] = {0x82, 0x20, 0x00, 0xA0};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// F_ON_OFF - PWR_FAILURE
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, PWR_FAILURE);
	myProf->Create(*msg);
	uint8_t data55[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, PWR_FAILURE);
	myProf->Create(*msg);
	uint8_t data56[] = {0x84, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],3),0);

	// F_POWERALARM
	// Off
	myProf->SetValue(F_POWERALARM,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data57[] = {0x84, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_POWERALARM,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data58[] = {0xC4, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data58[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD2010BControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0B);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - USER_INDICATION
	// Off
	ParseRawDate({0x02, 0x40, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x80},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, USER_INDICATION);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// 0% - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 100% - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Remember previous - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - PWR_FAILURE
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PWR_FAILURE);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x40},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PWR_FAILURE);
	EXPECT_EQ(1, u8GetValue);

	// F_POWERALARM
	// Off
	ParseRawDate({0x04, 0x00, 0x00},3);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x44, 0x00, 0x00},3);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TIME - MAX_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x7F, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(1270, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xFF, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MAX_SUB_TIME);
	EXPECT_NEAR(2550, fGetValue, 0.5);

	// S_TIME - MIN_SUB_TIME
	// Min
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x01, 0x01},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x7F},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0xFF},6);
	myProf->GetValue(S_TIME, fGetValue, MIN_SUB_TIME);
	EXPECT_NEAR(255, fGetValue, 0.5);
}

TEST_F(profileD201xxTest,eepD2010BControllerSendData)
{
	// Setup the test
	Init(0x0B);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x0F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x1F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// S_TIME - MAX_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)10, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data16a[] = {0x05, 0x80, 0x00, 0x00, 0x01, 0x00};
	EXPECT_EQ(memcmp(&data16a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)1270, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data17a[] = {0x05, 0x80, 0x00, 0x00, 0x7F, 0x00};
	EXPECT_EQ(memcmp(&data17a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)2550, MAX_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data18a[] = {0x05, 0x80, 0x00, 0x00, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data18a[0],&msg->data[0],6),0);

	// S_TIME - MIN_SUB_TIME
	// Min
	myProf->SetValue(S_TIME,(float)1, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data19a[] = {0x05, 0x80, 0x00, 0x00, 0xFF, 0x01};
	EXPECT_EQ(memcmp(&data19a[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)127, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data20a[] = {0x05, 0x80, 0x00, 0x00, 0xFF, 0x7F};
	EXPECT_EQ(memcmp(&data20a[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)255, MIN_SUB_TIME);
	myProf->Create(*msg);
	uint8_t data21a[] = {0x05, 0x80, 0x00, 0x00, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data21a[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x82, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// E_STATE
	// Off - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x82, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data53[] = {0x82, 0x00, 0x00, 0x10};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// Previous state - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data54[] = {0x82, 0x00, 0x00, 0x20};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// F_ON_OFF - USER_INDICATION
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data55[] = {0x82, 0x00, 0x00, 0x20};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, USER_INDICATION);
	myProf->Create(*msg);
	uint8_t data56[] = {0x82, 0x00, 0x00, 0xA0};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// F_ON_OFF - PWR_FAILURE
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, PWR_FAILURE);
	myProf->Create(*msg);
	uint8_t data57[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, PWR_FAILURE);
	myProf->Create(*msg);
	uint8_t data58[] = {0x84, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data58[0],&msg->data[0],3),0);

	// F_POWERALARM
	// Off
	myProf->SetValue(F_POWERALARM,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data59[] = {0x84, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data59[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_POWERALARM,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data60[] = {0xC4, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data60[0],&msg->data[0],3),0);
}

TEST_F(profileD201xxTest,eepD20110ControllerReceiveData01)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x10);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REPORT_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x05, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, RESET_MEASUREMENT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - QUERY
	// Off
	ParseRawDate({0x06, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x06, 0x20},2);
	myProf->GetValue(F_ON_OFF, u8GetValue, QUERY);
	EXPECT_EQ(1, u8GetValue);

	// S_POWER - POWER_W
	// Min
	ParseRawDate({0x07, 0x60, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_W);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_POWER - POWER_KW
	// Min
	ParseRawDate({0x07, 0x80, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_POWER, fGetValue, POWER_KW);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WS);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_WS
	// Min
	ParseRawDate({0x07, 0x20, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_WH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);

	// S_ENERGY - ENERGY_KWH
	// Min
	ParseRawDate({0x07, 0x40, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF},6);
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(2147483647.0f, fGetValue, 5);

	// Max
	ParseRawDate({0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF},6);;
	myProf->GetValue(S_ENERGY, fGetValue, ENERGY_KWH);
	EXPECT_NEAR(4294967295.0f, fGetValue, 5);
}

TEST_F(profileD201xxTest,eepD20110ControllerSendData)
{
	// Setup the test
	Init(0x10);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// F_ON_OFF - REPORT_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REPORT_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],3),0);

	// F_ON_OFF - RESET_MEASUREMENT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RESET_MEASUREMENT);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0xC0, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x06);

	// F_ON_OFF - QUERY
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, QUERY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x06, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, QUERY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x06, 0x20};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],2),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x07);

	// S_POWER - POWER_W
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_W);
	myProf->Create(*msg);
	uint8_t data18[] = {0x07, 0x60, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data19[] = {0x07, 0x60, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_W);
	myProf->Create(*msg);
	uint8_t data20[] = {0x07, 0x60, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// S_POWER - POWER_KW
	// Min
	myProf->SetValue(S_POWER,(float)0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x80, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_POWER,(float)2147483647.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data22[] = {0x07, 0x80, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_POWER,(float)4294967295.0, POWER_KW);
	myProf->Create(*msg);
	uint8_t data23[] = {0x07, 0x80, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WS
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x07, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data25[] = {0x07, 0x00, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WS);
	myProf->Create(*msg);
	uint8_t data26[] = {0x07, 0x00, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_WH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data27[] = {0x07, 0x20, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data28[] = {0x07, 0x20, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_WH);
	myProf->Create(*msg);
	uint8_t data29[] = {0x07, 0x20, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// S_ENERGY - ENERGY_KWH
	// Min
	myProf->SetValue(S_ENERGY,(float)0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data30[] = {0x07, 0x40, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_ENERGY,(float)2147483647.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data31[] = {0x07, 0x40, 0x7F, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_ENERGY,(float)4294967295.0, ENERGY_KWH);
	myProf->Create(*msg);
	uint8_t data32[] = {0x07, 0x40, 0xFF, 0xFF, 0xFF, 0xFF};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);
}

TEST_F(profileD201xxTest,eepD20111ControllerReceiveData01)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x11);

	// E_DIM_VALUE
	// New output - 0
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Dim timer 1 - 1
	ParseRawDate({0x01, 0x20, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Dim timer 2 - 2
	ParseRawDate({0x01, 0x40, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Dim timer 3 - 3
	ParseRawDate({0x01, 0x60, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Stop dimming - 4
	ParseRawDate({0x01, 0x80, 0x00},3);
	myProf->GetValue(E_DIM_VALUE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x01, 0x00, 0x32},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x01, 0x00, 0x64},3);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);
}

TEST_F(profileD201xxTest,eepD20111ControllerSendData)
{
	// Setup the test
	Init(0x11);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_DIM_VALUE
	// New output - 0
	myProf->SetValue(E_DIM_VALUE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Dim timer 1 - 1
	myProf->SetValue(E_DIM_VALUE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Dim timer 2 - 2
	myProf->SetValue(E_DIM_VALUE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x40, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);

	// Dim timer 3 - 3
	myProf->SetValue(E_DIM_VALUE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x60, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],3),0);

	// Stop dimming - 4
	myProf->SetValue(E_DIM_VALUE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],3),0);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x8F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x01, 0x9F, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data10[] = {0x01, 0x9F, 0x32};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data11[] = {0x01, 0x9F, 0x64};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],3),0);
}

/*TEST_F(profileD201xxTest,eepD20112ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x12);

	// E_IO_CHANNEL
	// Min
	ParseRawDate({0x01, 0x00, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Median
	ParseRawDate({0x01, 0x0f, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// Max
	ParseRawDate({0x01, 0x1F, 0x00},3);
	myProf->GetValue(E_IO_CHANNEL, u8GetValue);
	EXPECT_EQ(31, u8GetValue);

	// F_ON_OFF - PWR_FAILURE
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PWR_FAILURE);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x40},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PWR_FAILURE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x20, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, LOCAL_CONTROL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TAUGHT_IN_DEVICES);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// 0% - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 100% - 1
	ParseRawDate({0x02, 0x00, 0x00, 0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Remember previous - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);
}

TEST_F(profileD201xxTest,eepD20112ControllerSendData)
{
	// Setup the test
	Init(0x12);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// E_IO_CHANNEL
	// Min
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data7[] = {0x01, 0x0F, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(E_IO_CHANNEL,(uint8_t)31);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x1F, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// F_ON_OFF - PWR_FAILURE
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, PWR_FAILURE);
	myProf->Create(*msg);
	uint8_t data57[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],3),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, PWR_FAILURE);
	myProf->Create(*msg);
	uint8_t data58[] = {0x84, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data58[0],&msg->data[0],3),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - LOCAL_CONTROL
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data42[] = {0x02, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, LOCAL_CONTROL);
	myProf->Create(*msg);
	uint8_t data43[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],4),0);

	// F_ON_OFF - TAUGHT_IN_DEVICES
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data44[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TAUGHT_IN_DEVICES);
	myProf->Create(*msg);
	uint8_t data45[] = {0x02, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// E_STATE
	// Off - 0
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x02, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// On - 1
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data53[] = {0x02, 0x00, 0x00, 0x10};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// Previous state - 2
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data54[] = {0x02, 0x00, 0x00, 0x20};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);
}*/

