/*
 * PackageTest.cpp
 *
 *  Created on: 26.06.2012
 *      Author: tobias
 */

#include "PackageFixture.h"
#include "eoMockPacketStream.h"

void PackageFixture::RecPackage(uint8_t * stream,uint8_t bufferSize,uint8_t offset)
{
	uint8_t i;
	eoMockPacketStream myStream;
	eoPacket myPacket;

	myStream.SetStream(stream,bufferSize);
	EXPECT_EQ(EO_OK,myStream.Receive(&myPacket));
	EXPECT_EQ(stream[offset+1],(uint8_t)(myPacket.dataLength<<8)&0xFF);
	EXPECT_EQ(stream[offset+2],(uint8_t)myPacket.dataLength&0xFF);
	EXPECT_EQ(stream[offset+3],myPacket.optionalLength);
	EXPECT_EQ(stream[offset+4],myPacket.type);
	offset+=6;
	for(i=0;i<myPacket.dataLength;i++)
		EXPECT_EQ(stream[i+offset],myPacket.data[i]);
	offset+=myPacket.dataLength;
	for(i=0;i<myPacket.optionalLength;i++)
		EXPECT_EQ(stream[i+offset],myPacket.data[i+myPacket.dataLength]);
}
