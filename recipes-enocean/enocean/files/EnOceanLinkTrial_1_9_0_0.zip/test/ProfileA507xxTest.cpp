#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA507xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x07, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA507xxTest,eepA0701ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7D, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFA, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.0, fGetValue, 0.5);

	// F_OCCUPIED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x3F, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0xBE, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA507xxTest,eepA0701ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x40, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0xBF, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);
}

TEST_F(profileA507xxTest,eepA0702ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7D, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFA, 0x00, 0x00, 0x09},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.0, fGetValue, 0.5);

	// F_OCCUPIED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA507xxTest,eepA0702ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);
}

TEST_F(profileA507xxTest,eepA0703ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.0, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(500, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 0.5);

	// F_OCCUPIED
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA507xxTest,eepA0703ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}
