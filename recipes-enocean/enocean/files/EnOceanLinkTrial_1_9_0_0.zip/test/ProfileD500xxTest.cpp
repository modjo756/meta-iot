/*
 * ProfileD500Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileD500xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_1BS;
		myProf = eoProfileFactory::CreateProfile(0xD5, 0x00, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileD500xxTest,eepD50001ControllerReceiveData)
{
	uint8_t u8GetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// F_OPEN_CLOSED
	// Enum - 0
	ParseRawDate({0x00},1);
	EXPECT_EQ(myProf->GetValue(F_OPEN_CLOSED, u8GetValue),EO_OK);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01},1);
	EXPECT_EQ(myProf->GetValue(F_OPEN_CLOSED, u8GetValue),EO_OK);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileD500xxTest,eepD50001ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// F_OPEN_CLOSED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],1),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],1),0);
}
