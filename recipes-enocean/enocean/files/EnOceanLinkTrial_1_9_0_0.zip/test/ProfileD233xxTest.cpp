/*
 * ProfileD205Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileD233xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(6);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x33, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};


TEST_F(profileD233xxTest,eepD23300ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x00);

	// Set command
	//myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// F_ON_OFF - WINDOW_OPEN_DETECTION_STATUS
	// Off
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, WINDOW_OPEN_DETECTION_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x18, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, WINDOW_OPEN_DETECTION_STATUS);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - PIR_STATUS_DETECTION
	// Off
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PIR_STATUS_DETECTION);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x14, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, PIR_STATUS_DETECTION);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - REF_TEMP_STATUS
	// Off
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, REF_TEMP_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x12, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, REF_TEMP_STATUS);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE - TEMP_SCALE_STATUS
	// Enum - 0
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TEMP_SCALE_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x10, 0x00, 0x10, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TEMP_SCALE_STATUS);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x10, 0x00, 0x20, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TEMP_SCALE_STATUS);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x10, 0x00, 0x30, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TEMP_SCALE_STATUS);
	EXPECT_EQ(3, u8GetValue);

	// E_STATE - TIME_NOTATION_STATUS
	// Enum - 0
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TIME_NOTATION_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x10, 0x00, 0x04, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TIME_NOTATION_STATUS);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x10, 0x00, 0x08, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TIME_NOTATION_STATUS);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x10, 0x00, 0x0C, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, TIME_NOTATION_STATUS);
	EXPECT_EQ(3, u8GetValue);

	// E_STATE - DISP_CONTENT_STATUS
	// Enum - 0
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x10, 0x00, 0x00, 0x80},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x10, 0x00, 0x01, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x10, 0x00, 0x01, 0x80},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x10, 0x00, 0x02, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x10, 0x00, 0x02, 0x80},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x10, 0x00, 0x03, 0x00},4);
	myProf->GetValue(E_STATE, u8GetValue, DISP_CONTENT_STATUS);
	EXPECT_EQ(6, u8GetValue);

	// F_ON_OFF - DEROGATION_STATUS
	// Off
	ParseRawDate({0x10, 0x00, 0x00, 0x00},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DEROGATION_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x10, 0x00, 0x00, 0x40},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DEROGATION_STATUS);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - SCHEDULED_ORDER_TYPE
	// Off
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, SCHEDULED_ORDER_TYPE);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x28, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, SCHEDULED_ORDER_TYPE);
	EXPECT_EQ(1, u8GetValue);

	// E_DAYS - DAY_TIME_END
	// Enum - 0
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x21, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x22, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x23, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x24, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x25, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x26, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_END);
	EXPECT_EQ(6, u8GetValue);

	// S_TIME - MINUTE_TIME_END
	// Min
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MINUTE_TIME_END);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x20, 0x78, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MINUTE_TIME_END);
	EXPECT_NEAR(30, fGetValue, 5);

	// Max
	ParseRawDate({0x20, 0xEC, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MINUTE_TIME_END);
	EXPECT_NEAR(59, fGetValue, 5);

	// S_TIME - HOUR_TIME_END
	// Min
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, HOUR_TIME_END);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x20, 0x01, 0x80, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, HOUR_TIME_END);
	EXPECT_NEAR(12, fGetValue, 1);

	// Max
	ParseRawDate({0x20, 0x02, 0xE0, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, HOUR_TIME_END);
	EXPECT_NEAR(23, fGetValue, 1);

	// E_DAYS - DAY_TIME_START
	// Enum - 0
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x20, 0x00, 0x04, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x20, 0x00, 0x08, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x20, 0x00, 0x0C, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x20, 0x00, 0x10, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x20, 0x00, 0x14, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x20, 0x00, 0x18, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_DAYS, u8GetValue, DAY_TIME_START);
	EXPECT_EQ(6, u8GetValue);

	// S_TIME - MINUTE_TIME_START
	// Min
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MINUTE_TIME_START);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x20, 0x00, 0x01, 0xE0, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MINUTE_TIME_START);
	EXPECT_NEAR(30, fGetValue, 5);

	// Max
	ParseRawDate({0x20, 0x00, 0x03, 0xB0, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, MINUTE_TIME_START);
	EXPECT_NEAR(59, fGetValue, 5);

	// S_TIME - HOUR_TIME_START
	// Min
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, HOUR_TIME_START);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x20, 0x00, 0x00, 0x06, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, HOUR_TIME_START);
	EXPECT_NEAR(12, fGetValue, 1);

	// Max
	ParseRawDate({0x20, 0x00, 0x00, 0x0B, 0x80, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, HOUR_TIME_START);
	EXPECT_NEAR(23, fGetValue, 1);

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x40},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0.1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x3E, 0x80},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(25.0, fGetValue, 1);

	// Max
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x7D, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 1);

	// F_ON_OFF - CLEAR_SCHEDULE
	// Off
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, CLEAR_SCHEDULE);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x20},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, CLEAR_SCHEDULE);
	EXPECT_EQ(1, u8GetValue);

	// S_TIME - VLD_TIME_DAY
	// Min
	ParseRawDate({0x30, 0x80, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_DAY);
	EXPECT_NEAR(1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x37, 0x80, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_DAY);
	EXPECT_NEAR(15, fGetValue, 0.5);

	// Max
	ParseRawDate({0x3F, 0x80, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_DAY);
	EXPECT_NEAR(31, fGetValue, 0.5);

	// S_TIME - VLD_TIME_MONTH
	// Min
	ParseRawDate({0x30, 0x08, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_MONTH);
	EXPECT_NEAR(1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x30, 0x30, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_MONTH);
	EXPECT_NEAR(6, fGetValue, 0.5);

	// Max
	ParseRawDate({0x30, 0x60, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_MONTH);
	EXPECT_NEAR(12, fGetValue, 0.5);

	// S_TIME - VLD_TIME_YEAR
	// Min
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_YEAR);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x30, 0x04, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_YEAR);
	EXPECT_NEAR(2048, fGetValue, 0.5);

	// Max
	ParseRawDate({0x30, 0x07, 0xFF, 0x80, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_YEAR);
	EXPECT_NEAR(4095, fGetValue, 0.5);

	// S_TIME - VLD_TIME_MINUTE
	// Min
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_MINUTE);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x30, 0x00, 0x00, 0x3C, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_MINUTE);
	EXPECT_NEAR(30, fGetValue, 0.5);

	// Max
	ParseRawDate({0x30, 0x00, 0x00, 0x76, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_MINUTE);
	EXPECT_NEAR(59, fGetValue, 0.5);

	// S_TIME - VLD_TIME_HOUR
	// Min
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_HOUR);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0xC0},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_HOUR);
	EXPECT_NEAR(12, fGetValue, 0.5);

	// Max
	ParseRawDate({0x30, 0x00, 0x00, 0x01, 0x70},5);
	myProf->GetValue(S_TIME, fGetValue, VLD_TIME_HOUR);
	EXPECT_NEAR(23, fGetValue, 0.5);

	// E_DAYS - VLD_TIME_DAY_WEEK
	// Enum - 0
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x02},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x04},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x06},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x08},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x0A},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x30, 0x00, 0x00, 0x00, 0x0C},5);
	myProf->GetValue(E_DAYS, u8GetValue, VLD_TIME_DAY_WEEK);
	EXPECT_EQ(6, u8GetValue);

	// E_STATE - REQUEST_FRAME
	// Enum - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, REQUEST_FRAME);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x81, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, REQUEST_FRAME);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x82, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, REQUEST_FRAME);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x83, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, REQUEST_FRAME);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x84, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, REQUEST_FRAME);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x8F, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, REQUEST_FRAME);
	EXPECT_EQ(15, u8GetValue);

	// E_ERROR_STATE
	// Enum - 1
	ParseRawDate({0x80, 0x00, 0x01, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x80, 0x00, 0x02, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 4
	ParseRawDate({0x80, 0x00, 0x04, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 8
	ParseRawDate({0x80, 0x00, 0x08, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(8, u8GetValue);

	// F_ON_OFF - HEATING_FLAG
	// Enum - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, HEATING_FLAG);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x80, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, HEATING_FLAG);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE - PILOT_WIRE_FLAG
	// Enum - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PILOT_WIRE_FLAG);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x20, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PILOT_WIRE_FLAG);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x80, 0x00, 0x00, 0x40, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PILOT_WIRE_FLAG);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x80, 0x00, 0x00, 0x60, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PILOT_WIRE_FLAG);
	EXPECT_EQ(3, u8GetValue);

	// E_STATE - WINDOW_DETECTION_FLAG
	// Enum - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, WINDOW_DETECTION_FLAG);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x08, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, WINDOW_DETECTION_FLAG);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x80, 0x00, 0x00, 0x10, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, WINDOW_DETECTION_FLAG);
	EXPECT_EQ(2, u8GetValue);

	// E_STATE - PIR_STATUS_DETECTION
	// Enum - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PIR_STATUS_DETECTION);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x02, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PIR_STATUS_DETECTION);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x80, 0x00, 0x00, 0x04, 0x00, 0x00},6);
	myProf->GetValue(E_STATE, u8GetValue, PIR_STATUS_DETECTION);
	EXPECT_EQ(2, u8GetValue);

	// F_ON_OFF - REF_TEMP_FLAG
	// Off - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REF_TEMP_FLAG);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x80, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, REF_TEMP_FLAG);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - DEROGATION_FLAG
	// Off - 0
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, DEROGATION_FLAG);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x40, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue, DEROGATION_FLAG);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP - VLD_TIME_HOUR
	// Min
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x00, 0x20},6);
	myProf->GetValue(S_TEMP, fGetValue, INT_TEMPERATURE);
	EXPECT_NEAR(0.1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x1F, 0x40},6);
	myProf->GetValue(S_TEMP, fGetValue, INT_TEMPERATURE);
	EXPECT_NEAR(25, fGetValue, 0.5);

	// Max
	ParseRawDate({0x80, 0x00, 0x00, 0x00, 0x3E, 0x80},6);
	myProf->GetValue(S_TEMP, fGetValue, INT_TEMPERATURE);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// S_TEMP - DEROGATION_TEMP_SETPOINT
	// Min
	ParseRawDate({0x90, 0x00, 0x00, 0x00, 0x08, 0x00},6);
	myProf->GetValue(S_TEMP, fGetValue, DEROGATION_TEMP_SETPOINT);
	EXPECT_NEAR(0.1, fGetValue, 0.5);

	// Median
	ParseRawDate({0x90, 0x00, 0x00, 0x07, 0xC8, 0x00},6);
	myProf->GetValue(S_TEMP, fGetValue, DEROGATION_TEMP_SETPOINT);
	EXPECT_NEAR(25, fGetValue, 0.5);

	// Max
	ParseRawDate({0x90, 0x00, 0x00, 0x0F, 0xA0, 0x00},6);
	myProf->GetValue(S_TEMP, fGetValue, DEROGATION_TEMP_SETPOINT);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// S_VALUE - DEROGATION_TEMP_SETPOINT
	// Min
	ParseRawDate({0x90, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_VALUE, fGetValue, FIRMWARE_VERSION);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x90, 0x00, 0x00, 0x00, 0x04, 0x00},6);
	myProf->GetValue(S_VALUE, fGetValue, FIRMWARE_VERSION);
	EXPECT_NEAR(512, fGetValue, 0.5);

	// Max
	ParseRawDate({0x90, 0x00, 0x00, 0x00, 0x07, 0xFE},6);
	myProf->GetValue(S_VALUE, fGetValue, FIRMWARE_VERSION);
	EXPECT_NEAR(1023, fGetValue, 0.5);
}

TEST_F(profileD233xxTest,eepD23300ControllerSendData)
{
	// Setup the test
	Init(0x00);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	// F_ON_OFF - WINDOW_OPEN_DETECTION_STATUS
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, WINDOW_OPEN_DETECTION_STATUS);
	myProf->Create(*msg);
	uint8_t data0[] = {0x10, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, WINDOW_OPEN_DETECTION_STATUS);
	myProf->Create(*msg);
	uint8_t data1[] = {0x18, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// F_ON_OFF - PIR_STATUS_DETECTION
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, PIR_STATUS_DETECTION);
	myProf->Create(*msg);
	uint8_t data2[] = {0x18, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, PIR_STATUS_DETECTION);
	myProf->Create(*msg);
	uint8_t data3[] = {0x1C, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF - REF_TEMP_STATUS
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REF_TEMP_STATUS);
	myProf->Create(*msg);
	uint8_t data4[] = {0x1C, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REF_TEMP_STATUS);
	myProf->Create(*msg);
	uint8_t data5[] = {0x1E, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// E_STATE - TEMP_SCALE_STATUS
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, TEMP_SCALE_STATUS);
	myProf->Create(*msg);
	uint8_t data6[] = {0x1E, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, TEMP_SCALE_STATUS);
	myProf->Create(*msg);
	uint8_t data7[] = {0x1E, 0x00, 0x10, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, TEMP_SCALE_STATUS);
	myProf->Create(*msg);
	uint8_t data8[] = {0x1E, 0x00, 0x20, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3, TEMP_SCALE_STATUS);
	myProf->Create(*msg);
	uint8_t data9[] = {0x1E, 0x00, 0x30, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// E_STATE - TIME_NOTATION_STATUS
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, TIME_NOTATION_STATUS);
	myProf->Create(*msg);
	uint8_t data10[] = {0x1E, 0x00, 0x30, 0x00};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, TIME_NOTATION_STATUS);
	myProf->Create(*msg);
	uint8_t data11[] = {0x1E, 0x00, 0x34, 0x00};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, TIME_NOTATION_STATUS);
	myProf->Create(*msg);
	uint8_t data12[] = {0x1E, 0x00, 0x38, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3, TIME_NOTATION_STATUS);
	myProf->Create(*msg);
	uint8_t data13[] = {0x1E, 0x00, 0x3C, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// E_STATE - DISP_CONTENT_STATUS
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data14[] = {0x1E, 0x00, 0x3C, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data15[] = {0x1E, 0x00, 0x3C, 0x80};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data16[] = {0x1E, 0x00, 0x3D, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data17[] = {0x1E, 0x00, 0x3D, 0x80};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->SetValue(E_STATE,(uint8_t)4, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data18[] = {0x1E, 0x00, 0x3E, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->SetValue(E_STATE,(uint8_t)5, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data19[] = {0x1E, 0x00, 0x3E, 0x80};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->SetValue(E_STATE,(uint8_t)6, DISP_CONTENT_STATUS);
	myProf->Create(*msg);
	uint8_t data20[] = {0x1E, 0x00, 0x3F, 0x00};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// F_ON_OFF - DEROGATION_STATUS
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, DEROGATION_STATUS);
	myProf->Create(*msg);
	uint8_t data21[] = {0x1E, 0x00, 0x3F, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, DEROGATION_STATUS);
	myProf->Create(*msg);
	uint8_t data22[] = {0x1E, 0x00, 0x3F, 0x40};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_OFF - SCHEDULED_ORDER_TYPE
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, SCHEDULED_ORDER_TYPE);
	myProf->Create(*msg);
	uint8_t data23[] = {0x20, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, SCHEDULED_ORDER_TYPE);
	myProf->Create(*msg);
	uint8_t data24[] = {0x28, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// E_STATE - DAY_TIME_END
	// Enum - 0
	myProf->SetValue(E_DAYS,(uint8_t)0, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data25[] = {0x28, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Enum - 1
	myProf->SetValue(E_DAYS,(uint8_t)1, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data26[] = {0x29, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_DAYS,(uint8_t)2, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data27[] = {0x2A, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// Enum - 3
	myProf->SetValue(E_DAYS,(uint8_t)3, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data28[] = {0x2B, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Enum - 4
	myProf->SetValue(E_DAYS,(uint8_t)4, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data29[] = {0x2C, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// Enum - 5
	myProf->SetValue(E_DAYS,(uint8_t)5, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data30[] = {0x2D, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// Enum - 6
	myProf->SetValue(E_DAYS,(uint8_t)6, DAY_TIME_END);
	myProf->Create(*msg);
	uint8_t data31[] = {0x2E, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// S_TIME - MINUTE_TIME_END
	// Min
	myProf->SetValue(S_TIME,(float)0, MINUTE_TIME_END);
	myProf->Create(*msg);
	uint8_t data32[] = {0x2E, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)30, MINUTE_TIME_END);
	myProf->Create(*msg);
	uint8_t data33[] = {0x2E, 0x78, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)59, MINUTE_TIME_END);
	myProf->Create(*msg);
	uint8_t data34[] = {0x2E, 0xEC, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],6),0);

	// S_TIME - HOUR_TIME_END
	// Min
	myProf->SetValue(S_TIME,(float)0, HOUR_TIME_END);
	myProf->Create(*msg);
	uint8_t data35[] = {0x2E, 0xEC, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)12, HOUR_TIME_END);
	myProf->Create(*msg);
	uint8_t data36[] = {0x2E, 0xED, 0x80, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)23, HOUR_TIME_END);
	myProf->Create(*msg);
	uint8_t data37[] = {0x2E, 0xEE, 0xE0, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],6),0);

	// E_DAYS - DAY_TIME_START
	// Enum - 0
	myProf->SetValue(E_DAYS,(uint8_t)0, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data38[] = {0x2E, 0xEE, 0xE0, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],6),0);

	// Enum - 1
	myProf->SetValue(E_DAYS,(uint8_t)1, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data39[] = {0x2E, 0xEE, 0xE4, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_DAYS,(uint8_t)2, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data40[] = {0x2E, 0xEE, 0xE8, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data40[0],&msg->data[0],6),0);

	// Enum - 3
	myProf->SetValue(E_DAYS,(uint8_t)3, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data41[] = {0x2E, 0xEE, 0xEC, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data41[0],&msg->data[0],6),0);

	// Enum - 4
	myProf->SetValue(E_DAYS,(uint8_t)4, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data42[] = {0x2E, 0xEE, 0xF0, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],6),0);

	// Enum - 5
	myProf->SetValue(E_DAYS,(uint8_t)5, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data43[] = {0x2E, 0xEE, 0xF4, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],6),0);

	// Enum - 6
	myProf->SetValue(E_DAYS,(uint8_t)6, DAY_TIME_START);
	myProf->Create(*msg);
	uint8_t data44[] = {0x2E, 0xEE, 0xF8, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],6),0);

	// S_TIME - MINUTE_TIME_START
	// Min
	myProf->SetValue(S_TIME,(float)0, MINUTE_TIME_START);
	myProf->Create(*msg);
	uint8_t data45[] = {0x2E, 0xEE, 0xF8, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)30, MINUTE_TIME_START);
	myProf->Create(*msg);
	uint8_t data46[] = {0x2E, 0xEE, 0xF9, 0xE0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data46[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)59, MINUTE_TIME_START);
	myProf->Create(*msg);
	uint8_t data47[] = {0x2E, 0xEE, 0xFB, 0xB0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],6),0);

	// S_TIME - HOUR_TIME_START
	// Min
	myProf->SetValue(S_TIME,(float)0, HOUR_TIME_START);
	myProf->Create(*msg);
	uint8_t data48[] = {0x2E, 0xEE, 0xFB, 0xB0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data48[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)12, HOUR_TIME_START);
	myProf->Create(*msg);
	uint8_t data49[] = {0x2E, 0xEE, 0xFB, 0xB6, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data49[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)23, HOUR_TIME_START);
	myProf->Create(*msg);
	uint8_t data50[] = {0x2E, 0xEE, 0xFB, 0xBB, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data50[0],&msg->data[0],6),0);

	// S_TEMP_ABS
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)0.1);
	myProf->Create(*msg);
	uint8_t data51[] = {0x2E, 0xEE, 0xFB, 0xBB, 0x80, 0x40};
	EXPECT_EQ(memcmp(&data51[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)25.0);
	myProf->Create(*msg);
	uint8_t data52[] = {0x2E, 0xEE, 0xFB, 0xBB, 0xBE, 0x40};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);
	EXPECT_NEAR(data52[5],msg->data[5],0x80);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)50.0);
	myProf->Create(*msg);
	uint8_t data53[] = {0x2E, 0xEE, 0xFB, 0xBB, 0xFD, 0x00};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],6),0);

	// F_ON_OFF - CLEAR_SCHEDULE
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CLEAR_SCHEDULE);
	myProf->Create(*msg);
	uint8_t data54[] = {0x2E, 0xEE, 0xFB, 0xBB, 0xFD, 0x00};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CLEAR_SCHEDULE);
	myProf->Create(*msg);
	uint8_t data55[] = {0x2E, 0xEE, 0xFB, 0xBB, 0xFD, 0x20};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],4),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x03);

	// S_TIME - VLD_TIME_DAY
	// Min
	myProf->SetValue(S_TIME,(float)1, VLD_TIME_DAY);
	myProf->Create(*msg);
	uint8_t data56[] = {0x30, 0x80, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)15.0, VLD_TIME_DAY);
	myProf->Create(*msg);
	uint8_t data57[] = {0x37, 0x80, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)31.0, VLD_TIME_DAY);
	myProf->Create(*msg);
	uint8_t data58[] = {0x3F, 0x80, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data58[0],&msg->data[0],5),0);

	// S_TIME - VLD_TIME_MONTH
	// Min
	myProf->SetValue(S_TIME,(float)1, VLD_TIME_MONTH);
	myProf->Create(*msg);
	uint8_t data59[] = {0x3F, 0x88, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data59[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)6.0, VLD_TIME_MONTH);
	myProf->Create(*msg);
	uint8_t data60[] = {0x3F, 0xB0, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data60[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)12.0, VLD_TIME_MONTH);
	myProf->Create(*msg);
	uint8_t data61[] = {0x3F, 0xE0, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data61[0],&msg->data[0],5),0);

	// S_TIME - VLD_TIME_YEAR
	// Min
	myProf->SetValue(S_TIME,(float)0, VLD_TIME_YEAR);
	myProf->Create(*msg);
	uint8_t data62[] = {0x3F, 0xE0, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data62[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)2048, VLD_TIME_YEAR);
	myProf->Create(*msg);
	uint8_t data63[] = {0x3F, 0xE4, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data63[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)4095, VLD_TIME_YEAR);
	myProf->Create(*msg);
	uint8_t data64[] = {0x3F, 0xE7, 0xFF, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data64[0],&msg->data[0],5),0);

	// S_TIME - VLD_TIME_MINUTE
	// Min
	myProf->SetValue(S_TIME,(float)0, VLD_TIME_MINUTE);
	myProf->Create(*msg);
	uint8_t data65[] = {0x3F, 0xE7, 0xFF, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data65[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)30, VLD_TIME_MINUTE);
	myProf->Create(*msg);
	uint8_t data66[] = {0x3F, 0xE7, 0xFF, 0xBC, 0x00};
	EXPECT_EQ(memcmp(&data66[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)59, VLD_TIME_MINUTE);
	myProf->Create(*msg);
	uint8_t data67[] = {0x3F, 0xE7, 0xFF, 0xF6, 0x00};
	EXPECT_EQ(memcmp(&data67[0],&msg->data[0],5),0);

	// S_TIME - VLD_TIME_HOUR
	// Min
	myProf->SetValue(S_TIME,(float)0, VLD_TIME_HOUR);
	myProf->Create(*msg);
	uint8_t data68[] = {0x3F, 0xE7, 0xFF, 0xF6, 0x00};
	EXPECT_EQ(memcmp(&data68[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)12, VLD_TIME_HOUR);
	myProf->Create(*msg);
	uint8_t data69[] = {0x3F, 0xE7, 0xFF, 0xF6, 0xC0};
	EXPECT_EQ(memcmp(&data69[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)23, VLD_TIME_HOUR);
	myProf->Create(*msg);
	uint8_t data70[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x70};
	EXPECT_EQ(memcmp(&data70[0],&msg->data[0],5),0);

	// E_DAYS - VLD_TIME_DAY_WEEK
	// Enum - 0
	myProf->SetValue(E_DAYS,(uint8_t)0, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data71[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x70};
	EXPECT_EQ(memcmp(&data71[0],&msg->data[0],5),0);

	// Enum - 1
	myProf->SetValue(E_DAYS,(uint8_t)1, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data72[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x72};
	EXPECT_EQ(memcmp(&data72[0],&msg->data[0],5),0);

	// Enum - 2
	myProf->SetValue(E_DAYS,(uint8_t)2, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data73[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x74};
	EXPECT_EQ(memcmp(&data73[0],&msg->data[0],5),0);

	// Enum - 3
	myProf->SetValue(E_DAYS,(uint8_t)3, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data74[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x76};
	EXPECT_EQ(memcmp(&data74[0],&msg->data[0],5),0);

	// Enum - 4
	myProf->SetValue(E_DAYS,(uint8_t)4, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data75[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x78};
	EXPECT_EQ(memcmp(&data75[0],&msg->data[0],5),0);

	// Enum - 5
	myProf->SetValue(E_DAYS,(uint8_t)5, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data76[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x7A};
	EXPECT_EQ(memcmp(&data76[0],&msg->data[0],5),0);

	// Enum - 6
	myProf->SetValue(E_DAYS,(uint8_t)6, VLD_TIME_DAY_WEEK);
	myProf->Create(*msg);
	uint8_t data77[] = {0x3F, 0xE7, 0xFF, 0xF7, 0x7C};
	EXPECT_EQ(memcmp(&data77[0],&msg->data[0],5),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x08);

	// E_STATE - REQUEST_FRAME
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, REQUEST_FRAME);
	myProf->Create(*msg);
	uint8_t data78[] = {0x80, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data78[0],&msg->data[0],6),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, REQUEST_FRAME);
	myProf->Create(*msg);
	uint8_t data79[] = {0x81, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data79[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, REQUEST_FRAME);
	myProf->Create(*msg);
	uint8_t data80[] = {0x82, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data80[0],&msg->data[0],6),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3, REQUEST_FRAME);
	myProf->Create(*msg);
	uint8_t data81[] = {0x83, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data81[0],&msg->data[0],6),0);

	// Enum - 4
	myProf->SetValue(E_STATE,(uint8_t)4, REQUEST_FRAME);
	myProf->Create(*msg);
	uint8_t data82[] = {0x84, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data82[0],&msg->data[0],6),0);

	// Enum - 5
	myProf->SetValue(E_STATE,(uint8_t)15, REQUEST_FRAME);
	myProf->Create(*msg);
	uint8_t data83[] = {0x8F, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data83[0],&msg->data[0],6),0);

	// E_ERROR_STATE
	// Enum - 1
	myProf->SetValue(E_ERROR_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data84[] = {0x8F, 0x00, 0x01, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data84[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_ERROR_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data85[] = {0x8F, 0x00, 0x02, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data85[0],&msg->data[0],6),0);

	// Enum - 4
	myProf->SetValue(E_ERROR_STATE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data86[] = {0x8F, 0x00, 0x04, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data86[0],&msg->data[0],6),0);

	// Enum - 8
	myProf->SetValue(E_ERROR_STATE,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data87[] = {0x8F, 0x00, 0x08, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data87[0],&msg->data[0],6),0);

	// F_ON_OFF - HEATING_FLAG
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, HEATING_FLAG);
	myProf->Create(*msg);
	uint8_t data88[] = {0x8F, 0x00, 0x08, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data88[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, HEATING_FLAG);
	myProf->Create(*msg);
	uint8_t data89[] = {0x8F, 0x00, 0x08, 0x80, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data89[0],&msg->data[0],6),0);

	// E_STATE - PILOT_WIRE_FLAG
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, PILOT_WIRE_FLAG);
	myProf->Create(*msg);
	uint8_t data90[] = {0x8F, 0x00, 0x08, 0x80, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data90[0],&msg->data[0],6),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, PILOT_WIRE_FLAG);
	myProf->Create(*msg);
	uint8_t data91[] = {0x8F, 0x00, 0x08, 0xA0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data91[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, PILOT_WIRE_FLAG);
	myProf->Create(*msg);
	uint8_t data92[] = {0x8F, 0x00, 0x08, 0xC0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data92[0],&msg->data[0],6),0);

	// Enum - 3
	myProf->SetValue(E_STATE,(uint8_t)3, PILOT_WIRE_FLAG);
	myProf->Create(*msg);
	uint8_t data93[] = {0x8F, 0x00, 0x08, 0xE0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data93[0],&msg->data[0],6),0);

	// E_STATE - WINDOW_DETECTION_FLAG
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, WINDOW_DETECTION_FLAG);
	myProf->Create(*msg);
	uint8_t data94[] = {0x8F, 0x00, 0x08, 0xE0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data94[0],&msg->data[0],6),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, WINDOW_DETECTION_FLAG);
	myProf->Create(*msg);
	uint8_t data95[] = {0x8F, 0x00, 0x08, 0xE8, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data95[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, WINDOW_DETECTION_FLAG);
	myProf->Create(*msg);
	uint8_t data96[] = {0x8F, 0x00, 0x08, 0xF0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data96[0],&msg->data[0],6),0);

	// E_STATE - PIR_STATUS_DETECTION
	// Enum - 0
	myProf->SetValue(E_STATE,(uint8_t)0, PIR_STATUS_DETECTION);
	myProf->Create(*msg);
	uint8_t data97[] = {0x8F, 0x00, 0x08, 0xF0, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data97[0],&msg->data[0],6),0);

	// Enum - 1
	myProf->SetValue(E_STATE,(uint8_t)1, PIR_STATUS_DETECTION);
	myProf->Create(*msg);
	uint8_t data98[] = {0x8F, 0x00, 0x08, 0xF2, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data98[0],&msg->data[0],6),0);

	// Enum - 2
	myProf->SetValue(E_STATE,(uint8_t)2, PIR_STATUS_DETECTION);
	myProf->Create(*msg);
	uint8_t data99[] = {0x8F, 0x00, 0x08, 0xF4, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data99[0],&msg->data[0],6),0);

	// F_ON_OFF - REF_TEMP_FLAG
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, REF_TEMP_FLAG);
	myProf->Create(*msg);
	uint8_t data100[] = {0x8F, 0x00, 0x08, 0xF4, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data100[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, REF_TEMP_FLAG);
	myProf->Create(*msg);
	uint8_t data101[] = {0x8F, 0x00, 0x08, 0xF4, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data101[0],&msg->data[0],6),0);

	// F_ON_OFF - DEROGATION_FLAG
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0, DEROGATION_FLAG);
	myProf->Create(*msg);
	uint8_t data102[] = {0x8F, 0x00, 0x08, 0xF4, 0x80, 0x00};
	EXPECT_EQ(memcmp(&data102[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1, DEROGATION_FLAG);
	myProf->Create(*msg);
	uint8_t data103[] = {0x8F, 0x00, 0x08, 0xF4, 0xC0, 0x00};
	EXPECT_EQ(memcmp(&data103[0],&msg->data[0],6),0);

	// S_TEMP - INT_TEMPERATURE
	// Min
	myProf->SetValue(S_TEMP,(float)0.1, INT_TEMPERATURE);
	myProf->Create(*msg);
	uint8_t data104[] = {0x8F, 0x00, 0x08, 0xF4, 0xC0, 0x20};
	EXPECT_EQ(memcmp(&data104[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP,(float)25.0, INT_TEMPERATURE);
	myProf->Create(*msg);
	uint8_t data105[] = {0x8F, 0x00, 0x08, 0xF4, 0xDF, 0x20};
	EXPECT_EQ(memcmp(&data105[0],&msg->data[0],5),0);
	EXPECT_NEAR(data105[5],msg->data[5],0x40);
	// Max
	myProf->SetValue(S_TEMP,(float)50.0, INT_TEMPERATURE);
	myProf->Create(*msg);
	uint8_t data106[] = {0x8F, 0x00, 0x08, 0xF4, 0xFE, 0x80};
	EXPECT_EQ(memcmp(&data106[0],&msg->data[0],6),0);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x09);

	// S_TEMP - DEROGATION_TEMP_SETPOINT
	// Min
	myProf->SetValue(S_TEMP,(float)0.1, DEROGATION_TEMP_SETPOINT);
	myProf->Create(*msg);
	uint8_t data107[] = {0x90, 0x00, 0x00, 0x00, 0x08, 0x00};
	EXPECT_EQ(memcmp(&data107[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP,(float)25.0, DEROGATION_TEMP_SETPOINT);
	myProf->Create(*msg);
	uint8_t data108[] = {0x90, 0x00, 0x00, 0x07, 0xC8, 0x00};
	EXPECT_EQ(memcmp(&data108[0],&msg->data[0],4),0);
	//get temp raw value...
	uint32_t tmpValue=(msg->data[3] << 5) + (msg->data[4] >> 3);
	EXPECT_NEAR(tmpValue,250,1);
	// Max
	myProf->SetValue(S_TEMP,(float)50.0, DEROGATION_TEMP_SETPOINT);
	myProf->Create(*msg);
	uint8_t data109[] = {0x90, 0x00, 0x00, 0x0F, 0xA0, 0x00};
	EXPECT_EQ(memcmp(&data109[0],&msg->data[0],6),0);

	// S_VALUE - INT_TEMPERATURE
	// Min
	myProf->SetValue(S_VALUE,(float)0, FIRMWARE_VERSION);
	myProf->Create(*msg);
	uint8_t data110[] = {0x90, 0x00, 0x00, 0x0F, 0xA0, 0x00};
	EXPECT_EQ(memcmp(&data110[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_VALUE,(float)512, FIRMWARE_VERSION);
	myProf->Create(*msg);
	uint8_t data111[] = {0x90, 0x00, 0x00, 0x0F, 0xA3, 0xFE};
	EXPECT_EQ(memcmp(&data111[0],&msg->data[0],4),0);
	tmpValue=(((uint32_t)(msg->data[4]&0x07)) << 7) + (msg->data[5] >> 1);
	EXPECT_NEAR(tmpValue,512,1);
	// Max
	myProf->SetValue(S_VALUE,(float)1023, FIRMWARE_VERSION);
	myProf->Create(*msg);
	uint8_t data112[] = {0x90, 0x00, 0x00, 0x0F, 0xA7, 0xFE};
	EXPECT_EQ(memcmp(&data112[0],&msg->data[0],6),0);
}
