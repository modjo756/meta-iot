/*
 * ProfileD211Test.cpp
 *
 *  Created on: 01.09.2016
 *      Author: adam
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileD211xxTest: public ProfileFixture {
	/** */
protected:

	void Init(uint8_t type) {
		msg = new eoMessage(6);
		msg->RORG = RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x11, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileD211xxTest,eepD21101ControllerReceiveData) {
	/*uint8_t u8GetValue;
	 float fGetValue;

	 // Setup the test
	 Init(0x00);

	 ////////////////////////////////////////////////////////
	 // Start of General Message
	 ////////////////////////////////////////////////////////

	 // E_STATE - MSG_CONTINUATION
	 // Complete - 0
	 ParseRawDate({0x00, 0x00},2);
	 myProf->GetValue(E_STATE, u8GetValue, MSG_CONTINUATION);
	 EXPECT_EQ(0, u8GetValue);

	 // Incomplete - 1
	 ParseRawDate({0x01, 0x00},2);
	 myProf->GetValue(E_STATE, u8GetValue, MSG_CONTINUATION);
	 EXPECT_EQ(1, u8GetValue);

	 // Automatic message control - 2
	 ParseRawDate({0x02, 0x00},2);
	 myProf->GetValue(E_STATE, u8GetValue, MSG_CONTINUATION);
	 EXPECT_EQ(2, u8GetValue);


	 // S_RELHUM
	 // Min
	 ParseRawDate({0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},8);
	 myProf->GetValue(S_RELHUM, fGetValue);
	 EXPECT_NEAR(0, fGetValue, 0.9);

	 // Median
	 ParseRawDate({0x20, 0x7F, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},8);
	 myProf->GetValue(S_RELHUM, fGetValue);
	 EXPECT_NEAR(90, fGetValue, 0.9);

	 // Max
	 ParseRawDate({0x20, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},8);
	 myProf->GetValue(S_RELHUM, fGetValue);
	 EXPECT_NEAR(100, fGetValue, 0.9);*/
}

TEST_F(profileD211xxTest,eepD21101ControllerSendData)
{
	// Setup the test
	Init(0x01);

	////////////////////////////////////////////////////////
	// Start of Message Type A
	////////////////////////////////////////////////////////

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t) 0x00);

	// F_ON_OFF - SETPOINT_TYPE
	// Temperature correction - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data0[] = { 0x00 };
	EXPECT_EQ(memcmp(&data0[0], &msg->data[0], 1), 0);

	// Temperature setpoint - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data1[] = { 0x80 };
	EXPECT_EQ(memcmp(&data1[0], &msg->data[0], 1), 0);

	////////////////////////////////////////////////////////
	// End of Message Type A
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	// Start of Message Type B
	////////////////////////////////////////////////////////

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t) 0x01);

	// F_ON_OFF - SETPOINT_TYPE
	// Temperature correction - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data2[] = { 0x01, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data2[0], &msg->data[0], 4), 0);

	// Temperature setpoint - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data3[] = { 0x81, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data3[0], &msg->data[0], 4), 0);

	// F_ON_OFF - DISPLAY_HEATING_SYMBOL
	// Off - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, DISPLAY_HEATING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data4[] = { 0x81, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data4[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, DISPLAY_HEATING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data5[] = { 0xC1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data5[0], &msg->data[0], 4), 0);

	// F_ON_OFF - DISPLAY_COOLING_SYMBOL
	// Off - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, DISPLAY_COOLING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data6[] = { 0xC1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data6[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, DISPLAY_COOLING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data7[] = { 0xE1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data7[0], &msg->data[0], 4), 0);

	// F_ON_OFF - DISPLAY_WINDOW_OPEN_SYMBOL
	// Off - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, DISPLAY_WINDOW_OPEN_SYMBOL);
	myProf->Create(*msg);
	uint8_t data8[] = { 0xE1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data8[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, DISPLAY_WINDOW_OPEN_SYMBOL);
	myProf->Create(*msg);
	uint8_t data9[] = { 0xF1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data9[0], &msg->data[0], 4), 0);

	// S_TEMP - TEMP_CORRECTION
	// Need to set this so the limits are correct
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);

	// Min
	myProf->SetValue(S_TEMP, (float) -10.0, TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data10[] = { 0xF1, 0x00, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data10[0], &msg->data[0], 4), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 0, TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data11[] = { 0xF1, 0x7F, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data11[0], &msg->data[0], 4), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 10.0, TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data12[] = { 0xF1, 0xFF, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data12[0], &msg->data[0], 4), 0);

	// S_TEMP - TEMP_BASEPOINT
	// Min
	myProf->SetValue(S_TEMP, (float) 15, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data13[] = { 0xF1, 0xFF, 0x0F, 0xA0 };
	EXPECT_EQ(memcmp(&data13[0], &msg->data[0], 4), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 25, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data14[] = { 0xF1, 0xFF, 0x19, 0xA0 };
	EXPECT_EQ(memcmp(&data14[0], &msg->data[0], 4), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 30, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data15[] = { 0xF1, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data15[0], &msg->data[0], 4), 0);

	// E_STATE - VALID_TEMP_CORRECTION
	// -1...+1K - 1
	myProf->SetValue(E_STATE, (uint8_t) 1, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data16[] = { 0xF1, 0xFF, 0x1E, 0x10 };
	EXPECT_EQ(memcmp(&data16[0], &msg->data[0], 4), 0);

	// -2...+2K - 2
	myProf->SetValue(E_STATE, (uint8_t) 2, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data17[] = { 0xF1, 0xFF, 0x1E, 0x20 };
	EXPECT_EQ(memcmp(&data17[0], &msg->data[0], 4), 0);

	// -3...+3K - 3
	myProf->SetValue(E_STATE, (uint8_t) 3, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data18[] = { 0xF1, 0xFF, 0x1E, 0x30 };
	EXPECT_EQ(memcmp(&data18[0], &msg->data[0], 4), 0);

	// -4...+4K - 4
	myProf->SetValue(E_STATE, (uint8_t) 4, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data19[] = { 0xF1, 0xFF, 0x1E, 0x40 };
	EXPECT_EQ(memcmp(&data19[0], &msg->data[0], 4), 0);

	// -9...+9K - 9
	myProf->SetValue(E_STATE, (uint8_t) 9, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data20[] = { 0xF1, 0xFF, 0x1E, 0x90 };
	EXPECT_EQ(memcmp(&data20[0], &msg->data[0], 4), 0);

	// -6...+6K - 6
	myProf->SetValue(E_STATE, (uint8_t) 6, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data21[] = { 0xF1, 0xFF, 0x1E, 0x60 };
	EXPECT_EQ(memcmp(&data21[0], &msg->data[0], 4), 0);

	// -7...+7K - 7
	myProf->SetValue(E_STATE, (uint8_t) 7, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data22[] = { 0xF1, 0xFF, 0x1E, 0x70 };
	EXPECT_EQ(memcmp(&data22[0], &msg->data[0], 4), 0);

	// -8...+8K - 8
	myProf->SetValue(E_STATE, (uint8_t) 8, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data23[] = { 0xF1, 0xFF, 0x1E, 0x80 };
	EXPECT_EQ(memcmp(&data23[0], &msg->data[0], 4), 0);

	// -9...+9K - 9
	myProf->SetValue(E_STATE, (uint8_t) 9, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data24[] = { 0xF1, 0xFF, 0x1E, 0x90 };
	EXPECT_EQ(memcmp(&data24[0], &msg->data[0], 4), 0);

	// -10...+10K - 10
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data25[] = { 0xF1, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data25[0], &msg->data[0], 4), 0);

	// E_FANSPEED
	// Auto - 0
	myProf->SetValue(E_FANSPEED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data26[] = { 0xF1, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data26[0], &msg->data[0], 4), 0);

	// Speed 0 - 1
	myProf->SetValue(E_FANSPEED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data27[] = { 0xF1, 0xFF, 0x1E, 0xA2 };
	EXPECT_EQ(memcmp(&data27[0], &msg->data[0], 4), 0);

	// Speed 1 - 2
	myProf->SetValue(E_FANSPEED, (uint8_t) 2);
	myProf->Create(*msg);
	uint8_t data28[] = { 0xF1, 0xFF, 0x1E, 0xA4 };
	EXPECT_EQ(memcmp(&data28[0], &msg->data[0], 4), 0);

	// Speed 2 - 3
	myProf->SetValue(E_FANSPEED, (uint8_t) 3);
	myProf->Create(*msg);
	uint8_t data29[] = { 0xF1, 0xFF, 0x1E, 0xA6 };
	EXPECT_EQ(memcmp(&data29[0], &msg->data[0], 4), 0);

	// Speed 3 - 4
	myProf->SetValue(E_FANSPEED, (uint8_t) 4);
	myProf->Create(*msg);
	uint8_t data30[] = { 0xF1, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data30[0], &msg->data[0], 4), 0);

	// F_OCCUPIED
	// Off - 0
	myProf->SetValue(F_OCCUPIED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data31[] = { 0xF1, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data31[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_OCCUPIED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data32[] = { 0xF1, 0xFF, 0x1E, 0xA9 };
	EXPECT_EQ(memcmp(&data32[0], &msg->data[0], 4), 0);

	////////////////////////////////////////////////////////
	// End of Message Type B
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	// Start of Message Type C
	////////////////////////////////////////////////////////

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t) 0x02);

	// F_ON_OFF - SETPOINT_TYPE
	// Temperature correction - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data33[] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data33[0], &msg->data[0], 6), 0);

	// Temperature setpoint - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data34[] = { 0x82, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data34[0], &msg->data[0], 6), 0);

	// E_STATE - TEL_TYPE
	// Off - 0
	myProf->SetValue(E_STATE, (uint8_t) 0, TEL_TYPE);
	myProf->Create(*msg);
	uint8_t data35[] = { 0x82, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data35[0], &msg->data[0], 6), 0);

	// On - 1
	myProf->SetValue(E_STATE, (uint8_t) 1, TEL_TYPE);
	myProf->Create(*msg);
	uint8_t data36[] = { 0xA2, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data36[0], &msg->data[0], 6), 0);

	// On - 1
	myProf->SetValue(E_STATE, (uint8_t) 2, TEL_TYPE);
	myProf->Create(*msg);
	uint8_t data37[] = { 0xC2, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data37[0], &msg->data[0], 6), 0);

	// S_TEMP - TEMP_NORMAL
	// Min
	myProf->SetValue(S_TEMP, (float) 0.0, TEMP_NORMAL);
	myProf->Create(*msg);
	uint8_t data38[] = { 0xC2, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data38[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 20, TEMP_NORMAL);
	myProf->Create(*msg);
	uint8_t data39[] = { 0xC2, 0x7F, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data39[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 40.0, TEMP_NORMAL);
	myProf->Create(*msg);
	uint8_t data40[] = { 0xC2, 0xFF, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data40[0], &msg->data[0], 6), 0);

	// S_RELHUM
	// Min
	myProf->SetValue(S_RELHUM, (float) 0.0);
	myProf->Create(*msg);
	uint8_t data41[] = { 0xC2, 0xFF, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data41[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_RELHUM, (float) 50);
	myProf->Create(*msg);
	uint8_t data42[] = { 0xC2, 0xFF, 0x7D, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data42[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_RELHUM, (float) 100.0);
	myProf->Create(*msg);
	uint8_t data43[] = { 0xC2, 0xFF, 0xFA, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data43[0], &msg->data[0], 6), 0);

	// S_VALUE
	// Need to set this so the limits are correct
	EXPECT_EQ(0x00,myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION));

	// Min
	EXPECT_EQ(0x00,myProf->SetValue(S_VALUE, (float) -10.0));
	uint8_t temperature;
	myProf->GetValue(E_STATE, temperature, (uint8_t)VALID_TEMP_CORRECTION);
	EXPECT_EQ(10.0,temperature);
	myProf->Create(*msg);
	uint8_t data44[] = { 0xC2, 0xFF, 0xFA, 0x00, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data44[0], &msg->data[0], 6), 0);

	// Median
	EXPECT_EQ(0x00,myProf->SetValue(S_VALUE, (float) 0));
	myProf->Create(*msg);
	uint8_t data45[] = { 0xC2, 0xFF, 0xFA, 0x7F, 0x00, 0xA0 };
	for(uint8_t i=0;i<sizeof(data45);i++)
	{
		EXPECT_EQ(data45[i], msg->data[i]);
	}


	// Max
	EXPECT_EQ(0x00,myProf->SetValue(S_VALUE, (float) 10.0));
	myProf->Create(*msg);
	uint8_t data46[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data46[0], &msg->data[0], 6), 0);

	// S_TEMP - TEMP_BASEPOINT
	// Min
	myProf->SetValue(S_TEMP, (float) 15, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data47[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x0F, 0xA0 };
	EXPECT_EQ(memcmp(&data47[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 25, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data48[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x19, 0xA0 };
	EXPECT_EQ(memcmp(&data48[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 30, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data49[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data49[0], &msg->data[0], 6), 0);

	// E_STATE - VALID_TEMP_CORRECTION
	// -1...+1K - 1
	myProf->SetValue(E_STATE, (uint8_t) 1, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data50[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x10 };
	EXPECT_EQ(memcmp(&data50[0], &msg->data[0], 6), 0);

	// -2...+2K - 2
	myProf->SetValue(E_STATE, (uint8_t) 2, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data51[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x20 };
	EXPECT_EQ(memcmp(&data51[0], &msg->data[0], 6), 0);

	// -3...+3K - 3
	myProf->SetValue(E_STATE, (uint8_t) 3, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data52[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x30 };
	EXPECT_EQ(memcmp(&data52[0], &msg->data[0], 6), 0);

	// -4...+4K - 4
	myProf->SetValue(E_STATE, (uint8_t) 4, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data53[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x40 };
	EXPECT_EQ(memcmp(&data53[0], &msg->data[0], 6), 0);

	// -5...+5K - 5
	myProf->SetValue(E_STATE, (uint8_t) 5, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data54[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x50 };
	EXPECT_EQ(memcmp(&data54[0], &msg->data[0], 6), 0);

	// -6...+6K - 6
	myProf->SetValue(E_STATE, (uint8_t) 6, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data55[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x60 };
	EXPECT_EQ(memcmp(&data55[0], &msg->data[0], 6), 0);

	// -7...+7K - 7
	myProf->SetValue(E_STATE, (uint8_t) 7, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data56[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x70 };
	EXPECT_EQ(memcmp(&data56[0], &msg->data[0], 6), 0);

	// -8...+8K - 8
	myProf->SetValue(E_STATE, (uint8_t) 8, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data57[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x80 };
	EXPECT_EQ(memcmp(&data57[0], &msg->data[0], 6), 0);

	// -9...+9K - 9
	myProf->SetValue(E_STATE, (uint8_t) 9, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data58[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x90 };
	EXPECT_EQ(memcmp(&data58[0], &msg->data[0], 6), 0);

	// -10...+10K - 10
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data59[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data59[0], &msg->data[0], 6), 0);

	// E_FANSPEED
	// Auto - 0
	myProf->SetValue(E_FANSPEED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data60[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data60[0], &msg->data[0], 6), 0);

	// Speed 0 - 1
	myProf->SetValue(E_FANSPEED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data61[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA2 };
	EXPECT_EQ(memcmp(&data61[0], &msg->data[0], 6), 0);

	// Speed 1 - 2
	myProf->SetValue(E_FANSPEED, (uint8_t) 2);
	myProf->Create(*msg);
	uint8_t data62[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA4 };
	EXPECT_EQ(memcmp(&data62[0], &msg->data[0], 6), 0);

	// Speed 2 - 3
	myProf->SetValue(E_FANSPEED, (uint8_t) 3);
	myProf->Create(*msg);
	uint8_t data63[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA6 };
	EXPECT_EQ(memcmp(&data63[0], &msg->data[0], 6), 0);

	// Speed 3 - 4
	myProf->SetValue(E_FANSPEED, (uint8_t) 4);
	myProf->Create(*msg);
	uint8_t data64[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data64[0], &msg->data[0], 6), 0);

	// F_OCCUPIED
	// Off - 0
	myProf->SetValue(F_OCCUPIED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data65[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data65[0], &msg->data[0], 6), 0);

	// On - 1
	myProf->SetValue(F_OCCUPIED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data66[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA9 };
	EXPECT_EQ(memcmp(&data66[0], &msg->data[0], 6), 0);


	////////////////////////////////////////////////////////
	// End of Message Type C
	////////////////////////////////////////////////////////
}

TEST_F(profileD211xxTest,eepD21106ControllerReceiveData) {
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	////////////////////////////////////////////////////////
	// Start of Message Type A
	////////////////////////////////////////////////////////

	// F_ON_OFF - SETPOINT_TYPE
	// Complete - 0
	ParseRawDate( { 0x00 }, 1);

	myProf->GetValue(F_ON_OFF, u8GetValue, SETPOINT_TYPE);
	EXPECT_EQ(0, u8GetValue);

	// Incomplete - 1
	ParseRawDate( { 0x80 }, 1);
	myProf->GetValue(F_ON_OFF, u8GetValue, SETPOINT_TYPE);
	EXPECT_EQ(1, u8GetValue);

	////////////////////////////////////////////////////////
	// End of Message Type A
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	// Start of Message Type B
	////////////////////////////////////////////////////////

	// F_ON_OFF - SETPOINT_TYPE
	// Temp correction - 0
	ParseRawDate( { 0x01, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SETPOINT_TYPE);
	EXPECT_EQ(0, u8GetValue);

	// Temp setpoint - 1
	ParseRawDate( { 0x81, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, SETPOINT_TYPE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - DISPLAY_HEATING_SYMBOL
	// Off - 0
	ParseRawDate( { 0x01, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DISPLAY_HEATING_SYMBOL);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate( { 0x41, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DISPLAY_HEATING_SYMBOL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - DISPLAY_COOLING_SYMBOL
	// Off - 0
	ParseRawDate( { 0x01, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DISPLAY_COOLING_SYMBOL);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate( { 0x21, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DISPLAY_COOLING_SYMBOL);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - DISPLAY_WINDOW_OPEN_SYMBOL
	// Off - 0
	ParseRawDate( { 0x01, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DISPLAY_WINDOW_OPEN_SYMBOL);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate( { 0x11, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_ON_OFF, u8GetValue, DISPLAY_WINDOW_OPEN_SYMBOL);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP - TEMP_CORRECTION
	// Min
	ParseRawDate( { 0x01, 0x00, 0x00, 0xA0 }, 4);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_CORRECTION);
	EXPECT_NEAR(-10, fGetValue, 0.9);

	// Median
	ParseRawDate( { 0x01, 0x7F, 0x00, 0xA0 }, 4);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_CORRECTION);
	EXPECT_NEAR(0, fGetValue, 0.9);

	// Max
	ParseRawDate( { 0x01, 0xFF, 0x00, 0xA0 }, 4);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_CORRECTION);
	EXPECT_NEAR(10, fGetValue, 0.9);

	// S_TEMP - TEMP_BASEPOINT
	// Min
	ParseRawDate( { 0x01, 0x00, 0x0F, 0x00 }, 4);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_BASEPOINT);
	EXPECT_NEAR(15, fGetValue, 0.9);

	// Median
	ParseRawDate( { 0x01, 0x00, 0x19, 0x00 }, 4);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_BASEPOINT);
	EXPECT_NEAR(25, fGetValue, 0.9);

	// Max
	ParseRawDate( { 0x01, 0x00, 0x1E, 0x00 }, 4);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_BASEPOINT);
	EXPECT_NEAR(30, fGetValue, 0.9);

	// E_STATE - VALID_TEMP_CORRECTION
	// -1...+1K - 1
	ParseRawDate( { 0x01, 0x00, 0x00, 0x10 }, 4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(1, u8GetValue);

	// -2...+2K - 2
	ParseRawDate( { 0x01, 0x00, 0x00, 0x20 }, 4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(2, u8GetValue);

	// -3...+3K - 3
	ParseRawDate( { 0x01, 0x00, 0x00, 0x30 }, 4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(3, u8GetValue);

	// -4...+4K - 4
	ParseRawDate( { 0x01, 0x00, 0x00, 0x40 }, 4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(4, u8GetValue);

	// -5...+5K - 5
	ParseRawDate( { 0x01, 0x00, 0x00, 0x90 }, 4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(9, u8GetValue);

	// -6...+6K - 6
	ParseRawDate({0x01, 0x00, 0x00, 0x60},4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(6, u8GetValue);

	// -7...+7K - 7
	ParseRawDate({0x01, 0x00, 0x00, 0x70},4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(7, u8GetValue);

	// -8...+8K - 8
	ParseRawDate({0x01, 0x00, 0x00, 0x80},4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(8, u8GetValue);

	// -9...+9K - 9
	ParseRawDate({0x01, 0x00, 0x00, 0x90},4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(9, u8GetValue);

	// -10...+10K - 10
	ParseRawDate({0x01, 0x00, 0x00, 0xA0},4);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(10, u8GetValue);

	// E_FANSPEED
	// Auto - 0
	ParseRawDate( { 0x01, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Speed 0 - 1
	ParseRawDate( { 0x01, 0x00, 0x00, 0x02 }, 4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Speed 1 - 2
	ParseRawDate( { 0x01, 0x00, 0x00, 0x04 }, 4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Speed 2 - 3
	ParseRawDate( { 0x01, 0x00, 0x00, 0x06 }, 4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Speed 3 - 4
	ParseRawDate( { 0x01, 0x00, 0x00, 0x08 }, 4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// F_OCCUPIED
	// Off - 0
	ParseRawDate( { 0x01, 0x00, 0x00, 0x00 }, 4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate( { 0x01, 0x00, 0x00, 0x01 }, 4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	////////////////////////////////////////////////////////
	// End of Message Type B
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	// Start of Message Type C
	////////////////////////////////////////////////////////

	// F_ON_OFF - SETPOINT_TYPE
	// Temp correction - 0
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(F_ON_OFF, u8GetValue, SETPOINT_TYPE);
	EXPECT_EQ(0, u8GetValue);

	// Temp setpoint - 1
	ParseRawDate( { 0x82, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(F_ON_OFF, u8GetValue, SETPOINT_TYPE);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE - TEL_TYPE
	// Heartbeat - 0
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, TEL_TYPE);
	EXPECT_EQ(0, u8GetValue);

	// Change of temp or relhum - 1
	ParseRawDate( { 0x22, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, TEL_TYPE);
	EXPECT_EQ(1, u8GetValue);

	// User caused - 2
	ParseRawDate( { 0x42, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, TEL_TYPE);
	EXPECT_EQ(2, u8GetValue);

	// S_TEMP - TEMP_NORMAL
	// Min
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_NORMAL);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate( { 0x02, 0x7F, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_NORMAL);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate( { 0x02, 0xFF, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_NORMAL);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// S_RELHUM
	// Min
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate( { 0x02, 0x00,0x7D,  0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate( { 0x02, 0x00, 0xFA, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_VALUE
	// Min
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0xA0 }, 6);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(-10, fGetValue, 0.5);

	// Median
	ParseRawDate( { 0x02, 0x00, 0x00, 0x7F, 0x00, 0xA0 }, 6);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Max
	ParseRawDate( { 0x02, 0x00, 0x00, 0xFF, 0x00, 0xA0 }, 6);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(10, fGetValue, 0.5);

	// S_TEMP - TEMP_BASEPOINT
	// Min
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x0F, 0x00 }, 6);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_BASEPOINT);
	EXPECT_NEAR(15, fGetValue, 0.9);

	// Median
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x19, 0x00 }, 6);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_BASEPOINT);
	EXPECT_NEAR(25, fGetValue, 0.9);

	// Max
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x1E, 0x00 }, 6);
	myProf->GetValue(S_TEMP, fGetValue, TEMP_BASEPOINT);
	EXPECT_NEAR(30, fGetValue, 0.9);

	// E_STATE - VALID_TEMP_CORRECTION
	// -1...+1K - 1
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x10 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(1, u8GetValue);

	// -2...+2K - 2
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x20 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(2, u8GetValue);

	// -3...+3K - 3
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x30 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(3, u8GetValue);

	// -4...+4K - 4
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x40 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(4, u8GetValue);

	// -5...+5K - 5
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x50 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(5, u8GetValue);

	// -6...+6K - 6
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x60 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(6, u8GetValue);

	// -7...+7K - 7
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x70 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(7, u8GetValue);

	// -8...+8K - 8
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x80 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(8, u8GetValue);

	// -9...+9K - 9
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x90 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(9, u8GetValue);

	// -10...+10K - 10
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0xA0 }, 6);
	myProf->GetValue(E_STATE, u8GetValue, VALID_TEMP_CORRECTION);
	EXPECT_EQ(10, u8GetValue);

	// E_FANSPEED
	// Auto - 0
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Speed 0 - 1
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x02 }, 6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Speed 1 - 2
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x04 }, 6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Speed 2 - 3
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x06 }, 6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Speed 3 - 4
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x08 }, 6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// F_OCCUPIED
	// Off - 0
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 }, 6);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// On - 1
	ParseRawDate( { 0x02, 0x00, 0x00, 0x00, 0x00, 0x01 }, 6);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	////////////////////////////////////////////////////////
	// End of Message Type C
	////////////////////////////////////////////////////////
}

TEST_F(profileD211xxTest,eepD21106ControllerSendData)
{
	// Setup the test
	Init(0x06);

	////////////////////////////////////////////////////////
	// Start of Message Type A
	////////////////////////////////////////////////////////

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t) 0x00);

	// F_ON_OFF - SETPOINT_TYPE
	// Temperature correction - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data0[] = { 0x00 };
	EXPECT_EQ(memcmp(&data0[0], &msg->data[0], 1), 0);

	// Temperature setpoint - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data1[] = { 0x80 };
	EXPECT_EQ(memcmp(&data1[0], &msg->data[0], 1), 0);

	////////////////////////////////////////////////////////
	// End of Message Type A
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	// Start of Message Type B
	////////////////////////////////////////////////////////

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t) 0x01);

	// F_ON_OFF - SETPOINT_TYPE
	// Temperature correction - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data2[] = { 0x01, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data2[0], &msg->data[0], 4), 0);

	// Temperature setpoint - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data3[] = { 0x81, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data3[0], &msg->data[0], 4), 0);

	// F_ON_OFF - DISPLAY_HEATING_SYMBOL
	// Off - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, DISPLAY_HEATING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data4[] = { 0x81, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data4[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, DISPLAY_HEATING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data5[] = { 0xC1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data5[0], &msg->data[0], 4), 0);

	// F_ON_OFF - DISPLAY_COOLING_SYMBOL
	// Off - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, DISPLAY_COOLING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data6[] = { 0xC1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data6[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, DISPLAY_COOLING_SYMBOL);
	myProf->Create(*msg);
	uint8_t data7[] = { 0xE1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data7[0], &msg->data[0], 4), 0);

	// F_ON_OFF - DISPLAY_WINDOW_OPEN_SYMBOL
	// Off - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, DISPLAY_WINDOW_OPEN_SYMBOL);
	myProf->Create(*msg);
	uint8_t data8[] = { 0xE1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data8[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, DISPLAY_WINDOW_OPEN_SYMBOL);
	myProf->Create(*msg);
	uint8_t data9[] = { 0xF1, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data9[0], &msg->data[0], 4), 0);

	// S_TEMP - TEMP_CORRECTION
	// Need to set this so the limits are correct
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);

	// Min
	myProf->SetValue(S_TEMP, (float) -10.0, TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data10[] = { 0xF1, 0x00, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data10[0], &msg->data[0], 4), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 0, TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data11[] = { 0xF1, 0x7F, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data11[0], &msg->data[0], 4), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 10.0, TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data12[] = { 0xF1, 0xFF, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data12[0], &msg->data[0], 4), 0);

	// S_TEMP - TEMP_BASEPOINT
	// Min
	myProf->SetValue(S_TEMP, (float) 15, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data13[] = { 0xF1, 0xFF, 0x0F, 0xA0 };
	EXPECT_EQ(memcmp(&data13[0], &msg->data[0], 4), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 25, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data14[] = { 0xF1, 0xFF, 0x19, 0xA0 };
	EXPECT_EQ(memcmp(&data14[0], &msg->data[0], 4), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 30, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data15[] = { 0xF1, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data15[0], &msg->data[0], 4), 0);

	// E_STATE - VALID_TEMP_CORRECTION
	// -1...+1K - 1
	myProf->SetValue(E_STATE, (uint8_t) 1, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data16[] = { 0xF1, 0xFF, 0x1E, 0x10 };
	EXPECT_EQ(memcmp(&data16[0], &msg->data[0], 4), 0);

	// -2...+2K - 2
	myProf->SetValue(E_STATE, (uint8_t) 2, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data17[] = { 0xF1, 0xFF, 0x1E, 0x20 };
	EXPECT_EQ(memcmp(&data17[0], &msg->data[0], 4), 0);

	// -3...+3K - 3
	myProf->SetValue(E_STATE, (uint8_t) 3, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data18[] = { 0xF1, 0xFF, 0x1E, 0x30 };
	EXPECT_EQ(memcmp(&data18[0], &msg->data[0], 4), 0);

	// -4...+4K - 4
	myProf->SetValue(E_STATE, (uint8_t) 4, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data19[] = { 0xF1, 0xFF, 0x1E, 0x40 };
	EXPECT_EQ(memcmp(&data19[0], &msg->data[0], 4), 0);

	// -9...+9K - 9
	myProf->SetValue(E_STATE, (uint8_t) 9, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data20[] = { 0xF1, 0xFF, 0x1E, 0x90 };
	EXPECT_EQ(memcmp(&data20[0], &msg->data[0], 4), 0);

	// -6...+6K - 6
	myProf->SetValue(E_STATE, (uint8_t) 6, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data21[] = { 0xF1, 0xFF, 0x1E, 0x60 };
	EXPECT_EQ(memcmp(&data21[0], &msg->data[0], 4), 0);

	// -7...+7K - 7
	myProf->SetValue(E_STATE, (uint8_t) 7, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data22[] = { 0xF1, 0xFF, 0x1E, 0x70 };
	EXPECT_EQ(memcmp(&data22[0], &msg->data[0], 4), 0);

	// -8...+8K - 8
	myProf->SetValue(E_STATE, (uint8_t) 8, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data23[] = { 0xF1, 0xFF, 0x1E, 0x80 };
	EXPECT_EQ(memcmp(&data23[0], &msg->data[0], 4), 0);

	// -9...+9K - 9
	myProf->SetValue(E_STATE, (uint8_t) 9, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data24[] = { 0xF1, 0xFF, 0x1E, 0x90 };
	EXPECT_EQ(memcmp(&data24[0], &msg->data[0], 4), 0);

	// -10...+10K - 10
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data25[] = { 0xF1, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data25[0], &msg->data[0], 4), 0);

	// E_FANSPEED
	// Auto - 0
	myProf->SetValue(E_FANSPEED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data26[] = { 0xF1, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data26[0], &msg->data[0], 4), 0);

	// Speed 0 - 1
	myProf->SetValue(E_FANSPEED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data27[] = { 0xF1, 0xFF, 0x1E, 0xA2 };
	EXPECT_EQ(memcmp(&data27[0], &msg->data[0], 4), 0);

	// Speed 1 - 2
	myProf->SetValue(E_FANSPEED, (uint8_t) 2);
	myProf->Create(*msg);
	uint8_t data28[] = { 0xF1, 0xFF, 0x1E, 0xA4 };
	EXPECT_EQ(memcmp(&data28[0], &msg->data[0], 4), 0);

	// Speed 2 - 3
	myProf->SetValue(E_FANSPEED, (uint8_t) 3);
	myProf->Create(*msg);
	uint8_t data29[] = { 0xF1, 0xFF, 0x1E, 0xA6 };
	EXPECT_EQ(memcmp(&data29[0], &msg->data[0], 4), 0);

	// Speed 3 - 4
	myProf->SetValue(E_FANSPEED, (uint8_t) 4);
	myProf->Create(*msg);
	uint8_t data30[] = { 0xF1, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data30[0], &msg->data[0], 4), 0);

	// F_OCCUPIED
	// Off - 0
	myProf->SetValue(F_OCCUPIED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data31[] = { 0xF1, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data31[0], &msg->data[0], 4), 0);

	// On - 1
	myProf->SetValue(F_OCCUPIED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data32[] = { 0xF1, 0xFF, 0x1E, 0xA9 };
	EXPECT_EQ(memcmp(&data32[0], &msg->data[0], 4), 0);

	////////////////////////////////////////////////////////
	// End of Message Type B
	////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////
	// Start of Message Type C
	////////////////////////////////////////////////////////

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t) 0x02);

	// F_ON_OFF - SETPOINT_TYPE
	// Temperature correction - 0
	myProf->SetValue(F_ON_OFF, (uint8_t) 0, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data33[] = { 0x02, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data33[0], &msg->data[0], 6), 0);

	// Temperature setpoint - 1
	myProf->SetValue(F_ON_OFF, (uint8_t) 1, SETPOINT_TYPE);
	myProf->Create(*msg);
	uint8_t data34[] = { 0x82, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data34[0], &msg->data[0], 6), 0);

	// E_STATE - TEL_TYPE
	// Off - 0
	myProf->SetValue(E_STATE, (uint8_t) 0, TEL_TYPE);
	myProf->Create(*msg);
	uint8_t data35[] = { 0x82, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data35[0], &msg->data[0], 6), 0);

	// On - 1
	myProf->SetValue(E_STATE, (uint8_t) 1, TEL_TYPE);
	myProf->Create(*msg);
	uint8_t data36[] = { 0xA2, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data36[0], &msg->data[0], 6), 0);

	// On - 1
	myProf->SetValue(E_STATE, (uint8_t) 2, TEL_TYPE);
	myProf->Create(*msg);
	uint8_t data37[] = { 0xC2, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data37[0], &msg->data[0], 6), 0);

	// S_TEMP - TEMP_NORMAL
	// Min
	myProf->SetValue(S_TEMP, (float) 0.0, TEMP_NORMAL);
	myProf->Create(*msg);
	uint8_t data38[] = { 0xC2, 0x00, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data38[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 20, TEMP_NORMAL);
	myProf->Create(*msg);
	uint8_t data39[] = { 0xC2, 0x7F, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data39[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 40.0, TEMP_NORMAL);
	myProf->Create(*msg);
	uint8_t data40[] = { 0xC2, 0xFF, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data40[0], &msg->data[0], 6), 0);

	// S_RELHUM
	// Min
	myProf->SetValue(S_RELHUM, (float) 0.0);
	myProf->Create(*msg);
	uint8_t data41[] = { 0xC2, 0xFF, 0x00, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data41[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_RELHUM, (float) 50);
	myProf->Create(*msg);
	uint8_t data42[] = { 0xC2, 0xFF, 0x7D, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data42[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_RELHUM, (float) 100.0);
	myProf->Create(*msg);
	uint8_t data43[] = { 0xC2, 0xFF, 0xFA, 0x00, 0x00, 0x00 };
	EXPECT_EQ(memcmp(&data43[0], &msg->data[0], 6), 0);

	// S_VALUE
	// Need to set this so the limits are correct
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);

	// Min
	myProf->SetValue(S_VALUE, (float) -10.0);
	myProf->Create(*msg);
	uint8_t data44[] = { 0xC2, 0xFF, 0xFA, 0x00, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data44[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_VALUE, (float) 0);
	myProf->Create(*msg);
	uint8_t data45[] = { 0xC2, 0xFF, 0xFA, 0x7F, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data45[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_VALUE, (float) 10.0);
	myProf->Create(*msg);
	uint8_t data46[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x00, 0xA0 };
	EXPECT_EQ(memcmp(&data46[0], &msg->data[0], 6), 0);

	// S_TEMP - TEMP_BASEPOINT
	// Min
	myProf->SetValue(S_TEMP, (float) 15, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data47[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x0F, 0xA0 };
	EXPECT_EQ(memcmp(&data47[0], &msg->data[0], 6), 0);

	// Median
	myProf->SetValue(S_TEMP, (float) 25, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data48[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x19, 0xA0 };
	EXPECT_EQ(memcmp(&data48[0], &msg->data[0], 6), 0);

	// Max
	myProf->SetValue(S_TEMP, (float) 30, TEMP_BASEPOINT);
	myProf->Create(*msg);
	uint8_t data49[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data49[0], &msg->data[0], 6), 0);

	// E_STATE - VALID_TEMP_CORRECTION
	// -1...+1K - 1
	myProf->SetValue(E_STATE, (uint8_t) 1, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data50[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x10 };
	EXPECT_EQ(memcmp(&data50[0], &msg->data[0], 6), 0);

	// -2...+2K - 2
	myProf->SetValue(E_STATE, (uint8_t) 2, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data51[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x20 };
	EXPECT_EQ(memcmp(&data51[0], &msg->data[0], 6), 0);

	// -3...+3K - 3
	myProf->SetValue(E_STATE, (uint8_t) 3, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data52[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x30 };
	EXPECT_EQ(memcmp(&data52[0], &msg->data[0], 6), 0);

	// -4...+4K - 4
	myProf->SetValue(E_STATE, (uint8_t) 4, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data53[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x40 };
	EXPECT_EQ(memcmp(&data53[0], &msg->data[0], 6), 0);

	// -5...+5K - 5
	myProf->SetValue(E_STATE, (uint8_t) 5, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data54[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x50 };
	EXPECT_EQ(memcmp(&data54[0], &msg->data[0], 6), 0);

	// -6...+6K - 6
	myProf->SetValue(E_STATE, (uint8_t) 6, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data55[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x60 };
	EXPECT_EQ(memcmp(&data55[0], &msg->data[0], 6), 0);

	// -7...+7K - 7
	myProf->SetValue(E_STATE, (uint8_t) 7, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data56[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x70 };
	EXPECT_EQ(memcmp(&data56[0], &msg->data[0], 6), 0);

	// -8...+8K - 8
	myProf->SetValue(E_STATE, (uint8_t) 8, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data57[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x80 };
	EXPECT_EQ(memcmp(&data57[0], &msg->data[0], 6), 0);

	// -9...+9K - 9
	myProf->SetValue(E_STATE, (uint8_t) 9, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data58[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0x90 };
	EXPECT_EQ(memcmp(&data58[0], &msg->data[0], 6), 0);

	// -10...+10K - 10
	myProf->SetValue(E_STATE, (uint8_t) 10, VALID_TEMP_CORRECTION);
	myProf->Create(*msg);
	uint8_t data59[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data59[0], &msg->data[0], 6), 0);

	// E_FANSPEED
	// Auto - 0
	myProf->SetValue(E_FANSPEED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data60[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA0 };
	EXPECT_EQ(memcmp(&data60[0], &msg->data[0], 6), 0);

	// Speed 0 - 1
	myProf->SetValue(E_FANSPEED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data61[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA2 };
	EXPECT_EQ(memcmp(&data61[0], &msg->data[0], 6), 0);

	// Speed 1 - 2
	myProf->SetValue(E_FANSPEED, (uint8_t) 2);
	myProf->Create(*msg);
	uint8_t data62[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA4 };
	EXPECT_EQ(memcmp(&data62[0], &msg->data[0], 6), 0);

	// Speed 2 - 3
	myProf->SetValue(E_FANSPEED, (uint8_t) 3);
	myProf->Create(*msg);
	uint8_t data63[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA6 };
	EXPECT_EQ(memcmp(&data63[0], &msg->data[0], 6), 0);

	// Speed 3 - 4
	myProf->SetValue(E_FANSPEED, (uint8_t) 4);
	myProf->Create(*msg);
	uint8_t data64[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data64[0], &msg->data[0], 6), 0);

	// F_OCCUPIED
	// Off - 0
	myProf->SetValue(F_OCCUPIED, (uint8_t) 0);
	myProf->Create(*msg);
	uint8_t data65[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA8 };
	EXPECT_EQ(memcmp(&data65[0], &msg->data[0], 6), 0);

	// On - 1
	myProf->SetValue(F_OCCUPIED, (uint8_t) 1);
	myProf->Create(*msg);
	uint8_t data66[] = { 0xC2, 0xFF, 0xFA, 0xFF, 0x1E, 0xA9 };
	EXPECT_EQ(memcmp(&data66[0], &msg->data[0], 6), 0);


	////////////////////////////////////////////////////////
	// End of Message Type C
	////////////////////////////////////////////////////////
}
