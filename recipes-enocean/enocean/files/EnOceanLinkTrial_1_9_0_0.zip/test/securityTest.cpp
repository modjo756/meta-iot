/*
 * deviceTest.cpp
 *
 *  Created on: 27.06.2012
 *      Author: tobias
 */
#include <gtest/gtest.h>
#include "eoLink.h"
#include "GatewayFixture.h"
const uint8_t pskVector[16] ={0x54,0x6F,0x62,0x69,0x20,0x52,0x6F,0x63,0x6B,0x74,0x20,0x50,0x53,0x4B,0x21,0x00};
const uint8_t keyVector[16] ={0x45,0x6E,0x4F,0x63,0x65,0x61,0x6E,0x20,0x47,0x6D,0x62,0x48,0x2E,0x31,0x33,0x00};
const uint8_t expectedTeachMessage[] = {0x08,0x8B,0xA0,0x48,0x4E,0xC6,0xE0,0xC5,0x7E,0x1A,0xA9,0x91,0x9D,0xE0,0x60,0x4A,0x88,0x30,0xCB,0xC0,0x2F};
const uint8_t pskTestData[] = {0x34,0x20,0x42,0x53};
const uint8_t pskExpectedData[]={0x9B,0xD6,0xC3,0x1F,0x0C,0xFB,0xF7,0x3E};
const uint32_t rlcStart=0xC0FFEE;
TEST(eoSecurity, PSKVectorTest)
{
	eoReturn ret;
	eoSecurity security;
	eoDevice myDev;
	eoSecureInfo &devOut = myDev.secOut;
	eoMessage msgSec(30);
	eoMessage msgNonSec(sizeof(pskTestData));
	devOut.SLF=SLF_DATA_ENC_VAES128|SLF_MAC_3BYTE|SLF_RLC_ALGO_24BIT;
	devOut.keySize=16;
	devOut.rollingCode=rlcStart;
	devOut.teachInInfo=TEACH_INFO_PSK;
	memcpy(devOut.key,keyVector,sizeof(keyVector));
	memcpy(devOut.psk,pskVector,sizeof(pskVector));

	ret = security.CreateTeachIn(msgSec, myDev);
	EXPECT_EQ(ret,EO_OK);
	EXPECT_EQ(memcmp(msgSec.data, expectedTeachMessage, sizeof(expectedTeachMessage)), EO_OK);
	memcpy(msgNonSec.data,pskTestData,sizeof(pskTestData));
	ret = security.Encrypt(msgNonSec,msgSec,myDev);
	EXPECT_EQ(ret,EO_OK);
	EXPECT_EQ(memcmp(msgSec.data, pskExpectedData, sizeof(pskExpectedData)), EO_OK);



}

TEST(eoSecurity, SecurityTest)
{
	uint8_t	ret;

	eoSecurity security;
	eoDevice myDev;
	eoMessage *msgSec = new eoMessage(30);
	eoMessage *msgNonSec = new eoMessage(30);

	msgSec->RORG = 0x35;
	msgSec->dataLength = 20;
	uint8_t testData0 [] = {0x25, 0x4B, 0xE9, 0x53, 0x16, 0xAB, 0x0B, 0x6E, 0xD8, 0x3C, 0xD6, 0xB6, 0x6B, 0x7F, 0x75, 0x0C, 0x66, 0xC7, 0xF0, 0x47};
	msgSec->sourceID = 0xFEFFFF60;
	memcpy(msgSec->data, testData0, sizeof(testData0));

	ret = security.ParseTeachIn(*msgSec, myDev);
	EXPECT_EQ(ret,EO_OK);

	memcpy(myDev.secOut.key, myDev.secIn.key, myDev.secIn.keySize);
	myDev.secOut.keySize = myDev.secIn.keySize;
	myDev.secIn.rollingCode++;
	myDev.secOut.rollingCode = myDev.secIn.rollingCode;
	myDev.secOut.SLF = myDev.secIn.SLF;
	myDev.secOut.teachInInfo = myDev.secIn.teachInInfo;
	memcpy(myDev.secOut.subKey1, myDev.secIn.subKey1, 16);
	memcpy(myDev.secOut.subKey2, myDev.secIn.subKey2, 16);

	//NR1
	msgSec->RORG = 0x30;
	msgSec->dataLength = 4;
	uint8_t testData1 [] = {0x04, 0xA6, 0xA5, 0xFB};
	msgSec->sourceID = 0xFEFFFF60;
	memcpy(msgSec->data, testData1, 4);

	ret = security.Decrypt(*msgSec, *msgNonSec, myDev);
	EXPECT_EQ(ret,EO_OK);

	EXPECT_EQ(msgNonSec->data[0], 0x0F);
	EXPECT_EQ(msgNonSec->dataLength, 1);
	EXPECT_EQ(msgNonSec->sourceID, 0xFEFFFF60);
	EXPECT_EQ(msgNonSec->RORG, 0x32);

	//NR2
	msgNonSec->RORG = 0x32;
	msgNonSec->data[0] = 0x0F;
	msgNonSec->dataLength = 1;
	msgNonSec->sourceID = 0xFEFFFF60;

	ret = security.Encrypt(*msgNonSec, *msgSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgSec->RORG, 0x30);
	EXPECT_EQ(msgSec->dataLength, 4);
	EXPECT_EQ(memcmp(msgSec->data, testData1, 4), EO_OK);

	//NR3
	msgNonSec->RORG = 0x32;
	msgNonSec->dataLength = 4;
	uint8_t testData2[] = {0x11, 0x22, 0x33, 0x44};
	memcpy(msgNonSec->data, testData2, 4);

	myDev.secIn.SLF = 107;
	myDev.secOut.SLF = myDev.secIn.SLF;
	myDev.secIn.teachInInfo = 0;
	myDev.secOut.teachInInfo = myDev.secIn.teachInInfo;

	ret = security.Encrypt(*msgNonSec, *msgSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgSec->RORG, 0x30);

	ret = security.Decrypt(*msgSec, *msgNonSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgNonSec->RORG, 0x32);
	EXPECT_EQ(memcmp(msgNonSec->data, testData2, 4), EO_OK);

	//NR4
	myDev.secIn.SLF = 116;
	myDev.secOut.SLF = myDev.secIn.SLF;

	ret = security.Encrypt(*msgNonSec, *msgSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgSec->RORG, 0x30);

	ret = security.Decrypt(*msgSec, *msgNonSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgNonSec->RORG, 0x32);
	EXPECT_EQ(memcmp(msgNonSec->data, testData2, 4), EO_OK);

	//NR5
	myDev.secIn.SLF = 171;
	myDev.secOut.SLF = myDev.secIn.SLF;
	myDev.secIn.rollingCode = 0xE95732;
	myDev.secOut.rollingCode = myDev.secIn.rollingCode;

	ret = security.Encrypt(*msgNonSec, *msgSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgSec->RORG, 0x30);

	ret = security.Decrypt(*msgSec, *msgNonSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgNonSec->RORG, 0x32);
	EXPECT_EQ(memcmp(msgNonSec->data, testData2, 4), EO_OK);

	//NR6
	myDev.secOut.rollingCode = 0xE95D;
	myDev.secOut.SLF = 75;
	myDev.secOut.keySize = 16;
	uint8_t testKey[] = {0x16, 0xAB,0x0B, 0x6E, 0xD8, 0x3C, 0xD6, 0xB6, 0x6B, 0x7F, 0x75, 0x0C, 0x66, 0xC7, 0xF0, 0x47};
	memcpy(myDev.secOut.key, testKey, sizeof(testKey));
	myDev.secOut.teachInInfo = 0x25;

	ret = security.CreateTeachIn(*msgSec, myDev);
	EXPECT_EQ(ret, EO_OK);

	EXPECT_EQ(msgSec->dataLength, 20);
	uint8_t secTeachInResult [] = {0x25, 0x4B, 0xE9, 0x5D, 0x16, 0xAB, 0x0B, 0x6E, 0xD8, 0x3C, 0xD6, 0xB6, 0x6B, 0x7F, 0x75, 0x0C, 0x66, 0xC7, 0xF0, 0x47};
	EXPECT_EQ(memcmp(msgSec->data, secTeachInResult, msgSec->dataLength), EO_OK);
}
