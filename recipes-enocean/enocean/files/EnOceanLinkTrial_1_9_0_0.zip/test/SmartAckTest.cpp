/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>
#include "GatewayFixture.h"
#include "eoMockPacketStream.h"

TEST(eoProfile,SmartAck)
{
	GatewayFixture gateway;
	eoSerialCommand smartAck (&gateway);
	eoPacket serialPacket(512);
	delete gateway.stream;
	gateway.stream = new eoMockPacketStream();
	smartAck.SmartAckWriteLearnMode (true, SA_EL_ADVANCE, 0x11223344);
	smartAck.GetSerialPacket().copyTo(serialPacket);
	uint8_t packetData1 [] = {0x01, 0x01, 0x01, 0x11, 0x22, 0x33, 0x44};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 7);
	EXPECT_EQ(memcmp(serialPacket.data, packetData1, serialPacket.dataLength), 0);

	SA_RD_LEARNMODE_RESPONSE response;
	smartAck.SmartAckReadLearnMode(response);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData2 [] = {0x02};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData2, serialPacket.dataLength), 0);

	smartAck.SmartAckLearnConfirm(0x1122, SA_CC_LEARNIN, 0x11223344, 0x44556677);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData3 [] = {0x03, 0x11, 0x22, 0x00, 0x11, 0x22, 0x33, 0x44, 0x44, 0x55, 0x66, 0x77};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 12);
	EXPECT_EQ(memcmp(serialPacket.data, packetData3, serialPacket.dataLength), 0);

	smartAck.SmartAckSendLearnRequest(0x1122, 0x00334455);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData4 [] = {0x04, 0xF9, 0x22, 0x33, 0x44, 0x55};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 6);
	EXPECT_EQ(memcmp(serialPacket.data, packetData4, serialPacket.dataLength), 0);

	smartAck.SmartAckReset(0x12334455);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData5 [] = {0x05, 0x12, 0x33, 0x44, 0x55};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 5);
	EXPECT_EQ(memcmp(serialPacket.data, packetData5, serialPacket.dataLength), 0);

	SA_RD_LEARNEDCLIENTS_RESPONSE clients[20];
	uint8_t learnedCount;
	smartAck.SmartAckLearnedClients(clients, &learnedCount, 20);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData6 [] = {0x06};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 1);
	EXPECT_EQ(memcmp(serialPacket.data, packetData6, serialPacket.dataLength), 0);

	smartAck.SmartAckSetReclaimTries(0x23);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData7 [] = {0x07, 0x23};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 2);
	EXPECT_EQ(memcmp(serialPacket.data, packetData7, serialPacket.dataLength), 0);

	smartAck.SmartAckSetPostmaster(0x23);
	smartAck.GetSerialPacket().copyTo(serialPacket);

	uint8_t packetData8 [] = {0x08, 0x23};

	EXPECT_EQ(serialPacket.type, 6);
	EXPECT_EQ(serialPacket.dataLength, 2);
	EXPECT_EQ(memcmp(serialPacket.data, packetData8, serialPacket.dataLength), 0);
}
