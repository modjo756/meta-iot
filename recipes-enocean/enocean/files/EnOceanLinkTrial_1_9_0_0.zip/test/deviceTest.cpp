/*
 * deviceTest.cpp
 *
 *  Created on: 27.06.2012
 *      Author: tobias
 */
#include <gtest/gtest.h>
#include <string.h>
#include "eoLink.h"


TEST(eoDevice, DeviceCreation)
{
	eoDevice myDev = eoDevice(0x11324242);
	EXPECT_EQ(myDev.ID,0x11324242);

}

TEST(eoDevice, SetProfile)
{
	eoDevice myDev = eoDevice(0x11324242);
	EXPECT_EQ(myDev.SetProfile(NULL),WRONG_PARAM);

	EXPECT_EQ(myDev.SetProfile(0xA5,0x02,0x01),EO_OK);

	eoProfile *myProf = myDev.GetProfile();

	EXPECT_EQ(myDev.SetProfile(myProf),WRONG_PARAM);

	EXPECT_EQ(myDev.SetProfile(0xA5,0x02,0x02),EO_OK);

	EXPECT_TRUE(myProf!=myDev.GetProfile());

}
