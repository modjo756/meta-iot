#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA514xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x14, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA514xxTest,eepA51401ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.2);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.2);

	// F_OPEN_CLOSED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA514xxTest,eepA51401ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);
}

TEST_F(profileA514xxTest,eepA51402ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.2);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.2);

	// F_OPEN_CLOSED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(500, fGetValue, 0.2);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 0.2);
}

TEST_F(profileA514xxTest,eepA51402ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);
}

TEST_F(profileA514xxTest,eepA51403ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.2);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.2);

	// F_OPEN_CLOSED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_VIBRATION
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA514xxTest,eepA51403ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// F_VIBRATION
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);
}

TEST_F(profileA514xxTest,eepA51404ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.2);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.2);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(500, fGetValue, 0.2);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 0.2);

	// F_OPEN_CLOSED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_VIBRATION
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA514xxTest,eepA51404ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// F_VIBRATION
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);
}

TEST_F(profileA514xxTest,eepA51405ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.2);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.2);

	// F_VIBRATION
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA514xxTest,eepA51405ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_VIBRATION
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);
}

TEST_F(profileA514xxTest,eepA51406ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(2.5, fGetValue, 0.2);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5, fGetValue, 0.2);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(500, fGetValue, 0.2);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(1000, fGetValue, 0.2);

	// F_VIBRATION
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_VIBRATION, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA514xxTest,eepA51406ControllerSendData)
{
	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_VIBRATION));

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_VIBRATION
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_VIBRATION,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);
}

TEST_F(profileA514xxTest,ProfileA51407ControllerReceiveData)
{
uint8_t u8GetValue;
float fGetValue;
// Setup the test
Init(0x7);
// S_VOLTAGE
// Min - 0
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(0, fGetValue, 1);

// Median - 2.5
ParseRawDate({0x7D, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(2.5, fGetValue, 1);

// Max - 5
ParseRawDate({0xFA, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(5, fGetValue, 1);

// F_OPEN_CLOSED
// False
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( F_OPEN_CLOSED, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// True
ParseRawDate({0x0, 0x0, 0x0, 0xC },4);
myProf->GetValue( F_OPEN_CLOSED, u8GetValue);
EXPECT_EQ(1, u8GetValue);

// F_ON_OFF
// False
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( F_ON_OFF, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// True
ParseRawDate({0x0, 0x0, 0x0, 0xA },4);
myProf->GetValue( F_ON_OFF, u8GetValue);
EXPECT_EQ(1, u8GetValue);

}

TEST_F(profileA514xxTest,ProfileA51407ControllerSendData)
{
// Setup the test
Init(0x7);
// S_VOLTAGE
// Min - 0
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)0);
myProf->Create(*msg);
uint8_t data0[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data0[0], &msg->data[0], 4), 0);

// Min - 2.5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)2.5);
myProf->Create(*msg);
uint8_t data1[] = {0x7D, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data1[0], &msg->data[0], 4), 0);

// Min - 5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)5);
myProf->Create(*msg);
uint8_t data2[] = {0xFA, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data2[0], &msg->data[0], 4), 0);

// F_OPEN_CLOSED
// False
myProf->ClearValues();
myProf->SetValue( F_OPEN_CLOSED, (uint8_t)0);
myProf->Create(*msg);
uint8_t data3[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data3[0], &msg->data[0], 4), 0);

// True
myProf->ClearValues();
myProf->SetValue( F_OPEN_CLOSED, (uint8_t)1);
myProf->Create(*msg);
uint8_t data4[] = {0x0, 0x0, 0x0, 0xC };
EXPECT_EQ(memcmp(&data4[0], &msg->data[0], 4), 0);

// F_ON_OFF
// False
myProf->ClearValues();
myProf->SetValue( F_ON_OFF, (uint8_t)0);
myProf->Create(*msg);
uint8_t data6[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data6[0], &msg->data[0], 4), 0);

// True
myProf->ClearValues();
myProf->SetValue( F_ON_OFF, (uint8_t)1);
myProf->Create(*msg);
uint8_t data7[] = {0x0, 0x0, 0x0, 0xA };
EXPECT_EQ(memcmp(&data7[0], &msg->data[0], 4), 0);

}

TEST_F(profileA514xxTest,ProfileA51408ControllerReceiveData)
{
uint8_t u8GetValue;
float fGetValue;
// Setup the test
Init(0x8);
// S_VOLTAGE
// Min - 0
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(0, fGetValue, 1);

// Median - 2.5
ParseRawDate({0x7D, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(2.5, fGetValue, 1);

// Max - 5
ParseRawDate({0xFA, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(5, fGetValue, 1);

// F_OPEN_CLOSED
// False
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( F_OPEN_CLOSED, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// True
ParseRawDate({0x0, 0x0, 0x0, 0xC },4);
myProf->GetValue( F_OPEN_CLOSED, u8GetValue);
EXPECT_EQ(1, u8GetValue);

// F_ON_OFF
// False
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( F_ON_OFF, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// True
ParseRawDate({0x0, 0x0, 0x0, 0xA },4);
myProf->GetValue( F_ON_OFF, u8GetValue);
EXPECT_EQ(1, u8GetValue);

// F_VIBRATION
// False
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( F_VIBRATION, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// True
ParseRawDate({0x0, 0x0, 0x0, 0x9 },4);
myProf->GetValue( F_VIBRATION, u8GetValue);
EXPECT_EQ(1, u8GetValue);

}

TEST_F(profileA514xxTest,ProfileA51408ControllerSendData)
{
// Setup the test
Init(0x8);
// S_VOLTAGE
// Min - 0
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)0);
myProf->Create(*msg);
uint8_t data0[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data0[0], &msg->data[0], 4), 0);

// Min - 2.5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)2.5);
myProf->Create(*msg);
uint8_t data1[] = {0x7D, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data1[0], &msg->data[0], 4), 0);

// Min - 5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)5);
myProf->Create(*msg);
uint8_t data2[] = {0xFA, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data2[0], &msg->data[0], 4), 0);

// F_OPEN_CLOSED
// False
myProf->ClearValues();
myProf->SetValue( F_OPEN_CLOSED, (uint8_t)0);
myProf->Create(*msg);
uint8_t data3[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data3[0], &msg->data[0], 4), 0);

// True
myProf->ClearValues();
myProf->SetValue( F_OPEN_CLOSED, (uint8_t)1);
myProf->Create(*msg);
uint8_t data4[] = {0x0, 0x0, 0x0, 0xC };
EXPECT_EQ(memcmp(&data4[0], &msg->data[0], 4), 0);

// F_ON_OFF
// False
myProf->ClearValues();
myProf->SetValue( F_ON_OFF, (uint8_t)0);
myProf->Create(*msg);
uint8_t data6[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data6[0], &msg->data[0], 4), 0);

// True
myProf->ClearValues();
myProf->SetValue( F_ON_OFF, (uint8_t)1);
myProf->Create(*msg);
uint8_t data7[] = {0x0, 0x0, 0x0, 0xA };
EXPECT_EQ(memcmp(&data7[0], &msg->data[0], 4), 0);

// F_VIBRATION
// False
myProf->ClearValues();
myProf->SetValue( F_VIBRATION, (uint8_t)0);
myProf->Create(*msg);
uint8_t data9[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data9[0], &msg->data[0], 4), 0);

// True
myProf->ClearValues();
myProf->SetValue( F_VIBRATION, (uint8_t)1);
myProf->Create(*msg);
uint8_t data10[] = {0x0, 0x0, 0x0, 0x9 };
EXPECT_EQ(memcmp(&data10[0], &msg->data[0], 4), 0);

}

TEST_F(profileA514xxTest,ProfileA51409ControllerReceiveData)
{
uint8_t u8GetValue;
float fGetValue;
// Setup the test
Init(0x9);
// S_VOLTAGE
// Min - 0
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(0, fGetValue, 1);

// Median - 2.5
ParseRawDate({0x7D, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(2.5, fGetValue, 1);

// Max - 5
ParseRawDate({0xFA, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(5, fGetValue, 1);

// E_STATE
// Enum - 0
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( E_STATE, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// Enum - 1
ParseRawDate({0x0, 0x0, 0x0, 0xA },4);
myProf->GetValue( E_STATE, u8GetValue);
EXPECT_EQ(1, u8GetValue);

// Enum - 3
ParseRawDate({0x0, 0x0, 0x0, 0xE },4);
myProf->GetValue( E_STATE, u8GetValue);
EXPECT_EQ(3, u8GetValue);

}

TEST_F(profileA514xxTest,ProfileA51409ControllerSendData)
{
// Setup the test
Init(0x9);
// S_VOLTAGE
// Min - 0
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)0);
myProf->Create(*msg);
uint8_t data0[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data0[0], &msg->data[0], 4), 0);

// Min - 2.5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)2.5);
myProf->Create(*msg);
uint8_t data1[] = {0x7D, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data1[0], &msg->data[0], 4), 0);

// Min - 5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)5);
myProf->Create(*msg);
uint8_t data2[] = {0xFA, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data2[0], &msg->data[0], 4), 0);

// E_STATE
// Enum - 0
myProf->ClearValues();
myProf->SetValue( E_STATE, (uint8_t)0);
myProf->Create(*msg);
uint8_t data3[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data3[0], &msg->data[0], 4), 0);

// Enum - 1
myProf->ClearValues();
myProf->SetValue( E_STATE, (uint8_t)1);
myProf->Create(*msg);
uint8_t data4[] = {0x0, 0x0, 0x0, 0xA };
EXPECT_EQ(memcmp(&data4[0], &msg->data[0], 4), 0);

// Enum - 3
myProf->ClearValues();
myProf->SetValue( E_STATE, (uint8_t)3);
myProf->Create(*msg);
uint8_t data6[] = {0x0, 0x0, 0x0, 0xE };
EXPECT_EQ(memcmp(&data6[0], &msg->data[0], 4), 0);

}

TEST_F(profileA514xxTest,ProfileA5140AControllerReceiveData)
{
uint8_t u8GetValue;
float fGetValue;
// Setup the test
Init(0xA);
// S_VOLTAGE
// Min - 0
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(0, fGetValue, 1);

// Median - 2.5
ParseRawDate({0x7D, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(2.5, fGetValue, 1);

// Max - 5
ParseRawDate({0xFA, 0x0, 0x0, 0x8 },4);
myProf->GetValue( S_VOLTAGE, fGetValue);
EXPECT_NEAR(5, fGetValue, 1);

// E_STATE
// Enum - 0
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( E_STATE, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// Enum - 1
ParseRawDate({0x0, 0x0, 0x0, 0xA },4);
myProf->GetValue( E_STATE, u8GetValue);
EXPECT_EQ(1, u8GetValue);

// Enum - 3
ParseRawDate({0x0, 0x0, 0x0, 0xE },4);
myProf->GetValue( E_STATE, u8GetValue);
EXPECT_EQ(3, u8GetValue);

// F_VIBRATION
// False
ParseRawDate({0x0, 0x0, 0x0, 0x8 },4);
myProf->GetValue( F_VIBRATION, u8GetValue);
EXPECT_EQ(0, u8GetValue);

// True
ParseRawDate({0x0, 0x0, 0x0, 0x9 },4);
myProf->GetValue( F_VIBRATION, u8GetValue);
EXPECT_EQ(1, u8GetValue);

}

TEST_F(profileA514xxTest,ProfileA51410AControllerSendData)
{
// Setup the test
Init(0xA);
// S_VOLTAGE
// Min - 0
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)0);
myProf->Create(*msg);
uint8_t data0[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data0[0], &msg->data[0], 4), 0);

// Min - 2.5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)2.5);
myProf->Create(*msg);
uint8_t data1[] = {0x7D, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data1[0], &msg->data[0], 4), 0);

// Min - 5
myProf->ClearValues();
myProf->SetValue( S_VOLTAGE, (float)5);
myProf->Create(*msg);
uint8_t data2[] = {0xFA, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data2[0], &msg->data[0], 4), 0);

// E_STATE
// Enum - 0
myProf->ClearValues();
myProf->SetValue( E_STATE, (uint8_t)0);
myProf->Create(*msg);
uint8_t data3[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data3[0], &msg->data[0], 4), 0);

// Enum - 1
myProf->ClearValues();
myProf->SetValue( E_STATE, (uint8_t)1);
myProf->Create(*msg);
uint8_t data4[] = {0x0, 0x0, 0x0, 0xA };
EXPECT_EQ(memcmp(&data4[0], &msg->data[0], 4), 0);

// Enum - 3
myProf->ClearValues();
myProf->SetValue( E_STATE, (uint8_t)3);
myProf->Create(*msg);
uint8_t data6[] = {0x0, 0x0, 0x0, 0xE };
EXPECT_EQ(memcmp(&data6[0], &msg->data[0], 4), 0);

// F_VIBRATION
// False
myProf->ClearValues();
myProf->SetValue( F_VIBRATION, (uint8_t)0);
myProf->Create(*msg);
uint8_t data7[] = {0x0, 0x0, 0x0, 0x8 };
EXPECT_EQ(memcmp(&data7[0], &msg->data[0], 4), 0);

// True
myProf->ClearValues();
myProf->SetValue( F_VIBRATION, (uint8_t)1);
myProf->Create(*msg);
uint8_t data8[] = {0x0, 0x0, 0x0, 0x9 };
EXPECT_EQ(memcmp(&data8[0], &msg->data[0], 4), 0);

}
