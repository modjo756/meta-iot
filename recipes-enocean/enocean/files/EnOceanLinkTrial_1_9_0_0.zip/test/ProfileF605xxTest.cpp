/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include "Profiles/eoEEP_F605xx.h"
#include "ProfileFixture.h"
#include <gtest/gtest.h>
class ProfileF605Test : public ProfileFixture
{
	public:
	void Init(uint8_t type)
	{
		myProf = eoProfileFactory::CreateProfile(0xF6,0x05,type);
		ASSERT_TRUE(myProf!=NULL);
		msg = new eoMessage(1);
		msg->RORG=RORG_RPS;
	}
};
TEST_F(ProfileF605Test,eepF60500Receive)
{
	uint8_t u8GetValue;
	Init(0);

	// Alarm Off
	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(0,u8GetValue);

	// Alarm On
	msg->data[0]=0x10;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(16,u8GetValue);

	// Energy Low
	msg->data[0]=0x30;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(48,u8GetValue);
}

TEST_F(ProfileF605Test,eepF60500Send)
{
	Init(0);

	// Alarm off
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	// Alarm on
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)16));
	myProf->Create(*msg);
	EXPECT_EQ(0x10,msg->data[0]);

	// Energy low
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)48));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->data[0]);
}

TEST_F(ProfileF605Test,eepF60501Receive)
{
	uint8_t u8GetValue;
	Init(0x01);

	// No water
	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(0,u8GetValue);

	// Water detected
	msg->status = 0x30;
	msg->data[0]=0x11;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(17,u8GetValue);
}

TEST_F(ProfileF605Test,eepF60501Send)
{
	Init(0x01);

	// Alarm off
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	// Alarm on
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)17));
	myProf->Create(*msg);
	EXPECT_EQ(0x11,msg->data[0]);
}

TEST_F(ProfileF605Test,eepF60502Receive)
{
	uint8_t u8GetValue;
	Init(0x02);

	// Alarm Off
	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(0,u8GetValue);

	// Alarm On
	msg->data[0]=0x10;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(16,u8GetValue);

	// Energy Low
	msg->data[0]=0x30;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_STATE,u8GetValue));
	EXPECT_EQ(48,u8GetValue);
}

TEST_F(ProfileF605Test,eepF60502Send)
{
	Init(0x02);

	// Alarm off
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)0));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	// Alarm on
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)16));
	myProf->Create(*msg);
	EXPECT_EQ(0x10,msg->data[0]);

	// Energy low
	EXPECT_EQ(EO_OK,myProf->SetValue(E_STATE,(uint8_t)48));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->data[0]);
}
