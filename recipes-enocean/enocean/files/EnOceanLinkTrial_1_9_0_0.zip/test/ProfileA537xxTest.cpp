#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA537xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x37, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA537xxTest,eepA53701ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(S_VALUE));

	// S_SETPOINT
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// F_ON_OFF - ABS_REL_POWER
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, ABS_REL_POWER);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x80, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, ABS_REL_POWER);
	EXPECT_EQ(1, u8GetValue);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x32, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x64, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_TIME
	// Min
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(15, fGetValue, 2);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(1905, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(3825, fGetValue, 2);

	// S_VALUE
	// Min
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(7, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(15, fGetValue, 0.5);

	// F_ON_OFF - RAND_START_DELAY
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RAND_START_DELAY);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RAND_START_DELAY);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - ABS_REL_POWER
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RAND_END_DELAY);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, RAND_END_DELAY);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - MAX_MIN_POWER
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, MAX_MIN_POWER);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, MAX_MIN_POWER);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA537xxTest,eepA53701ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(S_VALUE));

	// S_SETPOINT
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF - ABS_REL_POWER
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, ABS_REL_POWER);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, ABS_REL_POWER);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_PERCENTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x32, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x64, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// S_TIME
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)15);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)1906);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)3825);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// S_VALUE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)7);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)15);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_ON_OFF - RAND_START_DELAY
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RAND_START_DELAY);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RAND_START_DELAY);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// F_ON_OFF - RAND_END_DELAY
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, RAND_END_DELAY);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, RAND_END_DELAY);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// F_ON_OFF - MAX_MIN_POWER
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, MAX_MIN_POWER);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, MAX_MIN_POWER);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);
}
