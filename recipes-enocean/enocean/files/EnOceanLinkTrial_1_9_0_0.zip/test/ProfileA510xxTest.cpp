/*
 * ProfileA504Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA510xxTest : public ProfileFixture
{
	/** */
	protected:
	bool OutChannelExist(CHANNEL_TYPE type)
	{
		eoEEPChannelInfo * myChan = (eoEEPChannelInfo *)((eoEEP_A510xx*)myProf)->GetChannel(type);
		return(myChan!=NULL);
	}

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x10, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};

TEST_F(profileA510xxTest,eepA51001ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51001ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51002ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51002ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51003ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51003ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51004ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51004ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51005ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51005ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51006ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51006ControllerSendData)
{
	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_DAY_NIGHT
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51007ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51007ControllerSendData)
{
	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51008ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51008ControllerSendData)
{
	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51009ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x09);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// F_DAY_NIGHT
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51009ControllerSendData)
{
	// Setup the test
	Init(0x09);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// F_DAY_NIGHT
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5100AControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_OPEN_CLOSED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5100AControllerSendData)
{
	// Setup the test
	Init(0x0A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_OPEN_CLOSED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5100BControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// F_OPEN_CLOSED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5100BControllerSendData)
{
	// Setup the test
	Init(0x0B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// F_OPEN_CLOSED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5100CControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0C);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// F_OPEN_CLOSED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5100CControllerSendData)
{
	// Setup the test
	Init(0x0C);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// F_OPEN_CLOSED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5100DControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x0D);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// F_OPEN_CLOSED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5100DControllerSendData)
{
	// Setup the test
	Init(0x0D);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));

	// F_OPEN_CLOSED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51010ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51010ControllerSendData)
{
	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51011ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x11);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51011ControllerSendData)
{
	// Setup the test
	Init(0x11);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51012ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x12);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51012ControllerSendData)
{
	// Setup the test
	Init(0x12);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51013ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x13);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51013ControllerSendData)
{
	// Setup the test
	Init(0x13);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51014ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x14);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51014ControllerSendData)
{
	// Setup the test
	Init(0x14);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51015ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x15);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x80, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(32, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFC, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(63, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(41.2, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x02, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(15.5,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x03, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51015ControllerSendData)
{
	// Setup the test
	Init(0x15);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)32);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)63);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFC, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)41.2);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)15.5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x02, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x03, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51016ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x16);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x80, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(32, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFC, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(63, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(41.2, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x02, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(15.5,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x03, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51016ControllerSendData)
{
	// Setup the test
	Init(0x16);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)32);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)63);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFC, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)41.2);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)15.5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x02, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x03, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51017ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x17);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(41.2, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x02, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(15.5,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x03, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51017ControllerSendData)
{
	// Setup the test
	Init(0x17);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)41.2);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)15.5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x02, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x03, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51018ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x18);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(500, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(1000, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51018ControllerSendData)
{
	// Setup the test
	Init(0x18);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data11[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_TEMP_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)20);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51019ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x19);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(50, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA51019ControllerSendData)
{
	// Setup the test
	Init(0x19);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data11[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_TEMP_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)20);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5101AControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x1A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(2.5, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(5.0, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFA, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5101AControllerSendData)
{
	// Setup the test
	Init(0x1A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_TEMP_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)40);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)20);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5101BControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x1B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(2.5, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(5.0, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(500, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(1000, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5101BControllerSendData)
{
	// Setup the test
	Init(0x1B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5101CControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x1C);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE_ABS));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_EQ(500, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_EQ(1000, fGetValue);

	// S_LUMINANCE_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(500, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(1000, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5101CControllerSendData)
{
	// Setup the test
	Init(0x1C);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE_ABS));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE_ABS,(float)500);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE_ABS,(float)1000);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_LUMINANCE_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data17[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data18[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5101DControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x1D);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_RELHUM_ABS));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_RELHUM_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM_ABS, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM_ABS, fGetValue);
	EXPECT_EQ(50, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM_ABS, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// S_LUMINANCE_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(50, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5101DControllerSendData)
{
	// Setup the test
	Init(0x1D);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_RELHUM_ABS));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_RELHUM_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM_ABS,(float)50);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM_ABS,(float)100);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_LUMINANCE_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data17[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data18[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5101EControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x1E);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_VOLTAGE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(2.5, fGetValue);

	// Max value
	ParseRawDate({0xFA, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(5.0, fGetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(500, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(1000, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
}

TEST_F(profileA510xxTest,eepA5101EControllerSendData)
{
	// Setup the test
	Init(0x1E);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// S_VOLTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.5);
	myProf->Create(*msg);
	uint8_t data11[] = {0x7D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data12[] = {0xFA, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)500);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)1000);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0xFA, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA5101FControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x1F);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x48, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x9B, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0xB1, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0xC7, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0xE8, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x28},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x28},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0xFF, 0x48},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x48},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// F_BTN_PRESS - Occupancy
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue,OCCUPANCY);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue,OCCUPANCY);
	EXPECT_EQ(0, u8GetValue);

	// F_BTN_PRESS - Unoccupancy
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue,UNOCCUPANCY);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue,UNOCCUPANCY);
	EXPECT_EQ(0, u8GetValue);
}

TEST_F(profileA510xxTest,eepA5101FControllerSendData)
{
	// Setup the test
	Init(0x1F);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x48, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x9B, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0xB1, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data3[] = {0xC7, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data4[] = {0xE8, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x7F, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0xFF, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7F, 0x48};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0xFF, 0x48};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// F_BTN_PRESS - Occupancy
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1, OCCUPANCY);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0, OCCUPANCY);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_BTN_PRESS - Unoccupancy
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1,UNOCCUPANCY);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0,UNOCCUPANCY);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51020ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x20);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_POWERALARM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// F_HIGH_LOW
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_POWERALARM
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);
}

TEST_F(profileA510xxTest,eepA51020ControllerSendData)
{
	// Setup the test
	Init(0x20);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_POWERALARM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// E_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x0FA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// F_HIGH_LOW
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_POWERALARM
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_POWERALARM,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_POWERALARM,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51021ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x21);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_POWERALARM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(50, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// F_HIGH_LOW
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_POWERALARM
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_POWERALARM, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// E_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);
}

TEST_F(profileA510xxTest,eepA51021ControllerSendData)
{
	// Setup the test
	Init(0x21);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_POWERALARM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// E_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x0FA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// F_HIGH_LOW
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_POWERALARM
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_POWERALARM,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_POWERALARM,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51022ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x22);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(50, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);
}

TEST_F(profileA510xxTest,eepA51022ControllerSendData)
{
	// Setup the test
	Init(0x22);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x0FA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);
}

TEST_F(profileA510xxTest,eepA51023ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x23);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_RELHUM
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7D, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(50, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFA, 0x00, 0x08},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_EQ(100, fGetValue);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7D, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20,fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40,fGetValue,0.5);

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// F_OCCUPIED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OCCUPIED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA510xxTest,eepA51023ControllerSendData)
{
	// Setup the test
	Init(0x23);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(F_OCCUPIED));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)127);
	myProf->Create(*msg);
	uint8_t data6[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)255);
	myProf->Create(*msg);
	uint8_t data7[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// S_RELHUM
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x7D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0xFA, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x0FA, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x7D, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// F_OCCUPIED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_OCCUPIED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);
}
