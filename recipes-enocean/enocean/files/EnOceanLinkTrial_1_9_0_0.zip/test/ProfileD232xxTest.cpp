/*
 * ProfileA512Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

TEST_F(ProfileFixture,eepD23200)
{
	eoMessage msg(256);
	uint8_t data [] = { 0x40, 0x00, 0x00};
	Init(0xD2,0x32,0x00);

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)0));

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],3));

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)4095));

	data[0] = 0x80;
	data[1] = 0xFF;
	data[2] = 0xF0;

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],3));

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)40));

	data[0] = 0x40;
	data[1] = 0x02;
	data[2] = 0x80;

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],3));

	// GetValue tests
	uint8_t uVal;
	float fVal;
	uint8_t data01[] = { 0x80, 0xD4, 0x40};
	memcpy(&msg.data[0],&data01[0],3);
	myProf->Parse(msg);

	EXPECT_EQ(EO_OK,myProf->GetValue(S_CURRENT,fVal));
	EXPECT_NEAR(3396,fVal,0.05);

	EXPECT_EQ(EO_OK,myProf->GetValue(F_ON_OFF,uVal));
	EXPECT_EQ(1,uVal);
}

TEST_F(ProfileFixture,eepD23201)
{
	eoMessage msg(256);
	uint8_t data [] = { 0x40, 0x00, 0x00, 0x00};
	Init(0xD2,0x32,0x01);

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)0,0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)0,1));

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],4));

	msg.Clear();

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)4095,0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)2048,1));

	data[0] = 0x80;
	data[1] = 0xFF;
	data[2] = 0xF8;
	data[3] = 0x00;

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],4));

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)40,0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)400,1));

	data[0] = 0x40;
	data[1] = 0x02;
	data[2] = 0x81;
	data[3] = 0x90;

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],4));

	// GetValue tests
	uint8_t uVal;
	float fVal;
	uint8_t data01[] = { 0x80, 0xD4, 0x40, 0x00};
	memcpy(&msg.data[0],&data01[0],4);
	myProf->Parse(msg);

	EXPECT_EQ(EO_OK,myProf->GetValue(S_CURRENT,fVal,0));
	EXPECT_NEAR(3396,fVal,0.05);

	EXPECT_EQ(EO_OK,myProf->GetValue(S_CURRENT,fVal,1));
	EXPECT_NEAR(0,fVal,0.05);

	EXPECT_EQ(EO_OK,myProf->GetValue(F_ON_OFF,uVal));
	EXPECT_EQ(1,uVal);
}


TEST_F(ProfileFixture,eepD23202)
{
	eoMessage msg(256);
	msg.Clear();
	uint8_t data [] = { 0x40, 0x00, 0x00, 0x00, 0x00, 0x00};
	Init(0xD2,0x32,0x02);
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)0,0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)0,1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)0,2));

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(msg.data,data,6));

	msg.Clear();

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)4095,0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)2048,1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)1024,2));

	data[0] = 0x80;
	data[1] = 0xFF;
	data[2] = 0xF8;
	data[3] = 0x00;
	data[4] = 0x40;
	data[5] = 0x00;

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],6));

	EXPECT_EQ(EO_OK,myProf->SetValue(F_ON_OFF,(uint8_t)0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)40,0));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)400,1));
	EXPECT_EQ(EO_OK,myProf->SetValue(S_CURRENT,(float)4000,2));

	data[0] = 0x00;
	data[1] = 0x02;
	data[2] = 0x81;
	data[3] = 0x90;
	data[4] = 0xFA;
	data[5] = 0x00;

	myProf->Create(msg);
	EXPECT_EQ(EO_OK,memcmp(&msg.data[0],&data[0],6));

	// GetValue tests
	uint8_t uVal;
	float fVal;
	uint8_t data01[] = { 0x80, 0xD4, 0x40, 0x00, 0x12, 0x30};
	memcpy(&msg.data[0],&data01[0],6);
	myProf->Parse(msg);

	EXPECT_EQ(EO_OK,myProf->GetValue(S_CURRENT,fVal,0));
	EXPECT_NEAR(3396,fVal,0.05);

	EXPECT_EQ(EO_OK,myProf->GetValue(S_CURRENT,fVal,1));
	EXPECT_NEAR(0,fVal,0.05);

	EXPECT_EQ(EO_OK,myProf->GetValue(S_CURRENT,fVal,2));
	EXPECT_NEAR(291,fVal,0.05);

	EXPECT_EQ(EO_OK,myProf->GetValue(F_ON_OFF,uVal));
	EXPECT_EQ(1,uVal);
}
