#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA530xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x30, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA530xxTest,eepA53001ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Enum - 0
	ParseRawDate({0x00, 0x3C, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Enum - 1
	ParseRawDate({0x00, 0xB5, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(1, fGetValue, 0.2);

	// F_OPEN_CLOSED
	// Min value
	ParseRawDate({0x00, 0x00, 0x62, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0xE1, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA530xxTest,eepA53001ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// S_VOLTAGE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x3C, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)255);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0xBE, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// F_OPEN_CLOSED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x62, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0xE2, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);
}

TEST_F(profileA530xxTest,eepA53002ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// F_OPEN_CLOSED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);
}

TEST_F(profileA530xxTest,eepA53002ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));

	// F_OPEN_CLOSED
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);
}

TEST_F(profileA530xxTest,eepA53003ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// F_HIGH_LOW - STATUS_WAKE
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, STATUS_WAKE);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x10, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, STATUS_WAKE);
	EXPECT_EQ(1, u8GetValue);

	// F_HIGH_LOW - DIGITAL_IN_3
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_3);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x08, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_3);
	EXPECT_EQ(1, u8GetValue);

	// F_HIGH_LOW - DIGITAL_IN_2
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_2);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x04, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_2);
	EXPECT_EQ(1, u8GetValue);

	// F_HIGH_LOW - DIGITAL_IN_1
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_1);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_1);
	EXPECT_EQ(1, u8GetValue);

	// F_HIGH_LOW - DIGITAL_IN_0
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_0);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_0);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA530xxTest,eepA53003ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_HIGH_LOW - STATUS_WAKE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, STATUS_WAKE);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, STATUS_WAKE);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x10, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_3
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_3);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_3);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x08, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_2
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_2);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_1
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_1);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_0
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA530xxTest,eepA53004ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VALUE));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// S_VALUE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(255, fGetValue, 0.5);

	// F_HIGH_LOW - DIGITAL_IN_2
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_2);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_2);
	EXPECT_EQ(1, u8GetValue);

	// F_HIGH_LOW - DIGITAL_IN_1
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_1);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_1);
	EXPECT_EQ(1, u8GetValue);

	// F_HIGH_LOW - DIGITAL_IN_0
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_0);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_HIGH_LOW, u8GetValue, DIGITAL_IN_0);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA530xxTest,eepA53004ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VALUE));
	EXPECT_TRUE(ChannelExist(F_HIGH_LOW));

	// S_VALUE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)127);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)255);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_2
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_2);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_1
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_1);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_HIGH_LOW - DIGITAL_IN_0
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)0, DIGITAL_IN_0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_HIGH_LOW,(uint8_t)1, DIGITAL_IN_0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA530xxTest,eepA53005ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_COUNTER));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(1.65, fGetValue, 0.1);

	// Max
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(3.3, fGetValue, 0.1);

	// F_ON_OFF
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x80, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// S_COUNTER
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x3F, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(63, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0xFF, 0x7F, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(127, fGetValue, 0.5);
}

TEST_F(profileA530xxTest,eepA53005ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(S_COUNTER));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)1.65);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)3.3);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x80, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_VALUE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)63);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x3F, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)127);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);
}

TEST_F(profileA530xxTest,eepA53006ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(E_KEY_DATA));

	// S_VOLTAGE
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_EQ(2.0, fGetValue);

	// Median
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(3.5, fGetValue, 0.1);

	// Max
	ParseRawDate({0x00, 0x00, 0x00, 0xF8},4);
	myProf->GetValue(S_VOLTAGE, fGetValue);
	EXPECT_NEAR(5.0, fGetValue, 0.1);

	// E_KEY_DATA - KEY_DATA_1
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x10, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x20, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x30, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x40, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x50, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x60, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x70, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x80, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x90, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_1);
	EXPECT_EQ(9, u8GetValue);

	// E_KEY_DATA - KEY_DATA_2
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x03, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x04, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x06, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x07, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x08, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x09, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_2);
	EXPECT_EQ(9, u8GetValue);

	// E_KEY_DATA - KEY_DATA_3
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x10, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x00, 0x20, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x00, 0x30, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x40, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x00, 0x50, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x00, 0x60, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x70, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x00, 0x80, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x00, 0x90, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_3);
	EXPECT_EQ(9, u8GetValue);

	// E_KEY_DATA - KEY_DATA_4
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x01, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x00, 0x02, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x00, 0x03, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x04, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x00, 0x05, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x00, 0x06, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x07, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x00, 0x08, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x00, 0x09, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_4);
	EXPECT_EQ(9, u8GetValue);

	// E_KEY_DATA - KEY_DATA_5
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x10, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x20, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x30, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x40, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x50, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x60, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x70, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x80, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x90, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_5);
	EXPECT_EQ(9, u8GetValue);

	// E_KEY_DATA - KEY_DATA_6
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x00, 0x00, 0x03, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x00, 0x00, 0x04, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0x00, 0x00, 0x05, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0x00, 0x00, 0x06, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0x00, 0x00, 0x07, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(7, u8GetValue);

	// Enum - 8
	ParseRawDate({0x00, 0x00, 0x08, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(8, u8GetValue);

	// Enum - 9
	ParseRawDate({0x00, 0x00, 0x09, 0x08},4);
	myProf->GetValue(E_KEY_DATA, u8GetValue, KEY_DATA_6);
	EXPECT_EQ(9, u8GetValue);
}

TEST_F(profileA530xxTest,eepA53006ControllerSendData)
{
	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_VOLTAGE));
	EXPECT_TRUE(ChannelExist(E_KEY_DATA));

	// S_VOLTAGE
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)2.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)3.5);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_VOLTAGE,(float)5.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0xF8};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// E_KEY_DATA - KEY_DATA_2
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)0, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)1, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data15[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)2, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data16[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)3, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data17[] = {0x03, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)4, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data18[] = {0x04, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)5, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data19[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)6, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data20[] = {0x06, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)7, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data21[] = {0x07, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)8, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data22[] = {0x08, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)9, KEY_DATA_2);
	myProf->Create(*msg);
	uint8_t data23[] = {0x09, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// E_KEY_DATA - KEY_DATA_3
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)0, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data24[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)1, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data25[] = {0x00, 0x10, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)2, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x20, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)3, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data27[] = {0x00, 0x30, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)4, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data28[] = {0x00, 0x40, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)5, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data29[] = {0x00, 0x50, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)6, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data30[] = {0x00, 0x60, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)7, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data31[] = {0x00, 0x70, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)8, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data32[] = {0x00, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)9, KEY_DATA_3);
	myProf->Create(*msg);
	uint8_t data33[] = {0x00, 0x90, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);

	// E_KEY_DATA - KEY_DATA_4
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)0, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data44[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)1, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data45[] = {0x00, 0x01, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)2, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data46[] = {0x00, 0x02, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data46[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)3, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data47[] = {0x00, 0x03, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)4, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data48[] = {0x00, 0x04, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data48[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)5, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data49[] = {0x00, 0x05, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data49[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)6, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data50[] = {0x00, 0x06, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data50[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)7, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data51[] = {0x00, 0x07, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data51[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)8, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data52[] = {0x00, 0x08, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)9, KEY_DATA_4);
	myProf->Create(*msg);
	uint8_t data53[] = {0x00, 0x09, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],4),0);

	// E_KEY_DATA - KEY_DATA_5
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)0, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data54[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data54[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)1, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data55[] = {0x00, 0x00, 0x10, 0x08};
	EXPECT_EQ(memcmp(&data55[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)2, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data56[] = {0x00, 0x00, 0x20, 0x08};
	EXPECT_EQ(memcmp(&data56[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)3, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data57[] = {0x00, 0x00, 0x30, 0x08};
	EXPECT_EQ(memcmp(&data57[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)4, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data58[] = {0x00, 0x00, 0x40, 0x08};
	EXPECT_EQ(memcmp(&data58[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)5, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data59[] = {0x00, 0x00, 0x50, 0x08};
	EXPECT_EQ(memcmp(&data59[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)6, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data60[] = {0x00, 0x00, 0x60, 0x08};
	EXPECT_EQ(memcmp(&data60[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)7, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data61[] = {0x00, 0x00, 0x70, 0x08};
	EXPECT_EQ(memcmp(&data61[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)8, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data62[] = {0x00, 0x00, 0x80, 0x08};
	EXPECT_EQ(memcmp(&data62[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)9, KEY_DATA_5);
	myProf->Create(*msg);
	uint8_t data63[] = {0x00, 0x00, 0x90, 0x08};
	EXPECT_EQ(memcmp(&data63[0],&msg->data[0],4),0);

	// E_KEY_DATA - KEY_DATA_6
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)0, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data64[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data64[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)1, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data65[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data65[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)2, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data66[] = {0x00, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data66[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)3, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data67[] = {0x00, 0x00, 0x03, 0x08};
	EXPECT_EQ(memcmp(&data67[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)4, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data68[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data68[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)5, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data69[] = {0x00, 0x00, 0x05, 0x08};
	EXPECT_EQ(memcmp(&data69[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)6, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data70[] = {0x00, 0x00, 0x06, 0x08};
	EXPECT_EQ(memcmp(&data70[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)7, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data71[] = {0x00, 0x00, 0x07, 0x08};
	EXPECT_EQ(memcmp(&data71[0],&msg->data[0],4),0);

	// Enum - 8
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)8, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data72[] = {0x00, 0x00, 0x08, 0x08};
	EXPECT_EQ(memcmp(&data72[0],&msg->data[0],4),0);

	// Enum - 9
	myProf->ClearValues();
	myProf->SetValue(E_KEY_DATA,(uint8_t)9, KEY_DATA_6);
	myProf->Create(*msg);
	uint8_t data73[] = {0x00, 0x00, 0x09, 0x08};
	EXPECT_EQ(memcmp(&data73[0],&msg->data[0],4),0);
}
