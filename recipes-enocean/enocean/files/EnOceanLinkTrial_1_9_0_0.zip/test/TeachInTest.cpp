/*
 * TeachInTest.cpp
 *
 *  Created on: 01.06.2015
 *      Author: tobias.meyer
 */
#include <gtest/gtest.h>
#include <string.h>
#include "eoLink.h"

class TeachInTest: public testing::Test {
public:
	eoDeviceManager devManager;
	eoSecurity secHandler;
	eoTeachInModule teachHandler;
	TeachInTest() : devManager(), secHandler(), teachHandler(&devManager,&secHandler)
	{

	}
};

TEST_F(TeachInTest, ManuellTeachIn)
{


	EXPECT_EQ(EEP_TEACH_IN,teachHandler.TeachIN(0xA5,0x02,0x01,0x12345678));
	ASSERT_TRUE(devManager.Get(0x12345678)!=NULL);
	eoProfile *prof = devManager.Get(0x12345678)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xA5);
	EXPECT_EQ(prof->func,0x02);
	EXPECT_EQ(prof->type,0x01);
	EXPECT_TRUE(teachHandler.isTeachedIN(*devManager.Get(0x12345678)));
	//Second teach in
	EXPECT_EQ(SECOND_TEACH_IN,teachHandler.TeachIN(0xA5,0x03,0x01,0x12345678));
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xA5);
	EXPECT_EQ(prof->func,0x02);
	EXPECT_EQ(prof->type,0x01);
}

TEST_F(TeachInTest, 4BSTeachInTelegram)
{
	eoMessage msg(4);
	msg.RORG=0xA5;
	msg.data[0]=0x08;
	msg.data[1]=0x0F;
	msg.data[2]=0xFF;
	msg.data[3]=0x80;
	msg.sourceID=0x0BADC0DE;
	EXPECT_EQ(EEP_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(devManager.Get(0x0BADC0DE)!=NULL);
	EXPECT_TRUE(teachHandler.isTeachedIN(*devManager.Get(0x0BADC0DE)));
	EXPECT_TRUE(teachHandler.isTeachedIN(msg));
	eoProfile *prof = devManager.Get(0x0BADC0DE)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xA5);
	EXPECT_EQ(prof->func,0x02);
	EXPECT_EQ(prof->type,0x01);
	EXPECT_EQ(prof->manufacturer,0x7FF);
	EXPECT_EQ(SECOND_TEACH_IN,teachHandler.TeachIN(msg));
	msg.data[0]=0x18;
	EXPECT_EQ(SECOND_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xA5);
	EXPECT_EQ(prof->func,0x02);
	EXPECT_EQ(prof->type,0x01);
	//Teach OUT
	teachHandler.TeachOut(0x0BADC0DE);
	EXPECT_EQ(EEP_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(devManager.Get(0x0BADC0DE)!=NULL);
	prof = devManager.Get(0x0BADC0DE)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xA5);
	EXPECT_EQ(prof->func,0x06);
	EXPECT_EQ(prof->type,0x01);
}

TEST_F(TeachInTest, RPSTest)
{
	eoMessage msg(1);
	msg.RORG=RORG_RPS;
	msg.data[0]=0x00;
	msg.sourceID=0x13371337;
	teachHandler.SetRPS(0x02,0x02);
	EXPECT_EQ(EEP_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(devManager.Get(0x13371337)!=NULL);
	EXPECT_TRUE(teachHandler.isTeachedIN(*devManager.Get(0x13371337)));
	EXPECT_TRUE(teachHandler.isTeachedIN(msg));
	eoProfile *prof = devManager.Get(0x13371337)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xF6);
	EXPECT_EQ(prof->func,0x02);
	EXPECT_EQ(prof->type,0x02);
}
TEST_F(TeachInTest, 1BSTest)
{
	eoMessage msg(1);
	msg.RORG=RORG_1BS;
	msg.data[0]=0x08;//no teach in...
	msg.sourceID=0x13371337;
	teachHandler.Set1BS(0x00,0x01);
	EXPECT_EQ(NO_TEACH_IN,teachHandler.TeachIN(msg));
	msg.data[0]=0x00;
	EXPECT_EQ(EEP_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(devManager.Get(0x13371337)!=NULL);
	EXPECT_TRUE(teachHandler.isTeachedIN(*devManager.Get(0x13371337)));
	EXPECT_TRUE(teachHandler.isTeachedIN(msg));
	eoProfile *prof = devManager.Get(0x13371337)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xD5);
	EXPECT_EQ(prof->func,0x00);
	EXPECT_EQ(prof->type,0x01);
}

TEST_F(TeachInTest, UTE_TEST)
{
	//Valid UTE, Query Response, Create UTEREsponse, parse ute response , no teach in, teach out, teach unknown...
	eoMessage msg(7);
	msg.RORG=RORG_UTE;
	msg.data[0]=0x80;
	//all channels
	msg.data[1]=0xFF;
	//manufacturer ID
	msg.data[2]=0xFF;
	//MSB
	msg.data[3]=0x7;
	msg.data[6]=0xD2;
	msg.data[5]=0xA0;
	msg.data[4]=0x01;
	msg.sourceID=0x13371337;
	EXPECT_EQ(EEP_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(devManager.Get(0x13371337)!=NULL);
	EXPECT_TRUE(teachHandler.isTeachedIN(*devManager.Get(0x13371337)));
	EXPECT_TRUE(teachHandler.isTeachedIN(msg));
	eoProfile *prof = devManager.Get(0x13371337)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_EQ(prof->rorg,0xD2);
	EXPECT_EQ(prof->func,0xA0);
	EXPECT_EQ(prof->type,0x01);
	eoMessage response(7);
	teachHandler.CreateUTEResponse(msg,response,TEACH_IN_ACCEPTED,UTE_DIRECTION_BIDIRECTIONAL);
	EXPECT_EQ(0x91,response.data[0]);
	EXPECT_EQ(0xFF,response.data[1]);
	EXPECT_EQ(0xFF,response.data[2]);
	EXPECT_EQ(0x7,response.data[3]);
	EXPECT_EQ(0x01,response.data[4]);
	EXPECT_EQ(0xA0,response.data[5]);
	EXPECT_EQ(0xD2,response.data[6]);
	//Response is not a teach IN
	EXPECT_EQ(NO_TEACH_IN,teachHandler.TeachIN(response));
	//second teach in...
	EXPECT_EQ(SECOND_TEACH_IN,teachHandler.TeachIN(msg));
	//Teach out rquest---
	msg.data[0]=0x90;
	EXPECT_EQ(REQUEST_FOR_TEACH_OUT,teachHandler.TeachIN(msg));

}
TEST_F(TeachInTest, GP_TEST)
{
	eoMessage msg(8);
	msg.RORG=GP_TI;
	msg.sourceID=0x13371337;
	msg.data[0]=0xFF;
	//all channels
	msg.data[1]=0xE0;
	//manufacturer ID
	msg.data[2]=0xFF;
	//MSB
	msg.data[3]=0x46;
	msg.data[4]=0x19;
	msg.data[5]=0xD8;
	msg.data[6]=0x15;
	msg.data[7]=0x01;
	EXPECT_EQ(GENERIC_TEACH_IN,teachHandler.TeachIN(msg));
	ASSERT_TRUE(devManager.Get(0x13371337)!=NULL);
	EXPECT_TRUE(teachHandler.isTeachedIN(*devManager.Get(0x13371337)));
	EXPECT_TRUE(teachHandler.isTeachedIN(msg));
	eoProfile *prof = devManager.Get(0x13371337)->GetProfile();
	ASSERT_TRUE(prof!=NULL);
	EXPECT_TRUE(typeid(*prof)==typeid(eoGenericProfile));
	eoMessage response(9);
	teachHandler.CreateGPResponse(response,0x7FF,0x13371337,RESP_TEACHIN,prof);
	EXPECT_EQ(0x02,response.GetDataLength());
	EXPECT_EQ(GP_TR,response.RORG);
	EXPECT_EQ(0x13371337,response.destinationID);
	EXPECT_EQ(0xFF,response.data[0]);
	EXPECT_EQ(0xE8,response.data[1]);
}
