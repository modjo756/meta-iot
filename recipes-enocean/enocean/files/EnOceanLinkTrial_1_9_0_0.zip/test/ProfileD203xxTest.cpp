/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Profiles/eoEEP_D203xx.h"
//Helper function for A5
class profileD203xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(1);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x03, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};

TEST_F(profileD203xxTest,eepD20300Receive)
{
	uint8_t u8GetValue;
	//Setup the test
	Init(0x00);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_ROCKER_A));
	EXPECT_TRUE(ChannelExist(E_ROCKER_B));
	EXPECT_TRUE(ChannelExist(E_ENERGYBOW));
	EXPECT_TRUE(ChannelExist(E_MULTIPRESS));
	//Enum tests - 0
	ParseRawDate({0x05},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_I,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_O,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);
	//0x06
	ParseRawDate({0x06},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_YES,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);
	//0x07
	ParseRawDate({0x07},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_O,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_O,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);
	//0x08
	ParseRawDate({0x08},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);
	//0x09
	ParseRawDate({0x09},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_I,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_I,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	ParseRawDate({10},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_O,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_I,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	ParseRawDate({11},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_I,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	ParseRawDate({12},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_O,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	ParseRawDate({13},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_I,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	ParseRawDate({14},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_O,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	ParseRawDate({15},1);
	myProf->GetValue(E_ROCKER_A, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_ROCKER_B, u8GetValue);
	EXPECT_EQ(STATE_NP,u8GetValue);
	myProf->GetValue(E_MULTIPRESS, u8GetValue);
	EXPECT_EQ(MULTIPRESS_NOT,u8GetValue);
	myProf->GetValue(E_ENERGYBOW,u8GetValue);
	EXPECT_EQ(ENERGY_RELEASED,u8GetValue);
}

TEST_F(profileD203xxTest,eepD20300Send)
{
	//Setup the test
	Init(0x00);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_ROCKER_A));
	EXPECT_TRUE(ChannelExist(E_ROCKER_B));
	EXPECT_TRUE(ChannelExist(E_ENERGYBOW));
	EXPECT_TRUE(ChannelExist(E_MULTIPRESS));
	//Enum tests - 0
	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_I);
	myProf->SetValue(E_ROCKER_B,(uint8_t)  STATE_O);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(0x05,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_NP);
	myProf->SetValue(E_ROCKER_B,(uint8_t)  STATE_NP);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_YES);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(0x06,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_O);
	myProf->SetValue(E_ROCKER_B,(uint8_t)  STATE_O);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(0x07,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_NP);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_NP);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(0x08,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_I);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_I);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(0x09,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_O);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_I);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(10,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_NP);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_I);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(11,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_NP);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_O);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(12,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_I);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_NP);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(13,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_O);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_NP);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_PRESSED);
	myProf->Create(*msg);
	EXPECT_EQ(14,msg->data[0]);

	myProf->SetValue(E_ROCKER_A,(uint8_t) STATE_NP);
	myProf->SetValue(E_ROCKER_B,(uint8_t) STATE_NP);
	myProf->SetValue(E_MULTIPRESS,(uint8_t)  MULTIPRESS_NOT);
	myProf->SetValue(E_ENERGYBOW,(uint8_t) ENERGY_RELEASED);
	myProf->Create(*msg);
	EXPECT_EQ(15,msg->data[0]);
}

TEST_F(profileD203xxTest,eepD20310Send)
{
	//Setup the test
	Init(0x10);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_WINDOWHANDLE));

	myProf->SetValue(E_WINDOWHANDLE,(uint8_t) WINDOW_UP);
	myProf->Create(*msg);
	EXPECT_EQ(4,msg->data[0]);

	myProf->SetValue(E_WINDOWHANDLE,(uint8_t) WINDOW_DOWN);
	myProf->Create(*msg);
	EXPECT_EQ(2,msg->data[0]);

	myProf->SetValue(E_WINDOWHANDLE,(uint8_t) WINDOW_MIDDLE);
	myProf->Create(*msg);
	EXPECT_EQ(1,msg->data[0]);

}

TEST_F(profileD203xxTest,eepD20310Receive)
{
	uint8_t u8GetValue;
	//Setup the test
	Init(0x10);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_WINDOWHANDLE));
	ParseRawDate({0x01},1);
	myProf->GetValue(E_WINDOWHANDLE, u8GetValue);
	EXPECT_EQ(WINDOW_MIDDLE,u8GetValue);

	ParseRawDate({0x02},1);
	myProf->GetValue(E_WINDOWHANDLE, u8GetValue);
	EXPECT_EQ(WINDOW_DOWN,u8GetValue);

	ParseRawDate({0x03},1);
	myProf->GetValue(E_WINDOWHANDLE, u8GetValue);
	EXPECT_EQ(WINDOW_MIDDLE,u8GetValue);

	ParseRawDate({0x04},1);
	myProf->GetValue(E_WINDOWHANDLE, u8GetValue);
	EXPECT_EQ(WINDOW_UP,u8GetValue);
}

TEST_F(profileD203xxTest,eepD20320Send)
{
	//Setup the test
	Init(0x20);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));

	myProf->SetValue(E_STATE,(uint8_t) 0);
	myProf->Create(*msg);
	EXPECT_EQ(0,msg->data[0]);

	myProf->SetValue(E_STATE,(uint8_t) 1);
	myProf->Create(*msg);
	EXPECT_EQ(128,msg->data[0]);

}

TEST_F(profileD203xxTest,eepD20320Receive)
{
	uint8_t u8GetValue;
	//Setup the test
	Init(0x20);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));

	ParseRawDate({0x00},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,u8GetValue);

	ParseRawDate({0x80},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1,u8GetValue);
}
