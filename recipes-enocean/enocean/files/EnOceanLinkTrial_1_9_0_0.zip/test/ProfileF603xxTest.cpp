/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include <gtest/gtest.h>

void CheckSetButtons(uint8_t a,uint8_t b,uint8_t c,uint8_t d,uint8_t bow, uint8_t expectValue, eoProfile *myProf)
{
	uint8_t ret;
	eoMessage msg (1);
	msg.RORG=RORG_RPS;
	myProf->ClearValues();
	ret = myProf->SetValue(E_ROCKER_A, a);
	EXPECT_EQ(EO_OK,ret);
	ret = myProf->SetValue(E_ROCKER_B, b);
	EXPECT_EQ(EO_OK,ret);
	ret = myProf->SetValue(E_ROCKER_C, c);
	EXPECT_EQ(EO_OK,ret);
	ret = myProf->SetValue(E_ROCKER_D, d);
	EXPECT_EQ(EO_OK,ret);
	ret = myProf->SetValue(E_ENERGYBOW, bow);
	EXPECT_EQ(EO_OK,ret);

	myProf->Create(msg);

	EXPECT_EQ(expectValue,msg.data[0]);
}


void NegativeCheckSetButtons(uint8_t a,uint8_t b,uint8_t c,uint8_t d,uint8_t bow, uint8_t expectRet, uint8_t numError, eoProfile *myProf)
{
	uint8_t cnt = 0;
	uint8_t ret;

	myProf->ClearValues();
	ret = myProf->SetValue(E_ROCKER_A, a);
	if (ret == expectRet)
		cnt++;
	ret = myProf->SetValue(E_ROCKER_B, b);
	if (ret == expectRet)
		cnt++;
	ret = myProf->SetValue(E_ROCKER_C, c);
	if (ret == expectRet)
		cnt++;
	ret = myProf->SetValue(E_ROCKER_D, d);
	if (ret == expectRet)
		cnt++;
	ret = myProf->SetValue(E_ENERGYBOW, bow);
	if (ret == expectRet)
		cnt++;


	EXPECT_EQ(cnt,numError);
}

void CheckGetButton (uint8_t data, uint8_t a, uint8_t b, uint8_t c, uint8_t d, uint8_t bow, eoProfile *myProf)
{
	uint8_t rocker1;
	uint8_t rocker2;
	uint8_t rocker3;
	uint8_t rocker4;
	uint8_t eBow;
	uint8_t mPres;
	eoMessage msg(1);
	msg.RORG=RORG_RPS;
	msg.data[0]=data;
	msg.status=0x30;
	myProf->Parse(msg);

	myProf->GetValue(E_ENERGYBOW,eBow);
	myProf->GetValue(E_MULTIPRESS,mPres);
	myProf->GetValue(E_ROCKER_A,rocker1);
	myProf->GetValue(E_ROCKER_B,rocker2);
	myProf->GetValue(E_ROCKER_C,rocker3);
	myProf->GetValue(E_ROCKER_D,rocker4);

	EXPECT_EQ(eBow,bow);
	EXPECT_EQ(mPres,0);
	EXPECT_EQ(rocker1,a);
	EXPECT_EQ(rocker2,b);
	EXPECT_EQ(rocker3,c);
	EXPECT_EQ(rocker4,d);
}

TEST(eoProfile,eepF60301)
{
	eoProfile* myProf= eoProfileFactory::CreateProfile(0xF6,0x03,0x01);

					    //i     		0      1      2      3	  4 	5	  6		7		8	9	 10		11	  12	13	  14	15
	const uint8_t expected_data1[16] = { 0xFF,  0xFF, 0xFF,  0x27,  0xFF, 0x2B, 0x2F, 0x20, 0xFF, 0x6B, 0x6F, 0x60, 0xAF, 0xA0, 0xE0, 0xFF};

	for (uint8_t i = 0; i<16; i++)
	{
		if (expected_data1[i] == 0xFF)
			continue;
		CheckSetButtons((uint8_t)(((i>>3) & 1)+1),(uint8_t)(((i>>2) & 1)+1),(uint8_t)(((i>>1) & 1)+1),(uint8_t)((i & 1)+1),0,expected_data1[i],myProf);
	}

	const uint8_t expected_data2[4] = {0x10, 0x50,  0x90, 0xD0};

	CheckSetButtons(0,2,2,2,1,expected_data2[0],myProf);
	CheckSetButtons(2,0,2,2,1,expected_data2[1],myProf);
	CheckSetButtons(2,2,0,2,1,expected_data2[2],myProf);
	CheckSetButtons(2,2,2,0,1,expected_data2[3],myProf);

	const uint8_t expected_data3[2] = {0x2F, 0x5D};

	CheckSetButtons(1,2,2,1,0,expected_data3[0],myProf);
	CheckSetButtons(2,0,2,0,1,expected_data3[1],myProf);

	//negative tests

	NegativeCheckSetButtons (3,3,3,3,3,OUT_OF_RANGE,5,myProf);

	/////////////////////////////////////////////////////////////////////////////////////////////////////

	//Rocker A = STATE_I
	CheckGetButton(0x10,0,2,2,2,1,myProf);

	//Rocker A = STATE_O
	CheckGetButton(0x30,1,2,2,2,1,myProf);

	//Rocker B = STATE_I
	CheckGetButton(0x50,2,0,2,2,1,myProf);

	//Rocker B = STATE_O
	CheckGetButton(0x70,2,1,2,2,1,myProf);

	//Rocker C = STATE_I
	CheckGetButton(0x90,2,2,0,2,1,myProf);

	//Rocker C = STATE_O
	CheckGetButton(0xB0,2,2,1,2,1,myProf);

	//Rocker D = STATE_I
	CheckGetButton(0xD0,2,2,2,0,1,myProf);

	//Rocker D = STATE_O
	CheckGetButton(0xF0,2,2,2,1,1,myProf);

	//Rocker A = STATE_I, RockerB = STATE_I
	CheckGetButton(0x15,0,0,2,2,1,myProf);

	//Rocker A = STATE_I, RockerB = STATE_O
	CheckGetButton(0x17,0,1,2,2,1,myProf);

	//Rocker A = STATE_I, RockerC = STATE_I
	CheckGetButton(0x19,0,2,0,2,1,myProf);

	//Rocker A = STATE_I, RockerC = STATE_O
	CheckGetButton(0x1B,0,2,1,2,1,myProf);

	//Rocker A = STATE_I, RockerD = STATE_I
	CheckGetButton(0x1D,0,2,2,0,1,myProf);

	//Rocker A = STATE_I, RockerD = STATE_O
	CheckGetButton(0x1F,0,2,2,1,1,myProf);

	//Rocker A = STATE_O, RockerB = STATE_I
	CheckGetButton(0x35,1,0,2,2,1,myProf);

	//Rocker A = STATE_O, RockerB = STATE_O
	CheckGetButton(0x37,1,1,2,2,1,myProf);

	//Rocker A = STATE_O, RockerC = STATE_I
	CheckGetButton(0x39,1,2,0,2,1,myProf);

	//Rocker A = STATE_O, RockerC = STATE_O
	CheckGetButton(0x3B,1,2,1,2,1,myProf);

	//Rocker A = STATE_I, RockerD = STATE_I
	CheckGetButton(0x3D,1,2,2,0,1,myProf);

	//Rocker A = STATE_I, RockerD = STATE_O
	CheckGetButton(0x3F,1,2,2,1,1,myProf);

	//Rocker B = STATE_I, RockerA = STATE_I
	CheckGetButton(0x51,0,0,2,2,1,myProf);

	//Rocker B = STATE_I, RockerA = STATE_O
	CheckGetButton(0x53,1,0,2,2,1,myProf);

	//Rocker B = STATE_I, RockerC = STATE_I
	CheckGetButton(0x59,2,0,0,2,1,myProf);

	//Rocker B = STATE_I, RockerC = STATE_O
	CheckGetButton(0x5B,2,0,1,2,1,myProf);

	//Rocker B = STATE_I, RockerD = STATE_I
	CheckGetButton(0x5D,2,0,2,0,1,myProf);

	//Rocker B = STATE_I, RockerD = STATE_O
	CheckGetButton(0x5F,2,0,2,1,1,myProf);

	//Rocker B = STATE_O, RockerA = STATE_I
	CheckGetButton(0x71,0,1,2,2,1,myProf);

	//Rocker B = STATE_O, RockerA = STATE_O
	CheckGetButton(0x73,1,1,2,2,1,myProf);

	//Rocker B = STATE_O, RockerC = STATE_I
	CheckGetButton(0x79,2,1,0,2,1,myProf);

	//Rocker B = STATE_O, RockerC = STATE_O
	CheckGetButton(0x7B,2,1,1,2,1,myProf);

	//Rocker B = STATE_O, RockerD = STATE_I
	CheckGetButton(0x7D,2,1,2,0,1,myProf);

	//Rocker B = STATE_O, RockerD = STATE_O
	CheckGetButton(0x7F,2,1,2,1,1,myProf);

	//Rocker C = STATE_I, RockerA = STATE_I
	CheckGetButton(0x91,0,2,0,2,1,myProf);

	//Rocker C = STATE_I, RockerA = STATE_O
	CheckGetButton(0x93,1,2,0,2,1,myProf);

	//Rocker C = STATE_I, RockerB = STATE_I
	CheckGetButton(0x95,2,0,0,2,1,myProf);

	//Rocker C = STATE_I, RockerB = STATE_O
	CheckGetButton(0x97,2,1,0,2,1,myProf);

	//Rocker C = STATE_I, RockerD = STATE_I
	CheckGetButton(0x9D,2,2,0,0,1,myProf);

	//Rocker C = STATE_I, RockerD = STATE_O
	CheckGetButton(0x9F,2,2,0,1,1,myProf);

	//Rocker C = STATE_O, RockerA = STATE_I
	CheckGetButton(0xB1,0,2,1,2,1,myProf);

	//Rocker C = STATE_O, RockerA = STATE_O
	CheckGetButton(0xB3,1,2,1,2,1,myProf);

	//Rocker C = STATE_O, RockerB = STATE_I
	CheckGetButton(0xB5,2,0,1,2,1,myProf);

	//Rocker C = STATE_O, RockerB = STATE_O
	CheckGetButton(0xB7,2,1,1,2,1,myProf);

	//Rocker C = STATE_O, RockerD = STATE_I
	CheckGetButton(0xBD,2,2,1,0,1,myProf);

	//Rocker C = STATE_O, RockerD = STATE_O
	CheckGetButton(0xBF,2,2,1,1,1,myProf);

	//Rocker D = STATE_I, RockerA = STATE_I
	CheckGetButton(0xD1,0,2,2,0,1,myProf);

	//Rocker D = STATE_I, RockerA = STATE_O
	CheckGetButton(0xD3,1,2,2,0,1,myProf);

	//Rocker D = STATE_I, RockerB = STATE_I
	CheckGetButton(0xD5,2,0,2,0,1,myProf);

	//Rocker D = STATE_I, RockerB = STATE_O
	CheckGetButton(0xD7,2,1,2,0,1,myProf);

	//Rocker D = STATE_I, RockerC = STATE_I
	CheckGetButton(0xD9,2,2,0,0,1,myProf);

	//Rocker D = STATE_I, RockerC = STATE_O
	CheckGetButton(0xDB,2,2,1,0,1,myProf);

	//Rocker D = STATE_O, RockerA = STATE_I
	CheckGetButton(0xF1,0,2,2,1,1,myProf);

	//Rocker D = STATE_O, RockerA = STATE_O
	CheckGetButton(0xF3,1,2,2,1,1,myProf);

	//Rocker D = STATE_O, RockerB = STATE_I
	CheckGetButton(0xF5,2,0,2,1,1,myProf);

	//Rocker D = STATE_O, RockerB = STATE_O
	CheckGetButton(0xF7,2,1,2,1,1,myProf);

	//Rocker D = STATE_O, RockerC = STATE_I
	CheckGetButton(0xF9,2,2,0,1,1,myProf);

	//Rocker D = STATE_O, RockerC = STATE_O
	CheckGetButton(0xFB,2,2,1,1,1,myProf);
}
