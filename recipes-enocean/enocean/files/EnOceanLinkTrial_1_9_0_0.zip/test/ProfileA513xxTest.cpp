/*
 * ProfileA504Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA513xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x13, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA513xxTest,eepA51301ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_VELOCITY));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x18},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(499, fGetValue, 2);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x18},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(999, fGetValue, 2);

	// S_TEMP
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x18},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 0.5);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x18},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(80.0, fGetValue, 0.5);

	// S_VELOCITY
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(S_VELOCITY, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x18},4);
	myProf->GetValue(S_VELOCITY, fGetValue);
	EXPECT_NEAR(35.0, fGetValue, 0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x18},4);
	myProf->GetValue(S_VELOCITY, fGetValue);
	EXPECT_NEAR(70.0, fGetValue, 0.5);

	// F_DAY_NIGHT
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x1C},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x1A},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA513xxTest,eepA51301ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(S_VELOCITY));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)499);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)999);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TEMP
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)80.0);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_VELOCITY
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VELOCITY,(float)0.0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VELOCITY,(float)35.0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x18};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VELOCITY,(float)70.0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x18};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_DAY_NIGHT
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x1C};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x1A};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51302ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_LUMINANCE - SUN_WEST
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_WEST);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_WEST);
	EXPECT_NEAR(75, fGetValue, 0.5);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_WEST);
	EXPECT_NEAR(150, fGetValue, 0.5);

	// S_LUMINANCE - SUN_SOUTH
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_SOUTH);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_SOUTH);
	EXPECT_NEAR(75, fGetValue, 0.5);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_SOUTH);
	EXPECT_NEAR(150, fGetValue, 0.5);

	// S_LUMINANCE - SUN_EAST
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_EAST);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_EAST);
	EXPECT_NEAR(75, fGetValue, 0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x28},4);
	myProf->GetValue(S_LUMINANCE, fGetValue, SUN_EAST);
	EXPECT_NEAR(150, fGetValue, 0.5);

	// F_ON_OFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x2C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA513xxTest,eepA51302ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_LUMINANCE - SUN_WEST
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0, SUN_WEST);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)75, SUN_WEST);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)150, SUN_WEST);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE - SUN_SOUTH
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0, SUN_SOUTH);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)75, SUN_SOUTH);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)150, SUN_SOUTH);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_LUMINANCE - SUN_EAST
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0, SUN_EAST);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)75, SUN_EAST);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x28};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)150, SUN_EAST);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x28};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x2C};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51303ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_TIME - TIME_DAY
	// Min value
	ParseRawDate({0x01, 0x00, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_DAY);
	EXPECT_EQ(1, fGetValue);

	// Median value
	ParseRawDate({0x0F, 0x00, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_DAY);
	EXPECT_EQ(15, fGetValue);

	// Max value
	ParseRawDate({0x1F, 0x00, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_DAY);
	EXPECT_EQ(31, fGetValue);

	// S_TIME - TIME_MONTH
	// Min value
	ParseRawDate({0x00, 0x01, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_MONTH);
	EXPECT_EQ(1, fGetValue);

	// Median value
	ParseRawDate({0x00, 0x06, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_MONTH);
	EXPECT_EQ(6, fGetValue);

	// Max value
	ParseRawDate({0x00, 0x0C, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_MONTH);
	EXPECT_EQ(12, fGetValue);

	// S_TIME - TIME_YEAR
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_YEAR);
	EXPECT_EQ(2000, fGetValue);

	// Median value
	ParseRawDate({0x00, 0x00, 0x31, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_YEAR);
	EXPECT_EQ(2049, fGetValue);

	// Max value
	ParseRawDate({0x00, 0x00, 0x63, 0x38},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_YEAR);
	EXPECT_EQ(2099, fGetValue);

	// F_ON_OFF
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x39},4);
	myProf->GetValue(F_ON_OFF, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA513xxTest,eepA51303ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_TIME - TIME_DAY
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)1, TIME_DAY);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)15, TIME_DAY);
	myProf->Create(*msg);
	uint8_t data2[] = {0x0F, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)31, TIME_DAY);
	myProf->Create(*msg);
	uint8_t data3[] = {0x1F, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TIME - TIME_MONTH
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)1, TIME_MONTH);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x01, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)6, TIME_MONTH);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x06, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)12, TIME_MONTH);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x0C, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TIME - TIME_YEAR
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)2000, TIME_YEAR);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)2049, TIME_YEAR);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x31, 0x38};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)2099, TIME_YEAR);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x63, 0x38};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x39};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51304ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_DAYS));
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// E_DAYS - TIME_HOUR
	// Enum - 1
	ParseRawDate({0x20, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 2
	ParseRawDate({0x40, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum - 3
	ParseRawDate({0x60, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum - 4
	ParseRawDate({0x80, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum - 5
	ParseRawDate({0xA0, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum - 6
	ParseRawDate({0xC0, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum - 7
	ParseRawDate({0xE0, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_DAYS, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_TIME - TIME_HOUR
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_HOUR);
	EXPECT_EQ(0, fGetValue);

	// Median value
	ParseRawDate({0x0C, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_HOUR);
	EXPECT_EQ(12, fGetValue);

	// Max value
	ParseRawDate({0x17, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_HOUR);
	EXPECT_EQ(23, fGetValue);

	// S_TIME - TIME_MINUTE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_MINUTE);
	EXPECT_EQ(0, fGetValue);

	// Median value
	ParseRawDate({0x00, 0x1E, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_MINUTE);
	EXPECT_EQ(30, fGetValue);

	// Max value
	ParseRawDate({0x00, 0x3B, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_MINUTE);
	EXPECT_EQ(59, fGetValue);

	// S_TIME - TIME_SECOND
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_SECOND);
	EXPECT_EQ(0, fGetValue);

	// Median value
	ParseRawDate({0x00, 0x00, 0x1E, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_SECOND);
	EXPECT_EQ(30, fGetValue);

	// Max value
	ParseRawDate({0x00, 0x00, 0x3B, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue, TIME_SECOND);
	EXPECT_EQ(59, fGetValue);

	// F_ON_OFF - TIME_FORMAT
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TIME_FORMAT);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x4C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TIME_FORMAT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - AM_PM
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, AM_PM);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x4A},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, AM_PM);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - TIME_SOURCE
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TIME_SOURCE);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x49},4);
	myProf->GetValue(F_ON_OFF, u8GetValue, TIME_SOURCE);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA513xxTest,eepA51304ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_DAYS));
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_TIME - TIME_HOUR
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)0, TIME_HOUR);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)12, TIME_HOUR);
	myProf->Create(*msg);
	uint8_t data2[] = {0x0C, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)23, TIME_HOUR);
	myProf->Create(*msg);
	uint8_t data3[] = {0x17, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_TIME - TIME_MINUTE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)0, TIME_MINUTE);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)30, TIME_MINUTE);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x1E, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)59, TIME_MINUTE);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x3B, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_TIME - TIME_SECOND
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)0, TIME_SECOND);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)30, TIME_SECOND);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x1E, 0x48};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)59, TIME_SECOND);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x3B, 0x48};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF - TIME_FORMAT
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TIME_FORMAT);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TIME_FORMAT);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x4C};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_ON_OFF - AM_PM
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, AM_PM);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, AM_PM);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x4A};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// F_ON_OFF - TIME_SOURCE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, TIME_SOURCE);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, TIME_SOURCE);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x49};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// E_DAYS
	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data16[] = {0x20, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum - 2
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data17[] = {0x40, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum - 3
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data18[] = {0x60, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum - 4
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data19[] = {0x80, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum - 5
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data20[] = {0xA0, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum - 6
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data21[] = {0xC0, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum - 7
	myProf->ClearValues();
	myProf->SetValue(E_DAYS,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data22[] = {0xE0, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51305ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_ANGLE - TIME_HOUR
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(S_ANGLE, fGetValue, ELEVATION);
	EXPECT_EQ(-90, fGetValue);

	// Median value
	ParseRawDate({0x5A, 0x00, 0x00, 0x58},4);
	myProf->GetValue(S_ANGLE, fGetValue, ELEVATION);
	EXPECT_EQ(0, fGetValue);

	// Max value
	ParseRawDate({0xB4, 0x00, 0x00, 0x58},4);
	myProf->GetValue(S_ANGLE, fGetValue, ELEVATION);
	EXPECT_EQ(90, fGetValue);

	// S_ANGLE - TIME_MINUTE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x58},4);
	myProf->GetValue(S_ANGLE, fGetValue, AZIMUTH);
	EXPECT_EQ(0, fGetValue);

	// Median value
	ParseRawDate({0x00, 0x00, 0xB4, 0x58},4);
	myProf->GetValue(S_ANGLE, fGetValue, AZIMUTH);
	EXPECT_EQ(180, fGetValue);

	// Max value
	ParseRawDate({0x00, 0x01, 0x67, 0x58},4);
	myProf->GetValue(S_ANGLE, fGetValue, AZIMUTH);
	EXPECT_EQ(359, fGetValue);
}

TEST_F(profileA513xxTest,eepA51305ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_ANGLE - ELEVATION
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)-90, ELEVATION);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0, ELEVATION);
	myProf->Create(*msg);
	uint8_t data2[] = {0x5A, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)90, ELEVATION);
	myProf->Create(*msg);
	uint8_t data3[] = {0xB4, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_ANGLE - AZIMUTH
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0, AZIMUTH);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x58};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)180, AZIMUTH);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0xB4, 0x58};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)359, AZIMUTH);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x01, 0x67, 0x58};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51306ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_ANGLE - LATITUDE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(S_ANGLE, fGetValue, LATITUDE);
	EXPECT_NEAR(-90, fGetValue,0.5);

	// Median value
	ParseRawDate({0x80, 0x00, 0x00, 0x68},4);
	myProf->GetValue(S_ANGLE, fGetValue, LATITUDE);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Max value
	ParseRawDate({0xF0, 0xFF, 0x00, 0x68},4);
	myProf->GetValue(S_ANGLE, fGetValue, LATITUDE);
	EXPECT_NEAR(90, fGetValue,0.5);

	// S_ANGLE - LATITUDE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(S_ANGLE, fGetValue, LONGITUDE);
	EXPECT_NEAR(-180, fGetValue,0.5);

	// Median value
	ParseRawDate({0x08, 0x00, 0x00, 0x68},4);
	myProf->GetValue(S_ANGLE, fGetValue, LONGITUDE);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Max value
	ParseRawDate({0x0F, 0x00, 0xFF, 0x68},4);
	myProf->GetValue(S_ANGLE, fGetValue, LONGITUDE);
	EXPECT_NEAR(180, fGetValue,0.5);
}

TEST_F(profileA513xxTest,eepA51306ControllerSendData)
{
	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_ANGLE - LATITUDE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)-90, LATITUDE);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0, LATITUDE);
	myProf->Create(*msg);
	uint8_t data2[] = {0x70, 0xFF, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)90, LATITUDE);
	myProf->Create(*msg);
	uint8_t data3[] = {0xF0, 0xFF, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_ANGLE - LONGITUDE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)-180, LONGITUDE);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0, LONGITUDE);
	myProf->Create(*msg);
	uint8_t data5[] = {0x07, 0x00, 0xFF, 0x68};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)180, LONGITUDE);
	myProf->Create(*msg);
	uint8_t data6[] = {0x0F, 0x00, 0xFF, 0x68};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51310ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(S_SOLAR_RAD));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_ANGLE - ELEVATION
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_ANGLE, fGetValue, ELEVATION);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Median value
	ParseRawDate({0x5A, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_ANGLE, fGetValue, ELEVATION);
	EXPECT_NEAR(45, fGetValue,0.5);

	// Max value
	ParseRawDate({0xB4, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_ANGLE, fGetValue, ELEVATION);
	EXPECT_NEAR(90, fGetValue,0.5);

	// F_DAY_NIGHT
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x78},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// S_ANGLE - AZIMUTH
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_ANGLE, fGetValue, AZIMUTH);
	EXPECT_NEAR(-90, fGetValue,0.5);

	// Median value
	ParseRawDate({0x00, 0x5A, 0x00, 0x78},4);
	myProf->GetValue(S_ANGLE, fGetValue, AZIMUTH);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xB4, 0x00, 0x78},4);
	myProf->GetValue(S_ANGLE, fGetValue, AZIMUTH);
	EXPECT_NEAR(90, fGetValue,0.5);

	// S_SOLAR_RAD
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x78},4);
	myProf->GetValue(S_SOLAR_RAD, fGetValue);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Median value
	ParseRawDate({0x00, 0x00, 0x7D, 0x78},4);
	myProf->GetValue(S_SOLAR_RAD, fGetValue);
	EXPECT_NEAR(1000, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFA, 0x78},4);
	myProf->GetValue(S_SOLAR_RAD, fGetValue);
	EXPECT_NEAR(2000, fGetValue,0.5);
}

TEST_F(profileA513xxTest,eepA51310ControllerSendData)
{
	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(S_SOLAR_RAD));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_ANGLE - ELEVATION
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0, ELEVATION);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)45, ELEVATION);
	myProf->Create(*msg);
	uint8_t data2[] = {0x5A, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)90, ELEVATION);
	myProf->Create(*msg);
	uint8_t data3[] = {0xB4, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_ANGLE - AZIMUTH
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)-90, AZIMUTH);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0, AZIMUTH);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x5A, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)90, AZIMUTH);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xB4, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// F_DAY_NIGHT
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// S_SOLAR_RAD
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SOLAR_RAD,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x78};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SOLAR_RAD,(float)1000);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x7D, 0x78};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SOLAR_RAD,(float)2000);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0xFA, 0x78};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51308ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(S_COUNTER));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_PERCENTAGE
	// Min value
	ParseRawDate({0x27, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR((float)-3.9, fGetValue,0.5);

	// Median value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Max value
	ParseRawDate({0x67, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(3.9, fGetValue,0.5);

	// S_COUNTER
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR((float)0, fGetValue,0.5);

	// Median value
	ParseRawDate({0x00, 0x7F, 0xFF, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(32767, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFF, 0xFF, 0x08},4);
	myProf->GetValue(S_COUNTER, fGetValue);
	EXPECT_NEAR(65535, fGetValue,0.5);

	// E_STATE
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA513xxTest,eepA51308ControllerSendData)
{
	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_PERCENTAGE));
	EXPECT_TRUE(ChannelExist(S_COUNTER));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_PERCENTAGE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)-3.9);
	myProf->Create(*msg);
	uint8_t data1[] = {0x27, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)0.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x40, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_PERCENTAGE,(float)3.9);
	myProf->Create(*msg);
	uint8_t data3[] = {0x67, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_COUNTER
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)32767);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_COUNTER,(float)65535);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// E_STATE
	// Enum - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);
}

TEST_F(profileA513xxTest,eepA51307ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_DIRECTION));
	EXPECT_TRUE(ChannelExist(S_VALUE));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// E_DIRECTION
	// NNE - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// NE - 1
	ParseRawDate({0x01, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// ENE - 2
	ParseRawDate({0x02, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// E - 3
	ParseRawDate({0x03, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// ESE - 4
	ParseRawDate({0x04, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// SE - 5
	ParseRawDate({0x05, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// SSE - 6
	ParseRawDate({0x06, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// S - 7
	ParseRawDate({0x07, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// SSW - 8
	ParseRawDate({0x08, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(8, u8GetValue);

	// SW - 9
	ParseRawDate({0x09, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// WSW - 10
	ParseRawDate({0x0A, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(10, u8GetValue);

	// W - 11
	ParseRawDate({0x0B, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(11, u8GetValue);

	// WNW - 12
	ParseRawDate({0x0C, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(12, u8GetValue);

	// NW - 13
	ParseRawDate({0x0D, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(13, u8GetValue);

	// NNW - 14
	ParseRawDate({0x0E, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(14, u8GetValue);

	// N - 15
	ParseRawDate({0x0F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_DIRECTION, u8GetValue);
	EXPECT_EQ(15, u8GetValue);

	// S_VALUE - AVG_WIND_SPEED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue, AVG_WIND_SPEED);
	EXPECT_NEAR((float)1, fGetValue,0.5);

	// Median value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue, AVG_WIND_SPEED);
	EXPECT_NEAR(100, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue, AVG_WIND_SPEED);
	EXPECT_NEAR(199.9, fGetValue,0.5);

	// S_VALUE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue, MAX_WIND_SPEED);
	EXPECT_NEAR((float)1, fGetValue,0.5);

	// Median value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue, MAX_WIND_SPEED);
	EXPECT_NEAR(100, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_VALUE, fGetValue, MAX_WIND_SPEED);
	EXPECT_NEAR(199.9, fGetValue,0.5);

	// E_STATE
	// Enum - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA513xxTest,eepA51307ControllerSendData)
{
	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_DIRECTION));
	EXPECT_TRUE(ChannelExist(S_VALUE));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(E_COMMAND));

	// S_VALUE - AVG_WIND_SPEED
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)1, AVG_WIND_SPEED);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)100, AVG_WIND_SPEED);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x7E, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)199.9, AVG_WIND_SPEED);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_VALUE - MAX_WIND_SPEED
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)1, MAX_WIND_SPEED);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)100, MAX_WIND_SPEED);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x7E, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)199.9, MAX_WIND_SPEED);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// E_DIRECTION
	// NNE - 0
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// NE - 1
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x01, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// ENE - 2
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x02, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// E - 3
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x03, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// ESE - 4
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data11[] = {0x04, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// SE - 5
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// SSE - 6
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data13[] = {0x06, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// S - 7
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data14[] = {0x07, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// SSW - 8
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data15[] = {0x08, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// SW - 9
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data16[] = {0x09, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// WSW - 10
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data17[] = {0x0A, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// W - 11
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data18[] = {0x0B, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// WNW - 12
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)12);
	myProf->Create(*msg);
	uint8_t data19[] = {0x0C, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// NW - 13
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)13);
	myProf->Create(*msg);
	uint8_t data20[] = {0x0D, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// NNW - 14
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)14);
	myProf->Create(*msg);
	uint8_t data21[] = {0x0E, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// N - 15
	myProf->ClearValues();
	myProf->SetValue(E_DIRECTION,(uint8_t)15);
	myProf->Create(*msg);
	uint8_t data22[] = {0x0F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);
}
