/*
 * profileFixture.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */


#include "GatewayFixture.h"
#include "stdlib.h"

eoReturn  GatewayFixture::Send(const eoReManMessage &reMsg,bool rep) {
	reManMessage.fnCode = reMsg.fnCode;
	reManMessage.dataLength = reMsg.dataLength;
	reManMessage.manufacturerID = reMsg.manufacturerID;
	reManMessage.sourceID = reMsg.sourceID;
	reManMessage.destinationID = reMsg.destinationID;
	memcpy (reManMessage.data, reMsg.data, reMsg.dataLength);

	return EO_OK;
}

eoReturn GatewayFixture::Send (const eoPacket &p) {
	packet.type = p.type;
	packet.dataLength = p.dataLength;
	packet.data = p.data;
	packet.optionalLength = p.optionalLength;
	return EO_OK;
}
