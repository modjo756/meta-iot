/*
 * ProfileD200Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileD200xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(6);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x00, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileD200xxTest,eepD20001ControllerReceiveData01)
{
	uint8_t u8GetValue;

	// Setup the test
	Init(0x01);

	// F_ON_OFF
	// Off
	ParseRawDate({0x01, 0x00},2);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_CONFIG_VALID);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x01, 0x80},2);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_CONFIG_VALID);
	EXPECT_EQ(1, u8GetValue);

	// E_USER_ACTION
	// Presence - 1
	ParseRawDate({0x01, 0x01},2);
	myProf->GetValue(E_USER_ACTION, u8GetValue);
	EXPECT_EQ(PRESENCE, u8GetValue);

	// Temp down - 2
	ParseRawDate({0x01, 0x02},2);
	myProf->GetValue(E_USER_ACTION, u8GetValue);
	EXPECT_EQ(TEMP_DOWN, u8GetValue);

	// Temp up - 5
	ParseRawDate({0x01, 0x05},2);
	myProf->GetValue(E_USER_ACTION, u8GetValue);
	EXPECT_EQ(TEMP_UP, u8GetValue);

	// Fan - 6
	ParseRawDate({0x01, 0x06},2);
	myProf->GetValue(E_USER_ACTION, u8GetValue);
	EXPECT_EQ(FAN, u8GetValue);
}

TEST_F(profileD200xxTest,eepD20001ControllerSendData01)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_USER_ACTION));

	// S_TEMP
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_CONFIG_VALID);
	myProf->Create(*msg);
	uint8_t data1[] = {0x01, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],2),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_CONFIG_VALID);
	myProf->Create(*msg);
	uint8_t data2[] = {0x01, 0x80};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],2),0);

	// E_USER_ACTION
	// Presence - 1
	myProf->SetValue(E_USER_ACTION,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data3[] = {0x01, 0x81};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],2),0);

	// Temp down - 2
	myProf->SetValue(E_USER_ACTION,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data4[] = {0x01, 0x82};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],2),0);

	// Temp up - 5
	myProf->SetValue(E_USER_ACTION,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data5[] = {0x01, 0x85};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],2),0);

	// Fan - 6
	myProf->SetValue(E_USER_ACTION,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data6[] = {0x01, 0x86};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],2),0);
}

TEST_F(profileD200xxTest,eepD20001ControllerReceiveData02)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	// F_ON_OFF - RCP_FAN_MANUAL
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_FAN_MANUAL);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x82, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_FAN_MANUAL);
	EXPECT_EQ(1, u8GetValue);

	// E_FANSPEED
	// Do not display - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Speed level 0 - 1
	ParseRawDate({0x12, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Speed level 1 - 2
	ParseRawDate({0x22, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Speed level 2 - 3
	ParseRawDate({0x32, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Speed level 3 - 4
	ParseRawDate({0x42, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// F_ON_OFF - RCP_MORE_DATA
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_MORE_DATA);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x0A, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_MORE_DATA);
	EXPECT_EQ(1, u8GetValue);

	// E_PRESENCE
	// Do not display - 0
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Present - 1
	ParseRawDate({0x02, 0x20, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Not presenet - 2
	ParseRawDate({0x02, 0x40, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Night time reduction - 3
	ParseRawDate({0x02, 0x60, 0x00, 0x00, 0x00},5);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// F_ON_OFF - RCP_USER_NOTIFICATION
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_USER_NOTIFICATION);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x10},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_USER_NOTIFICATION);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RCP_DEW_POINT
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_DEW_POINT);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x04},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_DEW_POINT);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RCP_COOLING
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_COOLING);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x02},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_COOLING);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - RCP_HEATING
	// Off
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x00},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_HEATING);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x02, 0x00, 0x00, 0x00, 0x01},5);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_HEATING);
	EXPECT_EQ(1, u8GetValue);

	// S_TEMP - RCP_ROOM_TEMPERATURE_C
	// Min
	ParseRawDate({0x02, 0x01, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_ROOM_TEMPERATURE_C);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x01, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_ROOM_TEMPERATURE_C);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x01, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_ROOM_TEMPERATURE_C);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// S_TEMP - RCP_ROOM_TEMPERATURE_F
	// Min
	ParseRawDate({0x02, 0x02, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_ROOM_TEMPERATURE_F);
	EXPECT_NEAR(32, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x02, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_ROOM_TEMPERATURE_F);
	EXPECT_NEAR(68, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x02, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_ROOM_TEMPERATURE_F);
	EXPECT_NEAR(104, fGetValue, 0.5);

	// S_TEMP - RCP_NOMINAL_TEMPERATURE_C
	// Min
	ParseRawDate({0x02, 0x03, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_NOMINAL_TEMPERATURE_C);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x03, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_NOMINAL_TEMPERATURE_C);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x03, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_NOMINAL_TEMPERATURE_C);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// S_TEMP - RCP_NOMINAL_TEMPERATURE_F
	// Min
	ParseRawDate({0x02, 0x04, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_NOMINAL_TEMPERATURE_F);
	EXPECT_NEAR(32, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x04, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_NOMINAL_TEMPERATURE_F);
	EXPECT_NEAR(68, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x04, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP, fGetValue,RCP_NOMINAL_TEMPERATURE_F);
	EXPECT_NEAR(104, fGetValue, 0.5);

	// S_TEMP - RCP_DELTA_TEMP_SETPOINT_C
	// Min
	ParseRawDate({0x02, 0x05, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_SETPOINT_C);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x05, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_SETPOINT_C);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x05, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_SETPOINT_C);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// S_TEMP - RCP_DELTA_TEMP_SETPOINT_F
	// Min
	ParseRawDate({0x02, 0x06, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_SETPOINT_F);
	EXPECT_NEAR(32, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x06, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_SETPOINT_F);
	EXPECT_NEAR(68, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x06, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_SETPOINT_F);
	EXPECT_NEAR(104, fGetValue, 0.5);

	// S_TEMP - RCP_DELTA_TEMP_GRAPHIC
	// Min
	ParseRawDate({0x02, 0x07, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_GRAPHIC);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x07, 0x07, 0xD0, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_GRAPHIC);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x07, 0x0F, 0xA0, 0x00},5);
	myProf->GetValue(S_TEMP_ABS, fGetValue,RCP_DELTA_TEMP_GRAPHIC);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// S_TIME - RCP_TIME_24_HOURS
	// Min
	ParseRawDate({0x02, 0x08, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_24_HOURS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x08, 0x04, 0xB0, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_24_HOURS);
	EXPECT_NEAR(1200, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x08, 0x09, 0x37, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_24_HOURS);
	EXPECT_NEAR(2359, fGetValue, 0.5);

	// S_TIME - RCP_TIME_AM_HOURS
	// Min
	ParseRawDate({0x02, 0x09, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_AM_HOURS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x09, 0x02, 0x58, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_AM_HOURS);
	EXPECT_NEAR(600, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x09, 0x04, 0x87, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_AM_HOURS);
	EXPECT_NEAR(1159, fGetValue, 0.5);

	// S_TIME - RCP_TIME_PM_HOURS
	// Min
	ParseRawDate({0x02, 0x0A, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_PM_HOURS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x0A, 0x02, 0x58, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_PM_HOURS);
	EXPECT_NEAR(600, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x0A, 0x04, 0x87, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_PM_HOURS);
	EXPECT_NEAR(1159, fGetValue, 0.5);

	// S_TIME - RCP_TIME_DAY_MONTH
	// Min
	ParseRawDate({0x02, 0x0B, 0x00, 0x65, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_DAY_MONTH);
	EXPECT_NEAR(101, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x0B, 0x06, 0x14, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_DAY_MONTH);
	EXPECT_NEAR(1556, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x0B, 0x0C, 0x28, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_DAY_MONTH);
	EXPECT_NEAR(3112, fGetValue, 0.5);

	// S_TIME - RCP_TIME_MONTH_DAY
	// Min
	ParseRawDate({0x02, 0x0C, 0x00, 0x65, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_MONTH_DAY);
	EXPECT_NEAR(101, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x0C, 0x02, 0x59, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_MONTH_DAY);
	EXPECT_NEAR(601, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x0C, 0x04, 0x6B, 0x00},5);
	myProf->GetValue(S_TIME, fGetValue,RCP_TIME_MONTH_DAY);
	EXPECT_NEAR(1131, fGetValue, 0.5);

	// S_LUMINANCE
	// Min
	ParseRawDate({0x02, 0x0D, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x0D, 0x13, 0x87, 0x00},5);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(4999, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x0D, 0x27, 0x0F, 0x00},5);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(9999, fGetValue, 0.5);

	// S_PERCENTAGE
	// Min
	ParseRawDate({0x02, 0x0E, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x0E, 0x13, 0x88, 0x00},5);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x0E, 0x27, 0x10, 0x00},5);
	myProf->GetValue(S_PERCENTAGE, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);

	// S_CONC
	// Min
	ParseRawDate({0x02, 0x0F, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x0F, 0x13, 0x87, 0x00},5);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(4999, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x0F, 0x27, 0x0F, 0x00},5);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(9999, fGetValue, 0.5);

	// S_RELHUM
	// Min
	ParseRawDate({0x02, 0x10, 0x00, 0x00, 0x00},5);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x02, 0x10, 0x13, 0x88, 0x00},5);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50, fGetValue, 0.5);

	// Max
	ParseRawDate({0x02, 0x10, 0x27, 0x10, 0x00},5);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100, fGetValue, 0.5);
}

TEST_F(profileD200xxTest,eepD20001ControllerSendData02)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x02);

	// F_ON_ OFF - RCP_FAN_MANUAL
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_FAN_MANUAL);
	myProf->Create(*msg);
	uint8_t data1[] = {0x02, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_FAN_MANUAL);
	myProf->Create(*msg);
	uint8_t data2[] = {0x82, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],5),0);

	// E_FANSPEED
	// Do not display - 0
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x82, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],2),0);

	// Speed level 0 - 1
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data4[] = {0x92, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],2),0);

	// Speed level 1 - 2
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data5[] = {0xA2, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],2),0);

	// Speed level 2 - 3
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data6[] = {0xB2, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],2),0);

	// Speed level 3 - 4
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data7[] = {0xC2, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],2),0);

	// F_ON_ OFF - RCP_MORE_DATA
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_MORE_DATA);
	myProf->Create(*msg);
	uint8_t data8[] = {0xC2, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_MORE_DATA);
	myProf->Create(*msg);
	uint8_t data9[] = {0xCA, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],5),0);

	// E_PRESENCE
	// Do not display - 0
	myProf->SetValue(E_PRESENCE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data10[] = {0xCA, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],2),0);

	// Present - 1
	myProf->SetValue(E_PRESENCE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data11[] = {0xCA, 0x20, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],2),0);

	// Not present - 2
	myProf->SetValue(E_PRESENCE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data12[] = {0xCA, 0x40, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],2),0);

	// Night time reduction - 3
	myProf->SetValue(E_PRESENCE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data13[] = {0xCA, 0x60, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],2),0);

	// F_ON_ OFF - RCP_USER_NOTIFICATION
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_USER_NOTIFICATION);
	myProf->Create(*msg);
	uint8_t data14[] = {0xCA, 0x60, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_USER_NOTIFICATION);
	myProf->Create(*msg);
	uint8_t data15[] = {0xCA, 0x60, 0x00, 0x00, 0x10};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],5),0);

	// F_ON_ F_OPEN_CLOSED
	// Off
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data16[] = {0xCA, 0x60, 0x00, 0x00, 0x10};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data17[] = {0xCA, 0x60, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],5),0);

	// F_ON_OFF - RCP_DEW_POINT
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_DEW_POINT);
	myProf->Create(*msg);
	uint8_t data18[] = {0xCA, 0x60, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_DEW_POINT);
	myProf->Create(*msg);
	uint8_t data19[] = {0xCA, 0x60, 0x00, 0x00, 0x1C};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],5),0);

	// F_ON_OFF - RCP_COOLING
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_COOLING);
	myProf->Create(*msg);
	uint8_t data20[] = {0xCA, 0x60, 0x00, 0x00, 0x1C};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_COOLING);
	myProf->Create(*msg);
	uint8_t data21[] = {0xCA, 0x60, 0x00, 0x00, 0x1E};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],5),0);

	// F_ON_OFF - RCP_HEATING
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_HEATING);
	myProf->Create(*msg);
	uint8_t data22[] = {0xCA, 0x60, 0x00, 0x00, 0x1E};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],5),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_HEATING);
	myProf->Create(*msg);
	uint8_t data23[] = {0xCA, 0x60, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],5),0);

	// S_TEMP - RCP_ROOM_TEMPERATURE_C
	// Min
	myProf->SetValue(S_TEMP,(float)0,RCP_ROOM_TEMPERATURE_C);
	myProf->Create(*msg);
	uint8_t data24[] = {0xCA, 0x61, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP,(float)20,RCP_ROOM_TEMPERATURE_C);
	myProf->Create(*msg);
	uint8_t data25[] = {0xCA, 0x61, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP,(float)40,RCP_ROOM_TEMPERATURE_C);
	myProf->Create(*msg);
	uint8_t data26[] = {0xCA, 0x61, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],5),0);

	// S_TEMP - RCP_ROOM_TEMPERATURE_F
	// Min
	myProf->SetValue(S_TEMP,(float)32,RCP_ROOM_TEMPERATURE_F);
	myProf->Create(*msg);
	uint8_t data27[] = {0xCA, 0x62, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP,(float)68,RCP_ROOM_TEMPERATURE_F);
	myProf->Create(*msg);
	uint8_t data28[] = {0xCA, 0x62, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP,(float)104,RCP_ROOM_TEMPERATURE_F);
	myProf->Create(*msg);
	uint8_t data29[] = {0xCA, 0x62, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],5),0);

	// S_TEMP - RCP_NOMINAL_TEMPERATURE_C
	// Min
	myProf->SetValue(S_TEMP,(float)0,RCP_NOMINAL_TEMPERATURE_C);
	myProf->Create(*msg);
	uint8_t data30[] = {0xCA, 0x63, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP,(float)20,RCP_NOMINAL_TEMPERATURE_C);
	myProf->Create(*msg);
	uint8_t data31[] = {0xCA, 0x63, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP,(float)40,RCP_NOMINAL_TEMPERATURE_C);
	myProf->Create(*msg);
	uint8_t data32[] = {0xCA, 0x63, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],5),0);

	// S_TEMP - RCP_NOMINAL_TEMPERATURE_F
	// Min
	myProf->SetValue(S_TEMP,(float)32,RCP_NOMINAL_TEMPERATURE_F);
	myProf->Create(*msg);
	uint8_t data33[] = {0xCA, 0x64, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP,(float)68,RCP_NOMINAL_TEMPERATURE_F);
	myProf->Create(*msg);
	uint8_t data34[] = {0xCA, 0x64, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP,(float)104,RCP_NOMINAL_TEMPERATURE_F);
	myProf->Create(*msg);
	uint8_t data35[] = {0xCA, 0x64, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],5),0);

	// S_TEMP - RCP_DELTA_TEMP_SETPOINT_C
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)0,RCP_DELTA_TEMP_SETPOINT_C);
	myProf->Create(*msg);
	uint8_t data36[] = {0xCA, 0x65, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)20,RCP_DELTA_TEMP_SETPOINT_C);
	myProf->Create(*msg);
	uint8_t data37[] = {0xCA, 0x65, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)40,RCP_DELTA_TEMP_SETPOINT_C);
	myProf->Create(*msg);
	uint8_t data38[] = {0xCA, 0x65, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],5),0);

	// S_TEMP - RCP_DELTA_TEMP_SETPOINT_F
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)32,RCP_DELTA_TEMP_SETPOINT_F);
	myProf->Create(*msg);
	uint8_t data39[] = {0xCA, 0x66, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)68,RCP_DELTA_TEMP_SETPOINT_F);
	myProf->Create(*msg);
	uint8_t data40[] = {0xCA, 0x66, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data40[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)104,RCP_DELTA_TEMP_SETPOINT_F);
	myProf->Create(*msg);
	uint8_t data41[] = {0xCA, 0x66, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data41[0],&msg->data[0],5),0);

	// S_TEMP - RCP_DELTA_TEMP_GRAPHIC
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)0,RCP_DELTA_TEMP_GRAPHIC);
	myProf->Create(*msg);
	uint8_t data42[] = {0xCA, 0x67, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data42[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)20,RCP_DELTA_TEMP_GRAPHIC);
	myProf->Create(*msg);
	uint8_t data43[] = {0xCA, 0x67, 0x07, 0xD0, 0x1F};
	EXPECT_EQ(memcmp(&data43[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)40,RCP_DELTA_TEMP_GRAPHIC);
	myProf->Create(*msg);
	uint8_t data44[] = {0xCA, 0x67, 0x0F, 0xA0, 0x1F};
	EXPECT_EQ(memcmp(&data44[0],&msg->data[0],5),0);

	// S_TIME - RCP_DELTA_TEMP_GRAPHIC
	// Min
	myProf->SetValue(S_TIME,(float)0,RCP_TIME_24_HOURS);
	myProf->Create(*msg);
	uint8_t data45[] = {0xCA, 0x68, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data45[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)1200,RCP_TIME_24_HOURS);
	myProf->Create(*msg);
	uint8_t data46[] = {0xCA, 0x68, 0x04, 0xAF, 0x1F};
	EXPECT_EQ(data46[1],msg->data[1]);
	EXPECT_NEAR(data46[2],msg->data[2],1);

	// Max
	myProf->SetValue(S_TIME,(float)2359,RCP_TIME_24_HOURS);
	myProf->Create(*msg);
	uint8_t data47[] = {0xCA, 0x68, 0x09, 0x37, 0x1F};
	EXPECT_EQ(memcmp(&data47[0],&msg->data[0],5),0);

	// S_TIME - RCP_TIME_AM_HOURS
	// Min
	myProf->SetValue(S_TIME,(float)0,RCP_TIME_AM_HOURS);
	myProf->Create(*msg);
	uint8_t data48[] = {0xCA, 0x69, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data48[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)600,RCP_TIME_AM_HOURS);
	myProf->Create(*msg);
	uint8_t data49[] = {0xCA, 0x69, 0x02, 0x58, 0x1F};
	EXPECT_EQ(memcmp(&data49[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)1159,RCP_TIME_AM_HOURS);
	myProf->Create(*msg);
	uint8_t data50[] = {0xCA, 0x69, 0x04, 0x87, 0x1F};
	EXPECT_EQ(memcmp(&data50[0],&msg->data[0],5),0);

	// S_TIME - RCP_TIME_PM_HOURS
	// Min
	myProf->SetValue(S_TIME,(float)0,RCP_TIME_PM_HOURS);
	myProf->Create(*msg);
	uint8_t data51[] = {0xCA, 0x6A, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data51[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_TIME,(float)600,RCP_TIME_PM_HOURS);
	myProf->Create(*msg);
	uint8_t data52[] = {0xCA, 0x6A, 0x02, 0x58, 0x1F};
	EXPECT_EQ(memcmp(&data52[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_TIME,(float)1159,RCP_TIME_PM_HOURS);
	myProf->Create(*msg);
	uint8_t data53[] = {0xCA, 0x6A, 0x04, 0x87, 0x1F};
	EXPECT_EQ(memcmp(&data53[0],&msg->data[0],5),0);

	// S_TIME - RCP_TIME_DAY_MONTH
	// Min
	myProf->SetValue(S_TIME,(float)101,RCP_TIME_DAY_MONTH);
	myProf->Create(*msg);
	uint8_t data54[] = {0xCA, 0x6B, 0x00, 0x64, 0x1F};
	EXPECT_EQ(data54[0],msg->data[0]);
	EXPECT_EQ(data54[1],msg->data[1]);
	EXPECT_EQ(data54[2],msg->data[2]);
	EXPECT_NEAR(data54[3],msg->data[3],1);
	EXPECT_EQ(data54[4],msg->data[4]);

	// Median
	myProf->SetValue(S_TIME,(float)1506,RCP_TIME_DAY_MONTH);
	myProf->Create(*msg);
	uint8_t data55[] = {0xCA, 0x6B, 0x05, 0xE1, 0x1F};
	EXPECT_EQ(data55[0],msg->data[0]);
	EXPECT_EQ(data55[1],msg->data[1]);
	EXPECT_EQ(data55[2],msg->data[2]);
	EXPECT_NEAR(data55[3],msg->data[3],1);
	EXPECT_EQ(data55[4],msg->data[4]);
	// Max
	myProf->SetValue(S_TIME,(float)3112,RCP_TIME_DAY_MONTH);
	myProf->Create(*msg);
	uint8_t data56[] = {0xCA, 0x6B, 0x0C, 0x28, 0x1F};
	EXPECT_EQ(data56[0],msg->data[0]);
	EXPECT_EQ(data56[1],msg->data[1]);
	EXPECT_EQ(data56[2],msg->data[2]);
	EXPECT_NEAR(data56[3],msg->data[3],1);
	EXPECT_EQ(data56[4],msg->data[4]);

	// S_TIME - RCP_TIME_MONTH_DAY
	// Min
	myProf->SetValue(S_TIME,(float)101,RCP_TIME_MONTH_DAY);
	myProf->Create(*msg);
	uint8_t data57[] = {0xCA, 0x6C, 0x00, 0x64, 0x1F};
	EXPECT_EQ(data57[0],msg->data[0]);
	EXPECT_EQ(data57[1],msg->data[1]);
	EXPECT_EQ(data57[2],msg->data[2]);
	EXPECT_NEAR(data57[3],msg->data[3],1);
	EXPECT_EQ(data57[4],msg->data[4]);
	// Median
	myProf->SetValue(S_TIME,(float)615,RCP_TIME_MONTH_DAY);
	myProf->Create(*msg);
	uint8_t data58[] = {0xCA, 0x6C, 0x02, 0x66, 0x1F};
	EXPECT_EQ(data58[0],msg->data[0]);
	EXPECT_EQ(data58[1],msg->data[1]);
	EXPECT_EQ(data58[2],msg->data[2]);
	EXPECT_NEAR(data58[3],msg->data[3],1);
	EXPECT_EQ(data58[4],msg->data[4]);
	// Max
	myProf->SetValue(S_TIME,(float)1231,RCP_TIME_MONTH_DAY);
	myProf->Create(*msg);
	uint8_t data59[] = {0xCA, 0x6C, 0x04, 0xCF, 0x1F};
	EXPECT_EQ(data59[0],msg->data[0]);
	EXPECT_EQ(data59[1],msg->data[1]);
	EXPECT_EQ(data59[2],msg->data[2]);
	EXPECT_NEAR(data59[3],msg->data[3],1);
	EXPECT_EQ(data59[4],msg->data[4]);

	// S_LUMINANCE
	// Min
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data60[] = {0xCA, 0x6D, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data60[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_LUMINANCE,(float)4999);
	myProf->Create(*msg);
	uint8_t data61[] = {0xCA, 0x6D, 0x13, 0x86, 0x1F};
	EXPECT_EQ(data61[0],msg->data[0]);
	EXPECT_EQ(data61[1],msg->data[1]);
	EXPECT_EQ(data61[2],msg->data[2]);
	EXPECT_NEAR(data61[3],msg->data[3],1);
	EXPECT_EQ(data61[4],msg->data[4]);


	// Max
	myProf->SetValue(S_LUMINANCE,(float)9999);
	myProf->Create(*msg);
	uint8_t data62[] = {0xCA, 0x6D, 0x27, 0x0F, 0x1F};
	EXPECT_EQ(data62[0],msg->data[0]);
	EXPECT_EQ(data62[1],msg->data[1]);
	EXPECT_EQ(data62[2],msg->data[2]);
	EXPECT_NEAR(data62[3],msg->data[3],1);
	EXPECT_EQ(data62[4],msg->data[4]);
	// S_PERCENTAGE
	// Min
	myProf->SetValue(S_PERCENTAGE,(float)0);
	myProf->Create(*msg);
	uint8_t data63[] = {0xCA, 0x6E, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data63[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_PERCENTAGE,(float)50);
	myProf->Create(*msg);
	uint8_t data64[] = {0xCA, 0x6E, 0x13, 0x88, 0x1F};
	EXPECT_EQ(data64[0],msg->data[0]);
	EXPECT_EQ(data64[1],msg->data[1]);
	EXPECT_EQ(data64[2],msg->data[2]);
	EXPECT_NEAR(data64[3],msg->data[3],1);
	EXPECT_EQ(data64[4],msg->data[4]);

	// Max
	myProf->SetValue(S_PERCENTAGE,(float)100);
	myProf->Create(*msg);
	uint8_t data65[] = {0xCA, 0x6E, 0x27, 0x10, 0x1F};
	EXPECT_EQ(data65[0],msg->data[0]);
	EXPECT_EQ(data65[1],msg->data[1]);
	EXPECT_EQ(data65[2],msg->data[2]);
	EXPECT_NEAR(data65[3],msg->data[3],1);
	EXPECT_EQ(data65[4],msg->data[4]);
	// S_CONC
	// Min
	myProf->SetValue(S_CONC,(float)0);
	myProf->Create(*msg);
	uint8_t data66[] = {0xCA, 0x6F, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data66[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_CONC,(float)4999);
	myProf->Create(*msg);
	uint8_t data67[] = {0xCA, 0x6F, 0x13, 0x86, 0x1F};
	EXPECT_EQ(data67[0],msg->data[0]);
	EXPECT_EQ(data67[1],msg->data[1]);
	EXPECT_EQ(data67[2],msg->data[2]);
	EXPECT_NEAR(data67[3],msg->data[3],1);
	EXPECT_EQ(data67[4],msg->data[4]);

	// Max
	myProf->SetValue(S_CONC,(float)9999);
	myProf->Create(*msg);
	uint8_t data68[] = {0xCA, 0x6F, 0x27, 0x0F, 0x1F};
	EXPECT_EQ(data68[1],msg->data[1]);
	EXPECT_EQ(data68[2],msg->data[2]);
	EXPECT_NEAR(data68[3],msg->data[3],1);
	EXPECT_EQ(data68[4],msg->data[4]);
	// S_RELHUM
	// Min
	myProf->SetValue(S_RELHUM,(float)0);
	myProf->Create(*msg);
	uint8_t data69[] = {0xCA, 0x70, 0x00, 0x00, 0x1F};
	EXPECT_EQ(memcmp(&data69[0],&msg->data[0],5),0);

	// Median
	myProf->SetValue(S_RELHUM,(float)50);
	myProf->Create(*msg);
	uint8_t data70[] = {0xCA, 0x70, 0x13, 0x88, 0x1F};
	EXPECT_EQ(memcmp(&data70[0],&msg->data[0],5),0);

	// Max
	myProf->SetValue(S_RELHUM,(float)100);
	myProf->Create(*msg);
	uint8_t data71[] = {0xCA, 0x70, 0x27, 0x10, 0x1F};
	EXPECT_EQ(memcmp(&data71[0],&msg->data[0],5),0);
}

TEST_F(profileD200xxTest,eepD20001ControllerReceiveData03)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	// E_FANSPEED
	// No change - 0
	ParseRawDate({0x03, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Speed level 0 - 1
	ParseRawDate({0x13, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Speed level 1 - 2
	ParseRawDate({0x23, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Speed level 2 - 3
	ParseRawDate({0x33, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Speed level 3 - 4
	ParseRawDate({0x43, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Speed level Auto - 5
	ParseRawDate({0x53, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// E_PRESENCE
	// Do not display - 0
	ParseRawDate({0x03, 0x00, 0x00, 0x00},4);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Present - 1
	ParseRawDate({0x03, 0x20, 0x00, 0x00},4);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Not presenet - 2
	ParseRawDate({0x03, 0x40, 0x00, 0x00},4);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Night time reduction - 3
	ParseRawDate({0x03, 0x60, 0x00, 0x00},4);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x03, 0x05, 0x00, 0x00},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(-12.7, fGetValue, 0.5);

	// Median
	ParseRawDate({0x03, 0x05, 0x04, 0xF6},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x03, 0x05, 0x09, 0xEC},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(12.7, fGetValue, 0.5);
}

TEST_F(profileD200xxTest,eepD20001ControllerSendData03)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND, (uint8_t)0x03);

	// E_FANSPEED
	// No change - 0
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x03, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Speed level 0 - 1
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x13, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Speed level 1 - 2
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x23, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Speed level 2 - 3
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x33, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Speed level 3 - 1
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x43, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Speed level Auto - 5
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data6[] = {0x53, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// E_PRESENCE
	// Do not display - 0
	myProf->SetValue(E_PRESENCE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x53, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Present - 1
	myProf->SetValue(E_PRESENCE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data8[] = {0x53, 0x20, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Not present - 2
	myProf->SetValue(E_PRESENCE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data9[] = {0x53, 0x40, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Night time reduction
	myProf->SetValue(E_PRESENCE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data10[] = {0x53, 0x60, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// S_TEMP_ABS
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)-12.7);
	myProf->Create(*msg);
	uint8_t data11[] = {0x53, 0x65, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x53, 0x65, 0x04, 0xF6};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)12.7);
	myProf->Create(*msg);
	uint8_t data13[] = {0x53, 0x65, 0x09, 0xEC};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);
}

TEST_F(profileD200xxTest,eepD20001ControllerReceiveData04)
{
	float fGetValue;

	// Setup the test
	Init(0x01);

	// S_TEMP
	// Min
	ParseRawDate({0x04, 0x00, 0x00},3);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x04, 0xD0, 0x07},3);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20, fGetValue, 0.5);

	// Max
	ParseRawDate({0x04, 0xA0, 0x0F},3);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40, fGetValue, 0.5);
}

TEST_F(profileD200xxTest,eepD20001ControllerSendData04)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->ClearValues();
	myProf->SetValue(E_COMMAND, (uint8_t)0x04);

	// S_TEMP
	// Min
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x04, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],3),0);

	// Median
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x04, 0xD0, 0x07};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],3),0);

	// Max
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x04, 0xA0, 0x0F};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],3),0);
}

TEST_F(profileD200xxTest,eepD20001ControllerReceiveData05)
{
	float fGetValue;
	uint8_t u8GetValue;

	// Setup the test
	Init(0x01);

	// F_ON_OFF - RCP_MORE_DATA
	// Off
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_MORE_DATA);
	EXPECT_EQ(0, u8GetValue);

	// On
	ParseRawDate({0x0D, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(F_ON_OFF, u8GetValue,RCP_MORE_DATA);
	EXPECT_EQ(1, u8GetValue);

	// S_SETPOINT - RCP_SETPOINT_RANGE_LIMIT
	// Min
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_SETPOINT, fGetValue, RCP_SETPOINT_RANGE_LIMIT);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x3F, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_SETPOINT, fGetValue, RCP_SETPOINT_RANGE_LIMIT);
	EXPECT_NEAR(6.35, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x7F, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_SETPOINT, fGetValue, RCP_SETPOINT_RANGE_LIMIT);
	EXPECT_NEAR(12.7, fGetValue, 0.5);

	// S_SETPOINT - RCP_SETPOINT_STEPS
	// Min
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_SETPOINT, fGetValue, RCP_SETPOINT_STEPS);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x3F, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_SETPOINT, fGetValue, RCP_SETPOINT_STEPS);
	EXPECT_NEAR(63.5, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x7F, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_SETPOINT, fGetValue, RCP_SETPOINT_STEPS);
	EXPECT_NEAR(127, fGetValue, 0.5);

	// S_TIME - RCP_TEMP_MEASUREMENT_TIMING
	// Min
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, RCP_TEMP_MEASUREMENT_TIMING);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0xE0, 0x01, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, RCP_TEMP_MEASUREMENT_TIMING);
	EXPECT_NEAR(300, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0xC0, 0x03, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, RCP_TEMP_MEASUREMENT_TIMING);
	EXPECT_NEAR(600, fGetValue, 0.5);

	// E_PRESENCE
	// 0
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 1
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x20, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// 2
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x40, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// 3
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x60, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// 4
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x80, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// 5
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xA0, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// 6
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xC0, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// 7
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0xE0, 0x00},6);
	myProf->GetValue(E_PRESENCE, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// E_FANSPEED
	// 0
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// 1
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x04, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// 2
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x08, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// 3
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x0C, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// 4
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x10, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// 5
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x14, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// 6
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x18, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// 7
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x1C, 0x00},6);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// S_TEMP_ABS
	// Min
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x70},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(1.5, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0xF0},6);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(3.0, fGetValue, 0.5);

	// S_TIME - RCP_KEEP_ALIVE_TIME
	// Min
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x00},6);
	myProf->GetValue(S_TIME, fGetValue, RCP_KEEP_ALIVE_TIME);
	EXPECT_NEAR(0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x04},6);
	myProf->GetValue(S_TIME, fGetValue, RCP_KEEP_ALIVE_TIME);
	EXPECT_NEAR(40, fGetValue, 0.5);

	// Max
	ParseRawDate({0x05, 0x00, 0x00, 0x00, 0x00, 0x07},6);
	myProf->GetValue(S_TIME, fGetValue, RCP_KEEP_ALIVE_TIME);
	EXPECT_NEAR(70, fGetValue, 0.5);
}

TEST_F(profileD200xxTest,eepD20001ControllerSendData05)
{
	// Setup the test
	Init(0x01);

	// Set Cmd
	myProf->SetValue(E_COMMAND, (uint8_t)0x05);

	// E_FANSPEED
	// 0
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x05, 0x00, 0x00, 0x00, 0x00, 0x00};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],6),0);

	// 1
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data2[] = {0x05, 0x00, 0x00, 0x00, 0x04, 0x00};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],6),0);

	// 2
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data3[] = {0x05, 0x00, 0x00, 0x00, 0x08, 0x00};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],6),0);

	// 3
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data4[] = {0x05, 0x00, 0x00, 0x00, 0x0C, 0x00};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],6),0);

	// 4
	myProf->SetValue(E_FANSPEED,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data5[] = {0x05, 0x00, 0x00, 0x00, 0x10, 0x00};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],6),0);

	// 5
	myProf->SetValue(E_FANSPEED,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data6[] = {0x05, 0x00, 0x00, 0x00, 0x14, 0x00};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],6),0);

	// 6
	myProf->SetValue(E_FANSPEED,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data7[] = {0x05, 0x00, 0x00, 0x00, 0x18, 0x00};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],6),0);

	// 7
	myProf->SetValue(E_FANSPEED,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data8[] = {0x05, 0x00, 0x00, 0x00, 0x1C, 0x00};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],6),0);

	// E_PRESENCE
	// 0
	myProf->SetValue(E_PRESENCE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x05, 0x00, 0x00, 0x00, 0x1C, 0x00};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],6),0);

	// 1
	myProf->SetValue(E_PRESENCE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data10[] = {0x05, 0x00, 0x00, 0x00, 0x3C, 0x00};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],6),0);

	// 2
	myProf->SetValue(E_PRESENCE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data11[] = {0x05, 0x00, 0x00, 0x00, 0x5C, 0x00};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],6),0);

	// 3
	myProf->SetValue(E_PRESENCE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data12[] = {0x05, 0x00, 0x00, 0x00, 0x7C, 0x00};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],6),0);

	// 4
	myProf->SetValue(E_PRESENCE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data13[] = {0x05, 0x00, 0x00, 0x00, 0x9C, 0x00};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],6),0);

	// 5
	myProf->SetValue(E_PRESENCE,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data14[] = {0x05, 0x00, 0x00, 0x00, 0xBC, 0x00};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],6),0);

	// 6
	myProf->SetValue(E_PRESENCE,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data15[] = {0x05, 0x00, 0x00, 0x00, 0xDC, 0x00};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],6),0);

	// 7
	myProf->SetValue(E_PRESENCE,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data16[] = {0x05, 0x00, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],6),0);

	// F_ON_OFF - RCP_MORE_DATA
	// Off
	myProf->SetValue(F_ON_OFF,(uint8_t)0,RCP_MORE_DATA);
	myProf->Create(*msg);
	uint8_t data17[] = {0x05, 0x00, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],6),0);

	// On
	myProf->SetValue(F_ON_OFF,(uint8_t)1,RCP_MORE_DATA);
	myProf->Create(*msg);
	uint8_t data18[] = {0x0D, 0x00, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],6),0);

	// S_SETPOINT - RCP_SETPOINT_RANGE_LIMIT
	// Min
	myProf->SetValue(S_SETPOINT,(float)0, RCP_SETPOINT_RANGE_LIMIT);
	myProf->Create(*msg);
	uint8_t data19[] = {0x0D, 0x00, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_SETPOINT,(float)6.35, RCP_SETPOINT_RANGE_LIMIT);
	myProf->Create(*msg);
	uint8_t data20[] = {0x0D, 0x3F, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_SETPOINT,(float)12.7, RCP_SETPOINT_RANGE_LIMIT);
	myProf->Create(*msg);
	uint8_t data21[] = {0x0D, 0x7F, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],6),0);

	// S_SETPOINT - RCP_SETPOINT_STEPS
	// Min
	myProf->SetValue(S_SETPOINT,(float)0, RCP_SETPOINT_STEPS);
	myProf->Create(*msg);
	uint8_t data22[] = {0x0D, 0x7F, 0x00, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_SETPOINT,(float)63.5, RCP_SETPOINT_STEPS);
	myProf->Create(*msg);
	uint8_t data23[] = {0x0D, 0x7F, 0x3F, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_SETPOINT,(float)127, RCP_SETPOINT_STEPS);
	myProf->Create(*msg);
	uint8_t data24[] = {0x0D, 0x7F, 0x7F, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],6),0);

	// S_TIME - RCP_TEMP_MEASUREMENT_TIMING
	// Min
	myProf->SetValue(S_TIME,(float)0, RCP_TEMP_MEASUREMENT_TIMING);
	myProf->Create(*msg);
	uint8_t data25[] = {0x0D, 0x7F, 0x7F, 0x00, 0xFC, 0x00};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)300, RCP_TEMP_MEASUREMENT_TIMING);
	myProf->Create(*msg);
	uint8_t data26[] = {0x0D, 0x7F, 0x7F, 0xE0, 0xFD, 0x00};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)600, RCP_TEMP_MEASUREMENT_TIMING);
	myProf->Create(*msg);
	uint8_t data27[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],6),0);

	// S_TEMP_ABS
	// Min
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data28[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0x00};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TEMP_ABS,(float)1.5);
	myProf->Create(*msg);
	uint8_t data29[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0x70};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TEMP_ABS,(float)3.0);
	myProf->Create(*msg);
	uint8_t data30[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0xF0};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],6),0);

	// S_TIME - RCP_KEEP_ALIVE_TIME
	// Min
	myProf->SetValue(S_TIME,(float)0, RCP_KEEP_ALIVE_TIME);
	myProf->Create(*msg);
	uint8_t data31[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0xF0};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],6),0);

	// Median
	myProf->SetValue(S_TIME,(float)30, RCP_KEEP_ALIVE_TIME);
	myProf->Create(*msg);
	uint8_t data32[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0xF3};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],6),0);

	// Max
	myProf->SetValue(S_TIME,(float)70, RCP_KEEP_ALIVE_TIME);
	myProf->Create(*msg);
	uint8_t data33[] = {0x0D, 0x7F, 0x7F, 0xC0, 0xFF, 0xF7};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],6),0);
}
