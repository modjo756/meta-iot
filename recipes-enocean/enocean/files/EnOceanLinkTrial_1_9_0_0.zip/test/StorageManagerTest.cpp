#include "eoLink.h"
#include <gtest/gtest.h>
#include "GatewayFixture.h"

//
TEST(eoStorageManager,StoreMaxDevices)
{
	eoGateway gatewayCreated;
	uint16_t counter=0xFFFF;
	while (counter--)
	{
		gatewayCreated.deviceManager->Add(counter);
		eoDevice * currentDevice = gatewayCreated.deviceManager->Get(counter);
		EXPECT_FALSE(NULL==currentDevice);
		currentDevice->SetProfile(eoProfileFactory::CreateProfile(0xA5,0x02,0x01));
	};
	eoStorageManager myStore;
	myStore.addObject("Gateway", &gatewayCreated);
	myStore.Save("learned.txt");
	myStore.RemoveObject("Gateway");

	eoGateway gatewayLoaded;
	eoStorageManager loadStore;
	loadStore.addObject("Gateway", &gatewayLoaded);
	loadStore.Load("learned.txt");

	EXPECT_EQ(gatewayCreated.deviceManager->Size(),gatewayLoaded.deviceManager->Size());
	counter=0xFFFF;
	while (counter--)
	{
		eoDevice * deviceExisting = gatewayCreated.deviceManager->Get(counter);
		eoDevice * currentDevice = gatewayLoaded.deviceManager->Get(counter);
		EXPECT_EQ(deviceExisting->ID,currentDevice->ID);
		EXPECT_TRUE(*(currentDevice->GetProfile()) == *(deviceExisting->GetProfile()));
	};
}

TEST(eoStorageManager,StoreOneDevice)
{
	eoDevice myDevice;
	myDevice.ID = 0x12345678;
	myDevice.SetProfile(eoProfileFactory::CreateProfile(0xA5, 0x02, 0x01));
	myDevice.secIn.SLF = 0xF0;
	myDevice.secIn.keySize = 16;
	myDevice.secIn.rollingCode = 16;
	uint16_t i;
	for (i = 0; i < sizeof(myDevice.secIn.key); i++)
		myDevice.secIn.key[i] = 0xA0 + i;
	for (i = 0; i < sizeof(myDevice.secIn.psk); i++)
		myDevice.secIn.psk[i] = 0xB0 + i;
	for (i = 0; i < sizeof(myDevice.secIn.subKey1); i++)
		myDevice.secIn.subKey1[i] = 0xC0 + i;
	for (i = 0; i < sizeof(myDevice.secIn.subKey2); i++)
		myDevice.secIn.subKey2[i] = 0xD0 + i;

	myDevice.secOut.SLF = 0x0F;
	myDevice.secOut.keySize = 16;
	for (i = 0; i < sizeof(myDevice.secOut.key); i++)
		myDevice.secOut.key[i] = 0xF0 + i;
	for (i = 0; i < sizeof(myDevice.secOut.psk); i++)
		myDevice.secOut.psk[i] = 0xE0 + i;
	for (i = 0; i < sizeof(myDevice.secOut.subKey1); i++)
		myDevice.secOut.subKey1[i] = 0xB0 + i;
	for (i = 0; i < sizeof(myDevice.secOut.subKey2); i++)
		myDevice.secOut.subKey2[i] = 0xA0 + i;

	eoStorageManager myStore;
	myStore.addObject("Device", &myDevice);
	myStore.Save("learned.txt");
	myStore.RemoveObject("Device");

	eoDevice myDeviceToLoad;
	myStore.addObject("Device", &myDeviceToLoad);
	myStore.Load("learned.txt");

	EXPECT_EQ(myDevice.ID,myDeviceToLoad.ID);
	EXPECT_EQ(myDevice.secIn.SLF,myDeviceToLoad.secIn.SLF);
	EXPECT_EQ(myDevice.secOut.SLF,myDeviceToLoad.secOut.SLF);
	for(i=0;i<16;i++)
	{
		EXPECT_EQ(myDevice.secIn.key[i],myDeviceToLoad.secIn.key[i]);
		EXPECT_EQ(myDevice.secIn.psk[i],myDeviceToLoad.secIn.psk[i]);
		EXPECT_EQ(myDevice.secIn.subKey1[i],myDeviceToLoad.secIn.subKey1[i]);
		EXPECT_EQ(myDevice.secIn.subKey2[i],myDeviceToLoad.secIn.subKey2[i]);
		EXPECT_EQ(myDevice.secOut.key[i],myDeviceToLoad.secOut.key[i]);
		EXPECT_EQ(myDevice.secOut.psk[i],myDeviceToLoad.secOut.psk[i]);
		EXPECT_EQ(myDevice.secOut.subKey1[i],myDeviceToLoad.secOut.subKey1[i]);
		EXPECT_EQ(myDevice.secOut.subKey2[i],myDeviceToLoad.secOut.subKey2[i]);
	}
	EXPECT_TRUE(*(myDevice.GetProfile()) == *(myDeviceToLoad.GetProfile()));
}
