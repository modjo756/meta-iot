/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Profiles/eoEEP_D204xx.h"
//Helper function for A5
class profileD204xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0x04, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};

TEST_F(profileD204xxTest,eepD20400Receive)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x00);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));

	//Check Co2 med,max
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(0,fGetValue,8);
	ParseRawDate({0x7F,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1000,fGetValue,8);
	ParseRawDate({0xFF,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(2000,fGetValue,8);

	//Check Humidity
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
	ParseRawDate({0x00,100,0x00,0x00},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);
	ParseRawDate({0x00,200,0x00,0x00},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);

	//Temp night..
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.3);
	ParseRawDate({0x00,0,0x7F,0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(25.5,fGetValue,0.3);
	ParseRawDate({0x00,0,0xFF,0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(51,fGetValue,0.3);

	//Day.Night
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	ParseRawDate({0x00,0,0x00,0x80},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1,u8GetValue);

	//Battery autonomy
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,NS_BATTERY_100_875);
	ParseRawDate({0x00,0,0x00,0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_875_75,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_75_625,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x30},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_625_50,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x40},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_50_375,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x50},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_375_25,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x60},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_25_125,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x70},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_125_0,u8GetValue);
}

TEST_F(profileD204xxTest,eepD20400Send)
{
	//Setup the test
	Init(0x00);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	//Concentration
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x7F,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Humidity
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(100,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(200,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Temperature
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)25.5);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x7F,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)51.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0xFF,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Day night flag
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x80,msg->data[3]);

	//Battery values...
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_100_875);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_875_75);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x10,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_75_625);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x20,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_625_50);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x30,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_50_375);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x40,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_375_25);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x50,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_25_125);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x60,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_125_0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x70,msg->data[3]);
}

TEST_F(profileD204xxTest,eepD20401Receive)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x01);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_FALSE(ChannelExist(S_TEMP));

	//Check Co2 med,max
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(0,fGetValue,8);
	ParseRawDate({0x7F,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1000,fGetValue,8);
	ParseRawDate({0xFF,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(2000,fGetValue,8);

	//Check Humidity
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.5);
	ParseRawDate({0x00,100,0x00,0x00},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(50,fGetValue,0.5);
	ParseRawDate({0x00,200,0x00,0x00},4);
	myProf->GetValue(S_RELHUM, fGetValue);
	EXPECT_NEAR(100,fGetValue,0.5);

	//Day.Night
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	ParseRawDate({0x00,0,0x00,0x80},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1,u8GetValue);

	//Battery autonomy
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,NS_BATTERY_100_875);
	ParseRawDate({0x00,0,0x00,0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_875_75,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_75_625,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x30},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_625_50,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x40},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_50_375,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x50},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_375_25,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x60},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_25_125,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x70},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_125_0,u8GetValue);
}

TEST_F(profileD204xxTest,eepD20401Send)
{
	//Setup the test
	Init(0x01);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_FALSE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	//Concentration
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x7F,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Humidity
	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)50.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(100,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_RELHUM,(float)100.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(200,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Day night flag
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x80,msg->data[3]);

	//Battery values...
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_100_875);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_875_75);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x10,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_75_625);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x20,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_625_50);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x30,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_50_375);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x40,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_375_25);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x50,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_25_125);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x60,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_125_0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x70,msg->data[3]);
}

TEST_F(profileD204xxTest,eepD20402Receive)
{
	uint8_t u8GetValue;
	float fGetValue;
	//Setup the test
	Init(0x02);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));

	//Check Co2 med,max
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(0,fGetValue,8);
	ParseRawDate({0x7F,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(1000,fGetValue,8);
	ParseRawDate({0xFF,0x00,0x00,0x00},4);
	myProf->GetValue(S_CONC, fGetValue);
	EXPECT_NEAR(2000,fGetValue,8);

	//Temp night..
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.3);
	ParseRawDate({0x00,0,0x7F,0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(25.5,fGetValue,0.3);
	ParseRawDate({0x00,0,0xFF,0x00},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(51,fGetValue,0.3);

	//Day.Night
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	ParseRawDate({0x00,0,0x00,0x80},4);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1,u8GetValue);

	//Battery autonomy
	ParseRawDate({0x00,0x00,0x00,0x00},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,NS_BATTERY_100_875);
	ParseRawDate({0x00,0,0x00,0x10},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_875_75,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x20},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_75_625,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x30},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_625_50,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x40},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_50_375,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x50},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_375_25,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x60},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_25_125,u8GetValue);

	ParseRawDate({0x00,0,0x00,0x70},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(NS_BATTERY_125_0,u8GetValue);
}

TEST_F(profileD204xxTest,eepD20402Send)
{
	//Setup the test
	Init(0x02);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	//Concentration
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)1000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x7F,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Temperature
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)25.5);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x7F,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)51.0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0xFF,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	//Day night flag
	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(F_DAY_NIGHT,(uint8_t)1);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x80,msg->data[3]);

	//Battery values...
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_100_875);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_875_75);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x10,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_75_625);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x20,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_625_50);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x30,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_50_375);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x40,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_375_25);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x50,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_25_125);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x60,msg->data[3]);

	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)NS_BATTERY_125_0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x70,msg->data[3]);
}
//K profiles are always same test for others only existense and max values!
TEST_F(profileD204xxTest,eepD2040X)
{
	//Setup the test
	Init(0x03);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_FALSE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	//Setup the test
	Init(0x04);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_FALSE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x05);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x06);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_FALSE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x07);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_FALSE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)2000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x08);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x09);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_TRUE(ChannelExist(S_RELHUM));
	EXPECT_FALSE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x10);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x1A);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_FALSE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x1B);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_FALSE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x1C);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x1C);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_TRUE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x1D);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_FALSE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_FALSE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);

	Init(0x1E);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_CONC));
	EXPECT_FALSE(ChannelExist(S_RELHUM));
	EXPECT_FALSE(ChannelExist(S_TEMP));
	EXPECT_TRUE(ChannelExist(F_DAY_NIGHT));
	EXPECT_TRUE(ChannelExist(E_STATE));
	myProf->ClearValues();
	myProf->SetValue(S_CONC,(float)5000.0);
	myProf->Create(*msg);
	EXPECT_EQ(0xFF,msg->data[0]);
}
