/*
 * PackageTest.h
 *
 *  Created on: 26.06.2012
 *      Author: tobias
 */

#ifndef PACKAGETEST_H_
#define PACKAGETEST_H_

#include <gtest/gtest.h>
#include "./eoLink.h"
class PackageFixture: public testing::Test {

protected:
	void  RecPackage(uint8_t * stream,uint8_t bufferSize,uint8_t offset);

};

#endif /* PACKAGETEST_H_ */
