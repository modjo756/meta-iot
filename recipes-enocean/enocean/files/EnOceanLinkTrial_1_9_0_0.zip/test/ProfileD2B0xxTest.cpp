#include <gtest/gtest.h>
#include "ProfileFixture.h"

class ProfileD2B0xxTest: public ProfileFixture
{
	protected:
	void Init(uint8_t type)
	{
		msg = new eoMessage(1);
		msg->RORG = RORG_VLD;
		myProf = eoProfileFactory::CreateProfile(0xD2, 0xB0, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};


TEST_F(ProfileD2B0xxTest,eepD2B051ControllerReceive)
{
	uint8_t u8GetValue;
	//Setup the test
	Init(0x51);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));

	//Enum tests - 0
	ParseRawDate({0x00},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0,u8GetValue);

	//Enum tests - 1
	ParseRawDate({0x11},1);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(17,u8GetValue);
}

TEST_F(ProfileD2B0xxTest,eepD2B051ControllerSend)
{
	//Setup the test
	Init(0x51);
	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));

	//Enums
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	//enum 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0x11);
	myProf->Create(*msg);
	EXPECT_EQ(0x11,msg->data[0]);
}

