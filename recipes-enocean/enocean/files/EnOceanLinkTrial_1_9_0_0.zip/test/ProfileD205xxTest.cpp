/*
 * ProfileD205Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

TEST_F(ProfileFixture,eepD205xx)
{
	float getValue;
	uint8_t getValue2;
	eoMessage msg(255);
	//Init the Profile via a simulated Teach IN message
	Init(0xD2,0x05,0x00);

	//////// Negative test - wrong command
	EXPECT_EQ(myProf->SetValue(E_COMMAND, (uint8_t)12),NOT_SUPPORTED);

	/////// Go to Position and Angle msg test
	uint8_t gotoData [] = {0x38, 0x0C, 0x17, 0x01};
	EXPECT_EQ(myProf->SetValue(E_COMMAND, (uint8_t)GOTO_MSG),EO_OK);
	// Negative tests
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)115, CUR_VER_POSITION),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)-90, CUR_ROT_ANGLE),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(E_END_POS, (uint8_t)5),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(E_STATE, (uint8_t)5),(uint8_t)OUT_OF_RANGE);
	// Positive tests
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)56, CUR_VER_POSITION),EO_OK);
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)12, CUR_ROT_ANGLE),EO_OK);
	EXPECT_EQ(myProf->SetValue(E_END_POS, (uint8_t)1),EO_OK);
	EXPECT_EQ(myProf->SetValue(E_STATE, (uint8_t)7),EO_OK);
	myProf->Create(msg);
	EXPECT_EQ(memcmp(&gotoData[0], &msg.data[0],4), EO_OK);

	/////// Stop msg test
	uint8_t stopData [] = {0x02};
	EXPECT_EQ(myProf->SetValue(E_COMMAND, (uint8_t)STOP_MSG),EO_OK);
	// Negative test
	EXPECT_EQ(myProf->SetValue(E_IO_CHANNEL, (uint8_t)10),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(E_IO_CHANNEL, (uint8_t)0),EO_OK);
	myProf->Create(msg);
	EXPECT_EQ(memcmp(&stopData[0], &msg.data[0],1), EO_OK);

	/////// Query Position and Angle msg test
	uint8_t queryData [] = {0x03};
	EXPECT_EQ(myProf->SetValue(E_COMMAND, (uint8_t)QUERY_MSG),EO_OK);
	myProf->Create(msg);
	EXPECT_EQ(memcmp(&queryData[0], &msg.data[0],1), EO_OK);

	/////// Reply Positon and Angle msg test
	uint8_t replyData [] = {0x0F, 0x59, 0x02, 0x04};
	EXPECT_EQ(myProf->SetValue(E_COMMAND, (uint8_t)REPLY_MSG),EO_OK);
	// Negative tests
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)-90, CUR_VER_POSITION),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)115, CUR_ROT_ANGLE),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(E_STATE, (uint8_t)7),OUT_OF_RANGE);
	// Positive tests
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)15, CUR_VER_POSITION),EO_OK);
	EXPECT_EQ(myProf->SetValue(S_PERCENTAGE, (float)89, CUR_ROT_ANGLE),EO_OK);
	EXPECT_EQ(myProf->SetValue(E_STATE, (uint8_t)2),EO_OK);
	myProf->Create(msg);
	EXPECT_EQ(memcmp(&replyData[0], &msg.data[0],4), EO_OK);

	/////// Set parameters msg test
	uint8_t replyData2[] = {0x7F, 0xFF, 0xFD, 0x07, 0x05};
	EXPECT_EQ(myProf->SetValue(E_COMMAND, (uint8_t)SET_PARAM_MSG),EO_OK);
	// Negative tests
	EXPECT_EQ(myProf->SetValue(S_TIME, (float)499, SET_VER_DURATION),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(S_TIME, (float)-10, SET_ROT_DURATION),(uint8_t)OUT_OF_RANGE);
	EXPECT_EQ(myProf->SetValue(E_STATE, (uint8_t)4),(uint8_t)OUT_OF_RANGE);
	// Positive tests
	EXPECT_EQ(myProf->SetValue(S_TIME, (float)32767, SET_VER_DURATION),EO_OK);
	EXPECT_EQ(myProf->SetValue(S_TIME, (float)253, SET_ROT_DURATION),EO_OK);
	EXPECT_EQ(myProf->SetValue(E_STATE, (uint8_t)7),EO_OK);
	myProf->Create(msg);
	EXPECT_EQ(memcmp(&replyData2[0], &msg.data[0],4), EO_OK);

	/////////////////////////////////////////
	// Parsing tests
	/////////////////////////////////////////
	// Parse Go to Position and Angle msg
	uint8_t data1[] = {0x58, 0x19, 0x12, 0x01};
	memcpy(&msg.data[0], &data1[0],4);
	msg.dataLength = 4;
	myProf->Parse(msg);
	// Negative test
	EXPECT_EQ(myProf->GetValue(S_TIME,getValue), NOT_SUPPORTED);
	// Getting values
	EXPECT_EQ(myProf->GetValue(S_PERCENTAGE,getValue,CUR_VER_POSITION),EO_OK);
	EXPECT_NEAR(getValue,88,0.5);
	EXPECT_EQ(myProf->GetValue(S_PERCENTAGE,getValue,CUR_ROT_ANGLE),EO_OK);
	EXPECT_NEAR(getValue,25,0.5);
	EXPECT_EQ(myProf->GetValue(E_END_POS,getValue2),EO_OK);
	EXPECT_EQ(getValue2,1);
	EXPECT_EQ(myProf->GetValue(E_STATE,getValue2),EO_OK);
	EXPECT_EQ(getValue2,2);

	// Parse Stop msg
	uint8_t data2 [] = {0x02};
	memcpy(&msg.data[0], &data2[0],1);
	msg.dataLength = 1;
	myProf->Parse(msg);
	// Negative test
	EXPECT_EQ(myProf->GetValue(S_TIME,getValue), (uint8_t)NOT_SUPPORTED);
	// Getting values
	EXPECT_EQ(myProf->GetValue(E_IO_CHANNEL,getValue2),EO_OK);
	EXPECT_EQ(getValue2,0);

	// Query Position and Angle msg
	uint8_t data3 [] = {0x03};
	memcpy(&msg.data[0], &data3[0],1);
	msg.dataLength = 1;
	myProf->Parse(msg);
	// Negative test
	EXPECT_EQ(myProf->GetValue(S_TIME,getValue), (uint8_t)NOT_SUPPORTED);
	// Getting values
	EXPECT_EQ(myProf->GetValue(E_IO_CHANNEL,getValue2),EO_OK);
	EXPECT_EQ(getValue2,0);

	// Reply Position and Angle msg
	uint8_t data4 [] = {0x7f, 0x62, 0x00, 0x04};
	memcpy(&msg.data[0], &data4[0],4);
	msg.dataLength = 4;
	myProf->Parse(msg);
	// Negative test
	EXPECT_EQ(myProf->GetValue(S_TIME,getValue), (uint8_t)NOT_SUPPORTED);
	// Getting values
	EXPECT_EQ(myProf->GetValue(S_PERCENTAGE,getValue,CUR_VER_POSITION),EO_OK);
	EXPECT_NEAR(getValue,127,0.5);
	EXPECT_EQ(myProf->GetValue(S_PERCENTAGE,getValue,CUR_ROT_ANGLE),EO_OK);
	EXPECT_NEAR(getValue,98,0.5);
	EXPECT_EQ(myProf->GetValue(E_STATE,getValue2),EO_OK);
	EXPECT_EQ(getValue2,0);

	// Set parameters msg
	uint8_t data5 [] = {0x0E, 0x46, 0xFF, 0x03, 0x05};
	memcpy(&msg.data[0], &data5[0],5);
	msg.dataLength = 5;
	myProf->Parse(msg);
	// Negative test
	EXPECT_EQ(myProf->GetValue(S_PERCENTAGE,getValue), (uint8_t)NOT_SUPPORTED);
	// Getting values
	EXPECT_EQ(myProf->GetValue(S_TIME,getValue,SET_VER_DURATION),EO_OK);
	EXPECT_NEAR(getValue,3654,0.5);
	EXPECT_EQ(myProf->GetValue(S_TIME,getValue,SET_ROT_DURATION),EO_OK);
	EXPECT_NEAR(getValue,255,0.5);
	EXPECT_EQ(myProf->GetValue(E_STATE,getValue2),EO_OK);
	EXPECT_EQ(getValue2,3);
}
