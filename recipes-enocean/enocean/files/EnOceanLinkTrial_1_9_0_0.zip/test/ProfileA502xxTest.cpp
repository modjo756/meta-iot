#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA502xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x02, type);
		ASSERT_TRUE(myProf!=NULL);
	}
};

TEST_F(profileA502xxTest,eepA50201ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-20.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50201ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50202ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(10.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-30.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50202ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-30.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50203ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-20.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50203ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50204ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(30.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(10.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50204ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50205ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50205ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50206ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(30.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(10.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50206ControllerSendData)
{
	// Setup the test
	Init(0x06);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50207ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50207ControllerSendData)
{
	// Setup the test
	Init(0x07);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50208ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(70.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(30.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50208ControllerSendData)
{
	// Setup the test
	Init(0x08);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)70.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50209ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x09);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(80.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50209ControllerSendData)
{
	// Setup the test
	Init(0x09);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)80.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA5020AControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x0A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(90.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(70.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA5020AControllerSendData)
{
	// Setup the test
	Init(0x0A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)90.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)70.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA5020BControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x0B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(100.0, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(80.0, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA5020BControllerSendData)
{
	// Setup the test
	Init(0x0B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)100.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)80.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50210ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-20.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-60.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50210ControllerSendData)
{
	// Setup the test
	Init(0x10);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-60.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50211ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x11);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(30.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-50.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50211ControllerSendData)
{
	// Setup the test
	Init(0x11);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-50.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50212ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x12);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50212ControllerSendData)
{
	// Setup the test
	Init(0x12);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50213ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x13);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(10.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-30.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50213ControllerSendData)
{
	// Setup the test
	Init(0x13);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-30.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50214ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x14);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-20.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50214ControllerSendData)
{
	// Setup the test
	Init(0x14);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-20.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50215ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x15);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(70.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(30.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50215ControllerSendData)
{
	// Setup the test
	Init(0x15);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)70.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50216ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x16);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(80.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50216ControllerSendData)
{
	// Setup the test
	Init(0x16);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)80.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)0.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50217ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x17);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(90.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(10.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50217ControllerSendData)
{
	// Setup the test
	Init(0x17);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)90.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)10.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50218ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x18);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(100.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(60.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(20.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50218ControllerSendData)
{
	// Setup the test
	Init(0x18);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)100.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)60.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)20.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50219ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x19);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(110.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(70.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(30.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA50219ControllerSendData)
{
	// Setup the test
	Init(0x19);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)110.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)70.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)30.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA5021AControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x1A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(120.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(80.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(40.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA5021AControllerSendData)
{
	// Setup the test
	Init(0x1A);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)120.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)80.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)40.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA5021BControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x1B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(130.0, fGetValue, 5);

	// Median
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(90.0, fGetValue, 5);

	// Max
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(50.0, fGetValue, 5);
}

TEST_F(profileA502xxTest,eepA5021BControllerSendData)
{
	// Setup the test
	Init(0x1B);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)130.0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)90.0);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)50.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50220ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x20);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(41.2, fGetValue, 0.5);

	// Median
	ParseRawDate({0x00, 0x01, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(15.6, fGetValue, 0.5);

	// Max
	ParseRawDate({0x00, 0x03, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-10.0, fGetValue, 0.5);
}

TEST_F(profileA502xxTest,eepA50220ControllerSendData)
{
	// Setup the test
	Init(0x20);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)41.2);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)15.6);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x01, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-10.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x03, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}

TEST_F(profileA502xxTest,eepA50230ControllerReceiveData)
{
	float fGetValue;

	// Setup the test
	Init(0x30);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(62.3, fGetValue, 2);

	// Median
	ParseRawDate({0x00, 0x01, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(11.15, fGetValue, 2);

	// Max
	ParseRawDate({0x00, 0x03, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40.0, fGetValue, 2);
}

TEST_F(profileA502xxTest,eepA50230ControllerSendData)
{
	// Setup the test
	Init(0x30);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_TEMP));

	// S_TEMP
	// Min
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)62.3);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Median
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)11.15);
	myProf->Create(*msg);
	uint8_t data2[] = {0x00, 0x01, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max
	myProf->ClearValues();
	myProf->SetValue(S_TEMP,(float)-40.0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x03, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);
}
