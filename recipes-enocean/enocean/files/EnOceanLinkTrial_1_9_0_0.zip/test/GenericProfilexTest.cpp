/*
 * ProfileA530Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"
#include "Includes/eoGenericProfile.h"
//Helper function for A5
class GenericProfileTest : public ProfileFixture
{
public:
	GenericProfileTest() : gpProf(512)
	{
		msg = new eoMessage(512);
		msg->RORG=GP_CD;
		myProf = &gpProf;
	};

	~GenericProfileTest()
	{
		myProf=NULL;
	}
	/** */
	protected:
	eoGenericProfile gpProf;
	bool OutChannelExist(CHANNEL_TYPE type)
	{
		eoChannelInfo * myChan = gpProf.GetChannelOut(type);
		return(myChan!=NULL);
	}
};
//simple profile test....

TEST_F(GenericProfileTest,SimpleGpTempReceiver)
{
	float fGetValue;
	msg->RORG=GP_TI;
	ParseRawDate({0xFF,0xE0,0x46,0x19,0xD8,0x15,0x01},7);
	ASSERT_TRUE(ChannelExist(S_TEMP));
	//get channel...
	eoGPChannelInfo * gpChannel = (eoGPChannelInfo*) gpProf.GetChannel(S_TEMP);
	ASSERT_TRUE(gpChannel!=NULL);
	EXPECT_EQ(80,gpChannel->GetEngMax());
	EXPECT_EQ(-40,gpChannel->GetEngMin());
	EXPECT_EQ(GP_RES_16BIT,gpChannel->GetResolution());
	//Parse temperatures
	msg->RORG=GP_CD;
	ParseRawDate({0x00,0x00},2);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(-40,fGetValue,0.1);

	ParseRawDate({0x55,0x55},2);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(0,fGetValue,0.1);
	ParseRawDate({0xFF,0xFF},2);
	myProf->GetValue(S_TEMP, fGetValue);
	EXPECT_NEAR(80,fGetValue,0.1);
}
TEST_F(GenericProfileTest,SimpleGpTempSender)
{
	gpProf.AddChannelOut(S_TEMP,GP_RES_16BIT,80,-40,GP_SCAL_1,GP_SCAL_1,VAL_CURR);
	gpProf.CreateTeachIN(*msg);
	EXPECT_EQ(GP_TI,msg->RORG);
	EXPECT_EQ(7,msg->dataLength);
	//,,,,,,
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0xE0,msg->data[1]);
	EXPECT_EQ(0x46,msg->data[2]);
	EXPECT_EQ(0x19,msg->data[3]);
	EXPECT_EQ(0xD8,msg->data[4]);
	EXPECT_EQ(0x15,msg->data[5]);
	EXPECT_EQ(0x01,msg->data[6]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_TEMP,-40.0F));
	EXPECT_EQ(EO_OK,myProf->Create(*msg));
	EXPECT_EQ(GP_CD,msg->RORG);
	EXPECT_EQ(2,msg->dataLength);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_TEMP,0.0F));
	EXPECT_EQ(EO_OK,myProf->Create(*msg));
	EXPECT_EQ(GP_CD,msg->RORG);
	EXPECT_EQ(2,msg->dataLength);
	EXPECT_EQ(0x55,msg->data[0]);
	EXPECT_EQ(0x55,msg->data[1]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_TEMP,80.0F));
	EXPECT_EQ(EO_OK,myProf->Create(*msg));
	EXPECT_EQ(GP_CD,msg->RORG);
	EXPECT_EQ(2,msg->dataLength);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
}

TEST_F(GenericProfileTest,BiDirectionalTest)
{
	float fGetValue;
	uint8_t u8GetValue;
	msg->RORG=GP_TI;
	ParseRawDate({0xFF,0xF0,0x43,0xDC,0x00,0x10,0xA6,0xC0,0x51,0x81,0x10,0x04,0x1D,0x19,0xB0,0x00,0x4A,0xA0},18);
	ASSERT_TRUE(ChannelExist(S_LUMINANCE));
	ASSERT_TRUE(ChannelExist(E_GP_MULTIPURPOSE));
	ASSERT_TRUE(ChannelExist(F_DAY_NIGHT));
	ASSERT_TRUE(OutChannelExist(S_TIME_ABS));

	msg->RORG=GP_CD;
	ParseRawDate({0x00,0x00,0x00,0x00,0x00},5);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(0,fGetValue,1);
	myProf->GetValue(E_GP_MULTIPURPOSE, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0,u8GetValue);

	msg->RORG=GP_SD;
	ParseRawDate({0x10,0xA0},2);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(0,fGetValue,1);
	myProf->GetValue(E_GP_MULTIPURPOSE, u8GetValue);
	EXPECT_EQ(0,u8GetValue);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(1,u8GetValue);

	msg->RORG=GP_CD;
	ParseRawDate({0x0C,0xCC,0xCC,0xCD,0x80},5);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_NEAR(50000,fGetValue,1);
	myProf->GetValue(E_GP_MULTIPURPOSE, u8GetValue);
	EXPECT_EQ(2,u8GetValue);
	myProf->GetValue(F_DAY_NIGHT, u8GetValue);
	EXPECT_EQ(0,u8GetValue);

	//send data...
	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_TIME_ABS,0.0F));
	EXPECT_EQ(EO_OK,myProf->Create(*msg));
	EXPECT_EQ(GP_CD,msg->RORG);
	EXPECT_EQ(4,msg->dataLength);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x00,msg->data[2]);
	EXPECT_EQ(0x00,msg->data[3]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_TIME_ABS,420000000.0F));
	EXPECT_EQ(EO_OK,myProf->Create(*msg));
	EXPECT_EQ(GP_CD,msg->RORG);
	EXPECT_EQ(4,msg->dataLength);
	EXPECT_EQ(0xFF,msg->data[0]);
	EXPECT_EQ(0xFF,msg->data[1]);
	EXPECT_EQ(0xFF,msg->data[2]);
	EXPECT_EQ(0xFF,msg->data[3]);

	myProf->ClearValues();
	EXPECT_EQ(EO_OK,myProf->SetValue(S_TIME_ABS,1000.0F));
	EXPECT_EQ(EO_OK,myProf->Create(*msg));
	EXPECT_EQ(GP_CD,msg->RORG);
	EXPECT_EQ(4,msg->dataLength);
	EXPECT_EQ(0x00,msg->data[0]);
	EXPECT_EQ(0x00,msg->data[1]);
	EXPECT_EQ(0x27,msg->data[2]);
	EXPECT_EQ(0xF2,msg->data[3]);
}
