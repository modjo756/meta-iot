/*
 * ProfileA504Test.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "ProfileFixture.h"

class profileA511xxTest : public ProfileFixture
{
	/** */
	protected:

	void Init(uint8_t type)
	{
		msg = new eoMessage(4);
		msg->RORG=RORG_4BS;
		myProf = eoProfileFactory::CreateProfile(0xA5, 0x11, type);
		ASSERT_TRUE(myProf!=NULL);
	}

};

TEST_F(profileA511xxTest,eepA51101ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE_ABS));
	EXPECT_TRUE(ChannelExist(S_DIMMING));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_LUMINANCE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(254, fGetValue);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE, fGetValue);
	EXPECT_EQ(510, fGetValue);

	// S_LUMINANCE_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x08},4);
	myProf->GetValue(S_LUMINANCE_ABS, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// S_DIMMING
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_EQ(127, fGetValue);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_EQ(255, fGetValue);

	// F_ON_OFF - CS_REPEATER
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_REPEATER);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_REPEATER);
	EXPECT_EQ(1, u8GetValue);
	EXPECT_EQ(255, fGetValue);

	// F_ON_OFF - CS_POWER_RELAY_TIMER
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_POWER_RELAY_TIMER);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_POWER_RELAY_TIMER);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_DAYLIGHT_HARVEST
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_DAYLIGHT_HARVEST);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_DAYLIGHT_HARVEST);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_DAYLIGHT_HARVEST
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_DIMMING);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_DIMMING);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_POWER_RELAY
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_POWER_RELAY);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_POWER_RELAY);
	EXPECT_EQ(1, u8GetValue);

	// F_OPEN_CLOSED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_OPEN_CLOSED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// F_BTN_PRESS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(F_BTN_PRESS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);
}

TEST_F(profileA511xxTest,eepA51101ControllerSendData)
{
	// Setup the test
	Init(0x01);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_LUMINANCE));
	EXPECT_TRUE(ChannelExist(S_LUMINANCE_ABS));
	EXPECT_TRUE(ChannelExist(S_DIMMING));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(F_OPEN_CLOSED));
	EXPECT_TRUE(ChannelExist(F_BTN_PRESS));

	// S_LUMINANCE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)0);
	myProf->Create(*msg);
	uint8_t data1[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)255);
	myProf->Create(*msg);
	uint8_t data2[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE,(float)510);
	myProf->Create(*msg);
	uint8_t data3[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// S_LUMINANCE_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE_ABS,(float)127);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x7F, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_LUMINANCE_ABS,(float)255);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0xFF, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// S_DIMMING
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_DIMMING,(float)0);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_DIMMING,(float)127);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_DIMMING,(float)255);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_REPEATER
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_REPEATER);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_REPEATER);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_POWER_RELAY_TIMER
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_POWER_RELAY_TIMER);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_POWER_RELAY_TIMER);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_DAYLIGHT_HARVEST
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_DAYLIGHT_HARVEST);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_DAYLIGHT_HARVEST);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_DIMMING
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_DIMMING);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_DIMMING);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_POWER_RELAY
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_POWER_RELAY);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_POWER_RELAY);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// F_OPEN_CLOSED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_OPEN_CLOSED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// F_BTN_PRESS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_BTN_PRESS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);
}

TEST_F(profileA511xxTest,eepA51102ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE));
	EXPECT_TRUE(ChannelExist(E_OCCUPANCY));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(50, fGetValue,0.5);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(100, fGetValue,0.5);

	// E_FANSPEED
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x01, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x02, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x03, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 16
	ParseRawDate({0x00, 0x10, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(16, u8GetValue);

	// Enum tests - 17
	ParseRawDate({0x00, 0x11, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(17, u8GetValue);

	// Enum tests - 18
	ParseRawDate({0x00, 0x12, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(18, u8GetValue);

	// Enum tests - 19
	ParseRawDate({0x00, 0x13, 0x00, 0x08},4);
	myProf->GetValue(E_FANSPEED, u8GetValue);
	EXPECT_EQ(19, u8GetValue);

	// E_CONTROLLER_MODE
	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x68},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// S_TEMP_ABS
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(25.6, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x08},4);
	myProf->GetValue(S_TEMP_ABS, fGetValue);
	EXPECT_NEAR(51.2, fGetValue,0.5);

	// F_ON_OFF - CS_ALARM
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ALARM);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ALARM);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_CONTROLLER_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_CONTROLLER_STATE);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_CONTROLLER_STATE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_ENERGY_HOLDOFF
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ENERGY_HOLDOFF);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ENERGY_HOLDOFF);
	EXPECT_EQ(1, u8GetValue);

	// E_OCCUPANCY
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(E_OCCUPANCY, u8GetValue);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileA511xxTest,eepA51102ControllerSendData)
{
	// Setup the test
	Init(0x02);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(E_FANSPEED));
	EXPECT_TRUE(ChannelExist(S_TEMP_ABS));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE));
	EXPECT_TRUE(ChannelExist(E_OCCUPANCY));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)50);
	myProf->Create(*msg);
	uint8_t data1[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)100);
	myProf->Create(*msg);
	uint8_t data2[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// S_TEMP_ABS
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)0);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)25.6);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x00, 0x7F, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TEMP_ABS,(float)51.2);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_ALARM
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_ALARM);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_ALARM);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_CONTROLLER_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_CONTROLLER_STATE);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_CONTROLLER_STATE);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_ENERGY_HOLDOFF
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_ENERGY_HOLDOFF);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_ENERGY_HOLDOFF);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// E_OCCUPANCY
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_OCCUPANCY,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_OCCUPANCY,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_OCCUPANCY,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_OCCUPANCY,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// E_CONTROLLER_MODE
	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0x68};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// E_FANSPEED
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x01, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x02, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x03, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Enum tests - 16
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)16);
	myProf->Create(*msg);
	uint8_t data24[] = {0x00, 0x10, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Enum tests - 17
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)17);
	myProf->Create(*msg);
	uint8_t data25[] = {0x00, 0x11, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// Enum tests - 18
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)18);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x12, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Enum tests - 19
	myProf->ClearValues();
	myProf->SetValue(E_FANSPEED,(uint8_t)19);
	myProf->Create(*msg);
	uint8_t data27[] = {0x00, 0x13, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);
}

TEST_F(profileA511xxTest,eepA51103ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(E_ERROR_STATE));
	EXPECT_TRUE(ChannelExist(E_END_POS));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_SETPOINT
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x32, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(50, fGetValue,0.5);

	// Max value
	ParseRawDate({0x64, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_SETPOINT, fGetValue);
	EXPECT_NEAR(100, fGetValue,0.5);

	// F_ON_OFF
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ANGLE_SIGN);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x80, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ANGLE_SIGN);
	EXPECT_EQ(1, u8GetValue);

	// S_ANGLE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_ANGLE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x2D, 0x00, 0x08},4);
	myProf->GetValue(S_ANGLE, fGetValue);
	EXPECT_NEAR(90, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x5A, 0x00, 0x08},4);
	myProf->GetValue(S_ANGLE, fGetValue);
	EXPECT_NEAR(180, fGetValue,0.5);

	// F_ON_OFF - CS_POSITION_VALUE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_POSITION_VALUE);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x80, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_POSITION_VALUE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_ANGLE_VALUE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ANGLE_VALUE);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x40, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_ANGLE_VALUE);
	EXPECT_EQ(1, u8GetValue);

	// E_ERROR_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x10, 0x08},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x20, 0x08},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x30, 0x08},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// E_END_POS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_END_POS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x04, 0x08},4);
	myProf->GetValue(E_END_POS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x08, 0x08},4);
	myProf->GetValue(E_END_POS, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x0C, 0x08},4);
	myProf->GetValue(E_END_POS, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// E_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x02, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x03, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// F_ON_OFF - CS_SETVICE_MODE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_SETVICE_MODE);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_SETVICE_MODE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_MODE_OF_POSITION
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_MODE_OF_POSITION);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_MODE_OF_POSITION);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA511xxTest,eepA51103ControllerSendData)
{
	// Setup the test
	Init(0x03);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_SETPOINT));
	EXPECT_TRUE(ChannelExist(S_ANGLE));
	EXPECT_TRUE(ChannelExist(E_ERROR_STATE));
	EXPECT_TRUE(ChannelExist(E_END_POS));
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));

	// S_SETPOINT
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)0);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)50);
	myProf->Create(*msg);
	uint8_t data1[] = {0x32, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_SETPOINT,(float)100);
	myProf->Create(*msg);
	uint8_t data2[] = {0x64, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_ANGLE_SIGN
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_ANGLE_SIGN);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_ANGLE_SIGN);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x80, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// S_ANGLE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)0);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)90);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x2D, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_ANGLE,(float)180);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x5A, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_POSITION_VALUE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_POSITION_VALUE);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_POSITION_VALUE);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x80, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_ANGLE_VALUE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_ANGLE_VALUE);
	myProf->Create(*msg);
	uint8_t data10[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_ANGLE_VALUE);
	myProf->Create(*msg);
	uint8_t data11[] = {0x00, 0x00, 0x40, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// E_ERROR_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x00, 0x10, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0x00, 0x20, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x30, 0x08};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// E_END_POS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_END_POS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data16[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_END_POS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data17[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_END_POS,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x08, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_END_POS,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x0C, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// E_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x03, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_SETVICE_MODE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_SETVICE_MODE);
	myProf->Create(*msg);
	uint8_t data24[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_SETVICE_MODE);
	myProf->Create(*msg);
	uint8_t data25[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_MODE_OF_POSITION
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_MODE_OF_POSITION);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_MODE_OF_POSITION);
	myProf->Create(*msg);
	uint8_t data27[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);
}

TEST_F(profileA511xxTest,eepA51104ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RGB));
	EXPECT_TRUE(ChannelExist(S_DIMMING));
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(S_VALUE));
	EXPECT_TRUE(ChannelExist(E_UNITS));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_ERROR_STATE));

	// S_RGB - CS_RGB_RED
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_RED);
	EXPECT_NEAR(0, fGetValue,0.5);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_RED);
	EXPECT_NEAR(127, fGetValue,0.5);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_RED);
	EXPECT_NEAR(255, fGetValue,0.5);

	// S_RGB - CS_RGB_GREEN
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_GREEN);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_GREEN);
	EXPECT_NEAR(127, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFF, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_GREEN);
	EXPECT_NEAR(255, fGetValue,0.5);

	// S_RGB - CS_RGB_BLUE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_BLUE);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x00, 0x7F, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_BLUE);
	EXPECT_NEAR(127, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0x00, 0xFF, 0x0A},4);
	myProf->GetValue(S_RGB, fGetValue,CS_RGB_BLUE);
	EXPECT_NEAR(255, fGetValue,0.5);

	// S_DIMMING
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_NEAR(127, fGetValue,0.5);

	// Max value
	ParseRawDate({0xFF, 0x00, 0x00, 0x08},4);
	myProf->GetValue(S_DIMMING, fGetValue);
	EXPECT_NEAR(255, fGetValue,0.5);

	// S_TIME
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x00, 0x7F, 0xFF, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(32767, fGetValue,0.5);

	// Max value
	ParseRawDate({0x00, 0xFF, 0xFF, 0x48},4);
	myProf->GetValue(S_TIME, fGetValue);
	EXPECT_NEAR(65535, fGetValue,0.5);

	// S_VALUE
	// Min value
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_EQ(0, fGetValue);

	// Medium value
	ParseRawDate({0x7F, 0xFF, 0x00, 0x0C},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(32767, fGetValue,0.5);

	// Max value
	ParseRawDate({0xFF, 0xFF, 0x00, 0x0C},4);
	myProf->GetValue(S_VALUE, fGetValue);
	EXPECT_NEAR(65535, fGetValue,0.5);

	// E_UNITS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x01, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x02, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x03, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x04, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// Enum tests - 5
	ParseRawDate({0x00, 0x00, 0x05, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(5, u8GetValue);

	// Enum tests - 6
	ParseRawDate({0x00, 0x00, 0x06, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(6, u8GetValue);

	// Enum tests - 7
	ParseRawDate({0x00, 0x00, 0x07, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(7, u8GetValue);

	// Enum tests - 8
	ParseRawDate({0x00, 0x00, 0x08, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(8, u8GetValue);

	// Enum tests - 9
	ParseRawDate({0x00, 0x00, 0x09, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(9, u8GetValue);

	// Enum tests - 10
	ParseRawDate({0x00, 0x00, 0x0A, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(10, u8GetValue);

	// Enum tests - 11
	ParseRawDate({0x00, 0x00, 0x0B, 0x0C},4);
	myProf->GetValue(E_UNITS, u8GetValue);
	EXPECT_EQ(11, u8GetValue);

	// F_ON_OFF - CS_SETVICE_MODE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_SETVICE_MODE);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x88},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_SETVICE_MODE);
	EXPECT_EQ(1, u8GetValue);

	// F_ON_OFF - CS_OPERATING_HOURS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_OPERATING_HOURS);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_OPERATING_HOURS);
	EXPECT_EQ(1, u8GetValue);

	// E_ERROR_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_ERROR_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// F_ON_OFF - CS_STATUS
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_STATUS);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(F_ON_OFF, u8GetValue,CS_STATUS);
	EXPECT_EQ(1, u8GetValue);
}

TEST_F(profileA511xxTest,eepA51104ControllerSendData)
{
	// Setup the test
	Init(0x04);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(S_RGB));
	EXPECT_TRUE(ChannelExist(S_DIMMING));
	EXPECT_TRUE(ChannelExist(S_TIME));
	EXPECT_TRUE(ChannelExist(S_VALUE));
	EXPECT_TRUE(ChannelExist(E_UNITS));
	EXPECT_TRUE(ChannelExist(F_ON_OFF));
	EXPECT_TRUE(ChannelExist(E_ERROR_STATE));

	// S_RGB - CS_RGB_RED
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)0,CS_RGB_RED);
	myProf->Create(*msg);
	uint8_t data0[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data0[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)127,CS_RGB_RED);
	myProf->Create(*msg);
	uint8_t data1[] = {0x7F, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data1[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)255,CS_RGB_RED);
	myProf->Create(*msg);
	uint8_t data2[] = {0xFF, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data2[0],&msg->data[0],4),0);

	// S_RGB - CS_RGB_GREEN
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)0,CS_RGB_GREEN);
	myProf->Create(*msg);
	uint8_t data3[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data3[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)127,CS_RGB_GREEN);
	myProf->Create(*msg);
	uint8_t data4[] = {0x00, 0x7F, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data4[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)255,CS_RGB_GREEN);
	myProf->Create(*msg);
	uint8_t data5[] = {0x00, 0xFF, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data5[0],&msg->data[0],4),0);

	// S_RGB - CS_RGB_BLUE
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)0,CS_RGB_BLUE);
	myProf->Create(*msg);
	uint8_t data6[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data6[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)127,CS_RGB_BLUE);
	myProf->Create(*msg);
	uint8_t data7[] = {0x00, 0x00, 0x7F, 0x0A};
	EXPECT_EQ(memcmp(&data7[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_RGB,(float)255,CS_RGB_BLUE);
	myProf->Create(*msg);
	uint8_t data8[] = {0x00, 0x00, 0xFF, 0x0A};
	EXPECT_EQ(memcmp(&data8[0],&msg->data[0],4),0);

	// S_DIMMING
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_DIMMING,(float)0);
	myProf->Create(*msg);
	uint8_t data9[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data9[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_DIMMING,(float)127);
	myProf->Create(*msg);
	uint8_t data10[] = {0x7F, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data10[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_DIMMING,(float)255);
	myProf->Create(*msg);
	uint8_t data11[] = {0xFF, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data11[0],&msg->data[0],4),0);

	// S_TIME
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)0);
	myProf->Create(*msg);
	uint8_t data12[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data12[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)32767);
	myProf->Create(*msg);
	uint8_t data13[] = {0x00, 0x7F, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data13[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_TIME,(float)65535);
	myProf->Create(*msg);
	uint8_t data14[] = {0x00, 0xFF, 0xFF, 0x08};
	EXPECT_EQ(memcmp(&data14[0],&msg->data[0],4),0);

	// S_DIMMING
	// Min value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)0);
	myProf->Create(*msg);
	uint8_t data15[] = {0x00, 0x00, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data15[0],&msg->data[0],4),0);

	// Medium value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)32767);
	myProf->Create(*msg);
	uint8_t data16[] = {0x7F, 0xFF, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data16[0],&msg->data[0],4),0);

	// Max value
	myProf->ClearValues();
	myProf->SetValue(S_VALUE,(float)65535);
	myProf->Create(*msg);
	uint8_t data17[] = {0xFF, 0xFF, 0x00, 0x0C};
	EXPECT_EQ(memcmp(&data17[0],&msg->data[0],4),0);

	// E_UNITS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data38[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data38[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data39[] = {0x00, 0x00, 0x01, 0x08};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x02, 0x08};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x03, 0x08};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x04, 0x08};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// Enum tests - 5
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)5);
	myProf->Create(*msg);
	uint8_t data21[] = {0x00, 0x00, 0x05, 0x08};
	EXPECT_EQ(memcmp(&data21[0],&msg->data[0],4),0);

	// Enum tests - 6
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)6);
	myProf->Create(*msg);
	uint8_t data22[] = {0x00, 0x00, 0x06, 0x08};
	EXPECT_EQ(memcmp(&data22[0],&msg->data[0],4),0);

	// Enum tests - 7
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)7);
	myProf->Create(*msg);
	uint8_t data23[] = {0x00, 0x00, 0x07, 0x08};
	EXPECT_EQ(memcmp(&data23[0],&msg->data[0],4),0);

	// Enum tests - 8
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)8);
	myProf->Create(*msg);
	uint8_t data24[] = {0x00, 0x00, 0x08, 0x08};
	EXPECT_EQ(memcmp(&data24[0],&msg->data[0],4),0);

	// Enum tests - 9
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)9);
	myProf->Create(*msg);
	uint8_t data25[] = {0x00, 0x00, 0x09, 0x08};
	EXPECT_EQ(memcmp(&data25[0],&msg->data[0],4),0);

	// Enum tests - 10
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)10);
	myProf->Create(*msg);
	uint8_t data26[] = {0x00, 0x00, 0x0A, 0x08};
	EXPECT_EQ(memcmp(&data26[0],&msg->data[0],4),0);

	// Enum tests - 11
	myProf->ClearValues();
	myProf->SetValue(E_UNITS,(uint8_t)11);
	myProf->Create(*msg);
	uint8_t data27[] = {0x00, 0x00, 0x0B, 0x08};
	EXPECT_EQ(memcmp(&data27[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_OPERATING_HOURS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_OPERATING_HOURS);
	myProf->Create(*msg);
	uint8_t data28[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data28[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_OPERATING_HOURS);
	myProf->Create(*msg);
	uint8_t data29[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data29[0],&msg->data[0],4),0);

	// E_ERROR_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data30[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data31[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data32[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_ERROR_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data33[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_SETVICE_MODE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_SETVICE_MODE);
	myProf->Create(*msg);
	uint8_t data34[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data34[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_SETVICE_MODE);
	myProf->Create(*msg);
	uint8_t data35[] = {0x00, 0x00, 0x00, 0x88};
	EXPECT_EQ(memcmp(&data35[0],&msg->data[0],4),0);

	// F_ON_OFF - CS_STATUS
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)0, CS_STATUS);
	myProf->Create(*msg);
	uint8_t data36[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data36[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(F_ON_OFF,(uint8_t)1, CS_STATUS);
	myProf->Create(*msg);
	uint8_t data37[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data37[0],&msg->data[0],4),0);
}

TEST_F(profileA511xxTest,eepA51105ControllerReceiveData)
{
	uint8_t u8GetValue;
	float fGetValue;

	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_STATE));
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE));

	// E_CONTROLLER_MODE
	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x18},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x28},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x38},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);

	// Enum tests - 4
	ParseRawDate({0x00, 0x00, 0x00, 0x48},4);
	myProf->GetValue(E_CONTROLLER_MODE, u8GetValue);
	EXPECT_EQ(4, u8GetValue);

	// E_STATE
	// Enum tests - 0
	ParseRawDate({0x00, 0x00, 0x00, 0x08},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(0, u8GetValue);

	// Enum tests - 1
	ParseRawDate({0x00, 0x00, 0x00, 0x09},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(1, u8GetValue);

	// Enum tests - 2
	ParseRawDate({0x00, 0x00, 0x00, 0x0A},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(2, u8GetValue);

	// Enum tests - 3
	ParseRawDate({0x00, 0x00, 0x00, 0x0B},4);
	myProf->GetValue(E_STATE, u8GetValue);
	EXPECT_EQ(3, u8GetValue);
}

TEST_F(profileA511xxTest,eepA51105ControllerSendData)
{
	// Setup the test
	Init(0x05);

	//Check that all in Channels exist
	EXPECT_TRUE(ChannelExist(E_CONTROLLER_MODE));
	EXPECT_TRUE(ChannelExist(E_STATE));

	// E_CONTROLLER_MODE
	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data39[] = {0x00, 0x00, 0x00, 0x18};
	EXPECT_EQ(memcmp(&data39[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data18[] = {0x00, 0x00, 0x00, 0x28};
	EXPECT_EQ(memcmp(&data18[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data19[] = {0x00, 0x00, 0x00, 0x38};
	EXPECT_EQ(memcmp(&data19[0],&msg->data[0],4),0);

	// Enum tests - 4
	myProf->ClearValues();
	myProf->SetValue(E_CONTROLLER_MODE,(uint8_t)4);
	myProf->Create(*msg);
	uint8_t data20[] = {0x00, 0x00, 0x00, 0x48};
	EXPECT_EQ(memcmp(&data20[0],&msg->data[0],4),0);

	// E_STATE
	// Enum tests - 0
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)0);
	myProf->Create(*msg);
	uint8_t data30[] = {0x00, 0x00, 0x00, 0x08};
	EXPECT_EQ(memcmp(&data30[0],&msg->data[0],4),0);

	// Enum tests - 1
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)1);
	myProf->Create(*msg);
	uint8_t data31[] = {0x00, 0x00, 0x00, 0x09};
	EXPECT_EQ(memcmp(&data31[0],&msg->data[0],4),0);

	// Enum tests - 2
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)2);
	myProf->Create(*msg);
	uint8_t data32[] = {0x00, 0x00, 0x00, 0x0A};
	EXPECT_EQ(memcmp(&data32[0],&msg->data[0],4),0);

	// Enum tests - 3
	myProf->ClearValues();
	myProf->SetValue(E_STATE,(uint8_t)3);
	myProf->Create(*msg);
	uint8_t data33[] = {0x00, 0x00, 0x00, 0x0B};
	EXPECT_EQ(memcmp(&data33[0],&msg->data[0],4),0);
}
