/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include "Profiles/eoEEP_F601xx.h"
#include "ProfileFixture.h"
#include <gtest/gtest.h>
class ProfileF601Test : public ProfileFixture
{
	public:
	void Init(uint8_t type)
	{
		myProf = eoProfileFactory::CreateProfile(0xF6,0x01,type);
		ASSERT_TRUE(myProf!=NULL);
		msg = new eoMessage(1);
		msg->RORG=RORG_RPS;
	}
};
TEST_F(ProfileF601Test,eepF60101Receive)
{
	uint8_t u8GetValue;
	Init(1);

	// Released
	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(F_BTN_PRESS,u8GetValue));
	EXPECT_EQ(0,u8GetValue);

	// Pressed & Hold
	msg->data[0]=0x10;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(F_BTN_PRESS,u8GetValue));
	EXPECT_EQ(1,u8GetValue);
}

TEST_F(ProfileF601Test,eepF60101Send)
{
	Init(1);
	EXPECT_EQ(EO_OK,myProf->SetValue(F_BTN_PRESS,(uint8_t)0));
	myProf->Create(*msg);
	EXPECT_EQ(0x00,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(F_BTN_PRESS,(uint8_t)1));
	myProf->Create(*msg);
	EXPECT_EQ(0x10,msg->data[0]);

}
