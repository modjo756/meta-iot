/*
 * profileFixture.h
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#ifndef PROFILEFIXTURE_H_
#define PROFILEFIXTURE_H_

#include <gtest/gtest.h>
#include <initializer_list>
#include "eoLink.h"

class ProfileFixture: public testing::Test {

protected:
	/**
	 * Inits the Profile via TeachIn generated from params
	 * @param rorg Rorg
	 * @param func Func
	 * @param type Type
	 */
	void Init(uint8_t rorg,uint8_t func,uint8_t type);
	/**
	 * Uses set and getValue to check the set and getValue functions (+/- 0.1)
	 * @param type ::CHANNEL_TYPE
	 * @param Value value to check
	 */
	void CheckValue(CHANNEL_TYPE type,double Value);
	/**
	 * Uses set and getValue to check the set and getValue functions(+/- 0.1)
	 * @param type ::CHANNEL_TYPE
	 * @param Value value to check
	 */
	void CheckValue(CHANNEL_TYPE type,int Value);
	/**
	 * Uses set and getValue to check the set and getValue functions(+/- 0.1)
	 * @param type ::CHANNEL_TYPE
	 * @param Value value to check
	 */
	void CheckValue(CHANNEL_TYPE type,uint8_t Value);
	/**
	 * Uses set and getValue to check the set and getValue functions
	 * @param type ::CHANNEL_TYPE
	 * @param Value value to check
	 */
	void CheckValue(CHANNEL_TYPE type,float Value);
	/**
	 *
	 * @param type
	 * @return
	 */
	bool ChannelExist(CHANNEL_TYPE type);
	/**
	 *
	 * @param type
	 * @param index
	 * @return
	 */
	bool ChannelExist(CHANNEL_TYPE type,uint8_t index);
	/**
	 * Checks if Channel exist and if we get OUT_OF_RANGE then our values are higher then the supported values
	 * @param type  ::CHANNEL_TYPE
	 */

	void CheckChannel(CHANNEL_TYPE type);
	/**
	 * Pointer to the created Profil,
	 */

	eoProfile *myProf;
	eoMessage *msg;
	/**
	 * Copies raw data into the internal message and call the parse function of the profile
	 * @param rawData
	 * @param length
	 */
	 void ParseRawDate(std::initializer_list<uint8_t> array,uint8_t length);


public:
	/**
	 *	Pointer the msg, will be initialized via Init
	 */

	ProfileFixture();
	~ProfileFixture();
};

#endif /* PROFILEFIXTURE_H_ */
