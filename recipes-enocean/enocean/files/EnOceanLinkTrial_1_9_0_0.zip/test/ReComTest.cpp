/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include <gtest/gtest.h>
#include "eoMockPacketStream.h"
#include "GatewayFixture.h"
#include "eoLink.h"

TEST(eoReCom,MetaData)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);

	recom.GetMetadata(0x12345678);

	EXPECT_EQ(gateway.reManMessage.dataLength, 0);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x12345678);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x210);

	QUERY_METADATA_RESPONSE metadataResponse;
	uint8_t metadataData [] = {0xA0, 0x10, 0x00, 0xAB, 0x09};
	memcpy(&gateway.reManMessage.data[0],&metadataData[0],5);
	gateway.reManMessage.fnCode = 0x810;
	gateway.reManMessage.dataLength = 5;

	recom.ParseGetMetadataResponse(metadataResponse);
	EXPECT_EQ(metadataResponse.remoteTeachOutbound,1);
	EXPECT_EQ(metadataResponse.remoteTeachInbound,0);
	EXPECT_EQ(metadataResponse.outboundLinkTable,1);
	EXPECT_EQ(metadataResponse.inboundLinkTable,0);

	EXPECT_EQ(metadataResponse.lengthOfOutbound,16);
	EXPECT_EQ(metadataResponse.maxOfOutbound,0);
	EXPECT_EQ(metadataResponse.lenghtOfInbound,0xAB);
	EXPECT_EQ(metadataResponse.maxOfInbound,9);

}
TEST(eoReCom,LinkTables)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);

	QUERY_LINK_TABLE linkTableQuery;
	linkTableQuery.tableDir = RECOM_OUTBOUND_TABLE;
	linkTableQuery.startIndex = 0x15;
	linkTableQuery.endIndex = 0xCD;
	uint8_t linkTableQueryData[] = {0x80, 0x15, 0xCD};
	recom.GetLinkTable(linkTableQuery,0x87654321);

	EXPECT_EQ(gateway.reManMessage.dataLength,3);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&linkTableQueryData[0],3),0);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x211);
	EXPECT_EQ(gateway.reManMessage.destinationID, 0x87654321);

	RECOM_TABLE_DIR tableDir;
	uint8_t maxSize;
	uint8_t tableSize = 1;
	uint8_t linkTableData[] = {0x80, 0x00, 0x12, 0x23, 0x34, 0x45, 0xA5, 0x37, 0x10, 0x05,
			0x01, 0x34, 0xAC, 0xBD, 0x53, 0xA5, 0x12, 0x0F, 0x12};
	memcpy(&gateway.reManMessage.data[0],&linkTableData[0],19);
	gateway.reManMessage.fnCode = 0x811;
	gateway.reManMessage.dataLength = 19;
	std::vector<LINK_TABLE> getLinkTableResponse;
	recom.ParseGetLinkTableResponse(getLinkTableResponse,tableDir);
	EXPECT_EQ(tableDir,RECOM_OUTBOUND_TABLE);
	EXPECT_EQ(getLinkTableResponse[0].EEP_RORG, 0xA5);
	EXPECT_EQ(getLinkTableResponse[0].EEP_FUNC, 0x37);
	EXPECT_EQ(getLinkTableResponse[0].EEP_TYPE, 0x10);
	EXPECT_EQ(getLinkTableResponse[0].ID, 0x12233445);
	EXPECT_EQ(getLinkTableResponse[0].index, 0);
	EXPECT_EQ(getLinkTableResponse[0].channel, 5);

	std::vector<LINK_TABLE> setLinkTable = std::vector<LINK_TABLE>(2);
	setLinkTable[0].index = 0x00;
	setLinkTable[0].ID = 0x12233445;
	setLinkTable[0].EEP_RORG = 0xA5;
	setLinkTable[0].EEP_FUNC=0x37;
	setLinkTable[0].EEP_TYPE=0x10;
	setLinkTable[0].channel = 0x05;

	setLinkTable[1].index = 0x01;
	setLinkTable[1].ID = 0x34ACBD53;
	setLinkTable[1].EEP_RORG = 0xA5;
	setLinkTable[1].EEP_FUNC=0x12;
	setLinkTable[1].EEP_TYPE=0x0F;
	setLinkTable[1].channel = 0x12;
	recom.SetLinkTable(setLinkTable,tableDir,0x05435638);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&linkTableData[0],19),0);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x212);
	EXPECT_EQ(gateway.reManMessage.dataLength,19);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x05435638);
}
TEST(eoReCom,gpTable)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);

	GP_LINK_TABLE gpLinkTable;
	gpLinkTable.tableDir = RECOM_OUTBOUND_TABLE;
	gpLinkTable.index = 121;

	uint8_t gpGetLinkTableData [] = {0x80, 0x79};
	recom.GetGPLinkTable(gpLinkTable,0x12345678);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&gpGetLinkTableData[0],2),0);
	EXPECT_EQ(gateway.reManMessage.dataLength,2);
	EXPECT_EQ(gateway.reManMessage.fnCode,FN_RECOM_GET_GP_TABLE);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x12345678);

	eoMessage msg(256);
	eoGenericProfile sendGProfile, recvGProfile;
	EXPECT_EQ(sendGProfile.AddChannelOut(S_TEMP,GP_RES_8BIT,(int8_t) 0, (int8_t)40, GP_SCAL_1, GP_SCAL_1, VAL_CURR),EO_OK);
	EXPECT_EQ(sendGProfile.AddChannelOut(S_RELHUM,GP_RES_8BIT,(int8_t) 0, (int8_t)100, GP_SCAL_1, GP_SCAL_1, VAL_CURR),EO_OK);
	EXPECT_EQ(sendGProfile.AddChannelOut(F_ON_OFF, VAL_CURR),EO_OK);

	sendGProfile.CreateTeachIN(msg);
	memcpy(&gateway.reManMessage.data[2],&msg.data[2],(msg.dataLength - 2));
	gateway.reManMessage.fnCode = FN_RECOM_GET_GP_TABLE_RESPONSE;
	gateway.reManMessage.dataLength = msg.dataLength;
	gateway.reManMessage.data[0] = 0x00;
	gateway.reManMessage.data[1] = 0xA3;

	recom.ParseGetGPLinkTableResponse(gpLinkTable);
	EXPECT_EQ(memcmp(&msg.data[2],gpLinkTable.gp_ti,gpLinkTable.length),0);

	EXPECT_EQ(sendGProfile.AddChannelOut(F_OPEN_CLOSED,VAL_CURR),EO_OK);
	EXPECT_EQ(sendGProfile.AddChannelOut(S_LUMINANCE,GP_RES_10BIT,(int8_t)0,(int8_t)100,GP_SCAL_1,GP_SCAL_1,VAL_CURR),EO_OK);
	sendGProfile.CreateTeachIN(msg);
	uint8_t setGPTableData [256];
	memcpy(&setGPTableData[0],&msg.data[2],(msg.dataLength - 2));
	gpLinkTable.index = 0x65;
	gpLinkTable.gp_ti=setGPTableData;
	gpLinkTable.length=msg.dataLength - 2;
	gpLinkTable.tableDir = RECOM_OUTBOUND_TABLE;
	recom.SetGPLinkTable(gpLinkTable,(uint32_t)0x12345678);


	EXPECT_EQ(memcmp(setGPTableData,&(gateway.reManMessage.data[2]),gateway.reManMessage.dataLength-2),0);

}
TEST(eoReCom,learnMode)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);
	QUERY_SET_LEARN_MODE learnMode;
	learnMode.mode = RECOM_LEARN_OUT;
	learnMode.inboundIndex = 0x25;
	uint8_t setLearnModeData[] = {0x40,0x25};

	recom.RemoteSetLearnMode(learnMode,0xFFFFFFFF);
	EXPECT_EQ(gateway.reManMessage.destinationID,0xFFFFFFFF);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x220);
	EXPECT_EQ(gateway.reManMessage.dataLength,2);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&setLearnModeData[0],2),0);

	recom.RemoteSetLearnMode(learnMode,0x12345678);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x12345678);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x220);
	EXPECT_EQ(gateway.reManMessage.dataLength,2);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&setLearnModeData[0],2),0);

	recom.TriggerOutboundTeachRequest(0x84,0x54665463);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x221);
	EXPECT_EQ(gateway.reManMessage.dataLength,1);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x54665463);
	EXPECT_EQ(gateway.reManMessage.data[0],0x84);
}

TEST(eoReCom,DeviceConfig)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(512);
	QUERY_DEVICE_CONFIG deviceConf;
	deviceConf.startIndex = 0x516;
	deviceConf.endIndex = 0x6335;
	deviceConf.length = 0xFF;
	uint8_t deviceConfData[] = {0x05, 0x16, 0x63, 0x35, 0xFF};

	recom.GetDeviceConfig(deviceConf,0x45465546);
	EXPECT_EQ(gateway.reManMessage.dataLength,5);
	EXPECT_EQ(gateway.reManMessage.fnCode, 0x230);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x45465546);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&deviceConfData[0],5),0);
	//parse get device config
	std::vector<DEVICE_CONFIG> config;

	gateway.reManMessage.fnCode = 0x830;
	gateway.reManMessage.dataLength=12;
	memset(gateway.reManMessage.data,0,12);
	gateway.reManMessage.data[2]=4;
	gateway.reManMessage.data[6]=1;
	gateway.reManMessage.data[8]=1;
	gateway.reManMessage.data[9]=2;
	gateway.reManMessage.data[10]=0xFF;
	gateway.reManMessage.data[11]=0xFF;
	recom.ParseDeviceConfigResponse(config);
	EXPECT_EQ(2,config.size());
	EXPECT_EQ(0,config[0].index);
	EXPECT_EQ(4,config[0].length);
	EXPECT_EQ(1,config[0].rawValue);
	EXPECT_EQ(1,config[1].index);
	EXPECT_EQ(2,config[1].length);
	EXPECT_EQ(0xFFFF,config[1].rawValue);
	gateway.reManMessage.copyTo(message);
	memset(gateway.reManMessage.data,0,12);
	//set device config...
	recom.SetDeviceConfig(config,0xFF112233);
	EXPECT_EQ(0x231,gateway.reManMessage.fnCode);
	EXPECT_EQ(12,gateway.reManMessage.dataLength);
	EXPECT_EQ(0xFF112233,gateway.reManMessage.destinationID);
	EXPECT_EQ(0,memcmp(message.data,gateway.reManMessage.data,12));

}
TEST(eoReCom,LinkedConfig)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);
	QUERY_LINK_BASED_CONFIG linkBasedConf;
	linkBasedConf.tableDir = RECOM_INBOUND_TABLE;
	linkBasedConf.tableIndex = 0x56;
	linkBasedConf.startIndex = 0xA56F;
	linkBasedConf.endIndex = 0xFFFF;
	linkBasedConf.length = 0x43;
	uint8_t linkBasedConfData[] = {0x00, 0x56, 0xA5, 0x6F, 0xFF, 0xFF, 0x43};

	recom.GetLinkBasedConfig(linkBasedConf,0x75646553);
	EXPECT_EQ(gateway.reManMessage.dataLength,7);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x232);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x75646553);
	EXPECT_EQ(memcmp(&gateway.reManMessage.data[0],&linkBasedConfData[0],7),0);
	// 2 paremeters get
	//0x832 //
	gateway.reManMessage.fnCode=0x832;
	gateway.reManMessage.dataLength=13;
	uint8_t remanData1[] = {0x00,0x22,0x00,0x01,0x01,0x00,0x00,0x02,0x04,0x01,0x02,0x03,0x04};
	memcpy(gateway.reManMessage.data,remanData1,13);
	std::vector<LINK_BASED_CONFIG> linkConfig;
	ASSERT_EQ(EO_OK,recom.ParseLinkBasedConfigResponse(linkConfig));
	EXPECT_EQ(2,linkConfig.size());
	EXPECT_EQ(1,linkConfig[0].index);
	EXPECT_EQ(1,linkConfig[0].length);
	EXPECT_EQ(0,linkConfig[0].rawValue);
	EXPECT_EQ(0,linkConfig[0].tableDir);
	EXPECT_EQ(0x22,linkConfig[0].tableIndex);

	EXPECT_EQ(2,linkConfig[1].index);
	EXPECT_EQ(4,linkConfig[1].length);
	EXPECT_EQ(0x01020304,linkConfig[1].rawValue);
	EXPECT_EQ(0,linkConfig[1].tableDir);
	EXPECT_EQ(0x22,linkConfig[1].tableIndex);
	//2 parameters set...
	memset(gateway.reManMessage.data,0,14);
	EXPECT_EQ(EO_OK,recom.SetLinkBasedConfig(linkConfig,0x11223344));
	EXPECT_EQ(0x233,gateway.reManMessage.fnCode);
	EXPECT_EQ(13,gateway.reManMessage.dataLength);
	EXPECT_EQ(0x11223344,gateway.reManMessage.destinationID);
	EXPECT_EQ(0,memcmp(remanData1,gateway.reManMessage.data,13));

}
TEST(eoReCom,CommonCommands)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);
	QUERY_APPLY_CHANGES applyChanges;
	applyChanges.linkTableChanges = RECOM_CHANGES_NOT_APPLY;
	applyChanges.configChanges = RECOM_CHANGES_APPLY;

	recom.ApplyChanges(applyChanges,0x12345678);
	EXPECT_EQ(gateway.reManMessage.dataLength,1);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x226);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x12345678);
	EXPECT_EQ(gateway.reManMessage.data[0],0x40);

	QUERY_RESET_DEFAULTS resetDefaults;
	resetDefaults.configParam = RECOM_DEFAULT_RESET;
	resetDefaults.inboundTable = RECOM_NO_DEFAULT_RESET;
	resetDefaults.outboundTable = RECOM_DEFAULT_RESET;

	recom.ResetDefaults(resetDefaults,0xFFFFFFFF);
	EXPECT_EQ(gateway.reManMessage.dataLength,1);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x224);
	EXPECT_EQ(gateway.reManMessage.destinationID,0xFFFFFFFF);
	EXPECT_EQ(gateway.reManMessage.data[0],0xA0);

	QUERY_RADIO_LINK_TEST radioLink;
	radioLink.isEnabled = true;
	radioLink.numOfRLT = 0x13;

	recom.RadioLinkTest(radioLink,0x879546AD);
	EXPECT_EQ(gateway.reManMessage.dataLength,1);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x225);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x879546AD);
	EXPECT_EQ(gateway.reManMessage.data[0],0x93);

	recom.GetProductID(0x879546AD);
	EXPECT_EQ(gateway.reManMessage.dataLength,0);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x227);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x879546AD);

	QUERY_PRODUCT_ID_RESPONSE productIdResponse;
	uint8_t productIdResponseData[] = {0x12, 0x34, 0xA1, 0xA2, 0x35, 0x54};
	memcpy(&gateway.reManMessage.data[0],&productIdResponseData[0],6);
	gateway.reManMessage.fnCode = 0x827;
	gateway.reManMessage.dataLength = 6;

	recom.ParseGetProductIDResponse(productIdResponse);
	EXPECT_EQ(productIdResponse.manufacturerId,0x1234);
	EXPECT_EQ(productIdResponse.productReference,0xA1A23554);
}
TEST(eoReCom,repeaterFunctions)
{
	GatewayFixture gateway;
	eoReCom recom (&gateway);
	eoReManMessage message(20);
	recom.GetRepeater(0x12345678);
	EXPECT_EQ(gateway.reManMessage.dataLength,0);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x12345678);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x250);

	REPEATER_FUNCTIONS repeaterResponse;
	uint8_t repeaterResponseData[] = {0x98};
	memcpy(&gateway.reManMessage.data[0], &repeaterResponseData[0],1);
	gateway.reManMessage.dataLength = 1;
	gateway.reManMessage.fnCode = 0x850;

	recom.ParseGetRepeaterResponse(repeaterResponse);
	EXPECT_EQ(repeaterResponse.repeaterFunc,RECOM_FILTERED_REPEATER_ON);
	EXPECT_EQ(repeaterResponse.repeaterLevel,RECOM_REPEATER_LEVEL_1);
	EXPECT_EQ(repeaterResponse.repeaterFilter,RECOM_REPEATER_OR);

	repeaterResponse.repeaterLevel = RECOM_REPEATER_LEVEL_2;
	recom.SetRepeater(repeaterResponse,0x98765432);
	EXPECT_EQ(gateway.reManMessage.dataLength,1);
	EXPECT_EQ(gateway.reManMessage.fnCode,0x251);
	EXPECT_EQ(gateway.reManMessage.destinationID,0x98765432);
	EXPECT_EQ(gateway.reManMessage.data[0],0xA8);
}

