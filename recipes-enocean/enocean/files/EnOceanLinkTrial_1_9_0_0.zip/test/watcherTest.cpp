/*
 * deviceTest.cpp
 *
 *  Created on: 27.06.2012
 *      Author: tobias
 */
#include <gtest/gtest.h>
#include <string.h>
#include "eoLink.h"


TEST(eoWatcher, deviceManagment)
{
	eoWatcher myWatcher;
	eoDevice myDev(0x11324242);
	eoTelegram tel(4);
	EXPECT_EQ(myWatcher.AddDevice(0x11324242,1,0,10,10,true),WATCH_OK);
	EXPECT_EQ(myWatcher.AddDevice(0x11324242,1,0,10,10,true),WATCH_DEVICE_ALREADY_EXIST);
	EXPECT_EQ(myWatcher.UpdateDevice(0x11324242,1,0,10,10,true),WATCH_OK);
	EXPECT_EQ(myWatcher.UpdateDevice(0x11324243,1,0,10,10,true),WATCH_DEVICE_NA);

	EXPECT_NE(myWatcher.CheckSecurity(&myDev,tel),WATCH_DEVICE_NA);
}

