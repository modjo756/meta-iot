/*
 * profileTest.cpp
 *
 *  Created on: 02.07.2012
 *      Author: tobias
 */

#include "eoLink.h"
#include "Profiles/eoEEP_F602xx.h"
#include "ProfileFixture.h"
#include <gtest/gtest.h>
class ProfileF602Test : public ProfileFixture
{
	public:
	void Init(uint8_t type)
	{
		myProf = eoProfileFactory::CreateProfile(0xF6,0x02,type);
		ASSERT_TRUE(myProf!=NULL);
		msg = new eoMessage(1);
		msg->RORG=RORG_RPS;
	}
};
TEST_F(ProfileF602Test,eepF60201Receive)
{
	uint8_t u8GetValue;
	Init(1);
	msg->status=0x30;

	msg->data[0]=0x10;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_RELEASED,u8GetValue);

	msg->data[0]=0x30;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x50;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x70;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	//two buttons
	msg->data[0]=0x15;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x17;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x35;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x37;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->status=0x20;
	msg->data[0]=0x70;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_MULTIPRESS,u8GetValue));
	EXPECT_EQ(MULTIPRESS_YES,u8GetValue);
}

TEST_F(ProfileF602Test,eepF60201Send)
{
	Init(1);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x10,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x30,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_NP));

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x50,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x70,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x15,msg->data[0]);


	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x17,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x35,msg->data[0]);


	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x37,msg->data[0]);

}

TEST_F(ProfileF602Test,eepF60202Receive)
{
	uint8_t u8GetValue;
	Init(1);
	msg->status=0x30;

	msg->data[0]=0x10;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_RELEASED,u8GetValue);

	msg->data[0]=0x30;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x50;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x70;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	//two buttons
	msg->data[0]=0x15;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x17;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x35;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x37;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->status=0x20;
	msg->data[0]=0x70;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_MULTIPRESS,u8GetValue));
	EXPECT_EQ(MULTIPRESS_YES,u8GetValue);
}

TEST_F(ProfileF602Test,eepF60202Send)
{
	Init(2);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x10,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x30,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_NP));

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x50,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x70,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x15,msg->data[0]);


	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x17,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x35,msg->data[0]);


	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x37,msg->data[0]);

}

TEST_F(ProfileF602Test,eepF60203Receive)
{
	uint8_t u8GetValue;
	Init(3);
	msg->status=0x30;

	msg->data[0]=0x10;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);

	msg->data[0]=0x30;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);

	msg->data[0]=0x50;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);

	msg->data[0]=0x70;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);

}

TEST_F(ProfileF602Test,eepF60103Send)
{
	Init(3);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x10,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x30,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_NP));

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x50,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	myProf->Create(*msg);
	EXPECT_EQ(0x30,msg->status);
	EXPECT_EQ(0x70,msg->data[0]);
}


TEST_F(ProfileF602Test,eepF60204Receive)
{
	uint8_t u8GetValue;
	Init(4);

	msg->data[0]=0x00;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_NP,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_NP,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_RELEASED,u8GetValue);

	msg->data[0]=0x8A;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_I,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x85;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_O,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);

	msg->data[0]=0x8F;
	EXPECT_EQ(EO_OK,myProf->Parse(*msg));
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_A,u8GetValue));
	EXPECT_EQ(STATE_IO,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ROCKER_B,u8GetValue));
	EXPECT_EQ(STATE_IO,u8GetValue);
	EXPECT_EQ(EO_OK,myProf->GetValue(E_ENERGYBOW,u8GetValue));
	EXPECT_EQ(ENERGY_PRESSED,u8GetValue);
}
TEST_F(ProfileF602Test,eepF60104Send)
{
	Init(4);
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_RELEASED));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_NP));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_NP));
	myProf->Create(*msg);
	EXPECT_EQ(0x0,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_I));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_I));
	myProf->Create(*msg);
	EXPECT_EQ(0x8A,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_O));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_O));
	myProf->Create(*msg);
	EXPECT_EQ(0x85,msg->data[0]);

	EXPECT_EQ(EO_OK,myProf->SetValue(E_ENERGYBOW,(uint8_t)ENERGY_PRESSED));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_A,(uint8_t)STATE_IO));
	EXPECT_EQ(EO_OK,myProf->SetValue(E_ROCKER_B,(uint8_t)STATE_IO));
	myProf->Create(*msg);
	EXPECT_EQ(0x8F,msg->data[0]);
}
