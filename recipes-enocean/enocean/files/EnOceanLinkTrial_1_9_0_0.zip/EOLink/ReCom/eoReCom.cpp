/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoGateway.h"
#include "eoReCom.h"
#include "eoManufacturer.h"
#include "memory.h"

eoReCom::eoReCom(eoGateway *gateway)
	:reManMessage(512)
{
	this->gateway = gateway;
	shallBeRepeated = false;
}

eoReCom::~eoReCom()
{
}

eoReturn eoReCom::initPacket(FN_RECOM_CODE const fnCode, uint8_t const length)
{
	if(reManMessage.SetDataLength(length)!=EO_OK)
		return OUT_OF_RANGE;

	reManMessage.fnCode = fnCode;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;

	return EO_OK;
}

eoReturn eoReCom::GetMetadata(uint32_t const destinationID)
{
	if(initPacket(FN_RECOM_GET_METADATA,0) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage,shallBeRepeated);
}

eoReturn eoReCom::ParseGetMetadataResponse(QUERY_METADATA_RESPONSE &response) const
{
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_METADATA_RESPONSE || gateway->reManMessage.GetDataLength() != 5)
		return NOT_SUPPORTED;

	response.remoteTeachOutbound = (RECOM_SUPPORT)((gateway->reManMessage.data[0] >> 7) & 0x01);
	response.remoteTeachInbound = (RECOM_SUPPORT)((gateway->reManMessage.data[0] >> 6) & 0x01);
	response.outboundLinkTable = (RECOM_SUPPORT)((gateway->reManMessage.data[0] >> 5) & 0x01);
	response.inboundLinkTable = (RECOM_SUPPORT)((gateway->reManMessage.data[0] >> 4) & 0x01);

	response.lengthOfOutbound = gateway->reManMessage.data[1];
	response.maxOfOutbound = gateway->reManMessage.data[2];
	response.lenghtOfInbound= gateway->reManMessage.data[3];
	response.maxOfInbound = gateway->reManMessage.data[4];

	return EO_OK;
}

eoReturn eoReCom::GetLinkTable(QUERY_LINK_TABLE const &query, uint32_t const destinationID)
{
	if(initPacket(FN_RECOM_GET_TABLE,3) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = ((uint8_t)query.tableDir << 7);
	reManMessage.data[1] = query.startIndex;
	reManMessage.data[2] = query.endIndex;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::ParseGetLinkTableResponse(std::vector<LINK_TABLE> &response, RECOM_TABLE_DIR &tableDir) const
{
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_TABLE_RESPONSE || (gateway->reManMessage.GetDataLength() % 9) != 1)
		return NOT_SUPPORTED;

	uint8_t numOfChannel = (uint8_t)((gateway->reManMessage.GetDataLength() - 1) / 9);
	for (uint8_t i = 0; (i < numOfChannel); i++)
	{
		LINK_TABLE tmpResponse;
		tmpResponse.index = gateway->reManMessage.data[(i * 9) + 1];
		tmpResponse.ID = (gateway->reManMessage.data[(i * 9) + 2] << 24) | (gateway->reManMessage.data[(i * 9) + 3] << 16) | (gateway->reManMessage.data[(i * 9) + 4] << 8) | (gateway->reManMessage.data[(i * 9) + 5]);
		tmpResponse.EEP_RORG = gateway->reManMessage.data[(i * 9) + 6];
		tmpResponse.EEP_FUNC = gateway->reManMessage.data[(i * 9) + 7];
		tmpResponse.EEP_TYPE = gateway->reManMessage.data[(i * 9) + 8];
		tmpResponse.channel = gateway->reManMessage.data[(i * 9) + 9];
		response.push_back(tmpResponse);
	}

	tableDir = (RECOM_TABLE_DIR)((gateway->reManMessage.data[0] >> 7) & 0x01);

	return EO_OK;
}

eoReturn eoReCom::GetGPLinkTable(GP_LINK_TABLE const &query, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_GET_GP_TABLE,2) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = query.tableDir << 7;
	reManMessage.data[1] = query.index;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::ParseGetGPLinkTableResponse(GP_LINK_TABLE &query) const
{
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_GP_TABLE_RESPONSE)
		return NOT_SUPPORTED;

	query.tableDir = (RECOM_TABLE_DIR)((gateway->reManMessage.data[0] >> 7) & 0x01);
	query.index = gateway->reManMessage.data[1];

	query.length=gateway->reManMessage.dataLength - 2;
	if(query.gp_ti!=NULL)
		delete[] query.gp_ti;

	query.gp_ti = new uint8_t[query.length];
	memcpy(query.gp_ti,&gateway->reManMessage.data[2],(query.length));

	return EO_OK;
}

eoReturn eoReCom::SetGPLinkTable(GP_LINK_TABLE const &query, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_SET_GP_TABLE,query.length+2) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;
	reManMessage.data[0] = query.tableDir << 7;
	reManMessage.data[1] = query.index;

	memcpy(&reManMessage.data[2],query.gp_ti,(query.length));

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::SetLinkTable(std::vector<LINK_TABLE> const &query, RECOM_TABLE_DIR tableDir, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_SET_TABLE,((query.size() * 9) + 1)) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = (uint8_t)tableDir << 7;
	for (uint8_t i = 0; i < query.size(); i++)
	{
		reManMessage.data[(i * 9) + 1] = query[i].index;

		reManMessage.data[(i * 9) + 2] = (query[i].ID >> 24) & 0xFF;
		reManMessage.data[(i * 9) + 3] = (query[i].ID >> 16) & 0xFF;
		reManMessage.data[(i * 9) + 4] = (query[i].ID >> 8) & 0xFF;
		reManMessage.data[(i * 9) + 5] = query[i].ID & 0xFF;

		reManMessage.data[(i * 9) + 6] = query[i].EEP_RORG;
		reManMessage.data[(i * 9) + 7] = query[i].EEP_FUNC;
		reManMessage.data[(i * 9) + 8] = query[i].EEP_TYPE;

		reManMessage.data[(i * 9) + 9] = query[i].channel;
	}

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::RemoteSetLearnMode(QUERY_SET_LEARN_MODE const &learnMode, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_SET_LEARN_MODE,2) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = learnMode.mode << 6;
	reManMessage.data[1] = learnMode.inboundIndex;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::TriggerOutboundTeachRequest(uint8_t channel, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_TRIG_OUTBOUND_TEACH_REQ,1) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = channel;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::GetDeviceConfig(QUERY_DEVICE_CONFIG const &deviceConf, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_GET_DEVICE_CONFIG,5) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = (deviceConf.startIndex >> 8) & 0xFF;
	reManMessage.data[1] = deviceConf.startIndex & 0xFF;
	reManMessage.data[2] = (deviceConf.endIndex >> 8) & 0xFF;
	reManMessage.data[3] = deviceConf.endIndex & 0xFF;
	reManMessage.data[4] = deviceConf.length;

	return gateway->Send(reManMessage, shallBeRepeated);
}
eoReturn eoReCom::ParseDeviceConfigResponse(std::vector<DEVICE_CONFIG> &deviceConf) const
{
	DEVICE_CONFIG tmpResponse;
	uint16_t length= gateway->reManMessage.GetDataLength();
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_DEVICE_CONFIG_RESPONSE|| length < 3)
		return NOT_SUPPORTED;

	for (uint8_t offset = 0; (offset+3 < length); )
	{

		tmpResponse.index = (gateway->reManMessage.data[offset+1] & 0xFF) | ((gateway->reManMessage.data[offset] << 8) & 0xFF00);
		tmpResponse.length = gateway->reManMessage.data[offset+2];

		if (GetRawValue(tmpResponse.length, offset + 3, gateway->reManMessage, tmpResponse.rawValue) != EO_OK)
			return OUT_OF_RANGE;

		deviceConf.push_back(tmpResponse);
		offset+=3+tmpResponse.length;
	}
	return EO_OK;

}
eoReturn eoReCom::SetDeviceConfig(std::vector<DEVICE_CONFIG> const &deviceConf, uint32_t destinationID)
{
	if(deviceConf.empty())
			return OUT_OF_RANGE;

	uint8_t length=0;
	for(std::vector<DEVICE_CONFIG>::const_iterator it=deviceConf.begin(); it != deviceConf.end(); ++it)
	{
		length+=3;
		length+=it->length;
	}
	if(initPacket(FN_RECOM_SET_DEVICE_CONFIG,length) != EO_OK)
		return OUT_OF_RANGE;
	reManMessage.destinationID = destinationID;
	int offset=0;
	for(std::vector<DEVICE_CONFIG>::const_iterator it=deviceConf.begin(); it != deviceConf.end(); ++it)
	{
		reManMessage.data[offset] = it->index >> 8;
		reManMessage.data[offset+1] = it->index;
		reManMessage.data[offset+2] = it->length;
		if(SetRawValue(it->length,offset+3,reManMessage,it->rawValue)!=EO_OK)
			return OUT_OF_RANGE;
		offset+=3+it->length;
	}
	return gateway->Send(reManMessage, shallBeRepeated);
}
eoReturn eoReCom::GetRawValue(uint8_t length,uint8_t offset,eoReManMessage const &reManMessage,uint32_t &value) const
{
	if(reManMessage.GetDataLength()<(offset+length))
	{
		return OUT_OF_RANGE;
	}
	uint8_t const * data = reManMessage.data;
	switch(length)
	{
        case 4:
        	value = ((data[offset] << 24) + (data[offset + 1] << 16) + (data[offset + 2] << 8) + (data[offset + 3]));
            break;
        case 3:
        	value = ((data[offset] << 16) + (data[offset + 1] << 8) + (data[offset + 2]));
            break;
        case 2:
        	value = ((data[offset] << 8) + (data[offset + 1]));
            break;
        case 1:
        	value = ((data[offset]));
            break;
        default:
    		return OUT_OF_RANGE;
	}
	return EO_OK;
}

eoReturn eoReCom::SetRawValue(uint8_t length,uint8_t offset,eoReManMessage  &reManMessage,uint32_t const &value) const
{
	if(reManMessage.GetDataLength()<(offset+length))
	{
		return OUT_OF_RANGE;
	}
	uint8_t  * data = reManMessage.data;
	switch(length)
	{
        case 4:
            data[offset] = (uint8_t)((value >> 24) & 0xFF);
            data[offset + 1] = (uint8_t)((value >> 16) & 0xFF);
            data[offset + 2] = (uint8_t)((value >> 8) & 0xFF);
            data[offset + 3] = (uint8_t)((value ) & 0xFF);
            offset += 4;
            break;
        case 3:
            data[offset] = (uint8_t)((value >> 16) & 0xFF);
            data[offset + 1] = (uint8_t)((value >> 8) & 0xFF);
            data[offset + 2] = (uint8_t)((value) & 0xFF);
            offset += 3;
            break;
        case 2:
            data[offset] = (uint8_t)((value >> 8) & 0xFF);
            data[offset + 1] = (uint8_t)((value) & 0xFF);
            offset += 2;
            break;
        case 1:
            data[offset] = (uint8_t)((value) & 0xFF);
            offset += 1;
            break;
        default:
    		return OUT_OF_RANGE;
	}
	return EO_OK;
}

eoReturn eoReCom::GetLinkBasedConfig(QUERY_LINK_BASED_CONFIG const &linkConfig, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_GET_LINK_BASED_CONFIG,7) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = linkConfig.tableDir << 0x06;
	reManMessage.data[1] = linkConfig.tableIndex;
	reManMessage.data[2] = (linkConfig.startIndex >> 8) & 0xFF;
	reManMessage.data[3] = linkConfig.startIndex & 0xFF;
	reManMessage.data[4] = (linkConfig.endIndex >> 8) & 0xFF;
	reManMessage.data[5] = linkConfig.endIndex & 0xFF;
	reManMessage.data[6] = linkConfig.length;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::SetLinkBasedConfig(std::vector<LINK_BASED_CONFIG> const &linkConfig, uint32_t destinationID)
{
	if(linkConfig.empty())
		return OUT_OF_RANGE;
	RECOM_TABLE_DIR tableDir=linkConfig[0].tableDir;
	uint8_t tableIndex=linkConfig[0].tableIndex;

	uint8_t length=2;
	for(std::vector<LINK_BASED_CONFIG>::const_iterator it=linkConfig.begin(); it != linkConfig.end(); ++it)
	{
		if(it->tableDir != tableDir || it->tableIndex!=tableIndex)
			continue;
		length+=3;
		length+=it->length;
	}
	if(initPacket(FN_RECOM_SET_LINK_BASED_CONFIG,length) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;
	reManMessage.data[0] = tableDir << 0x06;
	reManMessage.data[1] = tableIndex;
	int offset=2;
	for(std::vector<LINK_BASED_CONFIG>::const_iterator it=linkConfig.begin(); it != linkConfig.end(); ++it)
	{
		if(it->tableDir != tableDir || it->tableIndex!=tableIndex)
			continue;
		reManMessage.data[offset] = it->index >> 8;
		reManMessage.data[offset+1] = it->index;
		reManMessage.data[offset+2] = it->length;
		if(SetRawValue(it->length,offset+3,reManMessage,it->rawValue)!=EO_OK)
			return OUT_OF_RANGE;
		offset+=3+it->length;
	}
	return gateway->Send(reManMessage, shallBeRepeated);

}
eoReturn eoReCom::ParseLinkBasedConfigResponse(std::vector<LINK_BASED_CONFIG> &linkConfig) const
{
	uint16_t length= gateway->reManMessage.GetDataLength();
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_LINK_BASED_CONFIG_RESPONSE || length < 5)
		return NOT_SUPPORTED;

	RECOM_TABLE_DIR tableDir=(RECOM_TABLE_DIR)(gateway->reManMessage.data[0] >> 0x06);
	uint8_t tableIndex=gateway->reManMessage.data[1];
	for (uint8_t offset = 2; (offset+3 < length); )
	{
		LINK_BASED_CONFIG tmpResponse;
		tmpResponse.tableDir=tableDir;
		tmpResponse.tableIndex=tableIndex;
		tmpResponse.index = (gateway->reManMessage.data[offset+1] & 0xFF) | ((gateway->reManMessage.data[offset] << 8) & 0xFF00);
		tmpResponse.length = gateway->reManMessage.data[offset+2];
		if(GetRawValue(tmpResponse.length,offset+3,gateway->reManMessage,tmpResponse.rawValue)!=EO_OK)
			return OUT_OF_RANGE;
		linkConfig.push_back(tmpResponse);
		offset+=3+tmpResponse.length;
	}
	return EO_OK;
}
eoReturn eoReCom::ApplyChanges(QUERY_APPLY_CHANGES const &changes, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_APPLY_CHANGES,1) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = (changes.linkTableChanges << 7) | (changes.configChanges << 6);

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::ResetDefaults(QUERY_RESET_DEFAULTS const &defaults, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_RESET_TO_DEFAULTS,1) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = (defaults.configParam << 7) | (defaults.inboundTable << 6) | (defaults.outboundTable << 5);

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::RadioLinkTest(QUERY_RADIO_LINK_TEST const &radioLink, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_RADIO_LINK_TEST_CONTROL,1) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = radioLink.isEnabled << 7;
	reManMessage.data[0] |= radioLink.numOfRLT & 0x7F;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::GetProductID(uint32_t destinationID)
{
	if(initPacket(FN_RECOM_GET_PRODUCT_ID,0) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::ParseGetProductIDResponse(QUERY_PRODUCT_ID_RESPONSE &response) const
{
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_PRODUCT_RESPONSE || gateway->reManMessage.GetDataLength() != 6)
		return NOT_SUPPORTED;

	response.manufacturerId = (gateway->reManMessage.data[0] << 8) | gateway->reManMessage.data[1];
	response.productReference = (gateway->reManMessage.data[2] << 24) | (gateway->reManMessage.data[3] << 16) | (gateway->reManMessage.data[4] << 8) | gateway->reManMessage.data[5];

	return EO_OK;
}

eoReturn eoReCom::GetRepeater(uint32_t destinationID)
{
	if(initPacket(FN_RECOM_GET_REPEATER_FUNCTIONS,0) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoReCom::ParseGetRepeaterResponse(REPEATER_FUNCTIONS &response) const
{
	if (gateway->reManMessage.fnCode != FN_RECOM_GET_REPEATER_FUNCTIONS_RESPONSE || gateway->reManMessage.GetDataLength() != 1)
		return NOT_SUPPORTED;

	response.repeaterFunc = (RECOM_REPEATER_FUNC)((gateway->reManMessage.data[0] >> 6) & 0x03);
	response.repeaterLevel = (RECOM_REPEATER_LEVEL)((gateway->reManMessage.data[0] >> 4) & 0x03);
	response.repeaterFilter = (RECOM_REPEATER_FILTER)((gateway->reManMessage.data[0] >> 3) & 0x01);

	return EO_OK;
}

eoReturn eoReCom::SetRepeater(REPEATER_FUNCTIONS const &repeaterFunc, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_SET_REPEATER_FUNCTIONS,1) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = repeaterFunc.repeaterFunc << 6;
	reManMessage.data[0] |= repeaterFunc.repeaterLevel << 4;
	reManMessage.data[0] |= repeaterFunc.repeaterFilter << 3;

	return gateway->Send(reManMessage, shallBeRepeated);
}
eoReturn eoReCom::SetRepeaterFilter(QUERY_SET_REPEATER_FILTER const &repeaterFunc, uint32_t destinationID)
{
	if(initPacket(FN_RECOM_SET_REPEATER_FILTER,1) != EO_OK)
		return OUT_OF_RANGE;

	reManMessage.destinationID = destinationID;

	reManMessage.data[0] = repeaterFunc.repeaterFunc << 6;
	reManMessage.data[0] |= repeaterFunc.repeaterLevel << 4;
	reManMessage.data[1] = repeaterFunc.value >> 24;
	reManMessage.data[2] = repeaterFunc.value >> 16;
	reManMessage.data[3] = repeaterFunc.value >> 8;
	reManMessage.data[4] = repeaterFunc.value;
	return gateway->Send(reManMessage, shallBeRepeated);
}

