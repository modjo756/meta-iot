#!/bin/bash
make disctclean
mkdir ReleaseLib
cd ReleaseLib/
../configure --enable-platform=POSIX CPPFLAGS="-O3"
if [ "$?" -eq "0" ]; then
	echo "Starting Make process"
else
	echo "Configure failed!"
	exit $?
fi
make clean
make 
if [ "$?" -eq "0" ]; then
        echo "Copying static Library for examples/Tutorials"
else
        exit $?
fi
cp .libs/libEOLink.a ./libEOLink.a

