#ifndef EOVERSION_H_
#define EOVERSION_H_
//! Major Version number
#define EOLINK_VERSION_MAIN			1
//! Minor Version number
#define EOLINK_VERSION_BETA		9
//! Maintenance Version number
#define EOLINK_VERSION_ALPHA		0
//! Build Version number
#define EOLINK_VERSION_POINT		0
#endif //__AUTOBUILD_H__
