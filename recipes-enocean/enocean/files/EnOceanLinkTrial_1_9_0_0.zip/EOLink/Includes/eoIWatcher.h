/**
 * \file eoIWatcher.h
 * \brief Watcher Header File
 * \author EnOcean GmbH
 *
 * An Example Class Header, which allows the security checking of Devices.
 * */
#include "eoDevice.h"
#include "eoTelegram.h"

#ifndef EOIWATCHER_H_
#define EOIWATCHER_H_

typedef enum
{
	eoWATCHER = 1
} SUPPORTED_WATCHER;

/**
 * @class eoIWatcher
 * @brief The minimal Interface for an eoWatcher class.
 *
 * The CheckSecurity is called inside Gateway and stored as internal variable. This Interface allows you to implement an own
 * security check algorithm which is called for every received telegram.
 * The function eoIWatcher::CheckSecurity(eoDevice const * const  device,eoTelegram const &tel) is always called in the Gateway
 * after receiving a telegram. The result of the function can be accessed using the eoGateway::GetSecWatchResult()
 */
class eoIWatcher : public eoISerialize
{
public:
	//! Type of the eoIWatcher, this is used for the serialization
	uint8_t type;
	eoIWatcher();

	/**
	 * @brief checks the Security of a Device after Receiving a telegram.
	 *
	 * This function has to be called always after receiving a telegram!
	 *
	 * @param device pointer to eoDevice to Check
	 * @param tel last received telegram
	 * @return
	 */
	virtual uint32_t CheckSecurity(eoDevice const * const  device,eoTelegram const &tel);
	/**
	 * Serialization Function which will be called by the eoStorageManager
	 * This function will be called by the eoArchive(inside of the eoStorageManager) and allows the class to be Serialized.
	 * @param &arch Archive where to Load or to Store.
	 */
	virtual uint8_t Serialize(eoArchive &arch);
	virtual ~eoIWatcher();
private:

};

#endif /* EOWATCHER_H_ */
/** @}*/
