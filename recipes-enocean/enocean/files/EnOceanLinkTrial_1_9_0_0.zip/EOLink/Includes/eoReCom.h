/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoReCom.h
 * \brief eoRemoteCommissioning
 * \author EnOcean GmBH
 */
#ifndef EO_REMOTE_COMISSIONING_H_
#define EO_REMOTE_COMISSIONING_H_
#include "eoGateway.h"
#include "eoGenericProfile.h"
/**
 * @ingroup recom
 *@{
 */
/**
 * \typedef eoReComReturn
 * \brief Contains all the return values from ReCom functions
 */
typedef enum
{
	//! OK
	RECOM_OK	= 0x00,
	//! Wrong target ID
	RECOM_WRONG_ID	= 0x01,
	//! Wrong unlock code
	RECOM_WRONG_UNLOCK_CODE	= 0x02,
	//! Wrong EEP
	RECOM_WRONG_EEP	= 0x03,
	//! Wrong manufacturer ID
	RECOM_WRONG_MANUFACTURER_ID	= 0x04,
	//! Wrong data size
	RECOM_WRONG_DATA_SIZE	= 0x05,
	//! No code set
	RECOM_NO_CODE_SET	= 0x06,
	//! Not send
	RECOM_NOT_SEND	= 0x07,
	//! RPC failed
	RECOM_RPC_FAIL	= 0x08,
	//! Message time out
	RECOM_MSG_TIMEOUT	= 0x09,
	//! Too long message
	RECOM_MSG_TOO_LONG	= 0x0A,
	//! Message part already received
	RECOM_MSG_PART_RECEIVED	= 0x0B,
	//! Message part not received
	RECOM_MSG_PART_NOT_RECEIVED	= 0x0C,
	//! Address out of range
	RECOM_ADDR_OUT_OF_RANGE	= 0x0D,
	//! Code data size exceeded
	RECOM_CODE_DATA_SIZE_EXCEED	= 0x0E,
	//! Wrong data
	RECOM_WRONG_DATA	= 0x0F
} eoReComReturn;

/**
 * \typedef FN_RECOM_CODE
 * \brief Function codes for Remote Commissioning
 */
typedef enum
{
	//! Remote Commissioning Acknowledge
	FN_RECOM_ACK	= 0x240, //Remote Commissioning Acknowledge
	//! Get Link Table Metadata Query
	FN_RECOM_GET_METADATA	= 0x210, //Get Link Table Metadata Query
	//! Get Link Table Metadata Response
	FN_RECOM_GET_METADATA_RESPONSE	= 0x810, //Get Link Table Metadata Response
	//! Get Link Table Query
	FN_RECOM_GET_TABLE	= 0x211, //Get Link Table Query
	//! Get Link Table Response
	FN_RECOM_GET_TABLE_RESPONSE	= 0x811, //Get Link Table Response
	//! Set Link Table Query
	FN_RECOM_SET_TABLE	= 0x212, //Set Link Table Query
	//! Get Link Table GP Entry Query
	FN_RECOM_GET_GP_TABLE	= 0x213, //Get Link Table GP Entry Query
	//! Get Link Table GP Entry Response
	FN_RECOM_GET_GP_TABLE_RESPONSE	= 0x813, //Get Link Table GP Entry Response
	//! Set Link Table GP Entry Query
	FN_RECOM_SET_GP_TABLE	= 0x214, //Set Link Table GP Entry Query
	//! Remote Set Learn Mode
	FN_RECOM_SET_LEARN_MODE	= 0x220, //Remote Set Learn Mode
	//! Trigger Outbound Remote Teach Request
	FN_RECOM_TRIG_OUTBOUND_TEACH_REQ	= 0x221, //Trigger Outbound Remote Teach Request
	//! Get Device Configuration Query
	FN_RECOM_GET_DEVICE_CONFIG	= 0x230, //Get Device Configuration Query
	//! Get Device Configuration Response
	FN_RECOM_GET_DEVICE_CONFIG_RESPONSE	= 0x830, //Get Device Configuration Response
	//! Set Device Configuration Query
	FN_RECOM_SET_DEVICE_CONFIG	= 0x231, //Set Device Configuration Query
	//! Get Link Based Configuration Query
	FN_RECOM_GET_LINK_BASED_CONFIG	= 0x232, //Get Link Based Configuration Query
	//! Get Link Based Configuration Response
	FN_RECOM_GET_LINK_BASED_CONFIG_RESPONSE	= 0x832, //Get Link Based Configuration Response
	//! Set Link Based Configuration Query
	FN_RECOM_SET_LINK_BASED_CONFIG	= 0x233, //Set Link Based Configuration Query
	//! Apply Changes Command
	FN_RECOM_APPLY_CHANGES	= 0x226, //Apply Changes Command
	//! Reset to Defaults
	FN_RECOM_RESET_TO_DEFAULTS	= 0x224, //Reset to Defaults
	//! Radio Link Test Control
	FN_RECOM_RADIO_LINK_TEST_CONTROL	= 0x225, //Radio Link Test Control
	//! Get Product ID Query
	FN_RECOM_GET_PRODUCT_ID	= 0x227, //Get Product ID Query
	//! Get Product ID Response
	FN_RECOM_GET_PRODUCT_RESPONSE	= 0x827, //Get Product ID Response
	//! Get Repeater Functions Query
	FN_RECOM_GET_REPEATER_FUNCTIONS	= 0x250, //Get Repeater Functions Query
	//! Get Repeater Functions Response
	FN_RECOM_GET_REPEATER_FUNCTIONS_RESPONSE	= 0x850, //Get Repeater Functions Response
	//! Set Repeater Functions Query
	FN_RECOM_SET_REPEATER_FUNCTIONS	= 0x251, //Set Repeater Functions Query
	//! Set Repeater Filter Query
	FN_RECOM_SET_REPEATER_FILTER	= 0x252 //Set Repeater Filter Query
} FN_RECOM_CODE;

//! Enums for supported flags
typedef enum
{
	//! Not supported
	RECOM_NOT_SUPPORTED = 0x00,
	//! Supported
	RECOM_SUPPORTED = 0x01
} RECOM_SUPPORT;

//! Enums for table direction
typedef enum
{
	//! Inbound
	RECOM_INBOUND_TABLE = 0x00,
	//! Outbound
	RECOM_OUTBOUND_TABLE = 0x01
} RECOM_TABLE_DIR;

//! Enums for changes
typedef enum
{
	//! Do not apply changes
	RECOM_CHANGES_NOT_APPLY = 0x00,
	//! Apply changes
	RECOM_CHANGES_APPLY = 0x01
} RECOM_CHANGES;

//! Enums for learn modes
typedef enum
{
	//! Learn in mode
	RECOM_LEARN_IN = 0x00,
	//! Learn out mode
	RECOM_LEARN_OUT = 0x01,
	//! Exit any learn mode
	RECOM_EXIT_LEARN = 0x02
} RECOM_LEARN_MODE;

//! Enums for configuration
typedef enum
{
	//! Do not reset default
	RECOM_NO_DEFAULT_RESET = 0x00,
	//! Reset default
	RECOM_DEFAULT_RESET = 0x01
} RECOM_RESET;

//! Enums for repeater function
typedef enum
{
	//! Repeater off
	RECOM_REPEATER_OFF = 0x00,
	//! Repeater on
	RECOM_REPEATER_ON = 0x01,
	//! Filtered repeating on
	RECOM_FILTERED_REPEATER_ON = 0x02
} RECOM_REPEATER_FUNC;

//! Enums for repeater level
typedef enum
{
	//! Repeater level 1
	RECOM_REPEATER_LEVEL_1 = 0x01,
	//! Repeater level 2
	RECOM_REPEATER_LEVEL_2 = 0x02
} RECOM_REPEATER_LEVEL;

//! Enums for repeater filter
typedef enum
{
	//! Repeater filter AND
	RECOM_REPEATER_AND = 0x00,
	//! Repeater filter OR
	RECOM_REPEATER_OR = 0x01
} RECOM_REPEATER_FILTER;

//! Enums for repeater filter control
typedef enum
{
	//! Repeater filter Block
	RECOM_REPEATER_BLOCK = 0x00,
	//! Repeater filter Apply
	RECOM_REPEATER_APPLY = 0x01,
	//! Repeater filter delete specified
	RECOM_REPEATER_DELETE_FILTER = 0x02,
	//! Repeater filter delete all filter
	RECOM_REPEATER_DELETE_ALL = 0x03
} RECOM_REPEATER_FILTER_CONTROL;

//! Enums for repeater filter type
typedef enum
{
	//! Repeater filter source ID
	RECOM_FILTER_SOURCE_ID = 0x00,
	//! Repeater filter RORG
	RECOM_FILTER_RORG = 0x01,
	//! Repeater filter dBm
	RECOM_FILTER_DBM = 0x02,
	//! Repeater filter destination ID
	RECOM_FILTER_DESTINATION_ID = 0x03
} RECOM_REPEATER_FILTER_TYPE;

/**
 * \struct QUERY_METADATA_RESPONSE
 * \brief Query metadata response structure
 */
typedef struct
{
	//! Remote teach outbound supported
	RECOM_SUPPORT remoteTeachOutbound;
	//! Remote teach inbound supported
	RECOM_SUPPORT remoteTeachInbound;
	//! Outbound link table supported
	RECOM_SUPPORT outboundLinkTable;
	//! Inbound link table supported
	RECOM_SUPPORT inboundLinkTable;
	//! Current length of outbound table
	uint8_t lengthOfOutbound;
	//! Max length of outbound table
	uint8_t maxOfOutbound;
	//! Current length of inbound table
	uint8_t lenghtOfInbound;
	//! Max length of inbound table
	uint8_t maxOfInbound;
} QUERY_METADATA_RESPONSE;

/**
 * \struct QUERY_LINK_TABLE
 * \brief Query link table structure
 */
typedef struct
{
	//! Table direction
	RECOM_TABLE_DIR tableDir;
	//! Starting index
	uint8_t startIndex;
	//! Ending index
	uint8_t endIndex;
} QUERY_LINK_TABLE;

/**
 * \struct GP_LINK_TABLE
 * \brief Query gp teach in link table structure
 */
typedef struct gplinkTable
{
	//! Table direction
	RECOM_TABLE_DIR tableDir;
	//! Index
	uint8_t index;
	//! The length
	uint8_t length;
	//! The gp teach in message
	uint8_t * gp_ti;
	//!Constructor to ensure length is 0 and pointer too!
	gplinkTable() : length(0),gp_ti(NULL){};
} GP_LINK_TABLE;

/**
 * \struct LINK_TABLE
 * \brief Entry for get/set link table
 */
typedef struct
{
	//! Index
	uint8_t index;
	//! ID
	uint32_t ID;
	//! EEP RORG
	uint8_t EEP_RORG;
	//! EEP FUNC
	uint8_t EEP_FUNC;
	//! EEP TYPE
	uint8_t EEP_TYPE;
	//! Channel
	uint8_t channel;
} LINK_TABLE;

/**
 * \struct QUERY_SET_LEARN_MODE
 * \brief Set learn mode structure
 */
typedef struct
{
	//! Learn mode
	RECOM_LEARN_MODE mode;
	//! Inbound index
	uint8_t inboundIndex;
} QUERY_SET_LEARN_MODE;

/**
 * \struct QUERY_DEVICE_CONFIG
 * \brief Query device configuration
 */
typedef struct
{
	//! Starting index
	uint16_t startIndex;
	//! Ending index
	uint16_t endIndex;
	//! Length
	uint8_t length;
} QUERY_DEVICE_CONFIG;

/**
 * \struct DEVICE_CONFIG
 * \brief Dvice configuration response
 */
typedef struct
{
	//! Starting index
	uint16_t index;
	//! Byte-Length of the rawValue
	uint8_t length;
	//!the RawValue
	uint32_t rawValue;
} DEVICE_CONFIG;

/**
 * \struct QUERY_LINK_BASED_CONFIG
 * \brief Query link based configuration
 */
typedef struct
{
	//! Table direction
	RECOM_TABLE_DIR tableDir;
	//! Link table index
	uint16_t tableIndex;
	//! Start index
	uint16_t startIndex;
	//! End index
	uint16_t endIndex;
	//! Length
	uint8_t length;
} QUERY_LINK_BASED_CONFIG;
/**
 * \struct QUERY_LINK_BASED_CONFIG
 * \brief Query link based configuration
 */
typedef struct
{
	//! Table direction
	RECOM_TABLE_DIR tableDir;
	//! Link table index
	uint8_t tableIndex;
	//! Parameter Index
	uint16_t index;
	//! Byte Length of the Raw Value
	uint8_t length;
	//!the RawValue
	uint32_t rawValue;
} LINK_BASED_CONFIG;


/**
 * \struct QUERY_APPLY_CHANGES
 * \brief Apply changes struct
 */
typedef struct
{
	//! Link table changes
	RECOM_CHANGES linkTableChanges;
	//! Configuration changes
	RECOM_CHANGES configChanges;
} QUERY_APPLY_CHANGES;

/**
 * \struct QUERY_RESET_DEFAULTS
 * \brief Query reset structure
 */
typedef struct
{
	//! Configuration parameters
	RECOM_RESET configParam;
	//! Inbound link table
	RECOM_RESET inboundTable;
	//! Outbound link table
	RECOM_RESET outboundTable;
} QUERY_RESET_DEFAULTS;

/**
 * \struct QUERY_RADIO_LINK_TEST
 * \brief Radio link test control
 */
typedef struct
{
	//! Enable/disable
	bool isEnabled;
	//! Number of RLT slave
	uint8_t numOfRLT;
} QUERY_RADIO_LINK_TEST;

/**
 * \struct QUERY_PRODUCT_ID_RESPONSE
 * \brief Get product ID response
 */
typedef struct
{
	//! Manufacturer ID
	uint16_t manufacturerId;
	//! Product reference
	uint32_t productReference;
} QUERY_PRODUCT_ID_RESPONSE;

/**
 * \struct QUERY_REPEATER_RESPONSE
 * \brief Get repeater response
 */
typedef struct
{
	//! Repeater function
	RECOM_REPEATER_FUNC repeaterFunc;
	//! Repeater level
	RECOM_REPEATER_LEVEL repeaterLevel;
	//! Repeater filter
	RECOM_REPEATER_FILTER repeaterFilter;
} REPEATER_FUNCTIONS;

/**
 * \struct QUERY_SET_REPEATER_FILTER
 * \brief Set repeater filter
 */
typedef struct
{
	//! Filter control
	RECOM_REPEATER_FILTER_CONTROL repeaterFunc;
	//! Filter type
	RECOM_REPEATER_FILTER_TYPE repeaterLevel;
	//! Filter value
	uint32_t value;
} QUERY_SET_REPEATER_FILTER;

/**
 *\class eoReCom
 *@ingroup recom
 *\brief Remote Commissioning interface class.
 *
 * This helper class, allows sending and parsing of different Remote Commissioning commands.
 * The command parameter are wrapped in different parameter helper structs.
 * For a detailed explanation of remote commissioning please consult the ReCom Spec.
 */
class eoReCom
{
private:
	bool shallBeRepeated;
	eoGateway *gateway;
	eoReManMessage reManMessage;
	eoReturn initPacket(FN_RECOM_CODE const fnCode, uint8_t const length);

	eoReturn GetRawValue(uint8_t length,uint8_t offset,eoReManMessage const &reManMessage,uint32_t &value) const;

	eoReturn SetRawValue(uint8_t length,uint8_t offset,eoReManMessage &reManMessage,uint32_t const &value) const;


public:
	/**
	 *Constructor.
	 *@param gateway eoGateway to be used for remote commissioning.
	 */
	eoReCom(eoGateway *gateway);
	~eoReCom();
	/**
	* If true the send telegrams are set in such a state that they can be repeated
	*/
	bool GetShallBeRepeated() const      { return shallBeRepeated; };
	/**
	*@param repeat = if true, the send telegrams can be repeated
	*/
	void SetShallBeRepeated(bool repeat) { shallBeRepeated = repeat; };

	/**
	 * Get link table metadata command.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param destinationID The device ID of the end device
	 */
	eoReturn GetMetadata(uint32_t destinationID);
	/**
	 * With this command the actor parse the remote commission message into a QUERY_METADATA_RESPONSE structure.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param[out] response Metadata response
	 */
	eoReturn ParseGetMetadataResponse(QUERY_METADATA_RESPONSE  &response) const;
	/**
	 * Get link table command.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param query QUERY_LINK_TABLE structure
	 * @param destinationID The device ID of the end device
	 */
	eoReturn GetLinkTable(QUERY_LINK_TABLE const &query, uint32_t const destinationID);
	/**
	 * With this command the actor parse the remote commission message into a LINK_TABLE structure.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param[out] response Link Table response will be added to this pointer
	 * @param[out] tableDir The table direction of the returned entries
	 */
	eoReturn ParseGetLinkTableResponse(std::vector<LINK_TABLE> &response, RECOM_TABLE_DIR &tableDir) const;
	/**
	 * Set link table content command.
	 * Unicast: yes
	 * Broadcast: yes
	 * Command has paired response: yes
	 * @param query LINK_TABLE structures in a vector.
	 * @param tableDir The table direction of the entries
	 * @param destinationID The device ID of the end device
	 */
	eoReturn SetLinkTable(std::vector<LINK_TABLE> const &query, RECOM_TABLE_DIR tableDir, uint32_t destinationID);
	/**
	 * Get GP Link table command.
	 * Unicast: yes
	 * Broadcast: no
	 * Device response to command: yes
	 * @param query GP_LINK_TABLE
	 * @param  destinationID ID of the recom device to modify
	 */
	eoReturn GetGPLinkTable(GP_LINK_TABLE const &query, uint32_t destinationID);
	/**
	* Parses the GP Link table response
	* @param query  response parsed
	* @note the data array inside of the query, will be deleted and a new block of memory will be allocated!
	* @return
	*/
	eoReturn ParseGetGPLinkTableResponse(GP_LINK_TABLE &query) const;
	/**
	 * Set link table content command.
	 * Unicast: yes
	 * Broadcast: yes
	 * Command has paired response: no
	* @param query
	* @param destinationID
	* @return
	*/
	eoReturn SetGPLinkTable(GP_LINK_TABLE const &query, uint32_t destinationID);

	/**
	 * Remote set learn mode.
	 * Unicast: yes
	 * Broadcast: yes
	 * Command has paired response: no
	 * @param learnMode Device learn mode
	 * @param destinationID The device ID of the end device
	 */
	eoReturn RemoteSetLearnMode(QUERY_SET_LEARN_MODE const &learnMode, uint32_t destinationID);
	/**
	 * Trigger outbound remote teach request.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param channel Channel selection
	 * @param destinationID The device ID of the end device
	 */
	eoReturn TriggerOutboundTeachRequest(uint8_t channel, uint32_t destinationID);
	/**
	 * Get device configuration query.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param deviceConf device configuration query arguments
	 * @param destinationID The device ID of the end device
	 */
	eoReturn GetDeviceConfig(QUERY_DEVICE_CONFIG const &deviceConf, uint32_t destinationID);
	/**
	 * Parses the device config response
	 * @param deviceConf vector to store the response, new elements will be pushed to the back of the vector
	 * @return
	 */
	eoReturn ParseDeviceConfigResponse(std::vector<DEVICE_CONFIG> &deviceConf) const;
	/**
	 * Set device configuration.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: no
	 * @param deviceConf list of config parameters
	 * @param destinationID device ID
	 * @return
	 */
	eoReturn SetDeviceConfig(std::vector<DEVICE_CONFIG> const &deviceConf, uint32_t destinationID);
	/**
	 * Get link based configuration query.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param linkConfig QUERY_LINK_BASED_CONFIG structure
	 * @param destinationID The device ID of the end device
	 */
	eoReturn GetLinkBasedConfig(QUERY_LINK_BASED_CONFIG const &linkConfig, uint32_t destinationID);
	/**
	 * Set Link based configuration query
	 * Unicast: yes
	 * Broadcast: no
	 *
	 * @param linkConfig vector containing the parameters
	 * @note Warning the direction and table index will be taken from the first entry,
	 * entries which have a different direction or table index will be skipped!
	 * @param destinationID
	 * @return
	 */
	eoReturn SetLinkBasedConfig(std::vector<LINK_BASED_CONFIG> const &linkConfig, uint32_t destinationID);
	/**
	 * Parses the device config response
	* @param linkConfig vector to store the response, new elements will be pushed to the back of the vector
	* @return
	*/
	eoReturn ParseLinkBasedConfigResponse(std::vector<LINK_BASED_CONFIG> &linkConfig) const;
	/**
	 * Apply changes command.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: no
	 * @param changes QUERY_APPLY_CHANGES structure
	 * @param destinationID The device ID of the end device
	 */
	eoReturn ApplyChanges(QUERY_APPLY_CHANGES const &changes, uint32_t destinationID);
	/**
	 * Reset to defaults.
	 * Unicast: yes
	 * Broadcast: yes
	 * Command has paired response: no
	 * @param defaults QUERY_RESET_DEFAULTS structure
	 * @param destinationID The device ID of the end device
	 */
	eoReturn ResetDefaults(QUERY_RESET_DEFAULTS const &defaults, uint32_t destinationID);
	/**
	 * Radio link test control.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param radioLink QUERY_RADIO_LINK_TEST structure
	 * @param destinationID The device ID of the end device
	 */
	eoReturn RadioLinkTest(QUERY_RADIO_LINK_TEST const &radioLink, uint32_t destinationID);
	/**
	 * Get prodcut ID.
	 * Unicast: yes
	 * Broadcast: yes
	 * Command has paired response: yes
	 * @param destinationID The device ID of the end device
	 */
	eoReturn GetProductID(uint32_t destinationID = BROADCAST_ID);
	/**
	 * With this command the actor parse the remote commission message into a QUERY_PRODUCT_ID_RESPONSE structure.
	 * Unicast: yes
	 * Broadcast: yes
	 * Command has paired response: yes
	 * @note After sending a productID Request, each ReCom device sends ProductID Response in beaconing mode, until an
	 * addressed reman answer has been sent.
	 *
	 * @param[out] response QUERY_PRODUCT_ID_RESPONSE structure
	 */
	eoReturn ParseGetProductIDResponse(QUERY_PRODUCT_ID_RESPONSE &response) const;
	/**
	 * Get repeater functions query.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @note To stop the beaconing of the Get Product ID Response, an addressed reman message needs to be send.
	 *
	 * @param destinationID The device ID of the end device
	 */
	eoReturn GetRepeater(uint32_t destinationID);
	/**
	 * With this command the actor parse the remote commission message into a REPEATER_FUNCTIONS structure.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: yes
	 * @param[out] response REPEATER_FUNCTIONS structure
	 */
	eoReturn ParseGetRepeaterResponse(REPEATER_FUNCTIONS &response) const;
	/**
	 * Set repeater function.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: no
	 * @param repeaterFunc paramters to set
	 * @param destinationID The device ID of the end device
	 */
	eoReturn SetRepeater(REPEATER_FUNCTIONS const &repeaterFunc, uint32_t destinationID);
	/**
	 * Set repeater function.
	 * Unicast: yes
	 * Broadcast: no
	 * Command has paired response: no
	 * @param repeaterFunc filter to set
	 * @param destinationID The device ID of the end device
	 */
	eoReturn SetRepeaterFilter(QUERY_SET_REPEATER_FILTER const &repeaterFunc, uint32_t destinationID);

};
/**
 *@}
 */
#endif // !defined(EA_4BFBF49B_3520_48f7_BACB_B62331BA4509__INCLUDED_)
