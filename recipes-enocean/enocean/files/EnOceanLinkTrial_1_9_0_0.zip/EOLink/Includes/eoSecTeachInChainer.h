/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoSecTeachInChainer.h
 * \brief
 * \author EnOcean GmBH
 */

#ifndef EOSECTEACHINCHAINER_H_
#define EOSECTEACHINCHAINER_H_

#include "eoChainedMessage.h"
class eoGateway;

#include <map>
//!Message container for merging.
typedef std::map<uint32_t, eoChainedMessage*> id_msg_map;

/**
 * \class eoSecTeachInChainer
 * Chaining of Security Teach in telegrams.
 */    
class eoSecTeachInChainer
{
protected:
  //!List of messages to be merged.
	id_msg_map list;
public:
	eoSecTeachInChainer();
	virtual ~eoSecTeachInChainer();

	/**
	 * Cleans up the list of eoChainedMessage Objects by dropping the ones that are timed out
	 * @return
	 */
	void CleanUpList();

	/**
	 * Parses a chained SecureTeachIn message from several telegrams to an eoMessage
	 * @param tel incoming telegram
	 * @param msg resulting eoMessage
	 * @return
	 */
	eoReturn ParseChainedMessage(eoTelegram &tel, eoMessage &msg);
	/**
	 * Sends a SecureTeachIn message in multiple telegrams
	 * @param msg The Message to be split into telegrams
	 * @param gateway The eoGateway the telegrams are to be sent with
	 * @return
	 */
	eoReturn SendChainedMessage(const eoMessage &msg, eoGateway &gateway);

};

#endif // !defined(EOSECTEACHINCHAINER_H_)

