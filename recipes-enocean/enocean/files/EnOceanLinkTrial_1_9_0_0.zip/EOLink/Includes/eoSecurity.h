/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoSecurity.h
 * \brief
 * \author EnOcean GmBH
 */
#ifndef EO_SECURITY_H_
#define EO_SECURITY_H_
#include "eoMessage.h"
#include "eoDevice.h"
#include "api/sec.h"
#include "api/sec_api.h"

/**
 * \class eoSecurity
 * \brief handles EnOcean Security Telegrams
 * \details Allows you to receive and sent secured EnOcean Telegrams. After parsing a secured TeachIN telegram with the
 * ParseTeachIn function the security Information get stored in the eoDevice::secIn field. Using the eoDevice::secIn field
 * Secured Telegrams can be decrypted. Outgoing messages can also be encrypted using the stored
 * Information in the eoDevice::secOut field.
 *
 * \example Security_example.cpp
 */
class eoSecurity
{
private:
	MESSAGE_TYPE msg;
	MESSAGE_TYPE msgTmp;
	SECU_TYPE info;

	SEC_RESULT	lastResult;

public:
	eoSecurity();
	virtual ~eoSecurity();
	/**
	 * Parse the TeachIN Message
	 * @param msgTi TeachIn message to parse
	 * @param dev device to store eoSecureInfo to
	 * @return
	 */
	eoReturn ParseTeachIn(eoMessage &msgTi, eoDevice &dev);
	/**
	 * Create the TeachIN Message
	 * @param msgTi Secure TeachIn message to create
	 * @param dev device to store eoSecureInfo to
	 * @return
	 */
	eoReturn CreateTeachIn (eoMessage &msgTi, eoDevice &dev);
	/**
	 * Decrypt data
	 * @param msgSec Message containing Secured data
	 * @param msgNonSec Message containing decrypted data after a success
	 * @param dev eoDevice containing eoSecureInfo
	 * @return
	 */
	eoReturn Decrypt(eoMessage &msgSec, eoMessage &msgNonSec, eoDevice &dev);
	/**
	 * Encrypt data
	 * @param msgSec Message containing encrypted data after a success
	 * @param msgNonSec Message not decrypted Message to encrypt.
	 * @param dev eoDevice containing eoSecureInfo
	 * @return
	 */
	eoReturn Encrypt(eoMessage &msgNonSec, eoMessage &msgSec, eoDevice &dev);
	/**
	 * Get last error code
	 * @return the last error code
	 */
	SEC_RESULT GetLastError();

private:
	//! Helper functions
	static eoReturn MessageToType(eoMessage const &msg, MESSAGE_TYPE &mt);
	static eoReturn TypeToMessage(MESSAGE_TYPE const &mt, eoMessage  &msg);
	static eoReturn TypeToSecuInfo(SECU_TYPE const &it, eoSecureInfo &info);
	static eoReturn SecuInfoToType(eoSecureInfo const &info, SECU_TYPE  &it) ;

};
#endif // !defined(EA_C4479453_0471_4430_829A_098DBBFB613D__INCLUDED_)
