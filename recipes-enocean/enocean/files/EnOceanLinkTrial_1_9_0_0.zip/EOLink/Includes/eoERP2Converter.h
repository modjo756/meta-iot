/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoERP2Converter.h
 * \brief eoERP2Convert Helper Class
 * \author EnOcean GmBH
 */
#if !defined(_EOCONVERTERERP2_H_)
#define _EOCONVERTERERP2_H_

#include "eoHalTypes.h"
#include "eoMessage.h"
#include "eoReManMessage.h"
#include "eoTelegram.h"
#include "eoTelegramERP2.h"
#include "eoPacket.h"
#include "eoApiDef.h"


/**
 * \class eoERP2Converter
 * \brief Helper class for convert a ERP2_PACKET to eoTelegramERP2 and the other way around
 */
class eoERP2Converter
{
private:
	uint8_t * data;
	const eoPacket * packet;
	eoTelegramERP2 * telegram;
	uint8_t optLength;

	void parseOptionalData();
	void parseReclaim();
	eoReturn parseHeader();
	eoReturn addDataAndOptData();
	void clearPointers();
	eoReturn parseSourceID();
	eoReturn parseDestinationID();
	void parseExtendedHeader();
	void parseExtendedTelegramType();
	void parseAddressControl();
public:
	/**
	 * Constructor of the ERP2Converter
	 */
	eoERP2Converter();
	static const uint8_t AdvancedRORG [16];
	/**
	 * This helper class converts the ERP2 radio packet to an eoTelegramERP2
	 * @param packet, a ERP2 radio packet
	 * @param tel, the output eoTelegramERP2
	 * @return EO_OK,OUT_OF_RANGE
	 */
	eoReturn convertFromPacketToERP2(const eoPacket &packet,eoTelegramERP2 &tel);

};

#endif /* _EOCONVERTER_H_ */
