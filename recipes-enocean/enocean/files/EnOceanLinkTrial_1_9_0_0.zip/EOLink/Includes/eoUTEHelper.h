/******************************************************************************
DISCLAIMER

THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
CRIMINAL SANCTION.

THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
******************************************************************************/

/**
* \file eoUTEHelper.h
* \brief
* \author EnOcean GmBH
*/
#ifndef EO_UTE_HELPER_H_
#define EO_UTE_HELPER_H_
#include "eoHalTypes.h"
#include "eoMessage.h"

//!UTE Response codes.
typedef enum
{
	//! <b>0</b> - Request not accepted because of general reason
	GENERAL_REASON = 0,         //!< GENERAL_REASON
								//! <b>1</b> - Request accepted, teach-in successful
	TEACH_IN_ACCEPTED = 1,         //!< TEACH_IN_ACCEPTED
								   //! <b>2</b> - Request accepted, deletion of teach-in successful
	TEACH_OUT_ACCEPTED = 2,         //!< TEACH_OUT_ACCEPTED
									//! <b>3</b> - Request not accepted, EEP not supported
	EEP_NOT_SUPPORTED = 3         //!< EEP_NOT_SUPPORTED
} UTE_RESPONSE;

//!UTE Request codes.
typedef enum
{
	//! <b>0</b> - Teach-in request
	TEACH_IN_REQUEST = 0,         //!< TEACH_IN_REQUEST
								  //! <b>1</b> - Deletion of teached in device reqeusted
	TEACH_OUT_REQUEST = 1,         //!< TEACH_OUT_REQUEST
								   //! <b>2</b>  - Teach-in or deletion of teach-in, not specified
	TEACH_UNKNOW_REQUEST = 2,         //!< TEACH_UNKNOW_REQUEST
	UTE_NOT_USED_TEACH = 3         //!< UTE_NOT_USED_TEACH
} UTE_REQUEST;

//!UTE Command
typedef enum
{
	//! <b>0</b> - EEP Teach In Query
	EEP_TEACH_IN_QUERY = 0,         //!< EEP_TEACH_IN_QUERY
									//! <b>1</b> - EEP teach in response
	EEP_TEACH_IN_RESPONSE = 1         //!< EEP_TEACH_IN_RESPONSE
} UTE_COMMAND;

//!UTE Direction response codes.
typedef enum
{
	//! <b>0</b> - Unidirectional
	UTE_DIRECTION_UNIDIRECTIONAL = 0,         //!< UTE_DIRECTION_UNIDIRECTIONAL
											  //! <b>1</b> - Bidirectional
	UTE_DIRECTION_BIDIRECTIONAL = 1         //!< UTE_DIRECTION_BIDIRECTIONAL
} UTE_DIRECTION;

//!Helper Structure for eep teach in Queries
typedef struct
{
	uint8_t rorg; //!< Rorg of the profile to  be teached in
	uint8_t func;//!< Func of the profile to  be teached in
	uint8_t type;//!< Type of the profile to  be teached in
	uint8_t numberOfChannel;//!< Number of individual channel to be taught in
	uint16_t manufacturerID;//!< Manufacturer ID
	UTE_DIRECTION direction;//!< Communication capabilities
	UTE_REQUEST request;//!< Request
}UTE_EEP_TEACH_IN_QUERY;

//!Helper Structure for eep teach in Response
typedef struct
{
	uint8_t rorg; //!< Rorg of the profile to  be teached in
	uint8_t func;//!< Func of the profile to  be teached in
	uint8_t type;//!< Type of the profile to  be teached in
	uint8_t numberOfChannel;//!< Number of individual channel to be taught in
	uint16_t manufacturerID;//!< Manufacturer ID
	UTE_DIRECTION direction;//!< Communication capabilities
	UTE_RESPONSE response;//!< Request
}UTE_EEP_TEACH_IN_RESPONSE;

class eoUTEHelper
{
public:
/**
* Parse the message into UTE
* @param msg
* @param uteQuery 
* @return EO_OK
*/
static eoReturn ParseUTE(eoMessage &msg, UTE_EEP_TEACH_IN_QUERY &uteQuery);
/**
* Creates UTE teach in response from UTE teach in request
* @param uteResponse Response to base on
* @param [out] responseMessage
* @param type ::UTE_RESPONSE
* @param direction ::UTE_DIRECTION
* @return EO_OK
*/
static eoReturn CreateUTEResponse(UTE_EEP_TEACH_IN_RESPONSE &uteResponse, eoMessage &responseMessage);
/**
* Creates UTE teach in response from UTE teach in request
* @param uteQuery to use as base
* @param [out] responseMessage
* @param type ::UTE_RESPONSE
* @param direction ::UTE_DIRECTION
* @return EO_OK
*/
static eoReturn CreateUTEResponseFromQuery(UTE_EEP_TEACH_IN_QUERY &uteQuery, eoMessage &responseMessage, UTE_RESPONSE type, UTE_DIRECTION direction);
};
#endif
