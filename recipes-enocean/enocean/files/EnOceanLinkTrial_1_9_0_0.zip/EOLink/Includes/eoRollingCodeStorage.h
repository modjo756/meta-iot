/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoRollingCodeStorage.h
 * \brief
 * \author EnOcean GmBH
 */

#ifndef EOROLLINGCODESTORAGE_H_
#define EOROLLINGCODESTORAGE_H_

#include "eoHalTypes.h"
#include "eoApiDef.h"

#include <map>

using namespace std;

/**
 * \class eoRollingCodeStorage
 * \brief Manages the rolling codes
 * \details The RollingCodeStorage helps you to manage rolling codes. Using it functions you can get the rolling code to the IDs.
 */
class eoRollingCodeStorage
{
private:
	/**
	 * A std::map using the ID as key and the rolling code as value.
	 */
	map<uint32_t, uint32_t> list;
public:
	/**
	 * Constructor
	 */
	eoRollingCodeStorage();
	virtual ~eoRollingCodeStorage();

public:
	/**
	 * A new ID is added with the rolling code,
	 * if the ID already exists, it overwrites the previous rolling code.
	 * @param id The device ID
	 * @param rlc Value of the rolling code
	 */
	void SetRLC(uint32_t id, uint32_t rlc);
	/**
	 *Searches for the ID between the IDs and returns the value of rolling code.
	 * @param id The device ID
	 * @param rlc Value of the rolling code
	 */
	eoReturn GetRLC(uint32_t id, uint32_t &rlc);
	/**
	 *Searches for the ID between the IDs and delete the ID and the corresponding rolling code.
	 * @param id The device ID	 
	 */
	eoReturn RemoveID(uint32_t id);

public:
	/**
	 *Saves the map data into file
	 *Note: you have to add the extension (e.g. test.txt)
	 * @param file Name of the file
	 * @return EO_OK or error code if could not create the file
	 */
	eoReturn Save(const char* file);
	/**
	 *Loads the files data into map data. It deletes every values in the map before loading values into the file.
	 *Note: you have to add the extension (e.g. test.txt)
	 * @param file Name of the file
	 * @return EO_OK or error code if could not read the file
	 */
	eoReturn Load(const char* file);
};

#endif /* EOROLLINGCODESTORAGE_H_ */
