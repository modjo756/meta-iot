/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoChainedMessage.h
 * \brief
 * \author EnOcean GmBH
 */

#include "eoMessage.h"
#include "eoChunkMessage.h"
#include <vector>
#ifndef EOCHAINEDMESSAGE_H_
#define EOCHAINEDMESSAGE_H_
/** 
 * \class eoChainedMessage
 * chainedMessage Helper Class, will be copied to normal eoMessage, when we finished receiving
 */  
class eoChainedMessage: public eoMessage
{
public:
	//! Message has been processed
	bool received;
	//! Telegram Count for Messages
	uint8_t telCount;
	//! Expected Telegram Count for  Messages
	uint8_t expectedTelCount;
	//!Sequence of the chained message. Sequence is type of message indentifier.
	uint8_t seq;
  //! Expected data length of the chained message. Information should be contained in the header.
	uint16_t expectedDataLength;
	//! Actual Payload Datasize
	uint16_t sizeN;


	//! Timestamp of the first telegram. Used for Time-out functionality
	uint32_t timeStamp;	
  
	//! All Messages parts are located in the dataChunks array.
	std::vector<eoChunkMessage> dataChunks;

public:
  /**
   * Constructor.
   * @param maxSize defining the maximum size in bytes.
   */         
	eoChainedMessage(uint16_t maxSize);

	/**
	 * The Chunk messages will be processessed and saved into the ChainedMessagedatabuffer
	 * @return
	 */
	eoReturn ProcessChunks();

	virtual ~eoChainedMessage();

};

#endif /* EOCHAINEDMESSAGE_H_ */
