/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoSecureInfo.h
 * \brief
 * \author EnOcean GmBH
 */
#ifndef EO_SEC_INFO_H_
#define EO_SEC_INFO_H_

#include "api/sec_api.h"
#include "eoHalTypes.h"
#include "eoISerialize.h"
#include "eoArchive.h"

/**
 *@defgroup <slf SLF Fields
 * @{
 *@ingroup security
*/
//!No Data Encryption
#define SLF_DATA_ENC_OFF 0
//!Encryption via AES-AES128
#define SLF_DATA_ENC_AES128 0x04
//!Encryption via VAES-AES128
#define SLF_DATA_ENC_VAES128 0x03
//! CMAC is off
#define SLF_MAC_OFF (0<<3)
//! 3Byte CMAC
#define SLF_MAC_3BYTE (1<<3)
//! 4Byte CMAC
#define SLF_MAC_4BYTE (2<<3)
//! don't send RLC
#define SLF_RLC_TX_OFF (0<<5)
//! transmit RLC via TX
#define SLF_RLC_TX_ON (1<<5)
//! RLC OFF
#define SLF_RLC_ALGO_OFF (0<<6)
//! 2byte RLC
#define SLF_RLC_ALGO_16BIT (1<<6)
//! 3byte RLC
#define SLF_RLC_ALGO_24BIT (2<<6)
/**
 *@}
 */

/**
 *@defgroup <secTeach Teach Info Fields
 * @{
 *@ingroup security
*/
//! TeachInfo - Use PSK
#define TEACH_INFO_PSK (1<<3)
//! TeachInfo - PTM Type
#define TEACH_INFO_PTM (1<<2)

//! TeachInfo - ROCKER A normal Teach In for PTM Type
#define TEACH_INFO_PTM_ROCKERA (0<<0)
//! TeachInfo - ROCKER B normal Teach In for PTM Type
#define TEACH_INFO_PTM_ROCKERB (1<<0)

//! TeachInfo - Unidirectional security teach-in procedure
#define TEACH_INFO_UNIDIR (0<<0)
//! TeachInfo - ROCKER B normal Teach In
#define TEACH_INFO_BIDIR (1<<0)
/**
 *@}
 */
/**
 * \class eoSecureInfo
 * Helper Class for the eoDeviceManager, contains&stores security Information.
 */
class eoSecureInfo: public eoISerialize
{

public:
	eoSecureInfo();
	virtual ~eoSecureInfo();
	uint8_t Serialize(eoArchive &arch);
public:
	//!Passphrase Key
	uint8_t key[16];		
	//!keyLength
	uint8_t keySize;
	//!Secure Level Format
	uint8_t SLF;
	//!Teach-In Info
	uint8_t teachInInfo; 
	//!CMAC Sub-Key1
	uint8_t subKey1[16];	
	//!CMAC Sub-Key2
	uint8_t subKey2[16]; 
	//! Preshared key
	uint8_t psk[16];
	//!Rolling-code
	uint32_t rollingCode;
	//! Last Secure Error
	SEC_RESULT securityResult;
	//!The Previous Rolling code, allows to compare the old rolling code and new one
	uint32_t previousRollingCode;
};
#endif // !defined(EO_SEC_INFO_H_)
