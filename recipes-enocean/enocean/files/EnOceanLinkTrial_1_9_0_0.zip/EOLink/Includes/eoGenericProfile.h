/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//! \file eoGenericProfile.h

#if !defined(EO_GENERIC_PROFILE_H)
#define EO_GENERIC_PROFILE_H
#include "eoGPChannelInfo.h"
#include "eoProfile.h"
#include <vector>
//! Length of manufacturer ID in GP LRN.
#define GP_MANUFACTURER_LEN 11
//! Length of purpose in GP LRN.
#define GP_PURPOSE_LEN 2
//! Length data direction flag ID in GP LRN.
#define GP_DATA_DIRECTION_LEN 1

//! Specific offset for disabled channels.
#define GP_MANUFACTURER_OFF 0
//! Specific offset for disabled channels.
#define GP_PURPOSE_OFF 12
//! Specific offset for disabled channels.
#define GP_DATA_DIRECTION_OFF 11
/**
 * \typedef GP_HEADER_PURPOSE
 * \brief Purpose of the Teach IN Message
 */
typedef enum
{
	GP_TEACH_IN = 0, GP_TEACH_OUT, GP_TEACH_IN_OUT, RESP_NA
} GP_HEADER_PURPOSE;
/**
 * \typedef GP_DATA_DIRECTION
 * \brief Generic Profile Data Direction Information, informs if the Profile is unidirectional or bidirectional
 */
typedef enum
{
	UNIDIRECTIONAL = 0, BIDIRECTIONAL
} GP_DATA_DIRECTION;
/**\class eoGenericProfile
 * \brief The class to handle Generic Profiles
 * \details The eoGenericProfile class allows the user to handle and teachIN genericProfils. Must Functions
 * are the same as in the eoProfile class. For the user application the difference between a generic and
 * an Enocean equipment profile is in most cases transparent.
 *
 * The eoGenericProfile class adds some functions, to allow the user easy to create
 * an own generic Profile and to manually parse external Teach IN Message.
 */
class eoGenericProfile: public eoProfile
{
public:
	eoGenericProfile();
	/**
	 *Constructor
	 *@param msgLength Length of the generic profile message.
	 */      	
	eoGenericProfile(uint16_t msgLength);

	//! Teach-In Purpose
	GP_HEADER_PURPOSE purpose;
	//! Data direction
	GP_DATA_DIRECTION dataDirection;

	virtual ~eoGenericProfile();
	/**
	 * This function will activate the parsing for one Teach IN Telegram!
	 * After a parsing of a teachIN message the teachIN function will be deactivated again.
	 */
	void AllowTeachIN();
	/** Overloading equal operator.
	 *@param othProfile Profile to be compared with.
	 */	 
	bool operator==(const eoGenericProfile &othProfile) const;
	/** Overloading not equal operator.
	 *@param othProfile Profile to be compared with.
	 */
	bool operator!=(const eoGenericProfile &othProfile) const;
	/**
	 * @brief creates Teach In Messsage
	 *
	 * This function will create a teach in message as defined in the GenericProfile spec.
	 * The outbound channels will be used as outbound channel.
	 * If inbound channels are set, the dataDirection will be set to bidirectional and the
	 * inbound channels will be added inside the "teach-in information"
	 * @param msg
	 * @return
	 */
	eoReturn CreateTeachIN(eoMessage &msg);
	/**
	 * @brief creates Selective Data Message
	 *
	 * This function will create a Selective Data message as defined in the GenericProfile spec.
	 * @param msg
	 * @param channelNumbers
	 * @return
	 */
	eoReturn Create(eoMessage &m,std::vector<int> channelNumbers);
	/**
	 * Helper function to GP Selected DataChannel
	 * @param msg GP to parse
	 * @return
	 */
	eoReturn ParseSelData(const eoMessage &msg);
	/**
	 * Helper Function to parse TI Message, only works after calling AllowTeachIN()!
	 * @param msg
	 * @return eoReturn EO_OK, NOT_SUPPORTED
	 */
	eoReturn ParseTeachIN(const eoMessage &msg);
	/**
	 * Parses the Messages and will react if it is a Generic Profile Message.
	 * When you receive selective of a Full data Message, the internal data will be changed accordingly.
	 *
	 * If AllowTeachIN() is activated, a TeachIN Message will be parsed accordingly to the GP SPEC(meaning teachIN or teachOUT are allowed)
	 * , and a response will be prepared for you. You can access it via Create(eoMessage &m).
	 * @note Then you parse another Message after the TeachIN Message, the Teach IN response will be overwritten!
	 * @param msg
	 * @return
	 */
	eoReturn Parse(const eoMessage &msg);

	eoReturn GetValue(CHANNEL_TYPE type, float &value);

	eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t subFlag);

	eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);

	eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t subFlag);

	eoReturn SetValue(CHANNEL_TYPE type, float value);

	eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);

	eoReturn SetType(uint8_t type);
	//eoReturn AddChannel(eoGPChannelInfo myChannel);
	/**
	 * Adds an inbound Generic Profile Channel to this Generic Profile with the specified Values.
	 * @param type
	 * @param resolution
	 * @param engMaximum
	 * @param engMinimum
	 * @param scaleMaximum
	 * @param scaleMinimum
	 * @param valueType
	 * @return
	 */
	eoReturn AddChannel(CHANNEL_TYPE type, GP_RESOLUTION resolution, int8_t engMaximum, int8_t engMinimum, GP_SCALING scaleMaximum, GP_SCALING scaleMinimum, VALUE_TYPE valueType);
	/**
	 * Adds an outband Generic Profile Channel to this Generic Profile with the specified Values.
	 * @param type
	 * @param resolution
	 * @param engMaximum
	 * @param engMinimum
	 * @param scaleMaximum
	 * @param scaleMinimum
	 * @param valueType
	 * @return
	 */
	eoReturn AddChannelOut(CHANNEL_TYPE type, GP_RESOLUTION resolution, int8_t engMaximum, int8_t engMinimum, GP_SCALING scaleMaximum, GP_SCALING scaleMinimum, VALUE_TYPE valueType);
	/**
	 * Allows you to add an inbound Flag Type Generic Channel
	 * @param type
	 * @param valueType
	 * @return EO_OK or NOT_SUPPORTED
	 */
	eoReturn AddChannel(CHANNEL_TYPE type, VALUE_TYPE valueType);
	/**
	 * Allows you to add an outbound Flag Type Generic Channel
	 * @param type
	 * @param valueType
	 * @return EO_OK or NOT_SUPPORTED
	 */
	eoReturn AddChannelOut(CHANNEL_TYPE type, VALUE_TYPE valueType);
	/**
	 * Allows you to add an inbound ENUM Type Generic Channel
	 * @param type Type of the channel - signal,flag etc. 	 
	 * @param resolution of the ENum
	 * @param valueType
	 * @return EO_OK or NOT_SUPPORTED
	 */
	eoReturn AddChannel(CHANNEL_TYPE type, GP_RESOLUTION resolution, VALUE_TYPE valueType);
	/**
	 * Allows you to add an outband ENUM Type Generic Channel
	 * @param type Type of the channel - signal,flag etc.
	 * @param resolution of the ENum
	 * @param valueType
	 * @return EO_OK or NOT_SUPPORTED
	 */
	eoReturn AddChannelOut(CHANNEL_TYPE type, GP_RESOLUTION resolution, VALUE_TYPE valueType);
		/**
	 * Returns the inbound channel for the selected type
	 * @param type ::CHANNEL_TYPE
	 * @return Pointer to ChannelInfo or Null
	 */
	eoChannelInfo* GetChannel(CHANNEL_TYPE type);
	/**
	 * Returns the inbound channel for the selected channelnumber
	 * @param channelNumber channelnumber
	 * @return Pointer to ChannelInfo or Null
	 */
	eoChannelInfo* GetChannel(uint8_t channelNumber);
	/**
	 * Returns the outbound channel for the selected type
	 * @param type ::CHANNEL_TYPE
	 * @return Pointer to ChannelInfo or Null
	 */
	eoChannelInfo* GetChannelOut(CHANNEL_TYPE type);
	/**
	 * Returns the pointer to eoChannelInfo for the selected outbound channelNumber or NULL
	 * @param channelNumber
	 * @return Pointer to Channel
	 */
	eoChannelInfo* GetChannelOut(uint8_t channelNumber);
	/**
	 * This function allows you to access different inbound Channels with he same Channel_type. It will return the corresponding Channel or NULL.
	 *
	 * For example if you've a GP with 8 S_TEMP and you call GetChannel(S_TEMP,0) it will return the first corresponding Temperature channel.
	 * 3 will return the 4 channel and 8 will return NULL;
	 *
	 * @param type CHANNEL_TYPE
	 * @param subType subType specifies which Channel with the same type you want to Select
	 * @return
	 */
	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t subType);
	/**
	 * This function allows you to access different outband Channels with he same Channel_type. It will return the corresponding Channel or NULL.
	 *
	 * @param type CHANNEL_TYPE
	 * @param subType subType specifies which Channel with the same type you want to Select
	 * @return
	 */
	eoChannelInfo* GetChannelOut(CHANNEL_TYPE type, uint8_t subType);
	/**
	 * Returns Number of inbound channels for this profile
	 * @return number of channels
	 */
	uint8_t GetChannelCount() const;
	/**
	 * Returns Number of outbound channels for this profile
	 * @return number of channels
	 */
	uint8_t GetChannelCountOut() const;
	/**
	 * Delete all channels and resets the genericProfile
	 */
	void ClearChannels();
	/**
	 * Delete all channels and resets the genericProfile
	 */
	void ClearChannelsOut();
	/*
	 * Clears Channel Information and internal buffer
	 */
	void ClearValues();

	uint8_t Serialize(eoArchive &a);
	/**
	 * Returns the product ID for this profile
	 * @return product Id
	 */
	uint32_t GetProductId();
	/**
	 * Sets the product ID for this profile
	 * @param prodId product Id
	 */
	void SetProductId(const uint32_t prodId);

	virtual eoReturn Create(eoMessage &msg);

private:

	eoReturn CreateChannels(const eoMessage &msg);
	std::vector<eoGPChannelInfo> gpChannels;
	std::vector<eoGPChannelInfo> gpChannelsOut;
	uint16_t curBitOffset;
	uint16_t curBitOffsetOut;

	bool parseTeachIn;
	uint32_t productId;
};
#endif // !defined(EA_4EAE7E47_D018_4877_903B_B66D2DDE6E02__INCLUDED_)
