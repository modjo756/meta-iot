/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoGPChannelInfo.h
 * \brief Enocean GP channel Informations
 * \details Describes the available Channeltypes,resolutions and scalings in generic profiles.
 * \author EnOcean GmBH
 */

#ifndef EOGPCHANNELINFO_H_
#define EOGPCHANNELINFO_H_
#include "eoChannelInfo.h"
#include "eoApiDef.h"
#include "eoISerialize.h"
/**
 * \typedef GP_CHANNELTYPE
 * \brief Generic Profile ChannelTypes
 */
typedef enum
{
	//!00 Teach-in Information
	GP_TEACHIN_INFO = 0, //!< GP_TEACHIN_INFO
	//!01 Complex bit values
	GP_DATA,      //!< GP_DATA
	//! Single bit Values
	GP_FLAG,      //!< GP_FLAG
	//! Enumerated values
	GP_ENUMERATION	//!< GP_ENUMERATION
} GP_CHANNELTYPE;
/**
 * \typedef GP_RESOLUTION
 *  \brief Generic Profile Channel Resolution
 */
typedef enum
{
	GP_RES_RES = 0,
	GP_RES_1BIT = 1,
	GP_RES_2BIT = 2,
	GP_RES_3BIT = 3,
	GP_RES_4BIT = 4,
	GP_RES_5BIT = 5,
	GP_RES_6BIT = 6,
	GP_RES_8BIT = 8,
	GP_RES_10BIT = 10,
	GP_RES_12BIT = 12,
	GP_RES_16BIT = 16,
	GP_RES_20BIT = 20,
	GP_RES_24BIT = 24,
	GP_RES_32BIT = 32
} GP_RESOLUTION;
/**
 * \typedef GP_SCALING
 * \brief Generic Profile Channel Scaling
 */
typedef enum
{
	GP_SCAL_RES = 0,
	GP_SCAL_1,
	GP_SCAL_10,
	GP_SCAL_100,
	GP_SCAL_1000,
	GP_SCAL_10000,
	GP_SCAL_100000,
	GP_SCAL_1000000,
	GP_SCAL_10000000,
	GP_SCAL_0_1,
	GP_SCAL_0_01,
	GP_SCAL_0_001,
	GP_SCAL_0_000001,
	GP_SCAL_0_000000001
} GP_SCALING;

/**
 * \class eoGPChannelInfo
 * \brief Generic Profile Channel
 * \details Implements the Generic Profile Channel as described in the GP specification, with the following differences:

 CHANNEL_TYPE type contains all Signal,ENUM types. If you want to check the Generic Profile Channel Type use getGPChannelType();

 After setting the resolution or the scaling or the engineering  values, the real max and min value will be recalculated.

 */
class eoGPChannelInfo: public eoChannelInfo, public eoISerialize
{

	//! Channel type
	//uint16_t	u2ChannelType;
	//! Signal type
	//uint16_t	u8SignalType:8;	== signal type
	//! Value type
	//uint16_t	u2ValueType:2; // = valueFormat
private:
	void CalculateMin();
	void CalculateMax();
	//! Resolution
	GP_RESOLUTION res; //:4;

	//! Scaling minimum
	GP_SCALING scaleMin; //:4;
	//! Scaling maximum
	GP_SCALING scaleMax; //:4;

	int8_t engMax;
	int8_t engMin;
	uint8_t	rejected;
public:
	//!Offset of the channel value in data legram in bits.
	uint16_t bitoffs;

	/**
	 * bitoffs is Calculated automatically and should not be changed!!
	 */
	eoGPChannelInfo();
	/**
	 * Creates an new Generic profil channel info with specific variables.
	 * @param type Type of the channel - signal, flag etc.
	 * @param resolution Resolution of the new channel.
	 * @param engMaximum Engineering maximum of the expected value.
	 * @param engMinimum Engineering minimum of the expected value.
	 * @param scaleMaximum Scaling factor for engineering maximum of the expected value.
	 * @param scaleMinimum Scaling factor for engineering minimum of the expected value.
	 */
	eoGPChannelInfo(CHANNEL_TYPE type, GP_RESOLUTION resolution, int8_t engMaximum, int8_t engMinimum, GP_SCALING scaleMaximum, GP_SCALING scaleMinimum);

  //! Get the channel type - signal, flag etc.
	GP_CHANNELTYPE GetGPChannelType() const;

  //!Get the resolution of the channel type.
	GP_RESOLUTION GetResolution() const;
	//eoReturn SetResolution(GP_RESOLUTION resolution);

  //!Get the enginnering maximum - without scale.
	int8_t GetEngMax() const;
	/**
	 * Scale the value according a engineering maximum.
	 * @param engMaximum
	 */      	
	eoReturn Scale(int8_t engMaximum);

  //!Get the the enginnering minimum - without scale.
	int8_t GetEngMin() const;
	//eoReturn SetEngMin(int8_t engMinimum);
  
  //!Get the GP_SCALING of engineering maximum.
	GP_SCALING GetScaleMax() const;
	//eoReturn SetScaleMax(GP_SCALING scaleMaximum);
  
  //!Get the GP_SCALING of engineering minimum.
	GP_SCALING GetScaleMin() const;
	
	//!Set the rejected flag of the channel
	void SetRejected(uint8_t rejected);

	//!Get the rejected flag of the channel
	uint8_t GetRejected();

  /**
   *Convert the GP_SCALING to a float multiplier.
   *@param scale the intended scale.
   */
	static float ScaleToFloat(GP_SCALING scale);
	/**
	 *Serialize to an acrchive.
	 *@param a Intended ::eoArchive.
	 */      	
  uint8_t Serialize(eoArchive &a);
};

#endif /* EOGPCHANNELINFO_H_ */
