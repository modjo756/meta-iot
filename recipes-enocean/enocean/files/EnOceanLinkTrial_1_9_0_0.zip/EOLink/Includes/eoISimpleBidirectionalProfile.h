/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoISimpleBidirectionalProfile.h
 * \brief
 * \author EnOcean GmBH
 */
#ifndef __EOISIMPLEBIDIRECTIONALPROFILE_INCLUDED_
#define __EOISIMPLEBIDIRECTIONALPROFILE_INCLUDED_
typedef enum
{
	eoController,
	eoActuator
} SIMPLE_DIRECTION;
/**
 * \class eoISimpleBidirectionalProfile
 * \brief An interface for profiles which support bidirectional communication, but do not indicate the direction of the messages.
 *
 * \details This interface is an helper interface for EEProfiles which communicate bidirectional, but do not indicate in the message
 * itself which direction is used (e.g. Command Bytes). Profiles using this interface use the direction bit to indicate in which way messages
 * should be created/ parsed. If the direction is set to eoController, eoLink is the Controller and parses the messages as Actuator messages and
 * send messages as Controller. If the direction is set to eoActuator, eoLink simulates an Actuator device. The default direction is eoController.
 * When Changing the direction, the values are getting invalid.
 */
class  eoISimpleBidirectionalProfile
{
	public:
	eoISimpleBidirectionalProfile() {direction=eoController;};

	virtual ~eoISimpleBidirectionalProfile()  {};
	/**
	 * Set the direction of the profile, if the specific profile does not support Bidirectional mode, nothing happens.
	 * @param direction
	 */
	virtual eoReturn SetDirection(SIMPLE_DIRECTION direction)=0;

	/**
	* Returns the outChannel for the selected type and subtype
	* @param type CHANNEL_TYPE
	* @param subType is either the numeric "subChannelNUmber" (temperature CHannel 0,1,2,3) or a specified keyword for it(see profile)
	* @return Pointer to Channel
	*/
	virtual eoChannelInfo* GetOutChannel(CHANNEL_TYPE type, uint8_t subType) { return GetOutChannel(type); };

	/**
	* Returns the outChannel for the selected type
	* @param type ::CHANNEL_TYPE
	* @return Pointer to ChannelInfo or Null
	*/
	virtual eoChannelInfo* GetOutChannel(CHANNEL_TYPE type) = 0;

	/**
	* returns the pointer to eoChannelInfo for the selected outChannelNumber or NULL
	* @param channelNumber
	* @return Pointer to Channel
	*/
	virtual eoChannelInfo* GetOutChannel(uint8_t channelNumber) = 0;
	protected:
		SIMPLE_DIRECTION direction;

};

#endif
