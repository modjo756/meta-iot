/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoRemoteManager.h
 * \brief eoRemoteManager
 * \author EnOcean GmBH
 */
#ifndef EO_REMOTE_MANAGER_H_
#define EO_REMOTE_MANAGER_H_


/**
 * \typedef REMOTE_TYPE
 * \brief Remote learn types
 */
typedef enum
{
	//! Start learning
	R_START_LEARN = 1,	//Start learn
	//! Next channel
	R_NEXT_CHANNEL,		//Next channel
	//! Stop learning
	R_STOP_LEARN,		//Stop learn
	//! SmartACK start simple learn mode
	R_S_SIMPLE_LEARN,	//SmartACK start simple learn mode
	//! SmartACK start advanced learn mode
	R_S_ADVANCED_LEARN,	//SmartACK start advanced learn mode
	//! SmartACK stop learn mode
	R_S_STOP_LEARN		//SmartACK stop learn
} REMOTE_TYPE;

/**
 * \typedef FN_CODE
 * \brief Function codes
 */
typedef enum
{
	//! Unlock
	FN_UNLOCK	= 0x001, //Unlock
	//! Lock
	FN_LOCK	= 0x002, //Lock
	//! Query ID
	FN_SETCODE	= 0x003, //Set code
	//! Query ID
	FN_QUERYID	= 0x004, //Query ID
	//! Query ID answer
	FN_QUERYID_ANSWER	= 0x604, //Query ID answer
	//! Ext Query Id Answer
	FN_QUERYID_ANSWER_EXT = 0x704,
	//! Action
	FN_ACTION	= 0x005, //Action
	//! Ping
	FN_PING		= 0x006, //Ping
	//! Ping answer
	FN_PING_ANSWER		= 0x606, //Ping answer
	//! Query function
	FN_QUERY_FUNCTION	= 0x007, //Query function
	//! Query function answer
	FN_QUERY_FUNCTION_ANSWER	= 0x607, //Query function answer
	//! Query status
	FN_QUERY_STATUS	= 0x008, //Query status
	//! Query status answer
	FN_QUERY_STATUS_ANSWER	= 0x608, //Query status answer
	//! Remote learn in
	FN_REMOTE_LEARNIN	= 0x201, //Remote learn in
	//! Remote flash write
	FN_REMOTE_FLASH_WRITE	= 0x203, //Remote flash write
	//! Remote flash read
	FN_REMOTE_FLASH_READ	= 0x204, //Remote flash read
	//! Remote flash read answer
	FN_REMOTE_FLASH_READ_ANSWER	= 0x804, //Remote flash read answer
	//! SmartACK read
	FN_SMARTACK_READ	= 0x205, //SmartACK read
	//! SmartACK read mailbox answer
	FN_SMARTACK_READ_MAILBOX_ANSWER	= 0x805, //SmartACK read mailbox answer
	//! SmartACK read learned sensor answer
	FN_SMARTACK_READ_LEARNED_SENSOR_ANSWER	= 0x806, //SmartACK read learned sensor answer
	//! SmartACK write
	FN_SMARTACK_WRITE	= 0x206 //SmartACK write
} FN_CODE;

/**
 * \struct QUERY_ID
 * \brief Query ID structure
 */
typedef struct
{
	//! EEP RORG - 8 bit
	uint8_t rorg;	//EEP RORG 8 bits
	//! EEP Function - 6 bit
	uint8_t func; //EEP Function 6 bits
	//! EEP Type - 7 bit
	uint8_t type;	//EEP Type 7 bits
} QUERY_ID;

/**
 * \struct QUERY_ID_RESPONSE
 * \brief Query ID response structure
 */
typedef struct
{
	//! EEP RORG - 8 bit
	uint8_t rorg;	//EEP RORG 8 bits
	//! EEP Function - 6 bit
	uint8_t func; //EEP Function 6 bits
	//! EEP Type - 7 bit
	uint8_t type;	//EEP Type 7 bits
	//! Locked by other manager - bool
	uint8_t locked;	//Locked by other manager - bool
} QUERY_ID_RESPONSE;

/**
 * \struct QUERY_FUNCTION_RESPONSE
 * \brief Query function response structure
 */
typedef struct
{
	//! Function number
	uint16_t functionNum; //Function number
	//! Manufacturer ID
	uint16_t manufaturerID; //Manufacturer ID
} QUERY_FUNCTION_RESPONSE;

/**
 * \struct PING_RESPONSE
 * \brief Ping response structure
 */
typedef struct
{
	//! EEP RORG
	uint8_t rorg;	//EEP RORG
	//! EEP Function
	uint8_t func; //EEP Function
	//! EEP Type
	uint8_t type;	//EEP Type
	//! RSSI of the pinged device
	int8_t  rssi;	//RSSI of the pinged device
} PING_RESPONSE;

/**
 * \struct QUERY_STATUS_RESPONSE
 * \brief Query status response structure
 */
typedef struct
{
	//! Code set flag
	bool codeSetFlag;	//Code set flag
	//! Last SEQ
	uint8_t lastSEQ;		//Last SEQ
	//! Last function code
	uint16_t lastFunc;	//Last function code
	//! Last function return code
	uint8_t lastFuncRet;	//Last function return code
} QUERY_STATUS_RESPONSE;

/**
 * \struct FLASH_READ_RESPONSE
 * \brief Flash read response structure
 */
typedef struct
{
	//! Read data
	uint8_t data; //Read data
} FLASH_READ_RESPONSE;

/**
 * \struct MAILBOX_SETTINGS_RESPONSE
 * \brief Mailbox settings response structure
 */
typedef struct
{
	//! SmartAck flash address where the settings are stored
	uint16_t flashAddress;//SmartAck flash address where the settings are stored
	//! Number of mailboxes
	uint16_t mailboxCount;	//Number of mailboxes
} MAILBOX_SETTINGS_RESPONSE;

/**
 * \struct LEARNED_SENSOR_RESPONSE
 * \brief Learned sensors response structure
 */
typedef struct
{
	//! Device ID of the sensor
	uint32_t sensorID;	//Device ID of the sensor
	//! Device ID of the controller
	uint32_t controllerID;	//Device ID of the controller
	//! Number of learned in devices
	uint8_t learnedCount;	//Number of learned in devices
} LEARNED_SENSOR_RESPONSE;
/**
 *\class eoRemoteManager
 *\brief Remote Manager interface class. 
 */
class eoRemoteManager
{
private:
	eoGateway *gateway;
	eoReManMessage reManMessage;
	bool shallBeRepeated;
public:
	/**
	 *Constructor.
	 *@param gateway eoGateway to be used for remote management.
	 */
	eoRemoteManager(eoGateway *gateway);
	~eoRemoteManager();
	/**
	* If true the send telegrams are set in such a state that they can be repeated
	*/
	bool GetShallBeRepeated() const      { return shallBeRepeated; };
	/**
	*@param repeat = if true, the send telegrams can be repeated
	*/
	void SetShallBeRepeated(bool repeat) { shallBeRepeated = repeat; };

	/**
	 * This command unlocks the device.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 * @param securityCode Security code
	 */
	eoReturn UnLock(const uint32_t securityCode, const uint32_t destinationID);
	/**
	 * This command locks the device.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 * @param securityCode Security code
	 */
	eoReturn Lock(const uint32_t securityCode, const uint32_t destinationID);
	/**
	 * This command sets the security code of the device.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 * @param securityCode Security code
	 */
	eoReturn SetCode(const uint32_t securityCode, const uint32_t destinationID);
	/**
	 * When this command is received then the addressed device performs an action (audio, visual, etc),
	 * depending on the functionality of the device.
	 * @param destinationID The device ID of the end device
	 */
	eoReturn Action(const uint32_t destinationID);
	/**
	 * The ping command functionality is similar to ping in TCP / IP communication.
	 * The actor sends a ping request to see if the Remote Device is alive and communicating.
	 * Ping requests are processed also when device is in lock status.
	 * Remote device sends the radio signal strength of the received request within the ping response.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 */
	eoReturn Ping(const uint32_t destinationID);
	/**
	 * With this command the actor parse the remote management message into the PING_RESPONSE structure.
	 * Unicast: yes
	 * Broadcast: no
	 * Device responses to command: yes
	 * @param[out] response Pointer to the PING_RESPONSE structure
	 */
	eoReturn ParsePingAnswer(PING_RESPONSE &response);
	/**
	 * With this command the actor requests an answer from a specific EEP.
	 * Unicast: no
	 * Broadcast: yes
	 * Device responses to command: yes
	 * @param msg Pointer to the QUERY_ID structure
	 */
	eoReturn QueryID(const QUERY_ID &msg);
	/**
	 * With this command the actor parse the remote management message into the QUERY_ID structure.
	 * @param[out] response Pointer to the QUERY_ID_RESPONSE structure
	 */
	eoReturn ParseQueryIDAnswer(QUERY_ID_RESPONSE &response);
	/**
	 * With this command the actor parse the remote management message into the QUERY_ID structure.
	 * @param[out] response Pointer to the QUERY_ID structure
	 */
	eoReturn ParseQueryIDAnswer(QUERY_ID &response);
	/**
	 * With this command the actor requests the supported extended functions list.
	 * Unicast: yes
	 *	Boradcast: no
	 *	Device responses to command: yes
	 * @param destinationID The device ID of the end device
	 */
	eoReturn QueryFunction(const uint32_t destinationID);
	/**
	 * With this command the actor parse the remote management message into the QUERY_FUNCTION_RESPONSE structure.
	 * @param[in] maxIDCount Size of the QUERY_FUNCTION_RESPONSE array
	 * @param[out] IDCount The number of entry count on the RPC list
	 * @param[out] response Pointer to the QUERY_FUNCTION_RESPONSE array
	 */
	eoReturn ParseQueryFunctionAnswer(QUERY_FUNCTION_RESPONSE *response, uint8_t maxIDCount, uint8_t &IDCount);
	/**
	 * With this command the actor directly asks for the status info of the Remote Device.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: yes
	 * The Remote Device answers with remote management debug data.
	 *@param destinationID The device ID of the end device
	 */
	eoReturn QueryStatus(const uint32_t destinationID);
	/**
	 * With this command the actor parse the remote management message into the QUERY_STATUS_RESPONSE structure.
	 * @param[out] response Pointer to the QUERY_STATUS_RESPONSE array
	 */
	eoReturn ParseQueryStatusAnswer(QUERY_STATUS_RESPONSE &response);
	/**
	 * Determines the device type to learn in, all other devices learn telegrams are ignored.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 * @param learnFlag Determines different behaviour of the learn procedure
	 */
	eoReturn RemoteLearnIn(const uint32_t destinationID, REMOTE_TYPE learnFlag);
	/**
	 * Using this command the flash of a device can be written.
	 * Unicast: yes
	 * Broadcast: yes
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 * @param memoryAddress Destination where the data should be stored
	 * @param numOfBytes Number of bytes to be transfered and written to the flash
	 * @param data[] Array to be transfered and written to the flash
	 */
	eoReturn RemoteFlashWrite(const uint32_t destinationID, const uint16_t &memoryAddress, const uint16_t numOfBytes, const uint8_t data[]);
	/**
	 * Using this command the flash can be read from the application. The data requested data area transmitted in RPC telegrams.
	 * Unicast: yes
	 * Broadcast: no
	 * Device responses to command: no
	 * @param destinationID The device ID of the end device
	 * @param memoryAddress Destination where the data should be read from
	 * @param numOfBytes Number of bytes to be read from the flash
	 */
	eoReturn RemoteFlashRead(const uint32_t destinationID, const uint16_t &memoryAddress, const uint16_t numOfBytes);
	/**
	 * Using this command the actor parse the remote management message into FLASH_READ_RESPONSE structure.
	 * @param[out] response Pointer to the FLASH_READ_RESPONSE array
	 * @param[out] dataCount The number of bytes the device read from the memory
	 * @param[in] maxDataCount Size of the FLASH_READ_RESPONSE array
	 */
	eoReturn ParseRemoteFlashReadAnswer(FLASH_READ_RESPONSE *response, uint16_t *dataCount, uint8_t maxDataCount);
	/**
	 * Using this command the mailbox setting can be read.
	 * Unicast: yes
	 * Broadcast: no
	 * Device responses to command: yes
	 * @param destinationID The device ID of the end device
	 */
	eoReturn RemoteSmartReadMailboxSettings(const uint32_t destinationID);
	/**
	 * Using this command the actor parse the remote management message into MAILBOX_SETTINGS_RESPONSE structure.
	 * @param[out] response Pointer to the MAILBOX_SETTINGS_RESPONSE structure
	 */
	eoReturn ParseRemoteSmartReadMailboxSettingsAnswer(MAILBOX_SETTINGS_RESPONSE &response);
	/**
	 * Using this command the learned in sensors can be read.
	 * Unicast: yes
	 * Broadcast: no
	 * Device responses to command: yes
	 * @param destinationID The device ID of the end device
	 */
	eoReturn RemoteSmartReadLearnedSensors(const uint32_t destinationID);
	/**
	 * Using this command the actor parse the remote management message into LEARNED_SENSOR_RESPONSE structure
	 * @param[out] response Pointer to the LEARNED_SENSOR_RESPONSE array
	 * @param[out] learnedCount Number of learned in devices
	 * @param[in] maxLearnedCount Size of the LEARNED_SENSOR_RESPONSE array
	 */
	eoReturn ParseRemoteSmartReadLearnedSensors(LEARNED_SENSOR_RESPONSE *response, uint8_t *learnedCount, uint8_t maxLearnedCount);
	/**
	 * Using this command the device adds a mailbox. Only for controller!
	 * Unicast: yes
	 * Broadcast: no
	 * @param destinationID The device ID of the end device
	 * @param mailboxIndex Index of the mailbox
	 * @param sensorID The device ID of the sensor
	 * @param postmasterID The device ID of the postmaster
	 */
	eoReturn RemoteSmartAddMailbox(const uint32_t destinationID, const uint8_t mailboxIndex, const uint32_t sensorID, const uint32_t postmasterID);
	/**
	 * Using this command the device deletes the mailbox.
	 * @param destinationID The device ID of the postmaster
	 * @param mailboxIndex Index of the mailbox
	 */
	eoReturn RemoteSmartDeleteMailbox(const uint32_t destinationID, const uint8_t mailboxIndex);
	/**
	 * Using this command the device learns out the sensor. Only for controller!
	 * @param destinationID The device ID of the controller
	 * @param learnCount Learn count
	 * @param sensorID Device ID of the sensor
	 * @param controllerID Device ID of the controller or postmaster
	 */
	eoReturn RemoteSmartLearnIn(const uint32_t destinationID, const uint8_t learnCount, const uint32_t sensorID, const uint32_t controllerID);
	/**
	 * Using this command the device learns out the sensor. Only for controller!
	 * @param destinationID The device ID of the controller
	 * @param learnCount Learn count
	 * @param sensorID Device ID of the sensor
	 * @param controllerID Device ID of the controller or postmaster
	 */
	eoReturn RemoteSmartLearnOut(const uint32_t destinationID, const uint8_t learnCount, const uint32_t sensorID, const uint32_t controllerID);

};

#endif // !defined(EA_4BFBF49B_3520_48f7_BACB_B62331BA4509__INCLUDED_)
