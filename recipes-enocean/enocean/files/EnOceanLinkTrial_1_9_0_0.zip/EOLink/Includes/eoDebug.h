/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoDebug.h
 * \brief eoDebug
 * \author EnOcean GmBH
 */
#ifndef EODEBUG_H_
#define EODEBUG_H_

#include "eoHalTypes.h"
#include "eoMessage.h"
#include "eoTelegram.h"
#include "eoTelegramERP2.h"
#include "eoPacket.h"
#include "eoReManMessage.h"
/**
 *\class eoDebug
 *\brief helper class for Debug Messages
 */
class eoDebug
{
public:
	/**
	 * Helper class, which prints debug Information for the Telegram to the console
	 * @param tel Telegram
	 */
	static void Print(const eoTelegramERP2 &tel);
	/**
	 * Helper class, which prints debug Information for the Telegram to the console
	 * @param tel Telegram
	 */
	static void Print(const eoTelegram &tel);
	/**
	 * Helper class, which prints debug Information for the Message to the console
	 * @param msg eoMessage
	 */
	static void Print(const eoMessage &msg);
	/**
	 * Helper class, which prints debug Information for the eoReManMessage to the console
	 * @param reMsg eoReManMessage
	 */
	static void Print(const eoReManMessage &reMsg);
	/**
	 * Helper class, which prints debug Information from the Packet
	 * @param packet Packet
	 */
	static void Print(const eoPacket &packet);

};

#endif /* EODEBUG_H_ */
