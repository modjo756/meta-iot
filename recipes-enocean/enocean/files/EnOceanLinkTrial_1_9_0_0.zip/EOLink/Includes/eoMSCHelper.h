/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoMSCHelper.h
 * \brief MSC Helper
 * \author EnOcean GmBH
 */
#if !defined(_EOMSCHELPER_H_)
#define _EOMSCHELPER_H_

#include "eoManufacturer.h"
#include "eoHalTypes.h"
#include "eoApiDef.h"
#include "eoTelegram.h"

/**
 * \class eoMSCHelper
 * \brief contains static Helper Functions
 * \details The eoMSCHelper allows you to easily integrate MSC telegrams into your program.
 */
class eoMSCHelper
{
public:
	/**
	 * Get the MSC manufacturer
	 * @param[out] manufacturer Pointer to the variable where the manufacturer ID should be returned
	 * @param msg eoTelegram which needs to be converted
	 * @return EO_OK or EO_ERROR
	 */
	eoReturn GetMSCmanufacturer(MANUFACTURER_LIST *manufacturer, eoMessage &msg);
	/**
	 * Get the MSC payload
	 * @param[out] payload Pointer to an array
	 * @param maxDataCount The size of the payload array
	 * @param msg eoTelegram which needs to be converted
	 * @return EO_OK or EO_ERROR
	 */
	eoReturn GetMSCpayload(uint8_t *payload, uint8_t maxDataCount, eoMessage &msg);
	/**
	 * Set the MSC manufacturer
	 * @param manufacturer
	 * @param msg
	 * @return EO_OK
	 */
	eoReturn SetMSCmanufacturer(const MANUFACTURER_LIST manufacturer, eoMessage &msg);
	/**
	 * Set the MSC paylod
	 * @param payload
	 * @param dataCount
	 * @param msg
	 * @return EO_OK or WRONG_PARAM
	 */
	eoReturn SetMSCpayload(const uint8_t *payload, uint8_t dataCount, eoMessage &msg);
};

#endif /* _EOMSCHELPER_H_ */
