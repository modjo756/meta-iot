/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

/**
 * \file eoTeachInModule.h
 * \brief
 * \author EnOcean GmBH
 */
#ifndef EO_TEACH_IN_MODULE_H_
#define EO_TEACH_IN_MODULE_H_
#include "eoHalTypes.h"
#include "eoMessage.h"
#include "eoDevice.h"
#include "eoISerialize.h"
#include "eoUTEHelper.h"

class eoDeviceManager;
class eoSecurity;

#include <map>

//! Teach message structure.
typedef struct
{
     //! Teached in
	bool teachedIN;
} TEACH_STRUCT;

//! Teach process return codes.
typedef enum
{
	//! <b>0</b> -Tried to add an object with the same name, which differ!
	NO_TEACH_IN = 0,         //!< NO_TEACH_IN
	//! <b>1</b> -Added a new device
	NEW_DEVICE,             //!< NEW_DEVICE
	//! <b>2</b> - EEP teach in has been set
	EEP_TEACH_IN,           //!< EEP_TEACH_IN
	//! <b>3</b>- EEP teach in and new Device
	NEW_DEVICE_AND_EPP,     //!< NEW_DEVICE_AND_EPP
	//! <b>4</b>- SECURITY Teach IN
	SECURITY_TEACH_IN,      //!< SECURITY_TEACH_IN
	//! <b>5</b>- RECEIVED A SECOND TEACH IN
	SECOND_TEACH_IN,        //!< SECOND_TEACH_IN
	//! <b>6</b>- GP teach in
	GENERIC_TEACH_IN,				//!< GP_TEACH_IN
	//! <b>7</b> Teach Out Request received
	REQUEST_FOR_TEACH_OUT
} TEACH_RETURN;

/**
 * \typedef GP_RESPONSE_RESULT
 * \brief Result after a Teach IN
 */
typedef enum
{
	RESP_REJECTED_GENERALLY = 0,
	RESP_TEACHIN,
	RESP_TEACHOUT,
	RESP_REJECTED_CHANNELS
} GP_RESPONSE_RESULT;

//! Map type definition for teached devices.
typedef std::map<uint32_t, bool> teach_id_map;
/**
 * \ingroup gateway
 * @{
 */
/**
 * \class eoTeachInModule
 * \brief handles TeachIn Messages
 * \details a helper class to handle different TeachIn Messages (GP_TI, UTE, RPS/4BS/1BS EEP Teach IN request and SEC_TI)
 */
class eoTeachInModule : public eoISerialize
{

public:
	/**
	 *	Standard constructor for the TeachInModule
	 * @param eoDevManager eoDeviceManager
	 * @param sec security Module to use to handle security Messages
	 */
	eoTeachInModule(eoDeviceManager *eoDevManager, eoSecurity *sec);
	virtual ~eoTeachInModule();

	/**
	 * Allows you to set the manual RPS EEP to use
	 * @param func
	 * @param type
	 */
	void SetRPS(uint8_t func, uint8_t type);
	/**
	 * Allows you to set the manual 1BS EEP to use
	 * @param func
	 * @param type
	 */
	void Set1BS(uint8_t func, uint8_t type);
	/**
	 * Allows you to set the manual 4BS EEP to use
	 * @param func
	 * @param type
	 */
	void Set4BS(uint8_t func, uint8_t type);
	/**
	 * \brief handles Teach IN Message
	 * \details
	 * This function uses the information passed in the message to teach in a new device. If the device is already
	 * teached in and the message is not a teach out request, a SECOND_TEACH_IN will be returned and the device will  not be teached in.
	 * If the message is a security teach in, the security parameters will be set and saved in the device manager,
	 * if the security teach Information is from a ptm device, a ptm profile will be generated.
	 *
	 * EEP teach in messages and generic teach in messages will be parsed accordingly to spec, and a profile will
	 * be created if it is supported.
	 *
	 * For profiles which do not support teach in information (e.g. rps), the information has to be set before using
	 * the SetRPS,Set1Bs,.. function
	 *
	 * If a profile has been set the return value will be either EEP_TEACH_IN,NEW_DEVICE_AND_EPP or GENERIC_TEACH_IN.
	 *
	 * If the message is a teach out request, or the request type is set not specified/toogle a REQUEST_FOR_TEACH_OUT is generated
	 *
	 * @param m
	 * @return ::TEACH_RETURN  NO_TEACH_IN,NEW_DEVICE , SECOND_TEACH_IN, NEW_DEVICE_AND_EPP, EEP_TEACH_IN, REQUEST_FOR_TEACH_OUT
	 */
	TEACH_RETURN TeachIN(eoMessage &m);

	 /**
	 * \brief handles Teach IN Message
	 * \details
	 * This function uses the information passed to manually teach in a new device. If the device is already
	 * teached in SECOND_TEACH_IN will be returned and the device will not be teached in.
	 *
	 * If a profile has been set the return value will be either EEP_TEACH_IN,NEW_DEVICE_AND_EPP
	 * @param rorg
	 * @param func
	 * @param type
	 * @param deviceID Id of the device to teach in
	 * @return ::TEACH_RETURN  NO_TEACH_IN,NEW_DEVICE , SECOND_TEACH_IN, NEW_DEVICE_AND_EPP, EEP_TEACH_IN
	 */
	TEACH_RETURN TeachIN(uint8_t rorg,uint8_t func,uint8_t type,uint32_t device_id);
	/**
	* Enables or Disables the autoTeachOut of the TeachInModule
	* @param enable: enable or disable autoteachout
	*/
	void SetAutoTeachOut(bool enable) { allowAutoTeachOut = enable; };
	/**
	* Get the autoTeachOut of the TeachInModule
	*/
	bool GetAutoTeachOut() { return allowAutoTeachOut; };
	/**
	 * Removes all saved information about a device
	 * @param id Device ID
	 */
	void TeachOut(uint32_t id);
	/**
	 * Returns True if it is a teach IN telegram for 4BS or 1BS
	 * @param telegram to check
	 * @return true or false
	 */
	static bool isTeachIN(eoMessage &telegram);
	/**
	 * Checks if the device belonging to the Message is teached IN
	 * @param telegram
	 * @return true or false
	 */
	 bool isTeachedIN(eoMessage &telegram) ;
	/**
	 * Checkes if the device is Teached IN
	 * @param dev device to check
	 * @return true or false
	 */
	 bool isTeachedIN(eoDevice &dev) ;     
	 /**
	 * Checkes if the device is Teached IN
	 * @param dev deviceID to check
	 * @return true or false
	 */
	 bool isTeachedIN(uint32_t deviceID);
	 /**
	 \deprecated This function is depracted, instead the eoUTEHelper::ParseUTE(eoMessage &msg, UTE_EEP_TEACH_IN_QUERY &uteQuery) should be used
	 *
	 * Parse the message into UTE
	 * @param msg
	 * @return EO_OK
	 */
	 DEPRECATED(eoReturn ParseUTE(eoMessage &msg));
	 /**
	 * \deprecated This function is depracted, instead the eoUTEHelper::CreateUTEResponseFromQuery(UTE_EEP_TEACH_IN_RESPONSE &uteQuery, eoMessage &responseMessage, UTE_RESPONSE type, UTE_DIRECTION direction)
	 *
	 * Creates UTE teach in response from UTE teach in request
	 * @param teachInUTE
	 * @param [out] responseUTE
	 * @param type ::UTE_RESPONSE
	 * @param direction ::UTE_DIRECTION
	 * @return EO_OK
	 */
	 DEPRECATED(eoReturn CreateUTEResponse(eoMessage &teachInUTE, eoMessage &responseUTE, UTE_RESPONSE type, UTE_DIRECTION direction));


	/**
	 * Creates GP teach in response for GP teach in
	 * @param msg
	 * @param manId manufacturer ID
	 * @param destinationId
	 * @param response ::GP_RESPONSE_RESULT
	 * @param profile
	 * @return EO_OK
	 */
	 eoReturn CreateGPResponse (eoMessage &msg, uint16_t manId, uint32_t destinationId, GP_RESPONSE_RESULT response, eoProfile *profile);

	 /**
	 * \brief Serialization Function which will be called by the eoStorageManager
	 * \details This function will be called by the eoArchive(inside of the eoStorageManager) and allows the class to be Serialized.
	 * @param arch archive where to Load or to Store.
	 */
	 virtual uint8_t Serialize(eoArchive &arch);
	/**
	* If an UTE has been received, this returns a copy of the query information
	* @return copy of last UTE query information
	*/
	 UTE_EEP_TEACH_IN_QUERY GetUTEQuery();


private:
	teach_id_map teachInformation;
	eoSecurity *security;
	eoDeviceManager * deviceManager;
	uint8_t rps_func, rps_type, bs1_func, bs1_type, bs4_func, bs4_type;
	UTE_EEP_TEACH_IN_QUERY uteQuery;
	bool allowAutoTeachOut;

	bool IsDeviceTeachedIn(uint32_t deviceID);
	bool IsDuplicatedSimpleTeachInMessage(eoMessage & m);
	bool LinkProfileToDevice(eoDevice * device, eoProfile * profile);

	friend class eoTeachMessageHandler;

};


/**
 * @}
 */
#endif // !defined(EA_62DB5BA2_ABF0_41c3_9291_81B05C9C37AD__INCLUDED_)
