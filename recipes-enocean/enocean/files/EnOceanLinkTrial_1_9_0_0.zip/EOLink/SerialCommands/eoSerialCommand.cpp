/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoSerialCommand.h"
#include "eoGateway.h"

eoSerialCommand::eoSerialCommand(eoGateway *gateway) : serialPacket(255)
{
	this->gateway = gateway;
}

eoSerialCommand::~eoSerialCommand()
{

}

eoReturn eoSerialCommand::initPacket(uint8_t type, uint8_t command, uint8_t length)
{
	if (length > serialPacket.getBufferSize())
		return OUT_OF_RANGE;

	serialPacket.type = type;
	serialPacket.dataLength = length;
	serialPacket.optionalLength = 0;
	serialPacket.data[0] = command;

	return EO_OK;
}

eoReturn eoSerialCommand::Sleep(uint32_t sleepPeriod)
{
	if (sleepPeriod > 0x00FFFFFF)
		return EO_ERROR;
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_SLEEP, 5) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = (uint8_t)(sleepPeriod >> 24);
	serialPacket.data[2] = (uint8_t)(sleepPeriod >> 16);
	serialPacket.data[3] = (uint8_t)(sleepPeriod >> 8);
	serialPacket.data[4] = (uint8_t)sleepPeriod;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::Reset()
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_RESET, 1) != EO_OK)
		return OUT_OF_RANGE;

	return gateway->Send(serialPacket);
}
eoReturn eoSerialCommand::WriteMemory(CO_WR_MEMORY const &writeMemory)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_MEM, 6 + (uint8_t)writeMemory.memoryData.size()) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = writeMemory.memoryType;
	serialPacket.data[2] = (uint8_t)(writeMemory.memoryAddress >> 24);
	serialPacket.data[3] = (uint8_t)(writeMemory.memoryAddress >> 16);
	serialPacket.data[4] = (uint8_t)(writeMemory.memoryAddress >> 8);
	serialPacket.data[5] = (uint8_t)writeMemory.memoryAddress;
	uint8_t i = 5;
	for (std::vector<uint8_t>::const_iterator it = writeMemory.memoryData.begin(); it != writeMemory.memoryData.end(); ++it)
	{
		i++;
		serialPacket.data[i] += *it;
	}
	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::ReadMemory(CO_RD_MEMORY const &readMemory,CO_RD_MEMORY_RESPONSE &response)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_RD_MEM, 8) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = readMemory.memoryType;
	serialPacket.data[2] = (uint8_t)(readMemory.memoryAddress >> 24);
	serialPacket.data[3] = (uint8_t)(readMemory.memoryAddress >> 16);
	serialPacket.data[4] = (uint8_t)(readMemory.memoryAddress >> 8);
	serialPacket.data[5] = (uint8_t)readMemory.memoryAddress;
	serialPacket.data[6] = (uint8_t)(readMemory.dataLength >> 8);
	serialPacket.data[7] = (uint8_t)readMemory.dataLength;
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if (gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	response.memoryData.clear();

	for (uint8_t i = 0; i < gateway->responsePacket.dataLength - 1; i++)
	{
		response.memoryData.push_back(gateway->responsePacket.data[i + 1]);
	}

	return EO_OK;
}
eoReturn eoSerialCommand::GetFrequencyInfo(CO_RD_FREQUENY_RESPONSE &response)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_GET_FREQUENCY_INFO, 1) != EO_OK)
		return OUT_OF_RANGE;

	// Send packet
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	//the datalenght is constant, the first bit of the first data byte is the response, no other identifier for this response
	if (gateway->responsePacket.dataLength != 3 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	response.frequency = (ESP3_FREQUENCY)gateway->responsePacket.data[1];
	response.protocol = (ESP3_PROTOCOL)gateway->responsePacket.data[2];
	return EO_OK;
}
eoReturn eoSerialCommand::ReadVersion(CO_RD_VERSION_RESPONSE &response)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_RD_VERSION, 1) != EO_OK)
		return OUT_OF_RANGE;

	// Send packet
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	//the datalenght is constant, the first bit of the first data byte is the response, no other identifier for this response
	if (gateway->responsePacket.dataLength != 33 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	// Parse the response
	response.appVersion[0] = gateway->responsePacket.data[1];
	response.appVersion[1] = gateway->responsePacket.data[2];
	response.appVersion[2] = gateway->responsePacket.data[3];
	response.appVersion[3] = gateway->responsePacket.data[4];

	response.apiVersion[0] = gateway->responsePacket.data[5];
	response.apiVersion[1] = gateway->responsePacket.data[6];
	response.apiVersion[2] = gateway->responsePacket.data[7];
	response.apiVersion[3] = gateway->responsePacket.data[8];

	response.chipID = gateway->responsePacket.data[9] << 24 | gateway->responsePacket.data[10] << 16 | gateway->responsePacket.data[11] << 8 | gateway->responsePacket.data[12];

	response.chipVersion = gateway->responsePacket.data[13] << 24 | gateway->responsePacket.data[14] << 16 | gateway->responsePacket.data[15] << 8 | gateway->responsePacket.data[16];

	for (uint8_t i = 0; i < 16; i++)
		response.appDescription[i] = gateway->responsePacket.data[i + 17];
	return EO_OK;
}

eoReturn eoSerialCommand::BIST()
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_BIST, 1) != EO_OK)
		return OUT_OF_RANGE;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::WriteIDBase(uint32_t baseID)
{

	if (baseID > 0xFFFFFFFE || baseID < 0xFF800000)
		return EO_ERROR;

	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_IDBASE, 5) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = (uint8_t)(baseID >> 24);
	serialPacket.data[2] = (uint8_t)(baseID >> 16);
	serialPacket.data[3] = (uint8_t)(baseID >> 8);
	serialPacket.data[4] = (uint8_t)baseID;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::ReadIDBase(CO_RD_IDBASE_RESPONSE &response)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_RD_IDBASE, 1) != EO_OK)
		return OUT_OF_RANGE;

	// Send packet
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if (gateway->responsePacket.dataLength != 5 && gateway->responsePacket.optionalLength != 1 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	// Parse the response
	response.baseID = gateway->responsePacket.data[1] << 24 | gateway->responsePacket.data[2] << 16 | gateway->responsePacket.data[3] << 8 | gateway->responsePacket.data[4];

	response.remainingWrites = gateway->responsePacket.data[5];

	return EO_OK;
}

eoReturn eoSerialCommand::WriteRepeater(bool repEnable, uint8_t repLevel)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_REPEATER, 3) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = repEnable ? 1 : 0;
	serialPacket.data[2] = repEnable ? repLevel : 0;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::ReadRepeater(CO_RD_REPEATER_RESPONSE &response)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_RD_REPEATER, 1) != EO_OK)
		return OUT_OF_RANGE;

	// Send packet
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if (gateway->responsePacket.dataLength != 3 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	// Parse the response
	response.repEnable = gateway->responsePacket.data[1] != 0;
	response.repLevel = gateway->responsePacket.data[2];

	return EO_OK;
}

eoReturn eoSerialCommand::AddFilter(FILTER_TYPE filterType, uint32_t filterValue, FILTER_KIND filterKind)
{

	if (filterKind != 0x80 && filterKind != 0x00)
		return EO_ERROR;

	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_FILTER_ADD, 7) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = (uint8_t)filterType;
	serialPacket.data[2] = (uint8_t)(filterValue >> 24);
	serialPacket.data[3] = (uint8_t)(filterValue >> 16);
	serialPacket.data[4] = (uint8_t)(filterValue >> 8);
	serialPacket.data[5] = (uint8_t)filterValue;
	serialPacket.data[6] = (uint8_t)filterKind;

	// Send packet
	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::DeleteFilter(FILTER_TYPE filterType, uint32_t filterValue)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_FILTER_DEL, 6) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = (uint8_t)filterType;
	serialPacket.data[2] = (uint8_t)(filterValue >> 24);
	serialPacket.data[3] = (uint8_t)(filterValue >> 16);
	serialPacket.data[4] = (uint8_t)(filterValue >> 8);
	serialPacket.data[5] = (uint8_t)filterValue;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::DeleteAllFilter()
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_FILTER_DEL_ALL, 1) != EO_OK)
		return OUT_OF_RANGE;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::EnableFilter(bool filterEnabled, FILTER_OPERATOR filterOperator)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_FILTER_ENABLE, 3) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = filterEnabled ? 1 : 0;
	serialPacket.data[2] = (uint8_t)filterOperator;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::ReadFilter(CO_RD_FILTER_RESPONSE *filter, uint8_t *filterCount, uint8_t maxFilterCount)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_RD_FILTER, 1) != EO_OK)
		return OUT_OF_RANGE;

	// Send packet
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if ((gateway->responsePacket.dataLength % 5) != 1 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	// Parse the response
	*filterCount = (uint8_t)(gateway->responsePacket.dataLength - 1) / 5;

	for (uint8_t i = 0; i < *filterCount && i < maxFilterCount; i++)
	{
		filter[i].filterType = (FILTER_TYPE) gateway->responsePacket.data[i * 5 + 1];

		filter[i].filterValue = gateway->responsePacket.data[i * 5 + 2] << 24 | gateway->responsePacket.data[i * 5 + 3] << 16 | gateway->responsePacket.data[i * 5 + 4] << 8 | gateway->responsePacket.data[i * 5 + 5];
	}

	return EO_OK;
}

eoReturn eoSerialCommand::WaitMaturity(bool waitMaturity)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_WAIT_MATURITY, 2) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = waitMaturity ? 1 : 0;

	return gateway->Send(serialPacket);
}
eoReturn eoSerialCommand::SmartAckConfirmLearn(uint16_t responseTime, SA_CONFIRM_CODE confirmCode)
{
	if (initPacket(PACKET_RESPONSE, EO_OK, 4) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = (uint8_t)(responseTime >> 8);
	serialPacket.data[2] = (uint8_t)responseTime;
	serialPacket.data[3] = (uint8_t)confirmCode;

	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	return EO_OK;
}

eoReturn eoSerialCommand::SmartAckLearnAck(SA_LEARN_ACK_RESPONSE &response)
{
	if (gateway->packet.type != PACKET_EVENT)
		return NOT_SUPPORTED;

	if (gateway->packet.data[0] != SA_LEARN_ACK)
		return NOT_SUPPORTED;

	if (gateway->packet.dataLength != 4)
		return NOT_SUPPORTED;

	response.responseTime = gateway->packet.data[1] << 8 | gateway->packet.data[2];

	switch (gateway->packet.data[3])
	{
		case SA_LEARN_IN:
		case SA_EEP_NOT_ACCEPTED:
		case SA_PM_FULL:
		case SA_CONTROLLER_FULL:
		case SA_RSSI_NOT_GOOD:
		case SA_LEARN_OUT:
			response.confirmCode = (SA_CONFIRM_CODE) gateway->packet.data[3];
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}
	return EO_OK;
}

eoReturn eoSerialCommand::Ready(CO_READY_RESPONSE &response)
{
	if (gateway->packet.type != PACKET_EVENT)
		return INVALID_PACKET;

	if (gateway->packet.data[0] != SA_READY)
		return NOT_SUPPORTED;

	if (gateway->packet.dataLength != 2)
		return NOT_SUPPORTED;

	switch (gateway->packet.data[1])
	{
		case EC_VOLTAGE_DROP:
		case EC_RESET_PIN:
		case EC_WATCHDOG_TIMER:
		case EC_FLYWHEEL_TIMER:
		case EC_PARITY_ERROR:
		case EC_PARITY_MEM_ERROR:
		case EC_MEM_ERRPR:
		case EC_WAKE_PIN_0:
		case EC_WAKE_PIN_1:
		case EC_UNKNOWN:
			response.resetCause = (EC_RESET_CAUSE) gateway->packet.data[1];
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}
eoReturn eoSerialCommand::SmartAckWriteLearnMode(bool enable, SA_EXTENDED_LEARNMODE extended, uint32_t timeout)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_WR_LEARNMODE, 7) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = enable ? 1 : 0;
	serialPacket.data[2] = (uint8_t)extended;
	serialPacket.data[3] = (uint8_t)(timeout >> 24);
	serialPacket.data[4] = (uint8_t)(timeout >> 16);
	serialPacket.data[5] = (uint8_t)(timeout >> 8);
	serialPacket.data[6] = (uint8_t) timeout;

	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::SmartAckReadLearnMode(SA_RD_LEARNMODE_RESPONSE &response)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_RD_LEARNMODE, 1) != EO_OK)
		return OUT_OF_RANGE;

	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if (gateway->responsePacket.dataLength != 3 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	response.enabled = gateway->responsePacket.data[1]!=0;
	switch (gateway->responsePacket.data[2])
	{
		case 0x00:
			response.extended = SA_EL_SIMPLE;
			break;
		case 0x01:
			response.extended = SA_EL_ADVANCE;
			break;
		case 0x02:
			response.extended = SA_EL_ADVANCE_REP;
			break;
	}

	return EO_OK;
}

eoReturn eoSerialCommand::SmartAckLearnConfirm(uint16_t responseTime, SMARTACK_CONFIRM_CODE confirmCode, uint32_t postmasterID, uint32_t clientID)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_WR_LEARNCONFIRM, 12) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = responseTime >> 8;
	serialPacket.data[2] = responseTime & 0xFF;
	serialPacket.data[3] = (uint8_t)confirmCode;
	serialPacket.data[4] = (uint8_t)(postmasterID >> 24);
	serialPacket.data[5] = (uint8_t)(postmasterID >> 16);
	serialPacket.data[6] = (uint8_t)(postmasterID >> 8);
	serialPacket.data[7] = (uint8_t)postmasterID;
	serialPacket.data[8] = (uint8_t)(clientID >> 24);
	serialPacket.data[9] = (uint8_t)(clientID >> 16);
	serialPacket.data[10] = (uint8_t)(clientID >> 8);
	serialPacket.data[11] = (uint8_t)clientID;


	return (gateway->Send(serialPacket));
}

eoReturn eoSerialCommand::SmartAckSendLearnRequest(uint16_t manufacturerID, uint32_t EEP)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_WR_CLIENTLEARNRQ, 6) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = 0xF8 | ((manufacturerID >> 8) & 0x07);
	serialPacket.data[2] = manufacturerID & 0xFF;
	serialPacket.data[3] = (uint8_t)(EEP >> 16);
	serialPacket.data[4] = (uint8_t)(EEP >> 8);
	serialPacket.data[5] = (uint8_t)EEP;


	return 	gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::SmartAckReset(uint32_t clientID)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_WR_RESET, 5) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = (uint8_t)(clientID >> 24);
	serialPacket.data[2] = (uint8_t)(clientID >> 16);
	serialPacket.data[3] = (uint8_t)(clientID >> 8);
	serialPacket.data[4] = (uint8_t) clientID;


	return 	gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::SmartAckLearnedClients(SA_RD_LEARNEDCLIENTS_RESPONSE *clients, uint8_t *learnedCount, uint8_t maxLearnedCount)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_RD_LEARNEDCLIENTS, 1) != EO_OK)
		return OUT_OF_RANGE;

	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if ((gateway->responsePacket.dataLength % 9) != 1 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	*learnedCount = (uint8_t)(gateway->responsePacket.dataLength - 1) / 9;
	for (uint8_t i = 0; i < *learnedCount && i < maxLearnedCount; i++)
	{
		clients[i].clientID = gateway->responsePacket.data[i * 9 + 1] << 24 | gateway->responsePacket.data[i * 9 + 2] << 16 | gateway->responsePacket.data[i * 9 + 3] << 8 | gateway->responsePacket.data[i * 9 + 4];

		clients[i].postmasterID = gateway->responsePacket.data[i * 9 + 5] << 24 | gateway->responsePacket.data[i * 9 + 6] << 16 | gateway->responsePacket.data[i * 9 + 7] << 8 | gateway->responsePacket.data[i * 9 + 8];

		clients[i].mailboxIndex = gateway->responsePacket.data[i * 9 + 9];
	}

	return EO_OK;
}

eoReturn eoSerialCommand::SmartAckSetReclaimTries(uint8_t reclaimCount)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_WR_RECLAIMS, 2) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = reclaimCount;


	return gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::SmartAckSetPostmaster(uint8_t mailboxCount)
{
	if (initPacket(PACKET_SMART_ACK_COMMAND, SA_WR_POSTMASTER, 2) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = mailboxCount;
	return 	gateway->Send(serialPacket);
}

eoReturn eoSerialCommand::EventSmartAckConfirmLearn (SA_CONFIRM_LEARN_REQUEST &request)
{
	//check packettype
	if (!(gateway->packet.type == PACKET_EVENT && gateway->packet.data[0] == 0x02))
		return INVALID_PACKET;
	if (gateway->packet.dataLength != 17 )
		return INVALID_PACKET;

	request.priPostmaster = gateway->packet.data[1];
	request.manufacturerID = gateway->packet.data[2] << 8 | gateway->packet.data[3];

	request.eep[0] = gateway->packet.data[4];
	request.eep[1] = gateway->packet.data[5];
	request.eep[2] = gateway->packet.data[6];
	request.rssi = gateway->packet.data[7];
	 
	request.postmasterID = gateway->packet.data[8] << 24 | gateway->packet.data[9] << 16 | gateway->packet.data[10] << 8 | gateway->packet.data[11];

	request.smartAckID = gateway->packet.data[12] << 24 | gateway->packet.data[13] << 16 | gateway->packet.data[14] << 8 | gateway->packet.data[15];

	request.hopCount = gateway->packet.data[16];

	return EO_OK;
}

eoReturn  eoSerialCommand::WriteMode (WR_MODE_CODE mode)
{
	if ((mode != MODE_COMPATIBLE) && (mode != MODE_ADVANCED))
		return EO_ERROR;

	if (initPacket(PACKET_COMMON_COMMAND, CO_WR_MODE, 2) != EO_OK)
		return OUT_OF_RANGE;

	serialPacket.data[1] = mode;

	// Send packet
	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if ((eoReturn)gateway->responsePacket.data[0] == EO_OK)
		gateway->advancedMode = true;
	else
		gateway->advancedMode = false;

	return (eoReturn)(gateway->responsePacket.data[0]);
}

eoReturn eoSerialCommand::DutyCycleReadLimit(CO_RD_DUTYCYCLE_RESPONSE &response)
{
	if (initPacket(PACKET_COMMON_COMMAND, CO_RD_DUTYCYCLE_LIMIT, 1) != EO_OK)
		return OUT_OF_RANGE;

	eoReturn ret;
	if ((ret = gateway->Send(serialPacket)) != EO_OK)
		return ret;

	if (gateway->responsePacket.dataLength != 8 && gateway->responsePacket.data[0] != EO_OK && gateway->responsePacket.type != PACKET_RESPONSE)
		return (eoReturn)gateway->responsePacket.data[0];

	response.availableCycle = gateway->responsePacket.data[1];
	response.numOfSlots = gateway->responsePacket.data[2];
	response.slotPeriod = ((gateway->responsePacket.data[3] & 0xFF) << 8 ) | (gateway->responsePacket.data[4] & 0xFF);
	response.slotPeriodLeft = ((gateway->responsePacket.data[5] & 0xFF) << 8 ) | (gateway->responsePacket.data[6] & 0xFF);
	response.loadAfterCycle = gateway->responsePacket.data[7];

	return EO_OK;
}

eoReturn eoSerialCommand::EventDutyCycleLimit (CO_DUTYCYCLE_LIMIT &request)
{

	if (gateway->responsePacket.dataLength != 2 && gateway->responsePacket.data[0] != SA_DUTYCYCLE_LIMIT && gateway->responsePacket.type != PACKET_EVENT)
		return NOT_SUPPORTED;

	request = (CO_DUTYCYCLE_LIMIT) gateway->responsePacket.data[1];

	return EO_OK;
}

eoReturn eoSerialCommand::DutyCycleLimit (CO_DUTYCYCLE_LIMIT limit)
{
	if (initPacket(PACKET_EVENT, SA_DUTYCYCLE_LIMIT, 2) != EO_OK)
		return OUT_OF_RANGE;
  
	if ((uint8_t)limit > 0x02)
		return NOT_SUPPORTED;

	serialPacket.data[1] = (uint8_t)limit;

	return (gateway->Send(serialPacket));
}


eoPacket eoSerialCommand::GetSerialPacket()
{
	eoPacket returnPacket(serialPacket);
	return returnPacket;
}
