#!/bin/bash
ARM_TOOLCHAIN_PATH=/opt/pitools/arm-bcm2708/arm-bcm2708hardfp-linux-gnueabi/bin/
ARM_TOOLCHAIN=arm-bcm2708hardfp-linux-gnueabi
ARM_CPPFLAGS=-Ofast -mfpu=vfp -mfloat-abi=hard  -march=armv6zk -mtune=arm1176jzf-s
PATH=$PATH:$ARM_TOOLCHAIN_PATH
mkdir RaspBerryPi
cd RaspBerryPi/
../configure --host=$ARM_TOOLCHAIN --enable-platform=POSIX CPPFLAGS="$ARM_CPPFLAGS"
if [[ "$?" -eq "0" ]]; then
	echo "Starting Make process"
else
	echo "Configure failed!"
	exit $?
fi
make clean
make 
if [[ "$?" -eq "0" ]]; then
        echo "Copying static Library for examples/Tutorials"
else
        exit $?
fi
cp .libs/libEOLink.a ./libEOLink.a

