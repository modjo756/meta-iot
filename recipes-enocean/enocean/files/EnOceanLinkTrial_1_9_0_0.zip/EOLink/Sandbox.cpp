#include <csignal>
#include <typeinfo>
//a Sandbox to play arroung
#ifdef WIN32
#include <windows.h>
#define SER_PORT "\\\\.\\COM102"  //COM4
#else
#define SER_PORT "/dev/ttyUSB0"//! the Serial Port Device
#endif


#define LOAD_CONFIG "./learned.txt" //! where to store the gateway Configuration
#define LEARN_TIME_S 1 //! allows you to set the time the gateway should stay in learnmode
#include "eoLink.h"
#include "./Profiles/eoF6EEProfile.h"
#include "./Profiles/eoEEP_A505xx.h"
#include <stdio.h>

#define	ROCKER_STATE_I 0
#define	ROCKER_STATE_O 1
#define	ROCKER_STATE_NP 2

int vld_example() {
	eoGateway gateway; //= eoGateway();
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	printf("bla");
	//adding eoIDFilter to the gateWay
	if (gateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return -1;
	}

	uint16_t recv;

	gateway.LearnMode=true;
	while(1)
	{
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = gateway.Receive();
		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)
		if (recv & RECV_TEACHIN)
		{
			//Print out the Message to stdout
			eoDebug::Print(gateway.telegram);
			//If the TeachIN process was successfull and we got a Profile print out the Message!
			eoProfile *profile = gateway.device->GetProfile();
			if(profile!=NULL)
			{
				printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", gateway.device->ID, profile->rorg, profile->func, profile->type );

				for (int i = 0; i<profile->GetChannelCount(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
				}
			}

			//If incoming telegram is UTE telegram
			if (gateway.telegram.RORG == RORG_UTE)
			{
				//Creating the UTE response depending on the incoming teachIN telegram
				eoMessage response = eoMessage(7);
				UTE_EEP_TEACH_IN_QUERY uteQuery = gateway.TeachInModule->GetUTEQuery();
				eoUTEHelper::CreateUTEResponseFromQuery(uteQuery, response, TEACH_IN_ACCEPTED, UTE_DIRECTION_BIDIRECTIONAL);
				response.destinationID = gateway.telegram.sourceID;
				eoDebug::Print(response);
				//Send the UTE response
				gateway.Send(response);
			}
		}
	}

	return 0;
}


int gpTest()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);
	eoMessage msg(511);
	printf("Opening Connection to USB300 \n");

	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return 0;
	}
	/*In the first step we create a new GenericProfile class, as
	 * Generic Profile messages can be quite big so we reserve a big internal message space
	 */
	eoGenericProfile *gpProf = new eoGenericProfile(255);
	if (gpProf == NULL) {
		printf("Unable to create GenericProfile");
	}
	printf("Created a new GP, trying to add some Channels\n");
	/**
	{GP_DATA,GP_VAL_CURR,GP_RES_8BIT,GP_ACCELERATION,-1,1,GP_SCAL_1,GP_SCAL_1,0,0 },
	{GP_FLAG,GP_VAL_CURR,GP_RES_RES,GP_AUTOMATIC_FLAG,0,1,GP_SCAL_1,GP_SCAL_1,0,0 },
	{GP_ENUMERATION,GP_VAL_CURR,GP_RES_2BIT,GP_OCCUPANCY_ENUM,0,3,GP_SCAL_1,GP_SCAL_1,0,0 }};
	};
	 */
	/**if (gpProf->AddChannelOut(F_BTN_PRESS, VAL_CURR) != EO_OK) {
		printf("Failed to add the button Channel");
	}**/
	if (gpProf->AddChannelOut(S_TEMP, GP_RES_8BIT, 1, -1, GP_SCAL_10,
			GP_SCAL_10, VAL_CURR) != EO_OK) {
		printf("Failed to add the first Temperature Channel");
	}
	if (gpProf->AddChannelOut(S_TIME, GP_RES_24BIT, 5, -1, GP_SCAL_10,
			GP_SCAL_10, VAL_CURR) != EO_OK) {
		printf("Failed to add the first Temperature Channel");
	}
	if (gpProf->AddChannelOut(S_VOLUME, GP_RES_8BIT, 5, -1, GP_SCAL_10,
			GP_SCAL_10, VAL_CURR) != EO_OK) {
		printf("Failed to add the first Temperature Channel");
	}
	if (gpProf->AddChannelOut(E_GP_MULTIPURPOSE, GP_RES_8BIT, VAL_CURR) != EO_OK) {
		printf("Failed to add the first Temperature Channel");
	}
	//now we just print the Channel Information again
	//afterwards we can create a TeachIN message
	if (gpProf->CreateTeachIN(msg) != EO_OK) {
		printf("Teach IN creation failed");
	}
	eoDebug::Print(msg);

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return 0;
	}
	eoTimer::Sleep(1000);

		myGateway.Send(msg);
		//Clear Values and set Message to rigth type
		gpProf->ClearValues();
    float i=-10;
	gpProf->SetValue(S_TEMP, 0.0F);
	gpProf->SetValue(S_TIME,0.0F);
	gpProf->SetValue(S_VOLUME,0.0F);
	gpProf->SetValue(E_GP_MULTIPURPOSE,(uint8_t)0);
	gpProf->SetValue(S_TEMP, i);
	std::vector<int> channelList;
	channelList.push_back(0);
	channelList.push_back(3);
	uint8_t uD=0;
	while(1)
	{
		uD+=1;
		gpProf->SetValue(E_GP_MULTIPURPOSE,uD);
		eoTimer::Sleep(1000);
		i+=0.5;
		gpProf->SetValue(S_TEMP, i);
		gpProf->Create(msg);
		eoDebug::Print(msg);
		myGateway.Send(msg);
		eoTimer::Sleep(1000);
		gpProf->Create(msg,channelList);
		eoDebug::Print(msg);
		myGateway.Send(msg);
		if(i>=10)
			i=-10;
	}
		//Set the values for the outbound channels



		//now we have a prepares message with the flags

		//Set the values for the outbound channels



	return 0;
}

int recomTest()
{
		setvbuf(stdout, NULL, _IONBF, 0);
		setvbuf(stderr, NULL, _IONBF, 0);
		//First a Gateway and a storageManager will be definied
		eoGateway myGateway;
		eoSerialCommand ser(&myGateway);

		printf("Opening Connection to USB300 \n");
		if (myGateway.Open(SER_PORT)!=EO_OK)
		{
			printf("Failed to open USB300\n");
			return 0;
		}

		CO_RD_VERSION_RESPONSE version;
		if (ser.ReadVersion(version) == EO_OK)
		{
			printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
									   version.appDescription,
									   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
									   version.chipID,
									   SER_PORT);
		}
		//Failed to read the version of the device
		else
		{
			printf("Failed to retrieve USB300 version\n");
			return 0;
		}
		eoTimer::Sleep(1000);
		eoReCom recom(&myGateway);
		eoReManMessage answear(512);
		//recom.GetDeviceConfig({0, 0, 0}, 0x010021F7 );
		uint16_t recv;
		while(1)
		{
			recv = myGateway.Receive();
			if(recv & RECV_TELEGRAM)
			{
				eoDebug::Print(myGateway.telegram);

			}
			if(recv & RECV_REMAN)
			{
				eoDebug::Print(myGateway.reManMessage);
				switch(myGateway.reManMessage.fnCode)
				{
					case FN_RECOM_GET_METADATA:
					{
						answear.fnCode=FN_RECOM_GET_METADATA_RESPONSE;
						answear.dataLength=0x5;
						answear.manufacturerID=0x7ff;
						uint8_t metaDataResponse[] = {0xF0,0x03,0x03,0x03,0x03};
						memcpy(answear.data,metaDataResponse,5);
						myGateway.Send(answear);
					}
					break;
					case FN_RECOM_GET_PRODUCT_ID:
					{
						answear.fnCode=0x827;
						answear.dataLength=0x6;
						answear.manufacturerID=0x7ff;
						uint8_t productIdResponseData[] = {0x12, 0x34, 0xA1, 0xA2, 0x35, 0x54};
						memcpy(answear.data,productIdResponseData,6);
						myGateway.Send(answear);
					}
					break;
					case  FN_RECOM_GET_DEVICE_CONFIG_RESPONSE:
					{
						std::vector<DEVICE_CONFIG> deviceConf;
						eoReturn recomResponse = recom.ParseDeviceConfigResponse(deviceConf);
						std::cout << recomResponse << std::endl;
					}

				}
			}
			eoTimer::Sleep(10);
		}

		return 1;
}
int win32Test()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	std::string serialPort(SER_PORT);
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);

	printf("Opening Connection to USB300 \n");
	while (myGateway.Open(serialPort.c_str())!=EO_OK)
	{
		std::cout << "Failed to open USB300" << std::endl;
		std::cout << "Please enter an alternative port (e.g." << SER_PORT << ")" << std::endl;
		std::getline(cin,serialPort);
	}

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return 0;
	}

	eoTimer::Sleep(1000);
	printf("EnOcean-Link Gateway LearnMode\n");
	//adding a dBm Filter as learnFilter

	//the eoIDFilter will allow our Gateway application to filter all the unwanted Telegrams
	eoIDFilter * myFilter = new eoIDFilter();
	myGateway.filter=myFilter;

	//recv stores the return Value of the Gateway
	uint16_t recv;
	//As RPS Telegrams don't have a teach IN Telegram, we need to set the wished profiled for an automated Teach IN
	myGateway.TeachInModule->Set1BS(0x00, 0x01);
	myGateway.TeachInModule->Set4BS(0x12, 0x04);
	myGateway.TeachInModule->SetRPS(0x02,0x01);
	//Set the learnTime and update the time
	//Activate LearnMode
	myGateway.LearnMode=true;

	uint32_t const endTime = eoTimer::GetTickCount() + 1000*60*60*24*2;//*60*24;
	while(true)//(endTime>eoTimer::GetTickCount())
	{

		recv = myGateway.Receive();
		if (recv & RECV_TELEGRAM_ERP2)
		{
			eoDebug::Print(myGateway.telegramERP2);
		}
		else if (recv & RECV_TELEGRAM)
		{
			eoDebug::Print(myGateway.telegram);
		}

		if ((recv & RECV_TEACHIN))
		{
			eoProfile *profile = myGateway.device->GetProfile();
			printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", myGateway.device->ID, profile->rorg, profile->func, profile->type );


			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
			}
			if(typeid(*profile)==typeid(eoGenericProfile))
			{
				printf("Outbound Channels gpProfile:");
				eoGenericProfile * gpProfile=static_cast <eoGenericProfile *> (profile);
				for (int i = 0; i<gpProfile->GetChannelCountOut(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", gpProfile->GetChannelOut(i)->ToString(NAME), gpProfile->GetChannelOut(i)->min, gpProfile->GetChannelOut(i)->max, gpProfile->GetChannelOut(i)->ToString(UNIT));

				}
			}

		}

		if (recv & RECV_PROFILE)
		{
			printf("Device %08X\n", myGateway.device->ID);
			eoProfile *profile = myGateway.device->GetProfile();

			float f;
			uint8_t t;
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				if (profile->GetValue( profile->GetChannel(i)->type, f) ==EO_OK)
					printf("%s %.2f %s\n", profile->GetChannel(i)->ToString(NAME),f,profile->GetChannel(i)->ToString(UNIT));
				if (profile->GetValue( profile->GetChannel(i)->type, t) ==EO_OK)
									printf("%s %u \n", profile->GetChannel(i)->ToString(NAME),t);

			}
		}
	}
	return 0;
}

void secTest()
{

	eoGateway myGateway;
	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return;
	}
	printf("Gateway Connected \n");
	eoDevice &myDevice=*(myGateway.deviceManager->Add(0x04100167));

	eoSecureInfo &devOut = myDevice.secOut;
	devOut.SLF=SLF_DATA_ENC_VAES128|SLF_MAC_3BYTE|SLF_RLC_ALGO_24BIT;
	for(int i=0;i<16;i++)
	{
		devOut.psk[i]=i;
		devOut.key[i]=i+1;
	}
	devOut.keySize=16;
	devOut.rollingCode=0xAC06;
	devOut.teachInInfo=TEACH_INFO_PSK;

	printf("preparing message\n");
	eoProfile *sendProf = eoProfileFactory::CreateProfile(0xF6,0x02,0x01);
	//Parse our Message
	eoMessage mytel(40);
	//non secure testTelegram

	if(myGateway.security.CreateTeachIn(mytel,myDevice)!=EO_OK)
	{
		printf("Could not generate Teach In Telegram\n");
	}
	else
	{

		eoDebug::Print(mytel);
		//mytel.sourceID=0;
		if(myGateway.Send(mytel)!=EO_OK)
		{
			printf("Could not send Telegram!\n");
		}
	}
	eoMessage rpsTel(1);
	sendProf->SetValue(E_ROCKER_B,(uint8_t)0);
	sendProf->SetValue(E_ROCKER_A,(uint8_t)0);
	sendProf->SetValue(E_ENERGYBOW,(uint8_t)1);
	sendProf->Create(rpsTel);
	if(myGateway.security.Encrypt(rpsTel,mytel,myDevice))
	{
		printf("Could not Encrypt Telegram\n");
	}
	else
	{

		eoDebug::Print(rpsTel);
		eoDebug::Print(mytel);
		//mytel.sourceID=0;
		if(myGateway.Send(mytel)!=EO_OK)
		{
			printf("Could not send Telegram!\n");
		}
	}
	sendProf->SetValue(E_ROCKER_B,(uint8_t)1);
	sendProf->SetValue(E_ROCKER_A,(uint8_t)1);
	sendProf->SetValue(E_ENERGYBOW,(uint8_t)0);
	sendProf->Create(rpsTel);
	if(myGateway.security.Encrypt(rpsTel,mytel,myDevice))
	{
		printf("Could not Encrypt Telegram\n");
	}
	else
	{

		eoDebug::Print(rpsTel);
		eoDebug::Print(mytel);
		//mytel.sourceID=0;
		if(myGateway.Send(mytel)!=EO_OK)
		{
			printf("Could not send Telegram!\n");
		}
	}
	myGateway.Close();
	delete sendProf;
}

void secSender()
{
eoGateway myGateway;
myGateway.deviceManager->Add(0x0080A6F2);
eoDevice &myDevice=*(myGateway.deviceManager->Get(0x0080A6F2));
eoSecureInfo &devOut = myDevice.secOut;
devOut.SLF=SLF_DATA_ENC_AES128|SLF_MAC_3BYTE|SLF_RLC_ALGO_16BIT;
for(int i=0;i<16;i++)
	devOut.key[i]=i+1;

devOut.keySize=16;
devOut.rollingCode=0xAC03;
devOut.teachInInfo=TEACH_INFO_PTM|TEACH_INFO_PTM_ROCKERA;

printf("Opening Connection to USB300 \n");
if (myGateway.Open(SER_PORT)!=EO_OK)
{
	printf("Failed to open USB300\n");
	return;
}

eoMessage TeachInMessage(30);
eoProfile* Tigris=eoProfileFactory::CreateProfile(0xD2,0x03,0x00);
myGateway.security.CreateTeachIn(TeachInMessage,myDevice);
printf("Sending TeachIn Message \n");
eoDebug::Print(TeachInMessage);
myGateway.Send(TeachInMessage);

eoMessage msg;
eoMessage secureMsg;
Tigris->SetValue(E_ROCKER_B,(uint8_t)0);
Tigris->SetValue(E_ROCKER_A,(uint8_t)0);
Tigris->SetValue(E_ENERGYBOW,(uint8_t)1);
Tigris->Create(msg);
eoDebug::Print(msg);
msg.RORG=RORG_SECD;
if(myGateway.security.Encrypt(msg,secureMsg,myDevice)==EO_OK)
{
	printf("Sending Encrypted Message\n");
	eoDebug::Print(secureMsg);
	myGateway.Send(secureMsg);
}
else
{
	printf("Could not encrypt Message: %d \n",myGateway.security.GetLastError());
}

return;
}

void secReciver()
{
	eoGateway myGateway;

	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return;
	}
	//Loading the prepared Configuartion
	eoStorageManager myStore;
	myStore.addObject("Gateway",&myGateway);
	printf("Prepare to Load Config \n");
	//	myStore.Load(LOAD_CONFIG);
	myGateway.TeachInModule->SetRPS(2,01);

	uint16_t recv;
	//we use in this example a 1BS Telegram, to send an Alarm Flag, which type of messsage is not specified!
	eoMessage myMessage = eoMessage(1);
	myMessage.RORG=RORG_1BS;
	myMessage.data[0]=0xFF;
	printf("Gateway is running \n");
	uint32_t learnTime=eoTimer::GetTickCount()+10*1000;
	uint32_t time=eoTimer::GetTickCount();
	//Activate LearnMode
	myGateway.LearnMode=true;
	while(1)
	{
		//updates the time, using the HAL getTickCount function
		time=eoTimer::GetTickCount();
		//updates the time, using the HAL getTickCount function
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = myGateway.Receive();
		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)	if (recv & RECV_TEACHIN)

		if (recv & RECV_TEACHIN)
		{
			//add the Source ID to the Normale Mode Filter
			//Print out the Message to stdout
			eoDebug::Print(myGateway.telegram);
			//If the TeachIN process was successfull and we got a Profile print out the Message!
			eoProfile *profile = myGateway.device->GetProfile();
			if(profile!=NULL)
			{
				printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", myGateway.device->ID, profile->rorg, profile->func, profile->type );

				for (int i = 0; i<profile->GetChannelCount(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
				}

			}
		}
		else if (recv & RECV_PROFILE)
		{
			printf("Device %08X\n", myGateway.device->ID);
			eoProfile *profile = myGateway.device->GetProfile();

			float f;
			uint8_t t;
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				//get the channel value if it is a float
				if (profile->GetValue( profile->GetChannel(i)->type, f) ==EO_OK)
					printf("%s %.2f %s\n", profile->GetChannel(i)->ToString(NAME),f,profile->GetChannel(i)->ToString(UNIT));
				//get the channel value if it is an uint
				if (profile->GetValue( profile->GetChannel(i)->type, t) ==EO_OK)
					printf("%s %u \n", profile->GetChannel(i)->ToString(NAME),t);

			}

		}
		else if(recv & RECV_MESSAGE)
		{
			eoDebug::Print(myGateway.message);
		}
	}
}


void chainedMsg()
{
	eoGateway myGateway;
	eoMessage TeachInMessage(64);
	TeachInMessage.sourceID=0x00;
	TeachInMessage.destinationID=BROADCAST_ID;
	TeachInMessage.RORG=GP_CD;
	for(int i=0;i<64;i++)
		TeachInMessage.data[i]=i+1;
	TeachInMessage.SetDataLength(64);
	myGateway.Send(TeachInMessage);

}

void remanSend()
{
	eoGateway myGateway;

	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return;
	}

/*
	msg.dataLength = 200;
	for(int i=0;i<msg.dataLength;i++)
		msg.data[i]=i;
	msg.fnCode = 0x612;
	msg.manufacturerID = 0x0B;
*/
 	eoReManMessage msg(256);
	uint16_t recv;

	while (1)
	{
		recv = myGateway.Receive();
		if (recv & RECV_TELEGRAM)
		{
			eoDebug::Print(myGateway.telegram);
		}
		if (recv & RECV_REMAN)
		{
			myGateway.reManMessage.destinationID = 0x0080AFF1;
			eoDebug::Print(myGateway.reManMessage);
			myGateway.Send(myGateway.reManMessage);
		}
	}
}

int svenFenster()
{
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	std::string serialPort(SER_PORT);
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);

	printf("Opening Connection to USB300 \n");
	while (myGateway.Open(serialPort.c_str())!=EO_OK)
	{
		std::cout << "Failed to open USB300" << std::endl;
		std::cout << "Please enter an alternative port (e.g." << SER_PORT << ")" << std::endl;
		std::getline(cin,serialPort);
	}

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return 0;
	}

	eoTimer::Sleep(1000);
	printf("EnOcean-Link Gateway LearnMode\n");
	//adding a dBm Filter as learnFilter

	//recv stores the return Value of the Gateway
	uint16_t recv;
	//As RPS Telegrams don't have a teach IN Telegram, we need to set the wished profiled for an automated Teach IN

	myGateway.TeachInModule->SetRPS(0x10,0x00);
	//Set the learnTime and update the time
	//Activate LearnMode
	myGateway.LearnMode=true;

	while(1)
	{

		recv = myGateway.Receive();

		if ((recv & RECV_PROFILE) && myGateway.telegram.RORG==0xF6)
		{
			eoDebug::Print(myGateway.telegram);
			if((myGateway.telegram.data[0]&0xD0)==0xC0)
			{
				printf("Handle is in the middle\n");
			}
			if((myGateway.telegram.data[0]&0xF0)==0xF0)
			{
				printf("Handle is down\n");
			}
			if((myGateway.telegram.data[0]&0xF0)==0xD0)
			{
				printf("Handle is at the top \n");
			}
		}
	}
	return 0;
}

void test()
{

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
	//First a Gateway and a storageManager will be definied
	std::string serialPort(SER_PORT);
	eoGateway myGateway;
	eoSerialCommand ser(&myGateway);

	printf("Opening Connection to USB300 \n");
	while (myGateway.Open(serialPort.c_str())!=EO_OK)
	{
		std::cout << "Failed to open USB300" << std::endl;
		std::cout << "Please enter an alternative port (e.g." << SER_PORT << ")" << std::endl;
		std::getline(cin,serialPort);
	}

	CO_RD_VERSION_RESPONSE version;
	if (ser.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return;
	}
	//Create an own gp Profile...

	//Create and send teach IN


	// Do something with it!

}

int main(int argc, const char* argv[])
{
	uint8_t packet32Bit[20] ={0x3F,0x02,0x03,0xAA,0xBB,0xCC,0xDD,0x11,0x22,0x33,0x44
			,0x55,0x66,0x77,0x88,0x11,0x22,0x00,0x01,0x02};
	eoPacket packet(packet32Bit,20);
	packet.type = PACKET_RADIO_ADVANCED;
	packet.dataLength=18;
	packet.optionalLength=2;
	eoTelegramERP2 erp2Telegram(255);
	eoConverter::advancedPacketToRadio(packet,erp2Telegram);
	//test();
	win32Test();
	//recomTest();
	//win32Test();
	//vld_example();
	//recomTest();
	//gpTest();
	//svenFenster();
	//secTest();
	//secSender();
	//secReciver();
	//chainedMsg();
	//secSender();
	//remanSend();
}

