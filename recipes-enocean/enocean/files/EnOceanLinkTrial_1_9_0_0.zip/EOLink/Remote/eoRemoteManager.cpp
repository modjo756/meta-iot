/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoGateway.h"
#include "eoRemoteManager.h"
#include "eoManufacturer.h"

eoRemoteManager::eoRemoteManager(eoGateway *gateway)
	:reManMessage(512)
{
	this->gateway = gateway;
	shallBeRepeated = false;
}

eoRemoteManager::~eoRemoteManager()
{
}

eoReturn eoRemoteManager::UnLock(const uint32_t securityCode, const uint32_t destinationID)
{
	if(reManMessage.SetDataLength(4)!=EO_OK)
		return OUT_OF_RANGE;

	reManMessage.data[0] = (uint8_t)(securityCode >> 24);
	reManMessage.data[1] = (uint8_t)(securityCode >> 16);
	reManMessage.data[2] = (uint8_t)(securityCode >> 8);
	reManMessage.data[3] = (uint8_t)securityCode;

	reManMessage.fnCode = FN_UNLOCK;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::Lock(const uint32_t securityCode, const uint32_t destinationID)
{
	if(reManMessage.SetDataLength(4)!=EO_OK)
		return OUT_OF_RANGE;

	reManMessage.data[0] = (uint8_t)(securityCode >> 24);
	reManMessage.data[1] = (uint8_t)(securityCode >> 16);
	reManMessage.data[2] = (uint8_t)(securityCode >> 8);
	reManMessage.data[3] = (uint8_t)securityCode;

	reManMessage.fnCode = FN_LOCK;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::SetCode(const uint32_t securityCode, const uint32_t destinationID)
{
	if(reManMessage.SetDataLength(4)!=EO_OK)
		return OUT_OF_RANGE;

	reManMessage.data[0] = (uint8_t)(securityCode >> 24);
	reManMessage.data[1] = (uint8_t)(securityCode >> 16);
	reManMessage.data[2] = (uint8_t)(securityCode >> 8);
	reManMessage.data[3] = (uint8_t)securityCode;

	reManMessage.fnCode = FN_SETCODE;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::Action(const uint32_t destinationID)
{
	if(reManMessage.SetDataLength(0)!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.fnCode = FN_ACTION;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::Ping(const uint32_t destinationID)
{
	if(reManMessage.SetDataLength(0)!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.fnCode = FN_PING;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;
	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParsePingAnswer(PING_RESPONSE &response)
{
	if (gateway->reManMessage.fnCode != FN_PING_ANSWER || gateway->reManMessage.GetDataLength() != 4)
		return NOT_SUPPORTED;

	response.rorg = gateway->reManMessage.data[0];
	response.func = gateway->reManMessage.data[1] >> 2 & 0x3F;
	response.type = ((gateway->reManMessage.data[1] << 5) | (gateway->reManMessage.data[2] >> 3)) & 0x7F;
	response.rssi = gateway->reManMessage.data[3];
	return EO_OK;
}

eoReturn eoRemoteManager::QueryID(const QUERY_ID &msg)
{
	if(reManMessage.SetDataLength(3)!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = msg.rorg;
	reManMessage.data[1] = (msg.func << 2) | (msg.type >> 5);
	reManMessage.data[2] = msg.type << 3;
	reManMessage.fnCode = FN_QUERYID;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = BROADCAST_ID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParseQueryIDAnswer(QUERY_ID_RESPONSE &response)
{
	if (gateway->reManMessage.fnCode != FN_QUERYID_ANSWER_EXT || gateway->reManMessage.GetDataLength() != 4)
		return NOT_SUPPORTED;

	response.rorg = gateway->reManMessage.data[0];
	response.func = (gateway->reManMessage.data[1] >> 2) & 0x7F;
	response.type = ((gateway->reManMessage.data[1] << 5) | gateway->reManMessage.data[2] >> 3) & 0x7F;
	response.locked = (gateway->reManMessage.data[3] >> 0x07) & 0x01;
	return EO_OK;
}

eoReturn eoRemoteManager::ParseQueryIDAnswer(QUERY_ID &response)
{
	if (gateway->reManMessage.fnCode != FN_QUERYID_ANSWER || gateway->reManMessage.GetDataLength() != 3)
		return NOT_SUPPORTED;

	response.rorg = gateway->reManMessage.data[0];
	response.func = (gateway->reManMessage.data[1] >> 2) & 0x7F;
	response.type = ((gateway->reManMessage.data[1] << 5) | gateway->reManMessage.data[2] >> 3) & 0x7F;
	return EO_OK;
}

eoReturn eoRemoteManager::QueryFunction(const uint32_t destinationID)
{
	if(reManMessage.SetDataLength(0)!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.fnCode = FN_QUERY_FUNCTION;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParseQueryFunctionAnswer(QUERY_FUNCTION_RESPONSE *response, uint8_t maxIDCount, uint8_t &IDCount)
{
	if (gateway->reManMessage.fnCode != FN_QUERY_FUNCTION_ANSWER || (gateway->reManMessage.GetDataLength() % 4) != 0)
		return NOT_SUPPORTED;

	IDCount = (uint8_t)(gateway->reManMessage.GetDataLength() / 4);
	for (uint8_t i = 0; i < IDCount && i < maxIDCount; i++)
	{
		response[i].functionNum = (gateway->reManMessage.data[i * 4] << 8) | gateway->reManMessage.data[i * 4 + 1];
		response[i].manufaturerID = (gateway->reManMessage.data[i * 4 + 2] << 8) | gateway->reManMessage.data[i * 4 + 3];
	}
	return EO_OK;
}

eoReturn eoRemoteManager::QueryStatus(uint32_t destinationID)
{
	if(reManMessage.SetDataLength(0)!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0;
	reManMessage.fnCode = FN_QUERY_STATUS;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParseQueryStatusAnswer(QUERY_STATUS_RESPONSE &response)
{
	if (gateway->reManMessage.fnCode != FN_QUERY_STATUS_ANSWER || gateway->reManMessage.GetDataLength() != 4)
		return NOT_SUPPORTED;

	response.codeSetFlag = (gateway->reManMessage.data[0] & 0x80) != 0;
	response.lastSEQ = gateway->reManMessage.data[0] & 0x03;
	response.lastFunc = (gateway->reManMessage.data[1] & 0xF) << 8 | gateway->reManMessage.data[2];
	response.lastFuncRet = gateway->reManMessage.data[3];
	return EO_OK;
}

eoReturn eoRemoteManager::RemoteLearnIn(const uint32_t destinationID, REMOTE_TYPE learnFlag)
{
	if(reManMessage.SetDataLength(4)!=EO_OK)
		return OUT_OF_RANGE;

	// EEP - omitted by default
	reManMessage.data[0] = 0x00; //RORG
	reManMessage.data[1] = 0x00; //Func
    reManMessage.data[2] = 0x00; //Type:5, MaskBytes:3

	reManMessage.data[3] = (uint8_t)learnFlag;
	reManMessage.fnCode = FN_REMOTE_LEARNIN;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::RemoteFlashWrite(const uint32_t destinationID, const uint16_t &memoryAddress, const uint16_t numOfBytes, const uint8_t data[])
{
	if(reManMessage.SetDataLength( 4 + numOfBytes)!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = memoryAddress >> 8;
	reManMessage.data[1] = memoryAddress & 0xFF;
	reManMessage.data[2] = numOfBytes >> 8;
	reManMessage.data[3] = numOfBytes & 0xFF;

	for (uint8_t i = 0; i < numOfBytes; i++)
	{
		reManMessage.data[4 + i] = data[i];
	}

	reManMessage.fnCode = FN_REMOTE_FLASH_WRITE;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::RemoteFlashRead(const uint32_t destinationID, const uint16_t &memoryAddress, const uint16_t numOfBytes)
{
	if(reManMessage.SetDataLength( 4 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = memoryAddress >> 8;
	reManMessage.data[1] = memoryAddress & 0xFF;
	reManMessage.data[2] = numOfBytes >> 8;
	reManMessage.data[3] = numOfBytes & 0xFF;

	reManMessage.fnCode = FN_REMOTE_FLASH_READ;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParseRemoteFlashReadAnswer(FLASH_READ_RESPONSE *response, uint16_t *dataCount, uint8_t maxDataCount)
{
	if (gateway->reManMessage.fnCode != FN_REMOTE_FLASH_READ_ANSWER)
		return NOT_SUPPORTED;

	*dataCount = gateway->reManMessage.GetDataLength();

	for (uint8_t i = 0; i < *dataCount && i < maxDataCount; i++)
		response[i].data = gateway->reManMessage.data[i];
	return EO_OK;
}

eoReturn eoRemoteManager::RemoteSmartReadMailboxSettings(const uint32_t destinationID)
{
	if(reManMessage.SetDataLength( 1 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0x01;

	reManMessage.fnCode = FN_SMARTACK_READ;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParseRemoteSmartReadMailboxSettingsAnswer(MAILBOX_SETTINGS_RESPONSE &response)
{
	if (gateway->reManMessage.fnCode != FN_SMARTACK_READ_MAILBOX_ANSWER || gateway->reManMessage.GetDataLength() != 4)
		return NOT_SUPPORTED;

	response.flashAddress = (gateway->reManMessage.data[0] << 8) | gateway->reManMessage.data[1];
	response.mailboxCount = (gateway->reManMessage.data[2] << 8) | gateway->reManMessage.data[3];
	return EO_OK;
}

eoReturn eoRemoteManager::RemoteSmartReadLearnedSensors(const uint32_t destinationID)
{
	if(reManMessage.SetDataLength( 1 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0x02;

	reManMessage.fnCode = FN_SMARTACK_READ;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::ParseRemoteSmartReadLearnedSensors(LEARNED_SENSOR_RESPONSE *response, uint8_t *learnedCount, uint8_t maxLearnedCount)
{
	if (gateway->reManMessage.fnCode != FN_SMARTACK_READ_LEARNED_SENSOR_ANSWER)
		return NOT_SUPPORTED;

	*learnedCount = (uint8_t)(gateway->reManMessage.GetDataLength() / 9);

	for (uint8_t i = 0; i < *learnedCount && i < maxLearnedCount; i++)
	{
		response[i].sensorID = (gateway->reManMessage.data[i * 9] << 24) | (gateway->reManMessage.data[i * 9 + 1] << 16) | (gateway->reManMessage.data[i * 9 + 2] << 8) | gateway->reManMessage.data[i * 9 + 3];
		response[i].controllerID = (gateway->reManMessage.data[i * 9 + 4] << 24) | (gateway->reManMessage.data[i * 9 + 5] << 16) | (gateway->reManMessage.data[i * 9 + 6] << 8) | gateway->reManMessage.data[i * 9 + 7];
		response[i].learnedCount = gateway->reManMessage.data[i * 9 + 8];
	}
	return EO_OK;
}

eoReturn eoRemoteManager::RemoteSmartAddMailbox(const uint32_t destinationID, const uint8_t mailboxIndex, const uint32_t sensorID, const uint32_t postmasterID)
{
	if(reManMessage.SetDataLength( 10 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0x01;
	reManMessage.data[1] = mailboxIndex;

	reManMessage.data[2] = (uint8_t)(sensorID >> 24);
	reManMessage.data[3] = (uint8_t)(sensorID >> 16);
	reManMessage.data[4] = (uint8_t)(sensorID >> 8);
	reManMessage.data[5] = (uint8_t)sensorID;

	reManMessage.data[6] = (uint8_t)(postmasterID >> 24);
	reManMessage.data[7] = (uint8_t)(postmasterID >> 16);
	reManMessage.data[8] = (uint8_t)(postmasterID >> 8);
	reManMessage.data[9] = (uint8_t)postmasterID;

	reManMessage.fnCode = 0x206;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::RemoteSmartDeleteMailbox(const uint32_t destinationID, const uint8_t mailboxIndex)
{
	if(reManMessage.SetDataLength( 10 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0x02;
	reManMessage.data[1] = mailboxIndex;

	for (uint8_t i = 2; i < 10; i++)
		reManMessage.data[i] = 0;

	reManMessage.fnCode = 0x206;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::RemoteSmartLearnIn(const uint32_t destinationID, const uint8_t learnCount, const uint32_t sensorID, const uint32_t controllerID)
{
	if(reManMessage.SetDataLength( 10 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0x03;
	reManMessage.data[1] = learnCount;

	reManMessage.data[2] = (uint8_t)(sensorID >> 24);
	reManMessage.data[3] = (uint8_t)(sensorID >> 16);
	reManMessage.data[4] = (uint8_t)(sensorID >> 8);
	reManMessage.data[5] = (uint8_t)sensorID;

	reManMessage.data[6] = (uint8_t)(controllerID >> 24);
	reManMessage.data[7] = (uint8_t)(controllerID >> 16);
	reManMessage.data[8] = (uint8_t)(controllerID >> 8);
	reManMessage.data[9] = (uint8_t)controllerID;

	reManMessage.fnCode = 0x206;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}

eoReturn eoRemoteManager::RemoteSmartLearnOut(const uint32_t destinationID, const uint8_t learnCount, const uint32_t sensorID, const uint32_t controllerID)
{
	if(reManMessage.SetDataLength( 10 )!=EO_OK)
		return OUT_OF_RANGE;
	reManMessage.data[0] = 0x04;
	reManMessage.data[1] = learnCount;

	reManMessage.data[2] = (uint8_t)(sensorID >> 24);
	reManMessage.data[3] = (uint8_t)(sensorID >> 16);
	reManMessage.data[4] = (uint8_t)(sensorID >> 8);
	reManMessage.data[5] = (uint8_t)sensorID;

	reManMessage.data[6] = (uint8_t)(controllerID >> 24);
	reManMessage.data[7] = (uint8_t)(controllerID >> 16);
	reManMessage.data[8] = (uint8_t)(controllerID >> 8);
	reManMessage.data[9] = (uint8_t)controllerID;

	reManMessage.fnCode = 0x206;
	reManMessage.manufacturerID = MULTI_USER_MANUFACTURER;
	reManMessage.sourceID = 0;
	reManMessage.destinationID = destinationID;

	return gateway->Send(reManMessage, shallBeRepeated);
}
