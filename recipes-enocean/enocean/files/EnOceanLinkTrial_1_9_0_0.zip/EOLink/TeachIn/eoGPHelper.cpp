#include "eoGPHelper.h"

eoReturn eoGPHelper::CreateGPResponse(eoMessage &msg, uint16_t manId, uint32_t destinationId, GP_RESPONSE_RESULT response, eoProfile *profile)
{
	uint8_t numOfBytes = 1;
	eoReturn ret = msg.SetDataLength(numOfBytes + 1);
	if(ret!= EO_OK)
		return ret;
	msg.RORG = GP_TR;
	msg.data[0] = 0;
	msg.data[1] = 0;
	msg.destinationID = destinationId;
	if (response == RESP_REJECTED_CHANNELS)
	{
		numOfBytes++;
		ret= msg.SetDataLength(2+((eoGenericProfile*)profile)->GetChannelCount()/7+((eoGenericProfile*)profile)->GetChannelCountOut()/7+2);
		if(ret!= EO_OK)
			return ret;
		uint8_t numOfBits = 0;
		for (int i = 0; i < profile->GetChannelCount(); i++, numOfBits++)
		{
			if (((eoGPChannelInfo*)profile->GetChannel(i))->GetRejected() != 1)
			{
				msg.data[numOfBytes] |= 0x01 << (7-(numOfBits % 8));
			}
			if (i == 7)
			{
				numOfBytes++;
			}
		}

		for (int i = 0; i < ((eoGenericProfile*)profile)->GetChannelCountOut(); i++, numOfBits++)
		{
			if (((eoGPChannelInfo*)((eoGenericProfile*)profile)->GetChannelOut(i))->GetRejected() != 1)
			{
				msg.data[numOfBytes] |= 0x01 << (7-(numOfBits % 8));
			}
			if (i == 7)
			{
				numOfBytes++;
			}
		}
		ret = msg.SetDataLength(numOfBytes);
	}
	if (ret == EO_OK)
	{
		msg.data[0] = (manId >> 3) & 0xFF;
		msg.data[1] = (manId & 7) << 5;
		msg.data[1] |= response << 3;
	}
	return ret;
}
