/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoTeachInModule.h"
#include "eoMessage.h"
#include "eoDeviceManager.h"
#include "eoSecurity.h"
#include "eoProfileFactory.h"
#include "eoGPChannelInfo.h"
#include "eoGenericProfile.h"
#include "eoConverter.h"
#include "eoUTEHelper.h"
#include "eoTeachMessageHandler.h"
#include "eoGPHelper.h"
eoTeachInModule::eoTeachInModule(eoDeviceManager *eoDevManager, eoSecurity *sec)
{
	deviceManager = eoDevManager;
	security = sec;
	rps_func = 0;
	rps_type = 0;
	bs1_func = 0;
	bs1_type = 0;
	bs4_func = 0;
	bs4_type = 0;
	allowAutoTeachOut=false;
}

eoTeachInModule::~eoTeachInModule()
{
	teachInformation.clear();
}

bool eoTeachInModule::isTeachIN(eoMessage &m)
{
	bool retBool = false;
	//RPS Does not have "TeachIn", this is why all RPS are handles as TeachIN
	if (m.RORG == RORG_RPS)
		retBool = true;
	if ((m.RORG == RORG_4BS) && (m.data[3] & 0x08) == 0x00)
		retBool = true;
	else if ((m.RORG == RORG_1BS) && (m.data[0] & 0x08) == 0x00)
		retBool = true;
	else if (m.RORG == GP_TI)
		retBool = true;
	else if (m.RORG == RORG_UTE)
		retBool = true;
	else if (m.RORG == RORG_SEC_TI)
		retBool = true;
	return retBool;
}

void eoTeachInModule::TeachOut(uint32_t id)
{
	deviceManager->Remove(id);
	teachInformation.erase(id);
}

bool eoTeachInModule::isTeachedIN(uint32_t deviceID)
{
	bool retBool = false;
	if (teachInformation.find(deviceID) != teachInformation.end())
		retBool = (teachInformation[deviceID]);

	return retBool;
}
bool eoTeachInModule::isTeachedIN(eoMessage &m)
{
	return isTeachedIN(m.sourceID);
}

bool eoTeachInModule::isTeachedIN(eoDevice &dev)
{
	return isTeachedIN(dev.ID);
}

TEACH_RETURN eoTeachInModule::TeachIN(uint8_t rorg,uint8_t func,uint8_t type,uint32_t device_id)
{
	TEACH_RETURN ret = NO_TEACH_IN;
	eoDevice* device = deviceManager->Get(device_id);
	eoProfile *profile = NULL;

	if (device == NULL)
	{
		device = deviceManager->Add(device_id);
		ret = NEW_DEVICE;
	}
	
	if (IsDeviceTeachedIn(device_id))
	{
		ret = SECOND_TEACH_IN;
	}
	if(ret!=SECOND_TEACH_IN)
	{
		profile = eoProfileFactory::CreateProfile(rorg, func, type);
		ret = EEP_TEACH_IN;
	}
	if(device->SetProfile(profile) != EO_OK && ret != SECOND_TEACH_IN)
	{
		ret = NO_TEACH_IN;
		TeachOut(device_id);
		delete profile;
	}
	else
	{
		teachInformation[device_id] = true;
	}
	return ret;
}
UTE_EEP_TEACH_IN_QUERY eoTeachInModule::GetUTEQuery()
{
	return uteQuery;
}
bool eoTeachInModule::LinkProfileToDevice(eoDevice * device, eoProfile * profile)
{
	if (profile == NULL)
		return false;
	if (device->SetProfile(profile) == EO_OK)
	{
		teachInformation[device->ID] = true;
		return true;
	}

	delete profile;
	return true;
}

bool eoTeachInModule::IsDeviceTeachedIn(uint32_t deviceID)
{
	if (teachInformation.find(deviceID) == teachInformation.end())
	{
		teachInformation[deviceID] = false;
	}
	return teachInformation[deviceID];
}
bool  eoTeachInModule::IsDuplicatedSimpleTeachInMessage(eoMessage &m)
{
	return IsDeviceTeachedIn(m.sourceID) && 
						   isTeachIN(m)  && 
		   !(m.RORG == RORG_UTE || m.RORG == GP_TI);
}

TEACH_RETURN eoTeachInModule::TeachIN(eoMessage &m)
{
	if (!isTeachIN(m))
		return NO_TEACH_IN;

	if(IsDuplicatedSimpleTeachInMessage(m))
	{
		return SECOND_TEACH_IN;
	}
	eoTeachMessageHandler handler(*this, m);
	return handler.ParseMessage();
}

void eoTeachInModule::SetRPS(uint8_t func, uint8_t type)
{
	rps_func = func;
	rps_type = type;
}

void eoTeachInModule::Set1BS(uint8_t func, uint8_t type)
{
	bs1_func = func;
	bs1_type = type;
}

void eoTeachInModule::Set4BS(uint8_t func, uint8_t type)
{
	bs4_func = func;
	bs4_type = type;
}
eoReturn eoTeachInModule::ParseUTE(eoMessage &msg)
{
	return 	eoUTEHelper::ParseUTE(msg, uteQuery);
}

eoReturn eoTeachInModule::CreateUTEResponse(eoMessage &teachInUTE, eoMessage &responseUTE, UTE_RESPONSE type = TEACH_IN_ACCEPTED, UTE_DIRECTION direction = UTE_DIRECTION_BIDIRECTIONAL)
{

	if (teachInUTE.copyTo(responseUTE) != EO_OK)
		return OUT_OF_RANGE;
	UTE_EEP_TEACH_IN_QUERY tmpQuery;
	eoUTEHelper::ParseUTE(teachInUTE, tmpQuery);

	responseUTE.sourceID = 0;
	responseUTE.destinationID = teachInUTE.sourceID;

	return 	eoUTEHelper::CreateUTEResponseFromQuery(tmpQuery, responseUTE, type, direction);
}

eoReturn eoTeachInModule::CreateGPResponse(eoMessage &msg, uint16_t manId, uint32_t destinationId, GP_RESPONSE_RESULT response, eoProfile *profile)
{
	return eoGPHelper::CreateGPResponse(msg,manId,destinationId,response,profile);
}

uint8_t eoTeachInModule::Serialize(eoArchive &arch)
{
	arch & "myDeviceManager" & deviceManager;
	arch & "rps_func" & rps_func;
	arch & "rps_type" & rps_type;
	arch & "bs1_func" & bs1_func;
	arch & "bs1_type" & bs1_type;
	arch & "bs4_func" & bs4_func;
	arch & "bs4_type" & bs4_type;
	arch & "allowAutoTeachOut" & allowAutoTeachOut;
	teach_id_map::iterator it;
	if (arch.isStoring)
	{
		uint32_t tmpCnt = (uint32_t)teachInformation.size();
		arch & "Counter" & tmpCnt;
		if (tmpCnt == 0)
			return EO_OK;
		if (tmpCnt > 0x0000FFFF)
			return EO_ERROR;
		tmpCnt = 0;
		for (it = teachInformation.begin(); it != teachInformation.end(); ++it)
		{
			char tmpName[14] = "TBDevice_";
			tmpName[9] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 12));
			tmpName[10] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 8));
			tmpName[11] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 4));
			tmpName[12] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 0));
			tmpName[13] = 0;
			tmpCnt++;
			//could be a NULL pointer, shouldn't be...
			arch & tmpName & ((*it).second);
			tmpName[1] = 'I'; 
			uint32_t tmpID = ((*it).first);
			arch & tmpName & tmpID;
		}
	}
	else
	{
		uint16_t tmpCnt;
		uint16_t cnt = 0;
		arch & "Counter" & cnt;
		for (tmpCnt = 0; tmpCnt < cnt; tmpCnt++)
		{
			char tmpName[14] = "TBDevice_";
			tmpName[9] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 12));
			tmpName[10] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 8));
			tmpName[11] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 4));
			tmpName[12] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 0));
			tmpName[13] = 0;
			tmpCnt++;
			bool tmpTeachInfo;
			arch & tmpName & tmpTeachInfo;
			tmpName[1] = 'I';
			uint32_t tmpID ;
			arch & tmpName & tmpID;
			teachInformation[tmpID] = tmpTeachInfo;
		}
	}

	return EO_OK;
}
