/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoTeachMessageHandler.h"
#include "eoProfileFactory.h"
#include "eoUTEHelper.h"
#include "eoSecurity.h"

static bool TeachInfoIsPTM210(eoDevice * device)
{
	return device->secIn.teachInInfo & 0x04;
}

eoTeachMessageHandler::eoTeachMessageHandler(eoTeachInModule &teachInModule, eoMessage &teachMessage) : teachInModule(teachInModule), teachMessage(teachMessage)
{
	profile = NULL;
	deviceManager = teachInModule.deviceManager;
	ret = NO_TEACH_IN;
}

void eoTeachMessageHandler::HandleTeachResult()
{
	switch (ret)
	{
		case NEW_DEVICE:
			teachInModule.TeachOut(teachMessage.sourceID);
			ret = NO_TEACH_IN;
			break;
		case SECOND_TEACH_IN:
		case NO_TEACH_IN:
			break;
		case REQUEST_FOR_TEACH_OUT:
			if (teachInModule.allowAutoTeachOut)
				teachInModule.TeachOut(device->ID);
			break;
		case SECURITY_TEACH_IN:
			if (teachInModule.LinkProfileToDevice(device, profile))
			{
				ret = EEP_TEACH_IN;
			}
			break;
		default:
			if (!teachInModule.LinkProfileToDevice(device, profile))
			{
				ret = NO_TEACH_IN;
				teachInModule.TeachOut(teachMessage.sourceID);
			}
			break;
	}
}
void eoTeachMessageHandler::GetOrCreateDevice()
{
	device = deviceManager->Get(teachMessage.sourceID);

	if (device == NULL)
	{
		device = deviceManager->Add(teachMessage.sourceID);
		ret = NEW_DEVICE;
	}
}
void eoTeachMessageHandler::Handle4BS()
{
	if ((teachMessage.data[3] & 0x88) == 0x00)
	{
		profile = eoProfileFactory::CreateProfile(RORG_4BS, teachInModule.bs4_func, teachInModule.bs4_type);
		ret = EEP_TEACH_IN;
	}
	else if ((teachMessage.data[3] & 0x88) == 0x80)
	{
		profile = eoProfileFactory::CreateProfile(teachMessage);
		ret = EEP_TEACH_IN;
	}
}
void eoTeachMessageHandler::HandleRPS()
{
	profile = eoProfileFactory::CreateProfile(RORG_RPS, teachInModule.rps_func, teachInModule.rps_type);
	ret = EEP_TEACH_IN;
}
void eoTeachMessageHandler::Handle1BS()
{
	profile = eoProfileFactory::CreateProfile(RORG_1BS, teachInModule.bs1_func, teachInModule.bs1_type);
	ret = EEP_TEACH_IN;
}
void eoTeachMessageHandler::HandleGP_TI()
{
	if (((teachMessage.data[1] & 0x0C) == 0x08))
	{
		ret = NO_TEACH_IN;
	}
	else
	{
		profile = eoProfileFactory::CreateProfile(teachMessage);
		ret = GENERIC_TEACH_IN;
	}
}

void eoTeachMessageHandler::HandleSEC_TI()
{
	if (teachInModule.security->ParseTeachIn(teachMessage, *device) == EO_OK)
	{
		ret = SECURITY_TEACH_IN;
		if (TeachInfoIsPTM210(device))
		{
			profile = eoProfileFactory::CreateProfile(0xD2, 0x03, 00);
		}
	}
}
void eoTeachMessageHandler::HandleUTE()
{
	if (eoUTEHelper::ParseUTE(teachMessage, teachInModule.uteQuery) != EO_OK)
		return;

	switch (teachInModule.uteQuery.request)
	{
		case TEACH_IN_REQUEST:
			if (teachInModule.isTeachedIN(teachMessage.sourceID))
				ret = SECOND_TEACH_IN;
			else
			{
				CreateProfileFromUTE();
			}
			break;
		case TEACH_OUT_REQUEST:
			if (teachInModule.isTeachedIN(teachMessage.sourceID))
				ret = REQUEST_FOR_TEACH_OUT;
			break;
		case  TEACH_UNKNOW_REQUEST:
			if (teachInModule.isTeachedIN(teachMessage.sourceID))
				ret = REQUEST_FOR_TEACH_OUT;
			else
			{
				CreateProfileFromUTE();
			}
			break;
		default:
			ret=NO_TEACH_IN;
			break;
	}
}
void eoTeachMessageHandler::CreateProfileFromUTE()
{
	profile = eoProfileFactory::CreateProfile(teachInModule.uteQuery.rorg, teachInModule.uteQuery.func, teachInModule.uteQuery.type);
	if (profile != NULL)
	{
		(profile)->manufacturer = teachInModule.uteQuery.manufacturerID;
		ret = EEP_TEACH_IN;
	}
}
void eoTeachMessageHandler::HandleMessage()
{
	switch (teachMessage.RORG)
	{
	case RORG_4BS:
		Handle4BS();
		break;
	case RORG_RPS:
		HandleRPS();
		break;
	case RORG_1BS:
		Handle1BS();
		break;
	case GP_TI:
		HandleGP_TI();
		break;
	case RORG_SEC_TI:
		HandleSEC_TI();
		break;
	case RORG_UTE:
		HandleUTE();
		break;
	default:
		break;
	}
}
TEACH_RETURN eoTeachMessageHandler::ParseMessage()
{
	profile = NULL;
	GetOrCreateDevice();
	HandleMessage();
	HandleTeachResult();
	return ret;
}