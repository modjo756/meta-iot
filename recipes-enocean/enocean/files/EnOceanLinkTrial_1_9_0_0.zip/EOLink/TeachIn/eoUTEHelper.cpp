#include "eoUTEHelper.h"

eoReturn eoUTEHelper::ParseUTE(eoMessage &msg, UTE_EEP_TEACH_IN_QUERY &uteQuery)
{
	if (msg.dataLength != 7)
		return OUT_OF_RANGE;

	UTE_COMMAND uteCommand = (UTE_COMMAND)(msg.data[0] & 0x0F);
	if (uteCommand != EEP_TEACH_IN_QUERY)
		return WRONG_PARAM;

	uteQuery.request = (UTE_REQUEST)((msg.data[0] & 0x30) >> 4);
	uteQuery.direction = (UTE_DIRECTION)(msg.data[0] >> 7);

	uteQuery.rorg = msg.data[6];
	uteQuery.func = msg.data[5];
	uteQuery.type = msg.data[4];
	uteQuery.manufacturerID = ((msg.data[3] & 0x7) << 8);
	uteQuery.manufacturerID |= (uint16_t)msg.data[2];
	uteQuery.numberOfChannel = msg.data[1];

	return EO_OK;
}
eoReturn eoUTEHelper::CreateUTEResponseFromQuery(UTE_EEP_TEACH_IN_QUERY &uteQuery, eoMessage &responseMessage, UTE_RESPONSE response, UTE_DIRECTION direction)
{
	UTE_EEP_TEACH_IN_RESPONSE uteResponse;
	uteResponse.rorg = uteQuery.rorg;
	uteResponse.func = uteQuery.func;
	uteResponse.type = uteQuery.type;
	uteResponse.manufacturerID = uteQuery.manufacturerID;
	uteResponse.response = response;
	uteResponse.direction = direction;
	uteResponse.numberOfChannel = uteQuery.numberOfChannel;
	return eoUTEHelper::CreateUTEResponse(uteResponse, responseMessage);
}
eoReturn eoUTEHelper::CreateUTEResponse(UTE_EEP_TEACH_IN_RESPONSE &uteResponse, eoMessage &responseMessage)
{
	if (responseMessage.SetDataLength(7) != EO_OK)
		return OUT_OF_RANGE;

	responseMessage.RORG = RORG_UTE;
	responseMessage.sourceID = 0;
	responseMessage.data[0] = (uint8_t)EEP_TEACH_IN_RESPONSE;
	responseMessage.data[0] |= ((uint8_t)uteResponse.response) << 4;
	responseMessage.data[0] |= ((uint8_t)uteResponse.direction) << 7;

	responseMessage.data[6] = uteResponse.rorg;
	responseMessage.data[5] = uteResponse.func;
	responseMessage.data[4] = uteResponse.type;

	responseMessage.data[3] = (uint8_t)(uteResponse.manufacturerID >> 8);
	responseMessage.data[2] = (uint8_t)uteResponse.manufacturerID;
	responseMessage.data[1] = (uint8_t)uteResponse.numberOfChannel;

	return EO_OK;
}