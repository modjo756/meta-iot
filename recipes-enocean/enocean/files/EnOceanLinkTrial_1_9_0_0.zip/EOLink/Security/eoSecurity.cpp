/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoSecurity.h"
#include "./api/sec.h"
#include "string.h"

eoSecurity::eoSecurity() 
{
	const int maxLength = 32;
	lastResult = SEC_OK;

	msg.u8Data = new uint8_t[maxLength];
	msg.u16MaxLength = maxLength;

	msgTmp.u8Data = new uint8_t[maxLength];
	msgTmp.u16MaxLength = maxLength;

	sec_init(NULL, 64);
}

eoSecurity::~eoSecurity()
{
	if(msg.u8Data!=NULL)
		delete[] msg.u8Data;
	msg.u8Data=NULL;

	if(msgTmp.u8Data!=NULL)
		delete[] msgTmp.u8Data;
	msgTmp.u8Data=NULL;
}

eoReturn eoSecurity::Decrypt(eoMessage &msgSec, eoMessage &msgNonSec, eoDevice &dev)
{
	MessageToType(msgSec, msg);
	SecuInfoToType(dev.secIn, info);
	dev.secIn.previousRollingCode=dev.secIn.rollingCode;
	lastResult = sec_convertToNonsecure(&msg, &msgTmp, &info,&dev.secIn.rollingCode);
	dev.secOut.securityResult=lastResult;
	if (lastResult != SEC_OK)
		return EO_ERROR;

	TypeToSecuInfo(info, dev.secIn);
	TypeToMessage(msgTmp, msgNonSec);

	return EO_OK;
}

eoReturn eoSecurity::Encrypt(eoMessage &msgNonSec, eoMessage &msgSec, eoDevice &dev)
{
	MessageToType(msgNonSec, msg);
	SecuInfoToType(dev.secOut, info);
	dev.secOut.previousRollingCode=dev.secOut.rollingCode;
	lastResult = sec_convertToSecure(&msg, &msgTmp, &info,&dev.secOut.rollingCode);

	if (lastResult != SEC_OK)
		return EO_ERROR;

	TypeToSecuInfo(info, dev.secOut);
	TypeToMessage(msgTmp, msgSec);
	return EO_OK;
}

eoReturn eoSecurity::ParseTeachIn(eoMessage &msgTi, eoDevice &dev)
{
	eoReturn retValue=EO_OK;
	if(retValue==EO_OK)
	{
		retValue=MessageToType(msgTi, msg);
	}
	if(retValue==EO_OK)
	{
		retValue=SecuInfoToType(dev.secIn, info);
	}
	if(retValue==EO_OK)
	{
		if (sec_parseTeachIn(&msg, &info,&dev.secIn.rollingCode,dev.secIn.psk) != SEC_OK)
		{
			//Pseudo set
			dev.secIn.previousRollingCode=dev.secIn.rollingCode-1;
			retValue=EO_ERROR;
		}
	}
	if(retValue==EO_OK)
	{
		TypeToSecuInfo(info, dev.secIn);
	}
	return retValue;
}

eoReturn eoSecurity::CreateTeachIn (eoMessage &msgTi, eoDevice &dev)
{

	SecuInfoToType(dev.secOut, info);
	dev.secOut.previousRollingCode=dev.secOut.rollingCode-1;
	lastResult = sec_createTeachIn(&info,&dev.secOut.rollingCode,&msg,dev.secOut.psk);
	if (lastResult != SEC_OK)
		return EO_ERROR;

	sec_createCMACSubkeys(info.u8Key, info.u8CMACsubkey1, info.u8CMACsubkey2);

	TypeToMessage(msg, msgTi);
	TypeToSecuInfo(info, dev.secOut);

	return EO_OK;
}

/*
 *
 * Helper functions
 *
 */
eoReturn eoSecurity::MessageToType(eoMessage const &msg, MESSAGE_TYPE &mt)
{
	if(mt.u16MaxLength<msg.GetDataLength())
		return OUT_OF_RANGE;

	mt.u8Choice = msg.RORG;
	mt.u16Length = msg.GetDataLength();
	mt.u32SourceId = msg.sourceID;
	mt.u8OptLength = 0;
	memcpy(mt.u8Data, msg.data, mt.u16Length);

	return EO_OK;
}

eoReturn eoSecurity::TypeToMessage(MESSAGE_TYPE const &mt, eoMessage &msg)
{
	if(msg.SetDataLength(mt.u16Length)!=EO_OK)
		return OUT_OF_RANGE;

	msg.RORG = mt.u8Choice;
	msg.sourceID = mt.u32SourceId;
	memcpy(msg.data, mt.u8Data, msg.GetDataLength());

	return EO_OK;
}

eoReturn eoSecurity::TypeToSecuInfo(SECU_TYPE const &it, eoSecureInfo &info)
{
	info.SLF = it.u8SLF;
	info.keySize = it.u8KeySize;
	info.teachInInfo = it.u8TeachInInfo;

	memcpy(info.key, it.u8Key, it.u8KeySize);
	memcpy(info.subKey1, it.u8CMACsubkey1, 16);
	memcpy(info.subKey2, it.u8CMACsubkey2, 16);

	return EO_OK;
}

eoReturn eoSecurity::SecuInfoToType(eoSecureInfo const &info, SECU_TYPE &it)
{
	it.u8SLF = info.SLF;
	it.u8KeySize = info.keySize;
	it.u8TeachInInfo = info.teachInInfo;

	memcpy(it.u8Key, info.key, it.u8KeySize);
	memcpy(it.u8CMACsubkey1, info.subKey1, 16);
	memcpy(it.u8CMACsubkey2, info.subKey2, 16);

	return EO_OK;
}

SEC_RESULT eoSecurity::GetLastError()
{
	return lastResult;
}
