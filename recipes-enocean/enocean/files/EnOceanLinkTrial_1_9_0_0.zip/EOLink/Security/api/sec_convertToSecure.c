/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/


#include "api/sec.h"
#include "string.h"
SEC_RESULT  sec_convertToSecure(MESSAGE_TYPE *mssgeNonsecure, MESSAGE_TYPE *mssgeSecure, SECU_TYPE *secuInfo, uint32_t *pu32RLC)
{	
	uint8_t 		*pu8;
	uint16_t 		u16AESCBCsize;	  				// DATA size without RLC, MAC or ID bytes
	uint16_t 		u16PayloadSize;	  				// DATA size without RLC, MAC or ID bytes
	uint8_t 		u8RLCtx;
	uint8_t 		u8RLCsize;
	uint8_t 		u8RLCArray[4];
	uint8_t 		u8CMACsize;
	uint8_t 		u8CMAC[16];
	uint8_t 		u8CMACDataIn[128];				// CHOICE + DATA bytes + [RLC] bytes
	uint8_t 		u8SLF = secuInfo->u8SLF;
	uint8_t const u8RLCSize[]  	= {	0, 	  	/* NO_RLC_ALGO */
									2, 	  	/* RLC_16_BIT */
									3, 	  	/* SLF_RLC_24_BIT */
									0xFF};	/* RESERVED */

	uint8_t const u8CMACSize[]  	= {	0, 	  	/* SLF_MAC_NO */
									3, 	  	/* SLF_MAC_3_AES128 */
									4, 	  	/* SLF_MAC_4_AES128 */
									0xFF};	/* RESERVED */


//	u8RLCtx 	= u8SLF & SLF_RLC_TX_MASK;

	u8RLCsize 	= u8RLCSize[(u8SLF & SLF_RLC_ALGO_MASK)>>6];
	if(u8RLCsize == 0xFF)
		return SEC_SIZE_WRONG;

	u8RLCtx 	= (u8SLF & SLF_RLC_TX_MASK) ? u8RLCsize : 0 ;

	u8CMACsize 	= u8CMACSize[(u8SLF & SLF_MAC_ALGO_MASK)>>3];
	if(u8CMACsize == 0xFF)
		return SEC_SIZE_WRONG;

	if(mssgeNonsecure->u8Choice ==  RADIO_CHOICE_SEC)
		return SEC_CHOICE_WRONG;


	// For non-secure messages with choice != RADIO_CHOICE_NON_SEC the choice is included in the data to encrypt
	if(mssgeNonsecure->u8Choice ==  RADIO_CHOICE_NON_SEC)
	{
		mssgeSecure->u8Choice 	= RADIO_CHOICE_SEC;
		u16PayloadSize 			= mssgeNonsecure->u16Length; 		

		if(mssgeSecure->u16MaxLength < (u16PayloadSize + u8RLCtx + u8CMACsize))
			return SEC_SIZE_WRONG;

	   	// Data to encrypt is copied to the mssgeSecure->u8Data
		memcpy(mssgeSecure->u8Data, mssgeNonsecure->u8Data, u16PayloadSize);
	}
	else
	{
		mssgeSecure->u8Choice 	= RADIO_CHOICE_SEC_ENCAPS;
		u16PayloadSize 			= mssgeNonsecure->u16Length + 1 ; 		

		if(mssgeSecure->u16MaxLength < (u16PayloadSize + u8RLCtx + u8CMACsize))
			return SEC_SIZE_WRONG;

	   	// Data to encrypt is copied to the mssgeSecure->u8Data
		mssgeSecure->u8Data[0]	= mssgeNonsecure->u8Choice;
		memcpy(&(mssgeSecure->u8Data[1]), mssgeNonsecure->u8Data, u16PayloadSize - 1);
	}
			

		
   	// ************ ENCRYPTION ********************
	// The encryption functions use as Data Input the bytes in mssgeSecure->u8Data field. 
	// The result of the encryption is stored also in this same mssgeSecure->u8Data array
	switch (u8SLF & SLF_DATA_ENC_MASK)
	{
		// If no encryption required, then nothing to do
		case SLF_ENC_NO:
			break;

		case SLF_ENC_VAES128:
			
			if(u8RLCsize != 0)
				sec_convertToArray(*pu32RLC, u8RLCsize, &u8RLCArray[0]);
				
			sec_VAES128(mssgeSecure->u8Data, u16PayloadSize, &u8RLCArray[0], u8RLCsize, secuInfo->u8Key, mssgeSecure->u8Data);

			// Is it PTM telegram? Type = 01 ? PTM Data has only 4 bits, so take only 4
			if ((secuInfo->u8TeachInInfo & TEACH_IN_TYPE_MASK) == TEACH_IN_TYPE_PTM)
				mssgeSecure->u8Data[0] &= 0x0F;

			break;

		
		case SLF_ENC_AES128:
			
			if(sec_encryptAESCBC(mssgeSecure->u8Data, u16PayloadSize, secuInfo->u8Key, mssgeSecure->u8Data, mssgeSecure->u16MaxLength, &u16AESCBCsize) == SEC_SIZE_WRONG)
				return SEC_SIZE_WRONG;
			u16PayloadSize = u16AESCBCsize;
			break;

		default:
			return SEC_ENC_WRONG;
	}
   	// ************ END DECRYPTION ********************
	

	// ************** INCLUDE RLC/CMAC ****************
	pu8 =  mssgeSecure->u8Data + u16PayloadSize;

	if(u8RLCsize)
	{	
		if(sec_convertToArray(*pu32RLC, u8RLCsize, &u8RLCArray[0]) != 0)
			return SEC_SIZE_WRONG;								 
	}
	
	if(u8RLCtx != 0)
	{
		memcpy(pu8, &u8RLCArray[0], u8RLCsize);
		pu8 += u8RLCsize;
	}
	mssgeSecure->u16Length	= u16PayloadSize + u8RLCtx + u8CMACsize;

	if(u8CMACsize != 0)
	{
		u8CMACDataIn[0] = mssgeSecure->u8Choice;
		memcpy(&u8CMACDataIn[1], mssgeSecure->u8Data, u16PayloadSize);
		memcpy(&u8CMACDataIn[1+u16PayloadSize], &u8RLCArray[0], u8RLCsize);
		sec_createCMAC(&u8CMACDataIn[0], 1+u16PayloadSize+u8RLCsize, secuInfo->u8Key, secuInfo->u8CMACsubkey1, secuInfo->u8CMACsubkey2, &u8CMAC[0]);
	    memcpy(pu8, &u8CMAC[0], u8CMACsize);
	}

	sec_RLCinc(pu32RLC, u8RLCsize);
	
	mssgeSecure->u32SourceId 	= mssgeNonsecure->u32SourceId;
	mssgeSecure->u8SourceIdLength = mssgeNonsecure->u8SourceIdLength;
	mssgeSecure->u32DestinationId = mssgeNonsecure->u32DestinationId;
	mssgeSecure->u8OptLength = mssgeNonsecure->u8OptLength;
	
   	// ************ END INCLUDE RLC/CMAC ********************

	return SEC_OK;
}





