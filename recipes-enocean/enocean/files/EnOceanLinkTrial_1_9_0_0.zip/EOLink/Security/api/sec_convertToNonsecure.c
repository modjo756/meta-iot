//! \sec_convertToNonsecure.c
/**
 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/


#include "api/sec.h"
#include "string.h" 

uint8_t sec_convertToArray(uint32_t u32Number, uint8_t u8Size, uint8_t *u8Array);
 
const uint8_t SLF_CMAC_size[4] = 
{	
	0,		// No CMAC
	3,		// AES128 3 byte
	4,		// AES128 4 byte
	0xFF	// N/A
};

const uint8_t SLF_RLC_size[4] = 
{
	0,		// No RLC 
	2,		// 16-bit x=x+1
	3,		// 24-bit x=x+1
	0xFF	// N/A	
};

SEC_RESULT  sec_convertToNonsecure(MESSAGE_TYPE *msgSec, MESSAGE_TYPE *msgNonSec, SECU_TYPE *secInfo, uint32_t *pu32RLC)
{	
	uint8_t 	u8SLF			= secInfo->u8SLF;
	uint8_t 	u8RLCsize		= SLF_RLC_size [(u8SLF>>6) & 3];
	uint8_t 	u8CMACsize		= SLF_CMAC_size[(u8SLF>>3) & 3];
	uint8_t 	u8RLCtxSize 	= (u8SLF & SLF_RLC_TX_MASK) ? u8RLCsize : 0;
	uint16_t 	u16PayloadSize 	= msgSec->u16Length - u8CMACsize - u8RLCtxSize;		// DATA size without RLC, MAC or ID bytes
	uint8_t 	*pu8MssgCMAC   	= msgSec->u8Data + u16PayloadSize + u8RLCtxSize;	// If u8CMACsize = 0, we don't use this variable
	uint32_t 	u32RLC;
	uint8_t 	u8RLCArray[4];
	uint8_t 	u8CMACexpected[16];
	uint8_t 	u8CMACDataIn[128];													// CHOICE + DATA bytes + [RLC] bytes
	uint32_t 	u32j; 
	uint8_t 	u8i; 


	if ((u8RLCsize == 0xFF) || (u8CMACsize == 0xFF))
		return SEC_SLF_WRONG;

	if( msgSec->u8Choice == RADIO_CHOICE_SEC_ENCAPS)
		msgNonSec->u16Length = u16PayloadSize - 1;

	else if(msgSec->u8Choice == RADIO_CHOICE_SEC)
		msgNonSec->u16Length = u16PayloadSize;

	else
   		return SEC_CHOICE_WRONG;

	if((msgNonSec->u16MaxLength  < msgNonSec->u16Length ))
		return SEC_SIZE_WRONG;


   	// ************  RLC & CMAC TEST ********************
	u8CMACDataIn[0] = msgSec->u8Choice;					// Copy Choice to CMAC array input							
 	memcpy(&u8CMACDataIn[1], msgSec->u8Data, u16PayloadSize + u8RLCtxSize);		


   	if ((u8RLCtxSize == 0) && (u8RLCsize != 0) && (u8CMACsize != 0)) 		// RLC is not transmitted in secure message DATA
	{
		
		u32RLC = *pu32RLC;

		for(u32j=0 ; u32j<u32RLCwindow ; u32j++)
		{
			sec_convertToArray(u32RLC, u8RLCsize, &u8CMACDataIn[1+u16PayloadSize]);
			sec_createCMAC(&u8CMACDataIn[0], 1 + u16PayloadSize + u8RLCsize, secInfo->u8Key, secInfo->u8CMACsubkey1, secInfo->u8CMACsubkey2, &u8CMACexpected[0]);
			if (memcmp(pu8MssgCMAC, u8CMACexpected, u8CMACsize) == 0)
				break;

			sec_RLCinc(&u32RLC, u8RLCsize);
		}
		
		if(u32j >= u32RLCwindow)
			return SEC_RLC_OUT_OF_RANGE;
	}

	else if ((u8RLCtxSize == 0) && (u8RLCsize == 0))   	// RLC not used
	{
		// Test CMAC
		if(u8CMACsize)
		{
			sec_createCMAC(&u8CMACDataIn[0], 1 + u16PayloadSize, secInfo->u8Key, secInfo->u8CMACsubkey1, secInfo->u8CMACsubkey2, &u8CMACexpected[0]);
			if (memcmp(pu8MssgCMAC, u8CMACexpected, u8CMACsize) != 0)
				return SEC_CMAC_WRONG;
		}
	}

	else if ((u8RLCtxSize != 0) && (u8RLCsize != 0))   	// RLC explicit in the secure message
	{
		// Test RLC
		sec_convertToNumber(msgSec->u8Data + u16PayloadSize, u8RLCsize, &u32RLC);
		if( sec_RLCdiff(u32RLC, *pu32RLC, u8RLCsize)  > u32RLCwindow)   	
			return SEC_RLC_OUT_OF_RANGE;

		// Test CMAC
		if(u8CMACsize)
		{
			sec_createCMAC(&u8CMACDataIn[0], 1 + u16PayloadSize + u8RLCtxSize, secInfo->u8Key, secInfo->u8CMACsubkey1, secInfo->u8CMACsubkey2, &u8CMACexpected[0]);
			if (memcmp(pu8MssgCMAC, u8CMACexpected, u8CMACsize) != 0)
				return SEC_CMAC_WRONG;
		}
	}

	else 												// u8RLCtxSize != 0 && u8RLCsize == 0 --> Not allowed
	 	return SEC_SLF_WRONG;


	
   	// ************ DATA DECRYPTION ********************
	switch (u8SLF & SLF_DATA_ENC_MASK)
	{
		case SLF_ENC_NO:
			memcpy(msgNonSec->u8Data, msgSec->u8Data, u16PayloadSize);
			break;

		case SLF_ENC_VAES128:

			if(u8RLCsize != 0)
				sec_convertToArray(u32RLC, u8RLCsize, &u8RLCArray[0]);

			sec_VAES128(msgSec->u8Data, u16PayloadSize, &u8RLCArray[0], u8RLCsize, secInfo->u8Key, msgNonSec->u8Data);

			// Is it PTM telegram? Type = 01 ? PTM Data has only 4 bits, so take only 4
			if ((secInfo->u8TeachInInfo & TEACH_IN_TYPE_MASK) == TEACH_IN_TYPE_PTM)
				msgNonSec->u8Data[0] &= 0x0F;
			
			break;

		case SLF_ENC_AES128:
//			if(u16PayloadSize != 16)
//				return SEC_SIZE_WRONG;
	//		memcpy(msgNonSec->u8Data, msgSec->u8Data, 16);
			//sec_AES128dec(msgNonSec->u8Data, secInfo->u8Key);
			if(sec_decryptAESCBC(msgSec->u8Data, u16PayloadSize, secInfo->u8Key, msgNonSec->u8Data, msgNonSec->u16MaxLength) == SEC_SIZE_WRONG)
				return SEC_SIZE_WRONG;
			break;

		default:
			return SEC_ENC_WRONG;
	}

	// ******************** SETTING NON-SECURE MESSAGE CHOICE, DATA AND ID **************
	if(msgSec->u8Choice == RADIO_CHOICE_SEC_ENCAPS)   	// The radio choice is encapsulated in the msgNonSec->u8Data[0]. 
	{													  	// It must be copied and the data bytes in mssageNonsecure moved to the left 
		msgNonSec->u8Choice = msgNonSec->u8Data[0];
		for(u8i=1 ; u8i < u16PayloadSize ; u8i++)
			msgNonSec->u8Data[u8i-1] = msgNonSec->u8Data[u8i];
	}

	else if(msgSec->u8Choice == RADIO_CHOICE_SEC)
		msgNonSec->u8Choice	 = RADIO_CHOICE_NON_SEC;

	else
	{
	}

	msgNonSec->u8SourceIdLength = msgSec->u8SourceIdLength;
	msgNonSec->u32SourceId = msgSec->u32SourceId;
	msgNonSec->u32DestinationId = msgSec->u32DestinationId;
	msgNonSec->u8OptLength = msgSec->u8OptLength;
	
	if(u8RLCsize != 0)			 					// Security includes RLC? Then increment it
		*pu32RLC = u32RLC + 1;

	
	return SEC_OK;

}





