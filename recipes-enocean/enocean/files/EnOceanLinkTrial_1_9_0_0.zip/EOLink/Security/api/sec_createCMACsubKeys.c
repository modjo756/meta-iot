/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//! \sec_createCMACSubkeys.c
#include "api/sec.h"
#include "string.h"

void sec_leftshift_onebit(unsigned char *input,unsigned char *output)
{
	int8_t i;
	uint8_t overflow = 0;
	
	for ( i=15; i>=0; i-- ) 
	{
		output[i] = input[i] << 1;
		output[i] |= overflow;
		overflow = (input[i] & 0x80)?1:0;
	}	
	return;
	}

// uint8_t const u8Const_Rb[16] 		= {	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
//							  			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x87 };

void  sec_createCMACSubkeys(uint8_t *pu8Key, uint8_t *pu8SubKey1, uint8_t *pu8SubKey2)
{
	uint8_t	*K1 = pu8SubKey1;
	uint8_t	*K2 = pu8SubKey2;
	uint8_t	 L[16];
	
	memset(L, 0x00, sizeof(L));

	// Step 1.  L := AES-128(K, const_Zero)
	sec_AES128enc(L, pu8Key);			

	// Step 2.  if MSB(L) is equal to 0                                
    //            then    K1 := L << 1;                                  
    //            else    K1 := (L << 1) XOR const_Rb;  
	sec_leftshift_onebit(L, K1);		// K1 := L << 1;
	if ( (L[0] & 0x80) != 0 )			
		K1[15] ^= 0x87;				// K1 := K1 xor const_Rb

	// Step 3.  if MSB(K1) is equal to 0                               
    //            then    K2 := K1 << 1;                                 
    //            else    K2 := (K1 << 1) XOR const_Rb; 
	sec_leftshift_onebit(K1, K2);	   // K2 := K1 << 1
	if ( (K1[0] & 0x80) != 0 )		
		K2[15] ^= 0x87;			   // K1 := K1 xor const_Rb
}




