/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoSecureInfo.h"
#include "eoConverter.h"
#include <string.h>

eoSecureInfo::eoSecureInfo()
{
	// Initialize member variables
	memset(key, 0x00, sizeof(key));
	memset(psk, 0x00, sizeof(key));
	memset(subKey1, 0x00, sizeof(subKey1));
	memset(subKey2, 0x00, sizeof(subKey2));
	keySize = 0;
	previousRollingCode = 0;
	rollingCode = 0;
	SLF = 0;
	teachInInfo = 0;
	securityResult = SEC_OK;
}

eoSecureInfo::~eoSecureInfo()
{

}

uint8_t eoSecureInfo::Serialize(eoArchive &arch)
{
	uint8_t tmpCnt;
	if (arch.isStoring && SLF == 0x00)
		return EO_OK;
	arch & "keySize" & keySize;
	arch & "rollingCode" & rollingCode;
	arch & "SLF" & SLF;
	arch & "teachInInfo" & teachInInfo;
	char keyStr[7] = "key_0\0";
	char skeyStr1[9] = "skey1_0\0";
	char skeyStr2[9] = "skey2_0\0";
	char pskStr[7] = "psk_0\0";
	for (tmpCnt = 0; tmpCnt < 16; tmpCnt++)
	{
		keyStr[4] = *eoConverter::NumToHex(tmpCnt);
		skeyStr1[6] = *eoConverter::NumToHex(tmpCnt);
		skeyStr2[6] = *eoConverter::NumToHex(tmpCnt);
		pskStr[4] = *eoConverter::NumToHex(tmpCnt);
		arch & keyStr & key[tmpCnt];
		arch & skeyStr1 & subKey1[tmpCnt];
		arch & skeyStr2 & subKey2[tmpCnt];
		arch & pskStr & psk[tmpCnt];
	}
	return EO_OK;
}
