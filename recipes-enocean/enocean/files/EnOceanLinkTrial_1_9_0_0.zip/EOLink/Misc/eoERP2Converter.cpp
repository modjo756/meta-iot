/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoERP2Converter.h"
#include <string.h>

//! Define for minimum advanced protocol data length
#define MINIMUM_ADVANCED_DATA_LENGTH 0x06
//! Define for advanced SmartAck Reclaim data length
#define SA_RECLAIM_DATA_LENGTH 0x05

//HEader bits...
const uint8_t extendedHeaderAvailable = 0x10;
const uint8_t extendedTelegramType = 0x0F;

const uint8_t eoERP2Converter::AdvancedRORG [16] =
{
		RORG_RPS,
		RORG_1BS,
		RORG_4BS,
		RORG_SIGNAL,
		RORG_VLD,
		RORG_UTE,
		RORG_MSC,
		RORG_SEC,
		RORG_SEC_ENCAPS,
		RORG_SEC_TI,
		GP_SD,
		0xA8,
		0xFF,
		0xFF,
		0xFF,
		0xFF
};

eoERP2Converter::eoERP2Converter()
{
	data = NULL;
	telegram = NULL;
	packet = NULL;
	optLength=0;
}

void eoERP2Converter::parseOptionalData()
{
	telegram->dBm = -packet->data[packet->dataLength + 1];
	telegram->subtelCount = packet->data[packet->dataLength];
}

void eoERP2Converter::parseReclaim()
{
	telegram->RORG = RADIO_CHOICE_RECLAIM;
	telegram->sourceID = (uint32_t)((packet->data[0] << 24) | (packet->data[1] << 16) | (packet->data[2] << 8) | packet->data[3]);
	telegram->dataLength = 1;
	telegram->data[0] = packet->data[4];
	telegram->status = 0x0F;
}

void eoERP2Converter::clearPointers()
{
	data = NULL;
	telegram = NULL;
	packet = NULL;
}
eoReturn eoERP2Converter::addDataAndOptData()
{
	if(optLength>0)
	{
		telegram->dataLength -= optLength;
		telegram->SetOptionalDataLength(optLength);
		memcpy(telegram->optionalData,&data[telegram->dataLength ],optLength);
	}

	if(telegram->dataLength > telegram->maxLength)
	{
		telegram->dataLength=0;
		clearPointers();
		return OUT_OF_RANGE;
	}
	memcpy(telegram->data, data, telegram->dataLength);

	return EO_OK;
}

eoReturn eoERP2Converter::parseSourceID()
{
	data++;
	switch (telegram->sourceIDLength)
	{
		case SourceID24Bit:
			telegram->sourceID = *(data++) << 16;
			telegram->sourceID |= *(data++) << 8;
			telegram->sourceID |= *(data++);
			telegram->dataLength-=3;
			break;
		case SourceID32Bit:
			telegram->sourceID = *(data++) << 24;
			telegram->sourceID |= *(data++) << 16;
			telegram->sourceID |= *(data++) << 8;
			telegram->sourceID |= *(data++);
			telegram->dataLength-=4;
			break;
		case SourceID48Bit:
			telegram->sourceIDMSB = *(data++) << 8;
			telegram->sourceIDMSB |= *(data++);
			telegram->sourceID = *(data++) << 24;
			telegram->sourceID |= *(data++) << 16;
			telegram->sourceID |= *(data++) << 8;
			telegram->sourceID |= *(data++);
			telegram->dataLength-=6;
			break;
		case SourceIDInvalid:
		default:
			return NOT_SUPPORTED;
	}
	return EO_OK;
}
eoReturn eoERP2Converter::parseDestinationID()
{
	switch(telegram->destIDLength)
	{
		case NoDestinationID:
			telegram->destinationID = 0xFFFFFFFF;
			break;
		case DestinationID32Bit:
			{
				telegram->dataLength-=4;
				telegram->destinationID = *(data++) << 24;
				telegram->destinationID |= *(data++) << 16;
				telegram->destinationID |= *(data++) << 8;
				telegram->destinationID |= *(data++);
			}
			break;
		case DestinationIDInvalid:
				return NOT_SUPPORTED;
			break;
	}
	return EO_OK;
}

void eoERP2Converter::parseExtendedHeader()
{
	data++;
	telegram->dataLength--;
	telegram->status = (*(data) & 0xF0) >> 4;
	telegram->SetRepeaterCount(telegram->status);
	optLength = *data & 0x0F;
}

void eoERP2Converter::parseExtendedTelegramType()
{
	const uint8_t AdvancedExtRORG[] =
	{
		RORG_SYS_EX,
		RORG_SM_LRN_REQ,
		RORG_SM_LRN_ANS,
		RORG_CDM,
		RORG_SECD,
		GP_TI,
		GP_TR,
		GP_CD
	};

	data++;
	telegram->dataLength--;
	if ( *data < sizeof(AdvancedExtRORG))
		telegram->RORG = AdvancedExtRORG[*data];
}

void eoERP2Converter::parseAddressControl()
{
	const SourceIDLength SourceIDLength[] =
	{
		SourceID24Bit,
		SourceID32Bit,
		SourceID32Bit,
		SourceID48Bit,
		SourceIDInvalid,
		SourceIDInvalid,
		SourceIDInvalid
	};

	const DestinationIDType DestinationIDLength[] =
	{
		NoDestinationID,
		NoDestinationID,
		DestinationID32Bit,
		NoDestinationID,
		DestinationIDInvalid,
		DestinationIDInvalid,
		DestinationIDInvalid
	};
	uint8_t addrControl = (*data & 0xE0) >> 5;
	telegram->sourceIDLength = SourceIDLength[addrControl];
	telegram->destIDLength = DestinationIDLength[addrControl];
}

eoReturn eoERP2Converter::parseHeader()
{
	data = &packet->data[0];
	parseAddressControl();

	const uint8_t crcAndHeaderLength = 2;
	telegram->dataLength = packet->dataLength - crcAndHeaderLength;
	optLength = 0;

	bool extHeader = (*data & extendedHeaderAvailable) == extendedHeaderAvailable;
	bool extTelType = (*data & extendedTelegramType) == extendedTelegramType;

	if (!extTelType)
		telegram->RORG = AdvancedRORG[*(data) & 0x0F];

	if (extHeader)
	{
		parseExtendedHeader();
	}

	if (extTelType)
	{
		parseExtendedTelegramType();
	}

	eoReturn ret=parseSourceID();
	if(ret==EO_OK)
		ret = parseDestinationID();

	return ret;
}
eoReturn eoERP2Converter::convertFromPacketToERP2(const eoPacket &p, eoTelegramERP2 &tel)
{
	packet = &p;
	telegram = &tel;
	if (packet->type != PACKET_RADIO_ADVANCED)
		return WRONG_PARAM;

	telegram->Clear();

	if (packet->optionalLength >= 2)
	{
		parseOptionalData();
	}

	if (packet->dataLength == SA_RECLAIM_DATA_LENGTH)
	{
		parseReclaim();
		clearPointers();
		return EO_OK;
	}

	if (packet->dataLength < MINIMUM_ADVANCED_DATA_LENGTH || packet->dataLength > telegram->maxLength)
	{
		clearPointers();
		return OUT_OF_RANGE;
	}

	eoReturn ret=parseHeader();
	if(ret!=EO_OK)
	{
		clearPointers();
		return ret;
	}
	ret = addDataAndOptData();
	clearPointers();
	return ret;
}
