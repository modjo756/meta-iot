/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoConverter.h"
#include "eoERP2Converter.h"
#include <string.h>
#define MULTIPLIER 37

const char numToHex[0x10] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

const char* eoConverter::NumToHex(uint8_t num)
{
	return &numToHex[num & 0xF];
}

eoReturn eoConverter::packetToRadio(const eoPacket &packet, eoTelegram &tel)
{
	if (packet.type == PACKET_RADIO_ADVANCED)
		return advancedPacketToRadio(packet, tel);

	if (packet.type != PACKET_RADIO && packet.type != PACKET_RADIO_SUB_TEL)
		return WRONG_PARAM;

	if (packet.dataLength > tel.GetMaxLength() + 6)
		return WRONG_PARAM;

	// Copy RORG
	tel.RORG = packet.data[0];

	// Copy DATA
	tel.SetDataLength((uint16_t)(packet.dataLength - 6U));
	memcpy(tel.data, &packet.data[1], tel.GetDataLength());

	// Copy SourceID
	uint16_t i = (uint16_t)(packet.dataLength - 5U);
	tel.sourceID = (uint32_t)((packet.data[i + 0] << 24)|(packet.data[i + 1] << 16)|(packet.data[i + 2] << 8)|(packet.data[i + 3]));
	tel.status = (packet.data[i + 4]);
	// Copy SubtelegramCount
	i = packet.dataLength;
	if (packet.optionalLength >= 1)
	{
		tel.subtelCount = packet.data[i];
		i += 1;
	}

	// Copy DestinationID
	if (packet.optionalLength >= 5)
	{
		tel.destinationID = (uint32_t)((packet.data[i + 0] << 24) | (packet.data[i + 1] << 16) | (packet.data[i + 2] << 8) | (packet.data[i + 3]));
		i += 4;
	}

	// Copy dBm
	if (packet.optionalLength >= 6)
	{
		tel.dBm = -packet.data[i];
	}

	return EO_OK;
}

eoReturn eoConverter::packetToAdvancedRadio (const eoMessage &msg, eoPacket &packet)
{
	uint8_t *packetData = &packet.data[0];
	packet.type = PACKET_RADIO_ADVANCED;
	packet.dataLength = 4;
	if(packet.getBufferSize()<9+msg.dataLength)
		return OUT_OF_RANGE;
	memset(packetData,0,9);
	//TODO: chaining for advanced?
	//For the advanced protocol modifies the security telegram
	if(msg.RORG==RORG_SEC_TI)
	{
		msg.data[0]&=0x0F;
		//sets idx=0,cnt=1;
		msg.data[0]|=0x10;
	}
	if (msg.destinationID == BROADCAST_ID)
	{
		packet.dataLength = 5;
		*packetData |= 0x20;
	}
	else
	{
		packet.dataLength = 9;
		*packetData |= 0x40;
	}


	uint8_t i = 0;
	for (; i < sizeof(eoERP2Converter::AdvancedRORG); i++)
	{
		if (msg.RORG == eoERP2Converter::AdvancedRORG[i])
		{
			*packetData++ |= i;
			break;
		}
	}

	if (i == sizeof(eoERP2Converter::AdvancedRORG))
	{
		*packetData++ |= 0x0F;
		const uint8_t AdvancedExtRORG[] =
		{
			RORG_SYS_EX,
			RORG_SM_LRN_REQ,
			RORG_SM_LRN_ANS,
			RORG_CDM,
			RORG_SECD,
			GP_TI,
			GP_TR,
			GP_CD
		};
		for(i=0;i<sizeof(AdvancedExtRORG);i++)
		{
			if(msg.RORG == AdvancedExtRORG[i])
			{
				*packetData++ = i;
			}
		}
		if(i==sizeof(AdvancedExtRORG))
			*packetData++ = 0xFF;
	}

	switch (sizeof(msg.sourceID))
	{
		case 3:
			*packetData++ = (msg.sourceID >> 16) & 0xFF;
			*packetData++ = (msg.sourceID >> 8) & 0xFF;
			*packetData++ = msg.sourceID & 0xFF;
			break;
		case 4:
			*packetData++ = (msg.sourceID >> 24) & 0xFF;
			*packetData++ = (msg.sourceID >> 16) & 0xFF;
			*packetData++ = (msg.sourceID >> 8) & 0xFF;
			*packetData++ = msg.sourceID & 0xFF;
			break;
		case 6:
			*packetData++ = 0x00;
			*packetData++ = 0x00;
			*packetData++ = (msg.sourceID >> 24) & 0xFF;
			*packetData++ = (msg.sourceID >> 16) & 0xFF;
			*packetData++ = (msg.sourceID >> 8) & 0xFF;
			*packetData++ = msg.sourceID & 0xFF;
			break;
		default:
			return EO_ERROR;
	}

	if (msg.destinationID != BROADCAST_ID)
	{
		*packetData++ = (msg.destinationID >> 24) & 0xFF;
		*packetData++ = (msg.destinationID >> 16) & 0xFF;
		*packetData++ = (msg.destinationID >> 8) & 0xFF;
		*packetData++ = msg.destinationID & 0xFF;
	}

	for (i = 0; i < msg.dataLength; i++)
		*packetData++ = msg.data[i];
	*packetData=0;
	packet.dataLength += msg.dataLength + 1;

	return EO_OK;
}

eoReturn eoConverter::advancedPacketToRadio(const eoPacket &packet, eoTelegramERP2 &tel)
{
	eoERP2Converter erp2;
	return erp2.convertFromPacketToERP2(packet,tel);
}

eoReturn eoConverter::advancedPacketToRadio(const eoPacket &packet, eoTelegram &tel)
{
	eoTelegramERP2 telegram2(255);
	eoReturn ret = advancedPacketToRadio(packet, telegram2);
	if (ret == EO_OK)
	{
		return telegram2.copyTo(tel);
	}
	else
	{
		return ret;
	}
}

eoReturn eoConverter::radioToPacket(const eoMessage &msg, eoPacket &packet)
{
	//checks Buffer Size before returning dataLength
	if (packet.getBufferSize() < (msg.GetDataLength() + 6 + 5))
		return OUT_OF_RANGE;
	if (msg.GetDataLength() > 14)
		return WRONG_PARAM;
	packet.type = PACKET_RADIO;

	packet.dataLength = msg.GetDataLength()+ 6;

	// Copy RORG
	packet.data[0] = msg.RORG;

	// Copy DATA
	memcpy(&packet.data[1], msg.data, msg.GetDataLength());

	// Copy SourceID
	uint16_t i = msg.GetDataLength() + 1;
	packet.data[i + 0] = (uint8_t)(msg.sourceID >> 24);
	packet.data[i + 1] = (uint8_t)(msg.sourceID >> 16);
	packet.data[i + 2] = (uint8_t)(msg.sourceID >> 8);
	packet.data[i + 3] = (uint8_t)(msg.sourceID);

	packet.data[i + 4] = msg.status;

	packet.optionalLength = 7;
	i = packet.dataLength;
	packet.data[i + 0] = 3; // subtelegram count
	packet.data[i + 1] = (uint8_t)(msg.destinationID >> 24);
	packet.data[i + 2] =(uint8_t)( msg.destinationID >> 16);
	packet.data[i + 3] = (uint8_t)(msg.destinationID >> 8);
	packet.data[i + 4] = (uint8_t)msg.destinationID;
	packet.data[i + 5] = 0xFF;
	packet.data[i + 6] = 0x00;
	return EO_OK;
}

eoReturn eoConverter::radioToPacket(const eoTelegram &tel, eoPacket &packet)
{
	return radioToPacket((const eoMessage)tel,packet);
}
uint8_t eoConverter::TigrisToRPS(eoTelegram &inTel, eoTelegram &outTel)
{
	const uint8_t secToRps[16] =	{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x70, 0x37, 0x10, 0x15, 0x35, 0x50, 0x70, 0x10, 0x30, 0x00 };
	const uint8_t secToStat[16] =	{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x30, 0x20, 0x30, 0x20, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x20 };

	if (inTel.RORG == RADIO_CHOICE_NON_SEC && inTel.GetDataLength() == 1)
	{
		outTel.RORG = RADIO_CHOICE_RPS;
		outTel.SetDataLength(1);
		outTel.data[0] = secToRps[inTel.data[0] & 0xF];
		outTel.status = secToStat[inTel.data[0] & 0xF];
		return EO_OK;
	}
	return NOT_SUPPORTED;

}

uint32_t eoConverter::Hash(char const * str)
{
	unsigned int h;
	unsigned char *p;

	h = 0;
	for (p = (unsigned char*) str; *p != '\0'; p++)
		h = MULTIPLIER * h + *p;
	return h; // or, h % ARRAY_SIZE;
}
eoReturn eoConverter::remanToPacket(const eoReManMessage &reManMes, eoPacket &packet)
{
	//checks Buffer Size before returning dataLength
	if (packet.getBufferSize() < (reManMes.GetDataLength() + 4 + 10))
		return OUT_OF_RANGE;

	packet.type = PACKET_REMOTE_MAN_COMMAND;
	packet.dataLength = reManMes.GetDataLength() + 4;

	packet.data[0] = reManMes.fnCode >> 8;
	packet.data[1] = reManMes.fnCode & 0xFF;
	packet.data[2] = reManMes.manufacturerID >> 8;
	packet.data[3] = reManMes.manufacturerID & 0xFF;

	memcpy(&packet.data[4], &reManMes.data[0], packet.dataLength - 4);

	uint8_t i = (uint8_t)packet.dataLength;

	packet.data[i] = (uint8_t)(reManMes.destinationID >> 24);
	packet.data[i + 1] = (uint8_t)(reManMes.destinationID >> 16);
	packet.data[i + 2] = (uint8_t)(reManMes.destinationID >> 8);
	packet.data[i + 3] = (uint8_t)reManMes.destinationID;

	packet.data[i + 4] = (uint8_t)(reManMes.sourceID >> 24);
	packet.data[i + 5] = (uint8_t)(reManMes.sourceID >> 16);
	packet.data[i + 6] = (uint8_t)(reManMes.sourceID >> 8);
	packet.data[i + 7] = (uint8_t)reManMes.sourceID;

	packet.data[i + 8] = 0xFF;
	packet.data[i + 9] = 0x00;
	packet.optionalLength = 0x0A;

	return EO_OK;
}

eoReturn eoConverter::packetToReman(const eoPacket &packet, eoReManMessage &reManMes)
{
	if (packet.type != PACKET_REMOTE_MAN_COMMAND)
		return WRONG_PARAM;

	if (packet.dataLength > reManMes.GetMaxLength() + 20)
		return WRONG_PARAM;

	reManMes.SetDataLength(packet.dataLength - 4);
	reManMes.fnCode = packet.data[0] << 8 | packet.data[1];
	reManMes.manufacturerID = packet.data[2] << 8 | packet.data[3];

	memcpy(&reManMes.data[0], &packet.data[4], packet.dataLength - 4);

	uint8_t i = (uint8_t)packet.dataLength;

	reManMes.destinationID = packet.data[i] << 24 | packet.data[i + 1] << 16 | packet.data[i + 2] << 8 | packet.data[i + 3];
	reManMes.sourceID = packet.data[i + 4] << 24 | packet.data[i + 5] << 16 | packet.data[i + 6] << 8 | packet.data[i + 7];

	return EO_OK;
}

eoReturn eoConverter::celsiusToFahrenheit(float &value)
{
	value = value * (9.0f/5.0f) + 32;
	return EO_OK;
}

eoReturn eoConverter::fahrenheitToCelsius(float &value)
{
	value = (value - 32) * (5.0f/9.0f);
	return EO_OK;
}

eoReturn eoConverter::literToMeter3(float &value)
{
	value = value / 1000;
	return EO_OK;
}

eoReturn eoConverter::meter3ToLiter(float &value)
{
	value = value * 1000;
	return EO_OK;
}
