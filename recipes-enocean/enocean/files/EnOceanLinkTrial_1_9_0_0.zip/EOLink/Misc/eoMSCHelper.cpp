/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoMSCHelper.h"

eoReturn eoMSCHelper::GetMSCmanufacturer(MANUFACTURER_LIST *manufacturer, eoMessage& msg)
{
	if (msg.RORG != RORG_MSC)
		return EO_ERROR;
	uint16_t tmp = msg.data[0] << 4 | ((msg.data[1] & 0xF0) >> 4);
	*manufacturer = (MANUFACTURER_LIST)tmp;
	return EO_OK;
}

eoReturn eoMSCHelper::GetMSCpayload(uint8_t *payload, uint8_t maxDataCount, eoMessage& msg)
{
	if (msg.RORG != RORG_MSC)
		return EO_ERROR;

	for (uint8_t i = 1; i < maxDataCount || i < msg.dataLength; i++)
	{
		*(payload + i - 1) = (msg.data[i] & 0x0F) << 4;
		if ((i+1) > msg.dataLength)
			break;
		*(payload + i - 1) |= (msg.data[i + 1] & 0xF0) >> 4;
	}

	return EO_OK;
}

eoReturn eoMSCHelper::SetMSCmanufacturer(const MANUFACTURER_LIST manufacturer, eoMessage &msg)
{
	msg.data[0] = (uint8_t)(manufacturer >> 4);
	msg.data[1] |= (uint8_t)((manufacturer << 4) & 0xF0);
	return EO_OK;
}

eoReturn eoMSCHelper::SetMSCpayload(const uint8_t *payload, uint8_t dataCount, eoMessage &msg)
{
	if (dataCount > 12)
		return WRONG_PARAM;

	msg.data[1] |= ((*payload) >> 4) & 0x0F;
	for (uint8_t i = 0; i < dataCount; i++)
	{
		msg.data[2+i] = (*(payload + i) & 0x0F) << 4;
		msg.data[2+i] |= (*(payload + i + 1) & 0xF0) >> 4;
	}

	return EO_OK;
}
