/******************************************************************************
DISCLAIMER

THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
CRIMINAL SANCTION.

THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
******************************************************************************/

#include "eoGpChainer.h"
#include "eoGateway.h"
#include "eoTimer.h"
#include <string.h>
using namespace std;

#define GP_HEADER_LENGTH 1
#define GP_FIRST_HEADER_LENGTH 3
#define BROADCOAST_LENGTH 5
// Problem timeout can be more
#define GP_TIMEOUT_FOR_CDM 250

eoGpChainer::eoGpChainer()
{
	seq = 0;
}

eoGpChainer::~eoGpChainer()
{
	map<uint32_t, eoChainedMessage*>::iterator p;
	for (p = list.begin(); p != list.end() &&!list.empty(); ++p)
	{
		if(p->second!=NULL)
		{
			delete p->second;
		}
		p->second=NULL;
	}

	list.clear();
}

void eoGpChainer::CleanUpList()
{
	map<uint32_t, eoChainedMessage*>::iterator p;
	for (p = list.begin(); p != list.end() && !list.empty(); ++p)
	{
		if (p->second!=NULL && (eoTimer::GetTickCount()	- p->second->timeStamp)  > GP_TIMEOUT_FOR_CDM)
		{
			delete (p->second);
			p->second=NULL;
			map<uint32_t, eoChainedMessage*>::iterator deleteIterator=p;
			if(p==list.begin())
			{
				list.erase(deleteIterator);
				if(list.empty())
				{
					break;
				}
				p=list.begin();
			}
			else
			{
				--p;
				list.erase(deleteIterator);
			}
		}
	}

}

eoChainedMessage* eoGpChainer::GetChainedMessage(const eoTelegram &tel,eoReturn &retValue)
{
	eoChainedMessage* chm=NULL;
	if (list.find(tel.sourceID) == list.end())
	{
		chm = new eoChainedMessage(32);
		list[tel.sourceID] = chm;
		chm->RORG = tel.RORG;
		chm->securityLevel = tel.securityLevel;
		chm->sourceID = tel.sourceID;
		chm->destinationID = tel.destinationID;
		chm->sizeN = 0;
		chm->seq = (tel.data[0] >> 6) & 0x03;
		chm->RORG = tel.data[3];
		chm->timeStamp = eoTimer::GetTickCount();
	}
	else
	{
		chm=list[tel.sourceID];
		if (eoTimer::GetTickCount() - chm->timeStamp > GP_TIMEOUT_FOR_CDM)
		{
			delete chm;
			chm = NULL;
			list.erase(tel.sourceID);
			retValue=TIME_OUT;
		}
		else
		{
			chm->timeStamp = eoTimer::GetTickCount();
		}
	}
	return chm;
}
eoReturn eoGpChainer::AddParsedChainedMessage(eoTelegram const &tel, eoMessage &msg,eoChainedMessage* chm)
{
	eoReturn retValue=NO_RX;
	uint8_t idx = tel.data[0] & 0x3F;
	uint8_t len = tel.dataLength - GP_HEADER_LENGTH;
	uint8_t const *  dataBuffer = &tel.data[1];

	if(idx == 0)
	{
		chm->expectedDataLength = tel.data[2] + ((uint16_t) tel.data[1] << 8);
		chm->dataChunks.resize(chm->expectedDataLength/len + 1);
		len -= GP_FIRST_HEADER_LENGTH;
		chm->SetDataLength(chm->expectedDataLength, true);
		chm->RORG=tel.data[3];
		dataBuffer = &tel.data[4];
		retValue=NO_RX;
	}
	chm->sizeN += len;
	if(chm->sizeN > chm->expectedDataLength)
	{
		chm->seq = 0;
		chm->sizeN -= len;
		retValue=OUT_OF_RANGE;
	}
	if (retValue == NO_RX)
	{
		if(idx>=chm->dataChunks.size())
		{
			chm->dataChunks.resize((idx+1));
		}
		if(!chm->dataChunks[idx].IsReceived())
		{
			chm->dataChunks[idx].CopyDataFrom(dataBuffer, len);
		}
		if (chm->sizeN == chm->expectedDataLength)
		{
			//chm->expectedTelCount=idx+1;
			retValue=chm->ProcessChunks();
			if(retValue==EO_OK)
			{
				chm->copyTo(msg);
			}
			list.erase(chm->sourceID);
			delete chm;

		}
	}
	return retValue;
}
eoReturn eoGpChainer::ParseChainedMessage(eoTelegram &tel, eoMessage &msg)
{
	eoReturn retValue=NO_RX;
  
	eoChainedMessage *chm = NULL;
	chm=GetChainedMessage(tel,retValue);
	if(retValue==NO_RX&&chm!=NULL)
	{
		uint8_t seq = (tel.data[0] >> 6) & 0x03;
		if (seq != chm->seq)
		{
			retValue=NO_RX;
		}
		else if(chm->received)
		{
			retValue=NO_RX;
		}
		else
		{
			retValue=AddParsedChainedMessage(tel,msg, chm);
		}

	}
	return retValue;
}

eoReturn eoGpChainer::SendChainedMessage(const eoMessage& msg,
		eoGateway& gateway)
{
	eoReturn retValue=EO_ERROR;
	uint8_t idx;
	uint8_t len;
	seq += 1;
	uint8_t firstTelLength = (msg.destinationID == BROADCAST_ID) ? 10 : 5;
	//No. of telegrams needed when first holds 10b and the following 13b each
	uint8_t telLength = (msg.destinationID == BROADCAST_ID) ? 13 : 8;
	uint8_t telCount = (uint8_t)(1 + ((msg.GetDataLength() + 2) / telLength));
	uint8_t offset;

	eoMessage outMsg(14);
	outMsg.RORG =RORG_CDM;
	outMsg.status = msg.status;
	outMsg.sourceID = msg.sourceID;
	outMsg.destinationID = msg.destinationID;
	outMsg.securityLevel = msg.securityLevel;

	for (idx = 0; idx < telCount; idx++)
	{
		outMsg.data[0] = idx;
		outMsg.data[0] |= (uint8_t) (seq << 6);

		if (idx == 0)
		{
			//first telegram contains 10bytes of payload
			offset = 4;
			//Length is encoded in data[1] and data[2]
			outMsg.data[1] = (msg.GetDataLength() >> 8) & 0xFF;
			outMsg.data[2] = msg.GetDataLength() & 0xFF;
			outMsg.data[3]= msg.RORG;
			if (msg.destinationID != BROADCAST_ID)
				outMsg.SetDataLength(9, false);
			memcpy(&outMsg.data[offset], &msg.data[0], firstTelLength);
		}
		else
		{
			offset = (idx - 1) * telLength + firstTelLength;
			len = (uint8_t)(idx == (telCount - 1) ? (msg.GetDataLength()) - firstTelLength - (idx - 1) * telLength : telLength);
			outMsg.SetDataLength(len + 1, false);
			memcpy(&outMsg.data[1], &msg.data[offset], len);
		}
		retValue=gateway.Send(outMsg);
		if(retValue!=EO_OK)
		{
			break;
		}
	}
	return EO_OK;

}
