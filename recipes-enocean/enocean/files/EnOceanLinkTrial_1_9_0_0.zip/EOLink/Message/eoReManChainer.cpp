/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoReManChainer.h"
#include "eoTimer.h"
#include "eoGateway.h"
#include <string.h>

#include <iostream>
using namespace std;
// Problem timeout can be more
#define RM_TIMEOUT_FOR_TELEGRAM_CHAIN 100 + 100
#define RM_RETURN_CODE_MESSAGE_NOT_RECEIVED 10
#define RM_RETURN_CODE_MESSAGE_TIME_OUT 11
#define RM_RETURN_CODE_MESSAGE_SEQ 12

#define BROADCOAST_ID 0xFFFFFFFF

eoReManChainer::eoReManChainer()
{
	seq = 1;
	reapeaterEnabled = false;
}

eoReManChainer::~eoReManChainer()
{
	map<uint32_t, eoChainedReManMessage*>::iterator p;
	for (p = list.begin(); p != list.end() && !list.empty(); ++p)
	{
		if(p->second!=NULL)
		{
			delete p->second;
		}
		p->second=NULL;
	}

	list.clear();
}

void eoReManChainer::CleanUpList()
{
	map<uint32_t, eoChainedReManMessage*>::iterator p;

	for (p = list.begin(); p != list.end() && !list.empty(); ++p)
	{
		if ((p->second!=NULL) && (eoTimer::GetTickCount() - p->second->timeStamp) > RM_TIMEOUT_FOR_TELEGRAM_CHAIN)
		{
			delete (p->second);
			p->second=NULL;
			map<uint32_t, eoChainedReManMessage*>::iterator deleteIterator=p;
			if(p==list.begin())
			{
				list.erase(deleteIterator);
				if(list.empty())
				{
					break;
				}
				p=list.begin();
			}
			else
			{
				--p;
				list.erase(deleteIterator);
			}
		}
	}

}

eoReturn eoReManChainer::ParseChainedMessage(eoTelegram &tel, eoReManMessage &msg)
{
	uint8_t idx;
	uint8_t seq;
	uint8_t len;
	uint8_t* dataBuffer;
	eoReturn retValue=NO_RX;
	eoChainedReManMessage *chm = NULL;
	if (list.find(tel.sourceID) == list.end())
	{
		chm = new eoChainedReManMessage(32);
		chm->RORG = tel.RORG;
		chm->securityLevel = tel.securityLevel;
		chm->sourceID = tel.sourceID;
		list[tel.sourceID] = chm;
		chm->seq = (tel.data[0] >> 6) & 0x03;
		chm->sizeN = 0;
	}
	else
	{
		chm=list[tel.sourceID];
		if (eoTimer::GetTickCount() - chm->timeStamp > RM_TIMEOUT_FOR_TELEGRAM_CHAIN)
		{
			list.erase(tel.sourceID);
			delete chm;
			return TIME_OUT;
		}
		if(chm->received)
			return NO_RX;
	}

	chm->timeStamp = eoTimer::GetTickCount();

	idx = tel.data[0] & 0x3F;
	seq = (tel.data[0] >> 6) & 0x03;
	dataBuffer = &tel.data[1];

	if (seq != chm->seq)
		return NO_RX;

	if (idx == 0)
	{
		//check if one telegram has been received!
		chm->expectedDataLength = (tel.data[1] << 1) | ((tel.data[2] & 0x80) >> 7);

		chm->manufacturerID = ((tel.data[2] & 0x7F) << 4) | ((tel.data[3] >> 4) & 0x0F);
		chm->fnCode = ((tel.data[3] & 0x0F) << 8) | tel.data[4];
		len = 4;

		chm->SetDataLength(chm->expectedDataLength, true);
		dataBuffer = &tel.data[5];
		if(chm->expectedDataLength ==0)
		{
			chm->copyTo(msg);
			return EO_OK;
		}
		chm->dataChunks.resize(chm->expectedDataLength/tel.dataLength+1);//this is just a estimation
	}
	else
	{
		if (chm->expectedDataLength - chm->sizeN >= 8)
		{
			len = 8;
		}
		else
		{
			len = (uint8_t)(chm->expectedDataLength - chm->sizeN);
		}
		dataBuffer = &tel.data[1];
	}

	chm->sizeN += len;
	if(chm->sizeN <= chm->expectedDataLength)
	{
		//IDX start with 0,size with 1, == means idx>vector sizes
		if(idx>=chm->dataChunks.size())
		{
			chm->dataChunks.resize((idx+1));
		}
		if(!chm->dataChunks[idx].IsReceived())
		{
			chm->dataChunks[idx].CopyDataFrom(dataBuffer, len);
		}

	}
	else
	{
		chm->seq = 0;
		retValue=OUT_OF_RANGE;
	}

	if (chm->sizeN == chm->expectedDataLength)
	{
		chm->expectedTelCount=idx+1;
		retValue=chm->ProcessChunks();
		if(retValue==EO_OK)
		{
			chm->copyTo(msg);
		}
	}
	return retValue;
}

eoReturn eoReManChainer::SendChainedMessage(const eoReManMessage& msg, eoGateway& gateway, bool reapeaterEnabled)
{
	eoReturn retValue=EO_ERROR;
	uint8_t idx;
	seq += 1;
	if(seq%4==0)
		seq += 1;
	uint8_t len;
	uint8_t telCount = (uint8_t)(1 + ((msg.GetDataLength() + 3) / 8));
	uint8_t offset;

	eoMessage outMsg(9);
	outMsg.RORG = RORG_SYS_EX;
	outMsg.status = reapeaterEnabled ? 0x80: 0x8F ;
	outMsg.sourceID = msg.sourceID;
	outMsg.destinationID = msg.destinationID;
	outMsg.securityLevel = msg.securityLevel;

	for (idx = 0; idx < telCount; idx++)
	{
		outMsg.data[0] = idx;
		outMsg.data[0] |= (uint16_t) (seq << 6);

		if (idx == 0)
		{
			len = 4;
			offset = 5;
			outMsg.data[1] = (uint8_t)((msg.GetDataLength() & 0x1FE) >> 1);
			outMsg.data[2] = (uint8_t)(((msg.GetDataLength() & 0x01) << 7) | ((msg.manufacturerID & 0x7F0) >> 4));
			outMsg.data[3] = (uint8_t)(((msg.manufacturerID & 0x0F) << 4) | ((msg.fnCode & 0xF00) >> 8));
			outMsg.data[4] = (uint8_t)((msg.fnCode & 0xFF));
			memcpy(&outMsg.data[offset], &msg.data[0], len);
		}
		else
		{
			offset = (idx - 1) * 8 + 4;
			len = (uint8_t)(idx == telCount ? msg.GetDataLength() - (4 + (idx - 1) * 8) : 8);
			memcpy(&outMsg.data[1], &msg.data[offset], len);
		}
		retValue=gateway.Send(outMsg);
		if (retValue != EO_OK)
		{
			break;
		}

		eoTimer::Sleep(40);
	}
	return retValue;

}
