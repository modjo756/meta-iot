/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/
#include "eoTelegramERP2.h"
#include <string.h>

eoTelegramERP2::eoTelegramERP2(uint16_t size) :
	eoTelegram(size)
{
	defaultConstructor();
}

eoTelegramERP2::eoTelegramERP2(const eoTelegramERP2& telegram) :
	eoTelegram(telegram)
{
	defaultConstructor();
}

void eoTelegramERP2::defaultConstructor()
{
	memset(optionalData, 0, 15);
	sourceIDMSB=0;
	sourceIDLength=SourceID32Bit;
	destIDLength=NoDestinationID;
	optionalDataLength=0;
	repeaterCount=0;
}

eoTelegramERP2::~eoTelegramERP2()
{

}

void eoTelegramERP2::Clear()
{
	memset(optionalData, 0, 15);
	sourceIDMSB=0;
	sourceIDLength=SourceID32Bit;
	destIDLength=NoDestinationID;
	optionalDataLength=0;
	repeaterCount=0;
	eoTelegram::Clear();
}
eoReturn eoTelegramERP2::SetDataLength(uint16_t dataLen, bool reallocate)
{
	if (optionalDataLength + dataLen > 255)
		return OUT_OF_RANGE;
	return eoAbstractMessage::SetDataLength(dataLen, reallocate);
}

eoReturn eoTelegramERP2::copyTo(eoTelegramERP2 &msg) const
{
	eoReturn ret=eoTelegram::copyTo(msg);
	if(ret!=EO_OK)
		return ret;
	msg.sourceIDMSB=sourceIDMSB;
	msg.sourceIDLength=sourceIDLength;
	msg.destIDLength=destIDLength;
	msg.repeaterCount=repeaterCount;
	ret = msg.SetOptionalDataLength(optionalDataLength);
	memcpy(msg.optionalData,optionalData,15);
	return ret;
}
eoReturn eoTelegramERP2::copyTo(eoTelegram &msg) const
{
	return eoTelegram::copyTo(msg);
}
eoReturn eoTelegramERP2::copyTo(eoMessage &msg) const
{
	return eoMessage::copyTo(msg);
}

uint8_t eoTelegramERP2::GetOptionalDataLength() const
{
	return optionalDataLength;
}
//Return false if the length could not be modified
eoReturn eoTelegramERP2::SetOptionalDataLength(uint8_t u8Length)
{
	if(u8Length>15)
		return OUT_OF_RANGE;
	if (u8Length + dataLength > 255)
		return OUT_OF_RANGE;
	else
		optionalDataLength = u8Length;
	return EO_OK;
}

uint8_t eoTelegramERP2::GetRepeaterCount(void) const
{
	return repeaterCount;
}
eoReturn eoTelegramERP2::SetRepeaterCount(uint8_t repCounter)
{
	if (repeaterCount > 15)
		return OUT_OF_RANGE;
	repeaterCount = repCounter;
	return EO_OK;
}
