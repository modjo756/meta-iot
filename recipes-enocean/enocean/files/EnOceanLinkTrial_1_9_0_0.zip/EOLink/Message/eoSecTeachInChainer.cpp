/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoSecTeachInChainer.h"
#include "eoGateway.h"
#include "eoTimer.h"
#include <string.h>

using namespace std;

#define SEC_TI_TYPE 2
#define SEC_TI_CNT 4
#define SEC_TI_IDX 6
#define SEC_TI_HEADER 1
//Systen timeout..
#define RM_TIMEOUT_FOR_SEC_TEACH_IN 10000 + 100

eoSecTeachInChainer::eoSecTeachInChainer()
{
}

eoSecTeachInChainer::~eoSecTeachInChainer()
{
	map<uint32_t, eoChainedMessage*>::iterator p;
	for (p = list.begin(); p != list.end() && !list.empty(); ++p)
	{
		if(p->second!=NULL)
		{
			delete p->second;
		}
		p->second=NULL;
	}

	list.clear();
}

void eoSecTeachInChainer::CleanUpList()
{
	map<uint32_t, eoChainedMessage*>::iterator p;

	for (p = list.begin(); !list.empty()&& p != list.end()  ; ++p)
	{
		if ((p->second!=NULL) && (eoTimer::GetTickCount() - p->second->timeStamp) > RM_TIMEOUT_FOR_SEC_TEACH_IN)
		{
			delete (p->second);
			p->second=NULL;
			map<uint32_t, eoChainedMessage*>::iterator deleteIterator=p;
			if(p==list.begin())
			{
				list.erase(deleteIterator);
				if(list.empty())
				{
					break;
				}
				p=list.begin();
			}
			else
			{
				--p;
				list.erase(deleteIterator);
			}
		}
	}

}

eoReturn eoSecTeachInChainer::ParseChainedMessage(eoTelegram &tel, eoMessage &msg)
{
	eoChainedMessage *chm = NULL;
	uint8_t idx = (tel.data[0] >> 6) & 0x03;
	if (list.find(tel.sourceID) == list.end())
	{
		chm = new eoChainedMessage(32);
		chm->RORG = RORG_SEC_TI;
		chm->expectedDataLength=32;
		chm->sourceID=tel.sourceID;
		list[tel.sourceID] = chm;
		msg.sourceID=tel.sourceID;
	}
	else
	{
		chm = list[tel.sourceID];
		if (eoTimer::GetTickCount() - chm->timeStamp > RM_TIMEOUT_FOR_SEC_TEACH_IN)
		{
			list.erase(tel.sourceID);
			delete chm; //free memory...
			return TIME_OUT;
		}
		else if(chm->received==true)
			return NO_RX;
	}
	chm->timeStamp = eoTimer::GetTickCount();

	eoChunkMessage *curMessage=NULL;

	if (idx == 0)
	{
		//chm->SetDataLength(tel.GetDataLength());
        chm->expectedTelCount = (tel.data[0] >> 4) & 0x3;
		//Only resize if we get more then expected, otherwise deconstructor is not called!
		if(chm->expectedTelCount>chm->dataChunks.size())
		{
	        chm->dataChunks.resize(chm->expectedTelCount);
		}
     	curMessage=&(chm->dataChunks[idx]);
     	curMessage->CopyFrom(tel);

	}
	else if(idx<chm->dataChunks.size())
	{
     	curMessage=&(chm->dataChunks[idx]);
		if(!curMessage->IsReceived())
		{
			curMessage->CopyDataFrom(&tel.data[1],tel.GetDataLength() - SEC_TI_HEADER);
		}
	}
	else
	{
		return EO_ERROR;
	}
	// Received all telegrams
	if (chm->expectedTelCount == (idx + 1))//Idx starts with 0
	{
		eoReturn retValue=chm->ProcessChunks();
		if(retValue==EO_OK)
		{
			chm->copyTo(msg);
		}
		else
		{

		}
		return retValue;
	}

	return ONGOING_RX;
}

eoReturn eoSecTeachInChainer::SendChainedMessage(const eoMessage& msg, eoGateway& gateway)
{
	eoReturn retValue=EO_ERROR;
	uint8_t idx;
	//First byte contains teachInfo, payload is 13bytes
	uint8_t telCount = (uint8_t)((msg.GetDataLength()-SEC_TI_HEADER)/13+((msg.GetDataLength()-SEC_TI_HEADER)%13!=0));
	uint8_t len = (uint8_t)((msg.GetDataLength()-SEC_TI_HEADER)/telCount+1);
	//uint8_t offset;
	uint8_t teachInInfo = 0;
	uint8_t offset=0;
	eoMessage outMsg(14);
	outMsg.RORG = msg.RORG;
	outMsg.status = msg.status;
	outMsg.sourceID = msg.sourceID;
	outMsg.destinationID = msg.destinationID;
	outMsg.securityLevel = msg.securityLevel;

	for (idx = 0; idx < telCount; idx++)
	{
		//Field IDX
		teachInInfo = (idx << SEC_TI_IDX);

		if (idx == 0)
		{
			//Field CNT
			teachInInfo |= (telCount << SEC_TI_CNT);
			//Field Type+Info
			teachInInfo |= msg.data[0] & 0x0F;
			offset=1;
		}
		else if(idx+1==telCount)//last telegram
		{
			len=msg.dataLength-offset;
		}
		memcpy(&outMsg.data[0], &teachInInfo, 1);
		memcpy(&outMsg.data[1], &msg.data[offset], len);
		outMsg.SetDataLength(len+1);
		retValue=gateway.Send(outMsg);
		if (retValue != EO_OK)
		{
			break;
		}
		offset+=len;
	}
	return retValue;
}
