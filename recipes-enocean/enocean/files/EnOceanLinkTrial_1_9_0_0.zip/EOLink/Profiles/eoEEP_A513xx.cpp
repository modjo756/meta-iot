/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A513xx.h"

#include "eoChannelEnums.h"
#include <string.h>
/*
 * Some internal informations CHANNEL 0= Humidity and CHANNEL 1 = Temperature
 */

const uint8_t numOfChan = 8;
const uint8_t numOfProfiles = 0x11;
const uint8_t numOfCommands = 0x11;
const EEP_ITEM listA513xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:01
{
{ true, 0, 8, 0, 255, 0, 999, S_LUMINANCE, 0 }, //Illuminance
{ true, 8, 8, 0, 255, -40, 80, S_TEMP, 0 }, //Temperature
{ true, 16, 8, 0, 255, 0, 70.0, S_VELOCITY, 0 }, //Wind speed
{ true, 29, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 }, //Day/Night
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, RAIN_NORAIN }, //Rain/ no rain
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:02
{
{ true, 0, 8, 0, 255, 0, 150, S_LUMINANCE, SUN_WEST }, //Sun west
{ true, 8, 8, 0, 255, 0, 150, S_LUMINANCE, SUN_SOUTH }, //Sun south
{ true, 16, 8, 0, 255, 0, 150, S_LUMINANCE, SUN_EAST }, //Sun east
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, 0 }, //Hemisphere
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:03
{
{ true, 3, 5, 1, 31, 1, 31, S_TIME, TIME_DAY }, //Day
{ true, 12, 4, 1, 12, 1, 12, S_TIME, TIME_MONTH }, //Month
{ true, 17, 7, 0, 99, 2000, 2099, S_TIME, TIME_YEAR }, //Year
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, TIME_SOURCE }, //Source
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:04
{
{ true, 0, 3, 1, 7, 1, 7, E_DAYS, 0 }, //Days
{ true, 3, 5, 0, 23, 0, 23, S_TIME, TIME_HOUR }, //Hour
{ true, 10, 6, 0, 59, 0, 59, S_TIME, TIME_MINUTE }, //Minute
{ true, 18, 6, 0, 59, 0, 59, S_TIME, TIME_SECOND }, //Second
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, TIME_FORMAT }, //Format
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, AM_PM }, //AM/PM
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, TIME_SOURCE }, //Source
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
},
//TYPE:05
{
{ true, 0, 8, 0, 180, -90, 90, S_ANGLE, ELEVATION }, //Elevation
{ true, 15, 9, 0, 359, 0, 359, S_ANGLE, AZIMUTH }, //Azimuth
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:06
{
{ true, 8, 8, 0, 4095, -90, 90, S_ANGLE, LATITUDE }, //Latitude
{ true, 16, 8, 0, 4095, -180, 180, S_ANGLE, LONGITUDE }, //Longitude
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:07
{
{ true, 4, 4, 0, 15, 0, 15, E_DIRECTION, 0 }, //Wind direction
{ true, 8, 8, 0, 255, 1, 199.9, S_VALUE, AVG_WIND_SPEED }, //Average wind speed
{ true, 16, 8, 0, 255, 1, 199.9, S_VALUE, MAX_WIND_SPEED }, //Maximum wind speed
{ true, 31, 1, 0, 1, 0, 1, E_STATE, 0 }, //Battery status
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:08
{
{ true, 2, 6, 0, 39, 0, 3.9, S_PERCENTAGE, 0 }, //Rainfall adjust
{ true, 8, 16, 0, 65535, 0, 65535, S_COUNTER, 0 }, //Rainfall count
{ true, 31, 1, 0, 1, 0, 1, E_STATE, 0 }, //Battery status
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:09
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0A
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0B
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0C
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0D
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0E
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0F
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:0x10
{
{ true, 0, 7, 0, 90, 0, 90, S_ANGLE, ELEVATION }, //Elevation
{ true, 7, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 }, //Day/night
{ true, 8, 8, 0, 180, -90, 90, S_ANGLE, AZIMUTH }, //Azimuth
{ true, 16, 8, 0, 2000, 0, 2000, S_SOLAR_RAD, 0 },
{ true, 24, 4, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
};

eoEEP_A513xx::eoEEP_A513xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	rorg = RORG_4BS;
	func = 0x13;
	cmd = 0;
}

eoEEP_A513xx::~eoEEP_A513xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_A513xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;

	if (type > numOfProfiles || type == 0x00)
		return NOT_SUPPORTED;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA513xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA513xx[type][tmpChannelCount].type;
			channel[channelCount].max = listA513xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA513xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA513xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (type == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	this->cmd = type;

	return EO_OK;
}
eoReturn eoEEP_A513xx::Parse(const eoMessage &m)
{
	if (Is4BSData(m))
	{
		switch (this->type)
		{
			case 0x07:
				SetCommand(0x07);
				break;
			case 0x08:
				SetCommand(0x08);
				break;
			case 0x10:
				SetCommand(0x10);
				break;
			default:
				SetCommand((m.data[3] & 0xF0) >> 4);
				break;
		}
		return eoProfile::Parse(m);
	}

	return NOT_SUPPORTED;
}
eoReturn eoEEP_A513xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	channelCount = 0;

	if (cmd > numOfCommands)
		return OUT_OF_RANGE;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA513xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA513xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listA513xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA513xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA513xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (cmd > numOfProfiles || cmd == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	this->cmd = cmd;

	uint32_t rawValue = this->cmd;

	switch (this->cmd)
	{
		case 0x07:
		case 0x08:
			break;
		default:
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;
	}
	return EO_OK;
}

eoReturn eoEEP_A513xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}
	if (this->cmd == 0 || this->cmd > numOfCommands)
		return NOT_SUPPORTED;
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_OPEN_CLOSED:
		case F_DAY_NIGHT:
			rawValue = value ? 0 : 1;
			break;
		case E_DAYS:
		case E_STATE:
		case E_DIRECTION:
			rawValue = value;
			break;
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	switch (this->cmd)
	{
		case 0x07:
		case 0x08:
			break;

		case 0x10:
			rawValue = 0x07;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;

		default:
			rawValue = this->cmd;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	//if (SetCommand((msg.data[3] & 0xF0) >> 4) != EO_OK)
	//	return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_OPEN_CLOSED:
		case F_DAY_NIGHT:
			value = rawValue ? 0 : 1;
			break;

		case E_DAYS:
		case E_STATE:
		case E_DIRECTION:
			value = (uint8_t)rawValue;
			break;
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (type == S_PERCENTAGE)
	{
		if (value < 0.0)
		{
			value *= -1;
			rawValue = 0;
			SetRawValue(msg, rawValue, (uint8_t)1, (uint8_t)1);
		}
		else
		{
			rawValue = 1;
			SetRawValue(msg, rawValue, (uint8_t)1, (uint8_t)1);
		}
	}

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_LUMINANCE:
		case S_TEMP:
		case S_VELOCITY:
		case S_TIME:
		case S_COUNTER:
		case S_PERCENTAGE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

			SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
			break;

		case S_SOLAR_RAD:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			tmpRawValue = rawValue >> 3;
			//MSB 8 bits first (offset 16)
			SetRawValue(msg, tmpRawValue, 16, 8);
			tmpRawValue = rawValue & 0x07;
			//then LSB last 3 bits (offset 29)
			SetRawValue(msg, tmpRawValue, 29, 3);
			break;

		default:
			return NOT_SUPPORTED;//TOBI return and break is not needed
	}

	switch (this->cmd)
	{
		case 0x07:
		case 0x08:
			break;

		case 0x10:
			rawValue = 0x07;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;

		default:
			rawValue = this->cmd;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::GetValue(CHANNEL_TYPE type, float &value)
{
	//if (SetCommand((msg.data[3] & 0xF0) >> 4) != EO_OK)
	//	return NOT_SUPPORTED;

	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_LUMINANCE:
		case S_TEMP:
		case S_VELOCITY:
		case S_TIME:
		case S_COUNTER:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_SOLAR_RAD:
			uint32_t tmpValue;
			if (GetRawValue(msg, tmpValue, 16, 8) != EO_OK)
				return NOT_SUPPORTED;
			rawValue = (tmpValue << 3);
			if (GetRawValue(msg, tmpValue, 29, 3) != EO_OK)
				return NOT_SUPPORTED;
			rawValue |= tmpValue;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_PERCENTAGE:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

			GetRawValue(msg, tmpRawValue, (uint8_t)1, (uint8_t)1);

			if (tmpRawValue == 0x00)
				value *= -1;

			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;
		default:
			return SetValue(type, value);
			break;
	}
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	switch (this->cmd)
	{
		case 0x07:
		case 0x08:
			break;

		case 0x10:
			rawValue = 0x07;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;

		default:
			rawValue = this->cmd;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;

		default:
			return GetValue(type, value);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_LUMINANCE:
		case S_VALUE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TIME:
			if (index == TIME_YEAR)
				rawValue = (uint32_t)(value - 2000);
			else
				rawValue = (uint32_t)(value);
			break;
		case S_ANGLE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			if (this->type != 0x05)
			{
				uint32_t tmpRawValue = rawValue >> 8;
				switch (index)
				{
					case LATITUDE:
						SetRawValue(msg, tmpRawValue, 0, 4);
						rawValue = rawValue & 0xFF;
						break;

					case LONGITUDE:
						SetRawValue(msg, tmpRawValue, 4, 4);
						rawValue = rawValue & 0xFF;
						break;
				}
			}
			break;

		default:
			return SetValue(type, value);

	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	switch (this->cmd)
	{
		case 0x07:
		case 0x08:
			break;

		case 0x10:
			rawValue = 0x07;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;

		default:
			rawValue = this->cmd;
			SetRawValue(msg, rawValue, (uint16_t)24, (uint8_t)4);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A513xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_LUMINANCE:
		case S_TIME:
		case S_VALUE:
			if (index == TIME_YEAR)
				value = (float)(rawValue + 2000);
			else
				value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_ANGLE:
			if (this->type != 0x05)
			{
				uint32_t tmpValue;
				switch (index)
				{
					case LATITUDE:
						if (GetRawValue(msg, tmpValue, 0, 4) != EO_OK)
							return NOT_SUPPORTED;
						rawValue = tmpValue << 8;
						if (GetRawValue(msg, tmpValue, 8, 8) != EO_OK)
							return NOT_SUPPORTED;
						rawValue |= tmpValue;
						break;
					case LONGITUDE:
						if (GetRawValue(msg, tmpValue, 4, 4) != EO_OK)
							return NOT_SUPPORTED;
						rawValue = tmpValue << 8;
						if (GetRawValue(msg, tmpValue, 16, 8) != EO_OK)
							return NOT_SUPPORTED;
						rawValue |= tmpValue;
						break;

				}
			}
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return GetValue(type, value);

	}

	return EO_OK;
}

eoChannelInfo* eoEEP_A513xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA513xx[cmd][tmpChannelCount].type == type && listA513xx[cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
