/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_A511_H__INCLUDED_)
#define eoEEP_A511_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
/**\class eoEEP_A511xx
 * \brief The class to handle EEP a511 profiles
 * \details Allows the user to handle EEP a511 profiles, the following profiles are available:
 * 		- A5-11-01
 * 		- A5-11-02
 * 		- A5-11-03
 * 		- A5-11-04
 * 		- A5-11-05\n\n
 *
 * The following channels are available for 01 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_LUMINANCE   	|float | |
 * | 1             | ::S_LUMINANCE_ABS 	|float | |
 * | 2             | ::S_DIMMING       	|float | | 
 * | 3             | ::F_ON_OFF		   	|uint8_t | Repeater, ::CS_REPEATER |
 * | 4             | ::F_ON_OFF   		|uint8_t | Power relay timer, ::CS_POWER_RELAY_TIMER |
 * | 5             | ::F_ON_OFF   		|uint8_t | Daylight harvesting, ::CS_DAYLIGHT_HARVEST |
 * | 6             | ::F_ON_OFF   		|uint8_t | Dimming, ::CS_DIMMING |
 * | 7             | ::F_OPEN_CLOSED   	|uint8_t |  |
 * | 8             | ::F_BTN_PRESS   	|uint8_t | |
 * | 9             | ::F_ON_OFF		   	|uint8_t | Power relay, ::CS_POWER_RELAY |
 * \n
 * The following channels are available for 02 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT   	|float |  |
 * | 1             | ::E_FANSPEED	 	|::CS_FAN_STAGE |  |
 * | 2             | ::S_TEMP_ABS      	|float |  |
 * | 3             | ::F_ON_OFF		   	|uint8_t | Alarm, ::CS_ALARM |
 * | 4             | ::E_CONTROLLER_MODE|::CS_ENUM_CONTROLLER_MODE |  |
 * | 5             | ::F_ON_OFF   		|uint8_t | Controller state, ::CS_CONTROLLER_STATE |
 * | 6             | ::F_ON_OFF   		|uint8_t | Energy hold-off, ::CS_ENERGY_HOLDOFF |
 * | 7             | ::E_OCCUPANCY   	|::CS_ENUM_ROOM_OCCUPANCY |   |
 * \n
 * The following channels are available for 03 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT   	|float |  |
 * | 1             | ::F_ON_OFF		 	|uint8_t | Angle sign, ::CS_ANGLE_SIGN |
 * | 2             | ::S_ANGLE      	|float |   |
 * | 3             | ::F_ON_OFF		   	|uint8_t | Position value flag, ::CS_POSITION_VALUE |
 * | 4             | ::F_ON_OFF			|uint8_t | Angle value flag, ::CS_ANGLE_VALUE |
 * | 5             | ::E_ERROR_STATE   	|::CS_ENUM_03_ERROR_STATE |  |
 * | 6             | ::E_END_POS   		|::CS_ENUM_END_POS |  |
 * | 7             | ::E_STATE		   	|::CS_ENUM_BLIND_STATE |  |
 * | 8             | ::F_ON_OFF		   	|uint8_t | Service mode, ::CS_SETVICE_MODE |
 * | 9             | ::F_ON_OFF			|uint8_t | Mode of the position, ::CS_MODE_OF_POSITION |
 * \n
 * The following channels are available for 04 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_RGB		   	|float | RGB Red, ::CS_RGB_RED |
 * | 1             | ::S_RGB		 	|float | RGB Green, ::CS_RGB_GREEN |
 * | 2             | ::S_RGB	       	|float | RGB Blue, ::CS_RGB_BLUE |
 * | 3             | ::S_DIMMING	   	|float |  |
 * | 4             | ::S_TIME   		|float |  |
 * | 5             | ::S_VALUE			|float |  |
 * | 6             | ::E_UNITS			|::CS_ENERGY_UNITS |  |
 * | 7             | ::F_ON_OFF   		|uint8_t | Service mode, ::CS_SETVICE_MODE |
 * | 8             | ::F_ON_OFF   		|uint8_t | Operating hours, ::CS_OPERATING_HOURS |
 * | 9             | ::E_ERROR_STATE   	|::CS_ENUM_04_ERROR_STATE |   |
 * | 10            | ::F_ON_OFF		   	|uint8_t | Status, ::CS_STATUS |
 * \n
 * The following channels are available for 05 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_CONTROLLER_MODE| ::CS_WORKING_MODE |
 * | 1             | ::E_STATE		 	| ::CS_RELAY_STATUS |
 * \n
 */

/**
 * \file eoEEP_A511xx.h
 */
//! Index enums for A5-11-xx profiles
typedef enum
{
	//! <b>Repeater</b> 0
	CS_REPEATER = 0x00,
	//! <b>Power relay timer</b> 1
	CS_POWER_RELAY_TIMER = 0x01,
	//! <b>Daylight Harvest</b> 2
	CS_DAYLIGHT_HARVEST = 0x02,
	//! <b>Dimming</b> 3
	CS_DIMMING = 0x03,
	//! <b>Power relay</b> 4
	CS_POWER_RELAY = 0x04,
	//! <b>Alarm</b> 5
	CS_ALARM = 0x05,
	//! <b>Controller state</b> 6
	CS_CONTROLLER_STATE = 0x06,
	//! <b>Energy hold-off</b> 7
	CS_ENERGY_HOLDOFF = 0x07,
	//! <b>Angle sign</b> 8
	CS_ANGLE_SIGN = 0x08,
	//! <b>Position value flag</b> 9
	CS_POSITION_VALUE = 0x09,
	//! <b>Angle value flag</b> 10
	CS_ANGLE_VALUE = 0x0A,
	//! <b>Service mode</b> 11
	CS_SETVICE_MODE = 0x0B,
	//! <b>Mode of the position</b> 12
	CS_MODE_OF_POSITION = 0x0C,
	//! <b>Operating hours flag</b> 13
	CS_OPERATING_HOURS = 0x0D,
	//! <b>Status</b> 14
	CS_STATUS = 0x0E,
	//! <b>RGB red</b> 15
	CS_RGB_RED = 0x0F,
	//! <b>RGB green</b> 16
	CS_RGB_GREEN = 0x10,
	//! <b>RGB blue</b> 17
	CS_RGB_BLUE = 0x11

} CS_INDEXES;

//!Units for A5-11-xx profiles
typedef enum
{
	//! <b>Mili Watt</b> 0
	CS_MILI_W = 0x00,
	//! <b>Watt</b> 1
	CS_W = 0x01,
	//! <b>Kilo Watt</b> 2
	CS_KILO_W = 0x02,
	//! <b>Mega Watt</b> 3
	CS_MEGA_W = 0x03,
	//! <b>Watthour</b> 4
	CS_WH = 0x04,
	//! <b>Kilo Watthour</b> 5
	CS_KILO_WH = 0x05,
	//! <b>Mega Watthour</b> 6
	CS_MEGA_WH = 0x06,
	//! <b>Giga Watthour</b> 7
	CS_GIGA_WH = 0x07,
	//! <b>Mili Amper</b> 8
	CS_MILI_A = 0x08,
	//! <b>1/10 Amper</b> 9
	CS_A_1_10 = 0x09,
	//! <b>Mili Volt</b> 10
	CS_MILI_V = 0x0A,
	//! <b>1/10 Volt</b> 11
	CS_V_1_10 = 0x0B
} CS_ENERGY_UNITS;

//!3 state error code for A5-11-xx profiles
typedef enum
{
	//! <b>No error</b> 0
	CS_NO_ERROR = 0x00,
	//! <b>Lamp failure</b> 1
	CS_LAMP_ERROR = 0x01,
	//! <b>Internal failure</b> 2
	CS_INTERNAL_ERROR = 0x02
} CS_ENUM_03_ERROR_STATE;

//!4 state error code for A5-11-xx profiles
typedef enum
{
	//! <b>No error</b> 0
	A5O_ERROR = 0x00,
	//! <b>Lamp failure</b> 1
	END_POS_NO_CONFIG = 0x01,
	//! <b>Internal failure</b> 2
	INTERNAL_ERROR = 0x02,
	//! <b>Failure on the external periphery</b> 3
	EXT_PERIPHERY_ERROR = 0x03
} CS_ENUM_04_ERROR_STATE;

//!Blind status for A5-11-xx profiles
typedef enum
{
	//! <b>Not available</b> 0
	NOT_AVAILABLE = 0x00,
	//! <b>Blind is stopped</b> 1
	BLIND_STOPPED = 0x01,
	//! <b>Blind opens</b> 2
	BLIND_OPENS = 0x02,
	//! <b>Blind closes</b> 3
	BLIND_CLOSES = 0x03
} CS_ENUM_BLIND_STATE;

//!Blind end position for A5-11-xx profiles
typedef enum
{
	//! <b>No end-position available</b> 0
	NO_END_POS_AVAILABLE = 0x00,
	//! <b>No end-position reached</b> 1
	NO_END_POS_REACHED = 0x01,
	//! <b>Blind fully open</b> 2
	BLIND_FULLY_OPEN = 0x02,
	//! <b>Blind fully close</b> 3
	BLIND_FULLY_CLOSE = 0x03
} CS_ENUM_END_POS;

//!Controller mode for A5-11-xx profiles
typedef enum
{
	//! <b>Heating</b> 0
	HEATING = 0x00,
	//! <b>Cooling</b> 1
	COOLING = 0x01,
	//! <b>Off</b> 2
	OFF = 0x02
} CS_ENUM_CONTROLLER_MODE;

//!Room occupancy for A5-11-xx profiles
typedef enum
{
	//! <b>Occupied</b> 0
	OCCUPIED = 0x00,
	//! <b>Unoccupied</b> 1
	UNOCCUPIED = 0x01,
	//! <b>StandBy</b> 2
	STANDBY = 0x02,
	//! <b>Frost</b> 3
	FROST = 0x03
} CS_ENUM_ROOM_OCCUPANCY;

//!Fan speed for A5-11-xx profiles
typedef enum
{
	//! <b>Stage 0 Manual</b> 0
	STAGE_0_MANUAL = 0x00,
	//! <b>Stage 1 Manual</b> 1
	STAGE_1_MANUAL = 0x01,
	//! <b>Stage 2 Manual</b> 2
	STAGE_2_MANUAL = 0x02,
	//! <b>Stage 3 Manual</b> 3
	STAGE_3_MANUAL = 0x03,
	//! <b>Stage 0 Automatic</b> 16
	STAGE_0_AUTO = 0x10,
	//! <b>Stage 1 Automatic</b> 17
	STAGE_1_AUTO = 0x11,
	//! <b>Stage 2 Automatic</b> 18
	STAGE_2_AUTO = 0x12,
	//! <b>Stage 3 Automatic</b> 19
	STAGE_3_AUTO = 0x13
} CS_FAN_STAGE;

//!Working mode for A5-11-05 profile
typedef enum
{
	//! <b>Mode 1</b> 0
	WORKING_MODE_1 = 0x01,
	//! <b>Mode 2</b> 1
	WORKING_MODE_2 = 0x02,
	//! <b>Mode 3</b> 2
	WORKING_MODE_3 = 0x03,
	//! <b>Mode 4</b> 3
	WORKING_MODE_4 = 0x04
} CS_WORKING_MODE;

//!Relay Status for A5-11-05 profile
typedef enum
{
	//! <b>Channel 1 off, channel 2 off</b> 0
	CH1_OFF_CH2_OFF = 0x00,
	//! <b>Channel 1 on, channel 2 off</b> 1
	CH1_ON_CH2_OFF = 0x01,
	//! <b>Channel 1 off, channel 2 on</b> 2
	CH1_OFF_CH2_ON = 0x02,
	//! <b>Channel 1 on, channel 2 on</b> 3
	CH1_ON_CH2_ON = 0x03
} CS_RELAY_STATUS;

class eoEEP_A511xx: public eoA5EEProfile
{

public:
	eoReturn SetType(uint8_t type);

	eoEEP_A511xx();
	virtual ~eoEEP_A511xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);

	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
