/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D231_H__INCLUDED_)
#define eoEEP_D231_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D231xx
 * \brief The class to handle EEP D231 profiles
 * \details Allows the user to handle EEP D231 profiles, the following profiles are available:
 * 		- D2-31-00
 * 		- D2-31-01\n
 *
 *	NOTE: set the command before use.
 *
 * The following channels are available for Set meter configuration command:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			| ::MSR_TIME_VALUES | ::MSR_CHANNEL_REPORT_TIME |
 * | 1             | ::E_STATE			| ::MSR_METER_BUS_TYPE | ::MSR_CHANNEL_METER_TYPE |
 * | 2             | ::S_VALUE			| float | ::MSR_CHANNEL_METER_CHANNEL |
 * | 3             | ::E_UNITS			| ::MSR_METER_UNITS | ::MSR_CHANNEL_METER_1 |
 * | 4             | ::E_UNITS			| ::MSR_METER_UNITS | ::MSR_CHANNEL_METER_2 |
 *
 * The rest of the channels are depending on the BUS type (MBUS, S0, D0).
 *
 * The following channels are available if MBUS is available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_VALUE	| float | ::MSR_CHANNEL_PRIMARY_ADDR |
 *
 * The following channels are available if S0 is available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_UNITS	| ::MSR_FACTOR_PULSES | ::MSR_CHANNEL_PULSES_FACTOR |
 * | 1             | ::S_VALUE	| float | ::MSR_CHANNEL_NUM_OF_PULSES |
 * | 2             | ::S_VALUE	| float | ::MSR_CHANNEL_PRESET_VALUE |
 *
 * The following channels are available if D0 is available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE	| ::MSR_PROTOCOL | ::MSR_CHANNEL_PROTOCOL |
 *
 *	The following channels are available for Meter status query command:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_STATE			| ::MSR_METER_BUS_TYPE |
 * | 1             | ::S_VALUE			| float |
 *
 * The following channels are available for Meter reading report/status response command:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			| ::MSR_METER_ERROR_CODE | ::MSR_CHANNEL_METER_ERROR |
 * | 1             | ::E_STATE			| ::MSR_METER_BUS_TYPE | ::MSR_CHANNEL_METER_TYPE |
 * | 2             | ::S_VALUE			| float | ::MSR_CHANNEL_METER_CHANNEL |
 * | 3             | ::E_STATE			| ::MSR_VALUE_SELECTION | ::MSR_CHANNEL_VALUE_SELECTION |
 * | 4             | ::E_UNITS			| ::MSR_VALUE_UNITS |  |
 * | 5             | ::S_VALUE			| float | ::MSR_CHANNEL_METER_1 |
 *
 * \n
 */

/**
 * \file eoEEP_D231xx.h
 */


class eoEEP_D231xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D231xx(uint16_t size = 10);
	virtual ~eoEEP_D231xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	virtual eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t subFlag);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
