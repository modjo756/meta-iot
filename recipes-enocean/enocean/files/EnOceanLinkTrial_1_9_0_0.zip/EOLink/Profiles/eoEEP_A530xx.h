/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if !defined(eoEEP_A530_H__INCLUDED_)
#define eoEEP_A530_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
/**\class eoEEP_A530xx
 * \brief The class to handle EEP a530 profiles
 * \details Allows the user to handle EEP a530 profiles, the following profiles are available:
 * 		- A5-30-01
 * 		- A5-30-02
 * 		- A5-30-03
 * 		- A5-30-04
 * 		- A5-30-05
 * 		- A5-30-06
 * 		\n
 * The following channels are available for 01 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::F_ON_OFF	  |uint8_t |
 * | 1             | ::S_VOLTAGE    |::A530_BATTERY_VALUE |
 *
 * The following channels are available for 02 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::F_ON_OFF	  |uint8_t |
 *
 * The following channels are available for 03 Profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_TEMP	  |float | |
 * | 1             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::STATUS_WAKE |
 * | 2             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_3 |
 * | 3             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_2 |
 * | 4             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_1 |
 * | 5             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_0 |
 *
 * The following channels are available for 04 Profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_VALUE	  |float | |
 * | 1             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_2 |
 * | 2             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_1 |
 * | 3             | ::F_HIGH_LOW |::A530_BATTERY_VALUE | ::DIGITAL_IN_0 |
 *
 * The following channels are available for 05 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_VOLTAGE  |float |
 * | 1             | ::F_ON_OFF   |::A530_SIGNAL_TYPE |
 * | 2             | ::S_COUNTER  |float |
 *
 * The following channels are available for 06 Profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_KEY_DATA  | uint8_t | ::KEY_DATA_1 |
 * | 1             | ::E_KEY_DATA  | uint8_t | ::KEY_DATA_2 |
 * | 2             | ::E_KEY_DATA  | uint8_t | ::KEY_DATA_3 |
 * | 3             | ::E_KEY_DATA  | uint8_t | ::KEY_DATA_4 |
 * | 4             | ::E_KEY_DATA  | uint8_t | ::KEY_DATA_5 |
 * | 5             | ::E_KEY_DATA  | uint8_t | ::KEY_DATA_6 |
 * | 6             | ::S_VOLTAGE   | float 	 |  |
 */
 
/**
 * \file eoEEP_A530xx.h
 */

//! Index enums for A5-30-xx profiles
typedef enum
{
	//! <b>1st key data</b> 0
	KEY_DATA_1 = 0x00,
	//! <b>2nd key data</b> 1
	KEY_DATA_2 = 0x01,
	//! <b>3rd key data</b> 2
	KEY_DATA_3 = 0x02,
	//! <b>4th key data</b> 3
	KEY_DATA_4 = 0x03,
	//! <b>5th key data</b> 4
	KEY_DATA_5 = 0x04,
	//! <b>6th key data</b> 5
	KEY_DATA_6 = 0x05
} A530_INDEX;

//! Battery values
typedef enum
{
	//! Battery low
	BATTERY_LOW = 0x00,
	//! Battery OK
	BATTERY_EO_OK = 0x01
} A530_BATTERY_VALUE;

//! Signal type
typedef enum
{
	//! Normal signal
	NORMAL_SIGNAL = 0x00,
	//! Heart beat signal
	HEART_BEAT_SIGNAL = 0x01
} A530_SIGNAL_TYPE;

//!Digital Inputs in A5-30-03 profile
typedef enum
{
	//! <b>Status of wake</b> 0
	STATUS_WAKE = 0x00,
	//! <b>Digital Input 0</b> 1
	DIGITAL_IN_0 = 0x01,
	//! <b>Digital Input 1</b> 2
	DIGITAL_IN_1 = 0x02,
	//! <b>Digital Input 2</b> 3
	DIGITAL_IN_2 = 0x03,
	//! <b>Digital Input 3</b> 4
	DIGITAL_IN_3 = 0x04
} ENUM_DIGITAL_INPUT;

class eoEEP_A530xx: public eoA5EEProfile
{

public:
	eoEEP_A530xx();
	virtual ~eoEEP_A530xx();

	eoReturn SetType(uint8_t type);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
