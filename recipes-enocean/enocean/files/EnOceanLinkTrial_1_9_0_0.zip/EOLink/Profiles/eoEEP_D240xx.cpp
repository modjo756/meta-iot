/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D240xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 9;
const uint8_t numOfProfiles = 0x02;
const uint8_t numOfCommands = 0x02;

const EEP_ITEM listD240xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
// MsgId 0x00
{
		{ true, 6, 2, 0, 1, 0, 1, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, DRIVING_LED }, //Driving LED
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, RESPONSE_MODE }, //Demand Response Mode
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGH_HARVEST }, //Daylight Harvest Active
		{ true, 3, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy State
		{ true, 5, 1, 0, 1, 0, 1, F_ON_OFF, STATUS_REASON }, //Status Tx Reason
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_MONO }, //Current Dim Level
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },

},
// MsgId 0x01
{
		{ true, 6, 2, 0, 1, 0, 1, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, DRIVING_LED }, //Driving LED
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, RESPONSE_MODE }, //Demand Response Mode
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGH_HARVEST }, //Daylight Harvest Active
		{ true, 3, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy State
		{ true, 5, 1, 0, 1, 0, 1, F_ON_OFF, STATUS_REASON }, //Status Tx Reason
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_RED }, //Current Dim Level - Red
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_GREEN }, //Current Dim Level - Green
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_BLUE }, //Current Dim Level - Blue
}
};

const EEP_ITEM typeListD240xx [numOfProfiles][9] =
{
	//Type 0x00
	{
		{ true, 6, 2, 0, 1, 0, 1, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, DRIVING_LED }, //Driving LED
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, RESPONSE_MODE }, //Demand Response Mode
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGH_HARVEST }, //Daylight Harvest Active
		{ true, 3, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy State
		{ true, 5, 1, 0, 1, 0, 1, F_ON_OFF, STATUS_REASON }, //Status Tx Reason
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_MONO }, //Current Dim Level
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x01
	{
		{ true, 6, 2, 0, 1, 0, 1, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, DRIVING_LED }, //Driving LED
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, RESPONSE_MODE }, //Demand Response Mode
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGH_HARVEST }, //Daylight Harvest Active
		{ true, 3, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy State
		{ true, 5, 1, 0, 1, 0, 1, F_ON_OFF, STATUS_REASON }, //Status Tx Reason
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_RED }, //Current Dim Level - Red
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_GREEN }, //Current Dim Level - Green
		{ true, 8, 8, 0, 200, 0, 100, S_PERCENTAGE, DIM_LEVEL_BLUE }, //Current Dim Level - Blue
	}
};

eoEEP_D240xx::eoEEP_D240xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x40;
	msg.RORG = RORG_VLD;
	cmd = 0;
}

eoEEP_D240xx::~eoEEP_D240xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D240xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() != 2 && m.GetDataLength() != 4)
		return NOT_SUPPORTED;

	SetCommand(m.data[0] & 0x03);

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D240xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	SetLength(type);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D240xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd >= numOfCommands)
		return NOT_SUPPORTED;

	msg.Clear();

	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {2, 4};
	msg.SetDataLength(dataLength[cmd]);

	if(cmd==this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD240xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD240xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD240xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD240xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD240xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D240xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_OCCUPANCY:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D240xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_OCCUPANCY:
			rawValue = (uint32_t)value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D240xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D240xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd > 4)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D240xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case DRIVING_LED:
				case RESPONSE_MODE:
				case DAYLIGH_HARVEST:
				case STATUS_REASON:
					break;
				default:
					return GetValue(type, value);
			}
			break;
		default:
			return GetValue(type, value);
	}

	value = (uint8_t)rawValue;
	return EO_OK;
}

eoReturn eoEEP_D240xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd > 4)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case DRIVING_LED:
				case RESPONSE_MODE:
				case DAYLIGH_HARVEST:
				case STATUS_REASON:
					break;
				default:
					return SetValue(type, value);
			}
			break;
		default:
			return SetValue(type, value);
			break;
	}

	rawValue = (uint32_t)value;
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D240xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
			switch(index)
			{
				case DIM_LEVEL_MONO:
				case DIM_LEVEL_RED:
				case DIM_LEVEL_GREEN:
				case DIM_LEVEL_BLUE:
					value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_D240xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd > 4)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
			switch(index)
			{
				case DIM_LEVEL_MONO:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				case DIM_LEVEL_RED:
				case DIM_LEVEL_GREEN:
				case DIM_LEVEL_BLUE:
					if (this->type != 0x01)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D240xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD240xx[this->cmd][tmpChannelCount].type == type && listD240xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D240xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD240xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD240xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD240xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD240xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD240xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
