/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D206xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 13;
const uint8_t numOfProfiles = 0x01;
const uint8_t numOfCommands = 0x07;

// Convert to more usable command code
const uint8_t cmdTableToCmd[] = { 0x00, 0x10, 0x20, 0x21, 0x22, 0x23, 0x80};
const uint8_t cmdToCmdTable[] =
{
	//0		1	 2		3	 4		5	 6		7	 8		9	 A		B	 C		D	 E		F
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 0
	0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 1
	0x02, 0x03, 0x04, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 2
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 3
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 4
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 5
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 6
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 7
	0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // 8
};

const EEP_ITEM listD206xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
{
		{ true, 8, 4, 0, 15, 0, 15, E_STATE, BURGLARY_ALARM }, //Burglary Alarm System
		{ true, 12, 4, 0, 15, 0, 15, E_STATE, PROTECTION_PLUS_ALARM }, //Protection Plus Alarm
		{ true, 16, 4, 0, 15, 0, 15, E_STATE, HANDLE_POSITION }, //Handle Position
		{ true, 20, 4, 0, 15, 0, 15, E_STATE, WINDOW_STATE }, //Window State
		{ true, 24, 4, 0, 15, 0, 15, E_STATE, BUTTON_1 }, //Button 1
		{ true, 28, 4, 0, 15, 0, 15, E_STATE, BUTTON_2 }, //Button 2
		{ true, 32, 4, 0, 15, 0, 15, E_STATE, MOTION }, //Motion
		{ true, 36, 4, 0, 15, 0, 15, E_STATE, VACATION_MODE }, //Vacation Mode
		{ true, 40, 8, 0, 250, -20.0, 60.0, S_TEMP, 0 }, //Temperature
		{ true, 48, 8, 0, 200, 0.0, 100.0, S_RELHUM, 0 }, //Humidity
		{ true, 56, 16, 0, 60000, 0.0, 60000.0, S_LUMINANCE, 0 }, //Illumination
		{ true, 72, 5, 0, 20, 0.0, 100.0, S_PERCENTAGE, 0 }, //Battery State
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
},
//Configuration Report
{
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, VACATION_MODE }, //Vacation Mode
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, HANDLE_CLICK }, //Handle Closed Click
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, BATTERY_CLICK }, //Battery Low Click
		{ true, 16, 16, 5, 65535, 5.0, 65535.0, S_TIME, SENSOR_INTERVAL }, //Sensor Update Interval
		{ true, 32, 8, 3, 255, 3, 255, S_TIME, VACATION_INTERVAL }, //Vacation Blink Interval
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//Log Data 01
{
		{ true, 8, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, POWER_ONS }, //Power Ons
		{ true, 40, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, ALARMS }, //Alarms
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//Log Data 02
{
		{ true, 8, 32, 0,  0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, HANDLE_CLOSED }, //Handle Movements Closed
		{ true, 40, 32, 0,  0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, HANDLE_OPENED }, //Handle Movements Opened
		{ true, 72, 32, 0,  0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, HANDLE_TILTED }, //Handle Movements Tilted
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//Log Data 03
{
		{ true, 8, 32, 0,  0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, WINDOW_TILTS }, //Window Tilts
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//Log Data 04
{
		{ true, 8, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, BUTTON_1 }, //Button 1
		{ true, 40, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, BUTTON_2 }, //Button 2
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//Control and Settings
{
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, START_TRANSMISSION_CONFIG_SETTINGS }, //Start Transmission of Configuration Settings
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, START_TRANSMISSION_LOG_DATA }, //Start Transmission of Log Data Packets
		{ true, 16, 16, 0, 65535, 0, 65535.0, F_ON_OFF, VACATION_MODE }, //Vacation mode
		{ true, 32, 8, 0, 255, 0, 255, E_STATE, HANDLE_CLICK }, //Handle Closed Click
		{ true, 16, 16, 0, 65535, 0, 65535.0, E_STATE, BATTERY_CLICK }, //Battery Low Click
		{ true, 16, 16, 0, 65535, 0, 65535.0, S_TIME, SENSOR_INTERVAL }, //Sensor Update Interval
		{ true, 32, 8, 0, 255, 0, 255, S_TIME, VACATION_INTERVAL }, //Vacation Blink Interval
		{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
}
};

const EEP_ITEM typeListD206xx [numOfProfiles][26] =
{
	//Type 0x00
	{
			{ true, 8, 4, 0, 15, 0, 15, E_STATE, BURGLARY_ALARM }, //Burglary Alarm System
			{ true, 12, 4, 0, 15, 0, 15, E_STATE, PROTECTION_PLUS_ALARM }, //Protection Plus Alarm
			{ true, 16, 4, 0, 15, 0, 15, E_STATE, HANDLE_POSITION }, //Handle Position
			{ true, 20, 4, 0, 15, 0, 15, E_STATE, WINDOW_STATE }, //Window State
			{ true, 24, 4, 0, 15, 0, 15, E_STATE, BUTTON_1 }, //Button 1
			{ true, 28, 4, 0, 15, 0, 15, E_STATE, BUTTON_2 }, //Button 2
			{ true, 32, 4, 0, 15, 0, 15, E_STATE, MOTION }, //Motion
			{ true, 36, 4, 0, 15, 0, 15, E_STATE, VACATION_MODE }, //Vacation Mode
			{ true, 40, 8, 0, 250, -20.0, 60.0, S_TEMP, 0 }, //Temperature
			{ true, 48, 8, 0, 200, 0.0, 100.0, S_RELHUM, 0 }, //Humidity
			{ true, 56, 16, 0, 60000, 0.0, 60000.0, S_LUMINANCE, 0 }, //Illumination
			{ true, 72, 5, 0, 20, 0.0, 100.0, S_PERCENTAGE, 0 }, //Battery State
			{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, VACATION_MODE }, //Vacation Mode
			{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, HANDLE_CLICK }, //Handle Closed Click
			{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, BATTERY_CLICK }, //Battery Low Click
			{ true, 16, 16, 0, 65535, 0, 65535.0, S_TIME, SENSOR_INTERVAL }, //Sensor Update Interval
			{ true, 32, 8, 0, 255, 0, 255, S_TIME, VACATION_INTERVAL }, //Vacation Blink Interval
			{ true, 8, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, POWER_ONS }, //Power Ons
			{ true, 40, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, ALARMS }, //Alarms
			{ true, 8, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, HANDLE_CLOSED }, //Handle Movements Closed
			{ true, 40, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, HANDLE_OPENED }, //Handle Movements Opened
			{ true, 72, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, HANDLE_TILTED }, //Handle Movements Tilted
			{ true, 8, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, WINDOW_TILTS }, //Window Tilts
			{ true, 8, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, BUTTON_1 }, //Button 1
			{ true, 40, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_COUNTER, BUTTON_2 }, //Button 2
			{ true, 0, 8, 0, 128, 0, 128, E_COMMAND, 0 }, //Message ID
	}
};

eoEEP_D206xx::eoEEP_D206xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x06;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D206xx::~eoEEP_D206xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D206xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 5 || m.GetDataLength() > 13)
		return NOT_SUPPORTED;

	SetCommand(m.data[0] & 0x0F);

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D206xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	SetLength(type);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D206xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	uint8_t tmpCmd = cmdToCmdTable[cmd];

	if(tmpCmd >= numOfCommands || cmd == 0)
		return NOT_SUPPORTED;

	msg.Clear();

	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {10, 5, 9, 13, 5, 9, 5};
	msg.SetDataLength(dataLength[tmpCmd]);

	if(cmd == this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD206xx[tmpCmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD206xx[tmpCmd][tmpChannelCount].type;
			channel[channelCount].max = listD206xx[tmpCmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD206xx[tmpCmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD206xx[tmpCmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D206xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_COMMAND:
			break;
		default:
			return NOT_SUPPORTED;
	}
	value = (uint8_t) rawValue;

	return EO_OK;
}

eoReturn eoEEP_D206xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	else
		return NOT_SUPPORTED;

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D206xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
		case S_TEMP:
		case S_RELHUM:
		case S_LUMINANCE:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D206xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint8_t tmpCmd = cmdToCmdTable[this->cmd];
	if (tmpCmd > 0x06)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
		case S_TEMP:
		case S_RELHUM:
		case S_LUMINANCE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D206xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint8_t tmpCmd = cmdToCmdTable[this->cmd];
	if (tmpCmd > 0x06)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case VACATION_MODE:
				case HANDLE_CLICK:
				case BATTERY_CLICK:
				case START_TRANSMISSION_CONFIG_SETTINGS:
				case START_TRANSMISSION_LOG_DATA:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_STATE:
			switch (index)
			{
				case BURGLARY_ALARM:
				case PROTECTION_PLUS_ALARM:
				case HANDLE_POSITION:
				case WINDOW_STATE:
				case BUTTON_1:
				case BUTTON_2:
				case MOTION:
				case VACATION_MODE:
				case HANDLE_CLICK:
				case BATTERY_CLICK:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	rawValue = (uint8_t)value;

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D206xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case VACATION_MODE:
				case HANDLE_CLICK:
				case BATTERY_CLICK:
				case START_TRANSMISSION_CONFIG_SETTINGS:
				case START_TRANSMISSION_LOG_DATA:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_STATE:
			switch (index)
			{
				case BURGLARY_ALARM:
				case PROTECTION_PLUS_ALARM:
				case HANDLE_POSITION:
				case WINDOW_STATE:
				case BUTTON_1:
				case BUTTON_2:
				case MOTION:
				case VACATION_MODE:
				case HANDLE_CLICK:
				case BATTERY_CLICK:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return GetValue(type, value);
			break;
	}

	value = (uint8_t)rawValue;

	return EO_OK;
}

eoReturn eoEEP_D206xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TIME:
			switch(index)
			{
				case SENSOR_INTERVAL:
				case VACATION_INTERVAL:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_COUNTER:
			switch(index)
			{
				case POWER_ONS:
				case ALARMS:
				case HANDLE_CLOSED:
				case HANDLE_OPENED:
				case HANDLE_TILTED:
				case WINDOW_TILTS:
				case BUTTON_1:
				case BUTTON_2:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	return EO_OK;
}

eoReturn eoEEP_D206xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint8_t tmpCmd = cmdToCmdTable[this->cmd];
	if (tmpCmd > 0x06)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TIME:
			switch(index)
			{
				case SENSOR_INTERVAL:
				case VACATION_INTERVAL:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_COUNTER:
			switch(index)
			{
				case POWER_ONS:
				case ALARMS:
				case HANDLE_CLOSED:
				case HANDLE_OPENED:
				case HANDLE_TILTED:
				case WINDOW_TILTS:
				case BUTTON_1:
				case BUTTON_2:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D206xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;
	uint8_t tmpCmd = cmdToCmdTable[this->cmd];

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD206xx[tmpCmd][tmpChannelCount].type == type && listD206xx[tmpCmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D206xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD206xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD206xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD206xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD206xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD206xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
