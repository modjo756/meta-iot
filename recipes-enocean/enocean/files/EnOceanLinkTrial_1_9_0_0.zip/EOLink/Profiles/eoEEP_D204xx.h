/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//! \file eoEEP_D204xx.h

#if  !defined(eoEEP_D204_H__INCLUDED_)
#define eoEEP_D204_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D204xx
 * \brief The class to handle EEP D204 Secure Light and Blind Control
 * \details Allows the user to handle EEP D204 Secure Light and Blind Control, 2 Rocker profiles, the following profile is available:
 * 		- D2-04-00
 * 		- D2-04-01
 * 		- D2-04-02
 * 		- D2-04-03
 * 		- D2-04-04
 * 		- D2-04-05
 * 		- D2-04-06
 * 		- D2-04-07
 * 		- D2-04-08
 * 		- D2-04-09
 * 		- D2-04-10
 * 		- D2-04-1A
 * 		- D2-04-1B
 * 		- D2-04-1C
 * 		- D2-04-1D
 * 		- D2-04-1E\n
 *
 * The following channels are available for 00 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_RELHUM	  | float |
 * | 2             | ::S_TEMP 	  | float |
 * | 3             | ::F_DAY_NIGHT| uint8_t |
 * | 4             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 01 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_RELHUM	  | float |
 * | 2             | ::F_DAY_NIGHT| uint8_t |
 * | 3             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 02 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 * | 2             | ::F_DAY_NIGHT| uint8_t |
 * | 3             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 03 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 * | 2             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 04 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 *
 * The following channels are available for 05 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 * | 2             | ::F_DAY_NIGHT| uint8_t |
 *
 * The following channels are available for 06 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::F_DAY_NIGHT| uint8_t |
 *
 * The following channels are available for 07 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::F_DAY_NIGHT| uint8_t |
 * | 2             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 *  NOTE: The ::S_CONC in the following devices has a range 0-5000 ppm.
 *
 * The following channels are available for 08 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_RELHUM	  | float |
 * | 2             | ::S_TEMP 	  | float |
 * | 3             | ::F_DAY_NIGHT| uint8_t |
 * | 4             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 09 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_RELHUM	  | float |
 * | 2             | ::F_DAY_NIGHT| uint8_t |
 * | 3             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 10 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 * | 2             | ::F_DAY_NIGHT| uint8_t |
 * | 3             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 1A profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 * | 2             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 * The following channels are available for 1B profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 *
 * The following channels are available for 1C profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::S_TEMP 	  | float |
 * | 2             | ::F_DAY_NIGHT| uint8_t |
 *
 * The following channels are available for 1D profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::F_DAY_NIGHT| uint8_t |
 *
 * The following channels are available for 1E profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC 	  | float |
 * | 1             | ::F_DAY_NIGHT| uint8_t |
 * | 2             | ::E_STATE 	  | ::NS_BATTERY_AUTONOMY |
 *
 *
 *
 */

//! Enums for Battery autonomy
typedef enum
{
	//! <b>0</b> 100-87.5%
	NS_BATTERY_100_875 = 0x00,
	//! <b>1</b> 87.5-75%
	NS_BATTERY_875_75 = 0x01,
	//! <b>2</b> 75-62.5%
	NS_BATTERY_75_625 = 0x02,
	//! <b>3</b> 62.5-50%
	NS_BATTERY_625_50 = 0x03,
	//! <b>4</b> 50-37.5%
	NS_BATTERY_50_375 = 0x04,
	//! <b>5</b> 37.5-25%
	NS_BATTERY_375_25 = 0x05,
	//! <b>6</b> 25-12.5%
	NS_BATTERY_25_125 = 0x06,
	//! <b>7</b> 12.5-0%
	NS_BATTERY_125_0 = 0x07
} NS_BATTERY_AUTONOMY;

class eoEEP_D204xx: public eoD2EEProfile
{
public:
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D204xx(uint16_t size = 4);
	virtual ~eoEEP_D204xx();
	eoReturn SetType(uint8_t type);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
