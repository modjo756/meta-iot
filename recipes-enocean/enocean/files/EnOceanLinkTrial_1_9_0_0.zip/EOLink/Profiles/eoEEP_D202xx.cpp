/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D202xx.h"

#include "eoChannelEnums.h"
#include <string.h>
const uint8_t numOfChan = 6;
const uint8_t numOfCommands = 0x05;
const uint8_t numOfProfiles = 0x03;

const EEP_ITEM listD202xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:01
{
{ true, 16, 16, 0, 65535, -40.0, 120.0, S_TEMP, 0 }, //Temperature
{ true, 16, 16, 0, 65535, 0, 2047, S_LUMINANCE, 0 }, //Illumination
{ true, 16, 16, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy
{ true, 16, 16, 0, 3, 0, 3, E_STATE, VLD_SMOKE_DETECTION }, //Smoke detected
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:02
{
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, VLD_SELF_TEST }, //Self test
{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, VLD_TRIGGER_ALARM }, //Trigger alarm
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:03
{
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, VLD_REPORT_MEASUREMENT }, //Report measurement
{ true, 16, 4, 0, 4095, -40, 120, S_TEMP_ABS, 0 }, //Temperature
{ true, 16, 4, 0, 4095, 0, 2047, S_LUMINANCE_ABS, 0 }, //Illumination
{ true, 32, 8, 0, 255, 10, 2550, S_TIME, VLD_MAX_TIME }, //Maximum time
{ true, 40, 8, 0, 255, 0, 255, S_TIME, VLD_MIN_TIME }, //Minimum time
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
},
//COMMAND:04
{
{ true, 8, 3, 0, 7, 0, 7, E_STATE, VLD_QUERY }, //Query
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } } };

eoEEP_D202xx::eoEEP_D202xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x02;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D202xx::~eoEEP_D202xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D202xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 2 || m.GetDataLength() > 6)
		return NOT_SUPPORTED;

	if(SetCommand(m.data[0] & 0x0F)!=EO_OK)
		return NOT_SUPPORTED;

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D202xx::SetType(uint8_t type)
{
	if(type > numOfProfiles)
		return NOT_SUPPORTED;
	SetCommand(1);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D202xx::SetCommand(uint8_t cmd)
{
	if(cmd>=numOfCommands||cmd==0)
		return NOT_SUPPORTED;

	msg.Clear();
	uint32_t rawValue = cmd;
	SetRawValue(msg, rawValue, 4, 4);
	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {0, 4, 2, 6, 2};
	msg.SetDataLength(dataLength[cmd]);

	if(cmd==this->cmd )
		return EO_OK;

	uint8_t tmpChannelCount;
	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD202xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD202xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD202xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD202xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD202xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if ( channelCount == 0)
		return NOT_SUPPORTED;

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D202xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_OCCUPIED:
			if (((msg.data[1] & 0xE0) != 0x40) || (this->type != 0x00))
				return NOT_SUPPORTED;
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D202xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	uint32_t rawValue;
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_OCCUPIED:
			if ((value > 0x03) || (this->type != 0x00))
				return NOT_SUPPORTED;

			msg.data[1] &= 0x1F;
			msg.data[1] |= 0x40;
			rawValue = value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D202xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue, rawValue2;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP:
			switch (this->cmd)
			{
				case 0x01:
					if ((msg.data[1] & 0xE0) != 0)
						return NOT_SUPPORTED;

					if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
						return NOT_SUPPORTED;
					break;

				default:
					if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
						return NOT_SUPPORTED;
					break;
			}
			break;

		case S_TEMP_ABS:
			if (this->cmd != 0x03)
				return NOT_SUPPORTED;

			if ((msg.data[2] & 0x03) != 0)
				return NOT_SUPPORTED;

			if (GetRawValue(msg, rawValue2, 24, 8) != EO_OK)
				return NOT_SUPPORTED;
			rawValue = rawValue2 << 4;
			if (GetRawValue(msg, rawValue2, 16, 4) != EO_OK)
				return NOT_SUPPORTED;
			rawValue |= rawValue2;

			break;

		case S_LUMINANCE:
			if (this->type == 0x02)
				return NOT_SUPPORTED;

			switch (this->cmd)
			{
				case 0x01:
					if ((msg.data[1] & 0xE0) != 0x20)
						return NOT_SUPPORTED;

					if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
						return NOT_SUPPORTED;
					break;

				default:
					if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
						return NOT_SUPPORTED;
					break;
			}
			break;

		case S_LUMINANCE_ABS:
			if (this->type == 0x02)
				return NOT_SUPPORTED;

			if (this->cmd != 0x03)
				return NOT_SUPPORTED;

			if ((msg.data[2] & 0x03) != 0x01)
				return NOT_SUPPORTED;

			if (GetRawValue(msg, rawValue2, 24, 8) != EO_OK)
				return NOT_SUPPORTED;
			rawValue = rawValue2 << 4;
			if (GetRawValue(msg, rawValue2, 16, 4) != EO_OK)
				return NOT_SUPPORTED;
			rawValue |= rawValue2;

			break;

		default:
			return NOT_SUPPORTED;
	}

	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoEEP_D202xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP:
			msg.data[1] &= 0x1F;

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TEMP_ABS:
			msg.data[2] &= 0xF8;

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			tmpRawValue = (rawValue >> 4) & 0xFF;
			rawValue = rawValue & 0x0F;

			SetRawValue(msg, tmpRawValue, 24, 8);
			break;
		case S_LUMINANCE:
			if (this->type == 0x02)
				return NOT_SUPPORTED;

			msg.data[1] &= 0x1F;
			msg.data[1] |= 0x20;

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_LUMINANCE_ABS:
			if (this->type == 0x02)
				return NOT_SUPPORTED;

			msg.data[2] &= 0xF8;
			msg.data[2] |= 0x01;

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			tmpRawValue = (rawValue >> 4) & 0xFF;
			rawValue = rawValue & 0x0F;

			SetRawValue(msg, tmpRawValue, 24, 8);

			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D202xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
	{
		return NOT_SUPPORTED;
	}
	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
	{

		return NOT_SUPPORTED;
	}
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;
		case E_STATE:
			switch (index)
			{
				case VLD_SMOKE_DETECTION:
					if ((msg.data[1] & 0xE0) != 0x60)
						return NOT_SUPPORTED;
					break;
				case VLD_QUERY:
					break;
				default:
					return NOT_SUPPORTED;
			}
			value = (uint8_t)rawValue;
			break;
		default:
			return GetValue(type, value);
	}

	return EO_OK;
}

eoReturn eoEEP_D202xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;
		case E_STATE:
			switch (index)
			{
				case VLD_SMOKE_DETECTION:
				case VLD_QUERY:
					if (value > 0x03)
						return NOT_SUPPORTED;

					msg.data[1] &= 0x1F;
					msg.data[1] |= 0x60;
					break;
				default:
					return NOT_SUPPORTED;
			}
			rawValue = value;
			break;
		default:
			return SetValue(type, value);
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D202xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	//Only channel in this profile is the Occupied channel, thats why we only check against NULL
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TIME:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return GetValue(type, value);
	}

	return EO_OK;
}

eoReturn eoEEP_D202xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TIME:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return SetValue(type, value);
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);


	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D202xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD202xx[this->cmd][tmpChannelCount].type == type && listD202xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
