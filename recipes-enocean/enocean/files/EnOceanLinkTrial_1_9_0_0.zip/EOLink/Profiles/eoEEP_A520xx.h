/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if !defined(eoEEP_A520_H__INCLUDED_)
#define eoEEP_A520_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
#include "eoISimpleBidirectionalProfile.h"
/**\class eoEEP_A520xx
 * \brief The class to handle EEP a520 profiles
 * \details Allows the user to handle EEP a520 profiles, the following profiles are available:
 * 		- A5-20-01 (two directions)
 * 		- A5-20-02 (two directions)
 * 		- A5-20-03 (two directions)
 * 		- A5-20-04 (two directions)
 * 		- A5-20-05 (two directions)
 * 		- A5-20-10 (two directions)
 * 		- A5-20-11 (two directions)
 * 		- A5-20-12\n\n
 * DIRECTION-1 = Transmit mode: Message from the actuator to the controller
 * DIRECTION-2 = Receive mode: Commands from the controller to the actuator
 * \note In Old EnOcean Link Version the direction could be set with E_DIRECTION, it is recommended with the new version to use
 * after initializing the profile the SetDirection Function to set once the direction of the profile. The Profile interprets then
 * the received data always as direction y and transmit data always with the direction x.
 *
 * The following channels are available for 01 profile, direction 1:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT   	|float |  |
 * | 1             | ::F_ON_OFF		 	|uint8_t | Service on, ::SERVICE_ON |
 * | 2             | ::F_ON_OFF       	|uint8_t | Energy input, ::ENERGY_INPUT |
 * | 3             | ::F_ON_OFF		   	|uint8_t | Energy storage, ::ENERGY_STORAGE |
 * | 4             | ::F_ON_OFF   		|uint8_t | Battery capacity, ::BATTERY_CAPACITY |
 * | 5             | ::F_ON_OFF   		|uint8_t | Contact cover, ::CONTACT_COVER |
 * | 6             | ::F_ON_OFF   		|uint8_t | Temperature sensor failure, ::TEMPERATURE_FAIL |
 * | 7             | ::F_ON_OFF		   	|uint8_t | Detection, window open, ::WINDOW_DETECTION |
 * | 8             | ::F_ON_OFF		   	|uint8_t | Actuator obstructed, ::ACTUATOR_OBSTRUCTED |
 * | 9             | ::S_TEMP		   	|float |    |
 * \n
 * The following channels are available for 01 profile, direction 2:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT   	|float |  |
 * | 1             | ::S_TEMP_ABS   	|float |   |
 * | 2             | ::S_TEMP		   	|float | |
 * | 3             | ::F_ON_OFF		 	|uint8_t | Run init sequence, ::RUN_INTI_SEQ |
 * | 4             | ::F_ON_OFF       	|uint8_t | Lift set, ::LIFT_SET |
 * | 5             | ::F_ON_OFF		   	|uint8_t | Valve open, ::VALVE_OPEN |
 * | 6             | ::F_ON_OFF   		|uint8_t | Valve closed, ::VALVE_CLOSED |
 * | 7             | ::F_ON_OFF   		|uint8_t | Summer bit, ::SUMMER_BIT |
 * | 8             | ::F_ON_OFF   		|uint8_t | Set point selection, ::SET_POINT_SELECTION |
 * | 9             | ::F_ON_OFF		   	|uint8_t | Set point inverse, ::SET_POINT_INVERSE |
 * | 10            | ::F_ON_OFF		   	|uint8_t | Select function, ::SELECT_FUNCTION |
 * \n
 * The following channels are available for 02 profile, direction 1:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PERCENTAGE   	|float |  |
 * | 1             | ::F_ON_OFF		 	|uint8_t | Set point inverse, ::SET_POINT_INVERSE |
 *\n
 * The following channels are available for 02 profile, direction 2:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT   	|float |  |
 * | 1             | ::F_ON_OFF		 	|uint8_t | Set point inverse, ::SET_POINT_INVERSE |
 * \n
 * The following channels are available for 03 profile, direction 1:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_SETPOINT   	|float |
 * | 1             | ::S_TEMP		   	|float |
 * \n
 * The following channels are available for 03 profile, direction 2:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT   	|float |  |
 * | 1             | ::S_TEMP_ABS   	|float |  |
 * | 2             | ::S_TEMP		   	|float |  |
 * | 3	           | ::F_ON_OFF		   	|uint8_t | Set point selection, ::SET_POINT_SELECTION |
 * | 4             | ::F_ON_OFF		   	|uint8_t | Set point inverse, ::SET_POINT_INVERSE |
 * \n
 * The following channels are available for 04 profile, direction 1:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PERCENTAGE   	|float |  |
 * | 1             | ::S_TEMP   		|float | ::FEED_TEMP |
 * | 2             | ::S_TEMP_ABS		|float |   |
 * | 3	           | ::S_TEMP		   	|float | ::CURRENT_TEMP |
 * | 4             | ::E_ERROR_STATE	|uint8_t |  |
 * | 5             | ::F_ON_OFF   		|::HVCA_MEASUREMENT_STATUS | ::MEASUREMENT_STATUS |
 * | 6             | ::F_ON_OFF   		|::HVCA_STATUS_REQUEST | ::STATUS_REQUEST |
 * | 7             | ::F_ON_OFF		   	|::HVCA_BUTTON_LOCK | ::BUTTON_LOCK  |
 * | 8	           | ::F_ON_OFF		   	|::HVCA_TEMP_SELECTION | ::TEMP_SELECTION |
 * | 9             | ::F_ON_OFF		   	|::HVCA_FAILURE | ::FAILURE |
 * \n
 * The following channels are available for 04 profile, direction 2:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PERCENTAGE   	|float |  |
 * | 1             | ::S_TEMP_ABS  		|float |  |
 * | 2             | ::F_ON_OFF			|::HVCA_MEASUREMENT_CONTROL | ::MEASUREMENT_CONTROL |
 * | 3	           | ::E_STATE		   	|::HVCA_WAKEUP_CYCLE | ::WAKEUP_CYCLE |
 * | 4             | ::E_STATE			|::HVCA_DISPLAY_ORIENTATION | ::DISPLAY_ORIENTATION |
 * | 0             | ::F_ON_OFF   		|::HVCA_MEASUREMENT_STATUS | ::BUTTON_LOCK |
 * | 1             | ::E_COMMAND   		|::HVCA_SERVICE_COMMAND |  |
 * \n
 * The following channels are available for 10 profile, direction 1, 2:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_CONTROLLER_MODE|::HVAC_MODE |   |
 * | 1             | ::E_END_POS	 	|::HVCA_VANE_POSITION |  |
 * | 2             | ::E_FANSPEED      	|::HVCA_FANSPEED |  |
 * | 3             | ::S_SETPOINT	   	|float |     |
 * | 4             | ::E_OCCUPANCY 		|::HVCA_ROOM_OCCUPANCY |  |
 * | 5             | ::F_ON_OFF		   	|uint8_t | On/Off, ::ON_OFF |
 * \n
 * The following channels are available for 11 profile, direction 1:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0	           | ::F_ON_OFF		   	|uint8_t | External disablement, ::EXTERNAL_DISABLEMENT |
 * | 1             | ::F_ON_OFF		   	|uint8_t | Remote controller disablement, ::DISABLE_REMOTE_CONTROL |
 * | 2             | ::F_OPEN_CLOSED	|uint8_t |   |
 * \n
 * The following channels are available for 11 profile, direction 2:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0	           | ::S_ERROR_CODE   	|float |  |
 * | 1             | ::F_ON_OFF		   	|uint8_t | Other disablement, ::OTHER_DISABLEMENT |
 * | 2             | ::F_ON_OFF		   	|uint8_t | Window contact disablement, ::WINDOW_DISABLEMENT |
 * | 3             | ::F_ON_OFF		   	|uint8_t | Key card disablement, ::KEYCARD_DISABLEMENT |
 * | 4             | ::F_ON_OFF		   	|uint8_t | External disablement, ::EXTERNAL_DISABLEMENT |
 * | 5             | ::F_ON_OFF		   	|uint8_t | Remote controller disablement, ::DISABLE_REMOTE_CONTROL |
 * | 6             | ::F_OPEN_CLOSED	|uint8_t |   |
 * | 7             | ::F_ON_OFF		   	|uint8_t | Alarm state, ::ALARM_STATE |
 * \n
 * The following channels are available for 12 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0	           | ::S_PERCENTAGE   	|float |  |
 * | 1             | ::E_FANSPEED	   	|::HVCA_FANSPEED |   |
 * | 2             | ::S_SETPOINT	   	|float |   |
 * | 3             | ::F_ON_OFF		   	|uint8_t | Fan override, ::FAN_OVERRIDE |
 * | 4             | ::E_CONTROLLER_MODE|::HVCA_CONTROLLER_MODE |  |
 * | 5             | ::F_ON_OFF		   	|uint8_t | Controller state, ::CONTROLLER_STATE |
 * | 7             | ::F_ON_OFF		   	|uint8_t | Energy hold-off, ::ENERGY_HOLDOFF |
 * | 7             | ::E_OCCUPANCY	  	|::HVCA_ROOM_OCCUPANCY_TYPE_20 |    |
 * \n
 */

/**
 * \file eoEEP_A520xx.h
 */
//! Index enums for A5-20-xx profiles
typedef enum
{
	//! <b>Energy input enabled</b> 0
	ENERGY_INPUT = 0x00,
	//! <b>Energy storage</b> 1
	ENERGY_STORAGE = 0x01,
	//! <b>Battery capacity</b> 2
	BATTERY_CAPACITY = 0x02,
	//! <b>Contact, cover open</b> 3
	CONTACT_COVER = 0x03,
	//! <b>Failure temperature sensor, out of range</b> 4
	TEMPERATURE_FAIL = 0x04,
	//! <b>Detection, window open</b> 5
	WINDOW_DETECTION = 0x05,
	//! <b>Actuator obstucted</b> 6
	ACTUATOR_OBSTRUCTED = 0x06,
	//! <b>Run init sequence</b> 7
	RUN_INTI_SEQ = 0x07,
	//! <b>Lift set</b> 8
	LIFT_SET = 0x08,
	//! <b>Valve open / maintenance</b> 9
	VALVE_OPEN = 0x09,
	//! <b>Valve closed</b> 10
	VALVE_CLOSED = 0x0A,
	//! <b>Summer bit</b> 11
	SUMMER_BIT = 0x0B,
	//! <b>Set point selection</b> \note deprecated should not be accessed is done automatically 12
	SET_POINT_SELECTION = 0x0C,
	//! <b>Set point inverse</b> 13
	SET_POINT_INVERSE = 0x0D,
	//! <b>Select function</b> 14
	SELECT_FUNCTION = 0x0E,
	//! <b>On - off</b> 15
	ON_OFF = 0x0F,
	//! <b>External disablement</b> 16
	EXTERNAL_DISABLEMENT = 0x10,
	//! <b>Disable remote controller</b> 17
	DISABLE_REMOTE_CONTROL = 0x11,
	//! <b>Other disablement</b> 18
	OTHER_DISABLEMENT = 0x12,
	//! <b>Window contact disablement</b> 19
	WINDOW_DISABLEMENT = 0x13,
	//! <b>Key card disablement</b> 20
	KEYCARD_DISABLEMENT = 0x14,
	//! <b>Alarm state</b> 21
	ALARM_STATE = 0x15,
	//! <b>Fan override</b> 22
	FAN_OVERRIDE = 0x16,
	//! <b>Controller state</b> 23
	CONTROLLER_STATE = 0x17,
	//! <b>Energy hold-off / dew point</b> 24
	ENERGY_HOLDOFF = 0x18,
	//! <b>Service on</b> 25
	SERVICE_ON = 0x19,
	//! <b>Feed temperature</b> 26
	FEED_TEMP = 0x1A,
	//! <b>Current room temperature</b> 27
	CURRENT_TEMP = 0x1B,
	//! <b>Measurement status</b> 28
	MEASUREMENT_STATUS = 0x1C,
	//! <b>Status request</b> 29
	STATUS_REQUEST = 0x1D,
	//! <b>Button lock status/control</b> 30
	BUTTON_LOCK = 0x1E,
	//! <b>Temperature selection</b> 31
	TEMP_SELECTION = 0x1F,
	//! <b>Failure</b> 32
	FAILURE = 0x20,
	//! <b>Measurement control</b> 33
	MEASUREMENT_CONTROL = 0x21,
	//! <b>Wake-up cycle</b> 34
	WAKEUP_CYCLE = 0x22,
	//! <b>Display orientation</b> 35
	DISPLAY_ORIENTATION = 0x23,
	//! <b>External node low battery</b> 36
	NODE_LOW_BATTERY = 0x24,
	//! <b>External node communication error</b> 37
	NODE_EXT_COMM_ERROR = 0x25,
	//! <b>Internal sensor error</b> 38
	INTERNAL_SENSOR_ERROR = 0x26,
	//! <b>Desired fan speed not reached error</b> 39
	FAN_SPEED_ERROR = 0x27,
	//! <b>Unit has an error</b> 40
	GENERAL_ERROR = 0x28,
	//! <b>Auto speed supported</b> 41
	AUTO_SPEED_SUPPORT = 0x29,
	//! <b>Summer bypass active</b> 42
	SUMMER_BYPASS = 0x2A,
	//! <b>Frost protection active</b> 43
	FROST_PROTECTION_ACTIVE = 0x2B,
	//! <b>Reset Error</b> 44
	RESET_ERROR = 0x2C,
	//! <b>Reset filter timer</b> 45
	RESET_FILTER_TIMER = 0x2D,
} HVCA_INDEX;

//! Mode enums for A5-20-10 profile
typedef enum
{
	//! <b>Auto</b> 0
	MODE_AUTO = 0x00,
	//! <b>Heat</b> 1
	MODE_HEAT = 0x01,
	//! <b>Morning warmup</b> 2
	MODE_MORING_WARMUP = 0x02,
	//! <b>Cool</b> 3
	MODE_COOL = 0x03,
	//! <b>Night purge</b> 4
	MODE_NIGHT_PURGE = 0x04,
	//! <b>Precool</b> 5
	MODE_PRECOOL = 0x05,
	//! <b>Off</b> 6
	MODE_OFF = 0x06,
	//! <b>Test</b> 7
	MODE_TEST = 0x07,
	//! <b>Emergency heat</b> 8
	MODE_EMERGENCY_HEAT = 0x08,
	//! <b>Fan only</b> 9
	MODE_FAN_ONLY = 0x09,
	//! <b>Free cool</b> 10
	MODE_FREE_COOL = 0x0A,
	//! <b>Ice</b> 11
	MODE_ICE = 0x0B,
	//! <b>Max heat</b> 12
	MODE_MAX_HEAT = 0x0C,
	//! <b>Economic heat/cool</b> 13
	MODE_ECONOMIC = 0x0D,
	//! <b>Dehumidification (dry)</b> 14
	MODE_DEHUMIDITY = 0x0E,
	//! <b>Calibration</b> 15
	MODE_CALIBRATION = 0x0F,
	//! <b>Emergency cool</b> 16
	MODE_EMERGENCY_COOL = 0x10,
	//! <b>Emergency steam</b> 17
	MODE_EMERGENCY_STEAM = 0x11,
	//! <b>Max cool</b> 18
	MODE_MAX_COOL = 0x12,
	//! <b>Hvc load</b> 19
	MODE_HVC_LOAD = 0x13,
	//! <b>No load</b> 18
	MODE_NO_LOAD = 0x14,
	//! <b>Auto heat</b> 19
	MODE_AUTO_HEAT = 0x1F,
	//! <b>Auto cool</b> 20
	MODE_AUTO_COOL = 0x20
} HVAC_MODE;

//! Vane position enums for A5-20-10 profile
typedef enum
{
	//! <b>Auto</b> 0
	VANE_AUTO = 0x00,
	//! <b>Horizontal</b> 1
	VANE_HORIZONTAL = 0x01,
	//! <b>Pos 2</b> 2
	VANE_POS_2 = 0x02,
	//! <b>Pos 3</b> 3
	VANE_POS_3 = 0x03,
	//! <b>Pos 4</b> 4
	VANE_POS_4 = 0x04,
	//! <b>Vertical</b> 5
	VANE_VERTICAL = 0x05,
	//! <b>Swing</b> 6
	VANE_SWING = 0x06,
	//! <b>Vertical swing</b> 7
	VANE_VERT_SWING = 0x0B,
	//! <b>Horizontal swing</b> 8
	VANE_HORIZ_SWING = 0x0C,
	//! <b>Horizontal and vertical swing</b> 9
	VANE_BOTH_SWING = 0x0D,
	//! <b>Stop swing</b> 10
	VANE_STOP_SWING = 0x0E
} HVCA_VANE_POSITION;

//! Room occupancy enums for A5-20-xx profiles
typedef enum
{
	//! <b>Occupied</b> 0
	HVCA_OCCUPIED = 0x00,
	//! <b>StandBy</b> 1
	HVCA_STANDBY = 0x01,
	//! <b>Unoccupied</b> 2
	HVCA_UNOCCUPIED = 0x02,
	//! <b>Off (no occupancy, no action)</b> 3
	HVCA_OFF = 0X03
} HVCA_ROOM_OCCUPANCY;

//! Room occupancy enums for A5-20-20 profile
typedef enum
{
	//! <b>Occupied</b> 0
	HVCA_OCCUPIED_20 = 0x00,
	//! <b>Unoccupied</b> 1
	HVCA_UNOCCUPIED_20 = 0x01,
	//! <b>StandBy</b> 2
	HVCA_STANDBY_20 = 0x02,
	//! <b>Frost</b> 3 
	HVCA_FROST_20 = 0X03
} HVCA_ROOM_OCCUPANCY_TYPE_20;

//! Fan speed enums for A5-20-20 profile
typedef enum
{
	//! <b>Stage 0</b> 0 
	HVCA_STAGE_0 = 0x00,
	//! <b>Stage 1</b> 1 
	HVCA_STAGE_1 = 0x01,
	//! <b>Stage 2</b> 2 
	HVCA_STAGE_2 = 0x02,
	//! <b>Stage 3</b> 3 
	HVCA_STAGE_3 = 0x03,
	//! <b>Auto</b> 31 
	HVCA_AUTO = 0x1F
} HVCA_FANSPEED;

//! Controller mode enums for A5-20-xx profiles
typedef enum
{
	//! <b>Auto mode</b> 0 
	HVCA_AUTO_MOD = 0x00,
	//! <b>Heating</b> 1 
	HVCA_HEAT_MOD = 0x01,
	//! <b>Cooling</b> 2
	HVCA_COOL_MOD = 0x02,
	//! <b>Off</b> 3
	HVCA_OFF_MOD = 0x03
} HVCA_CONTROLLER_MODE;

//! Failure code enums
typedef enum
{
	//! <b>Measurement error</b> 17
	MEASUREMENT_ERROR = 0x11,
	//! <b>Battery empty</b> 18
	BATTERY_EMPTY = 0x12,
	//! <b>Frost protection</b> 20
	FROST_PROTECTION = 0x14,
	//! <b>Blocked valve</b> 33
	BLOCKED_VALVE = 0x21,
	//! <b>End point detection</b> 36
	END_POINT_DETECTION = 0x24,
	//! <b>No valve</b> 40
	NO_VALVE = 0x28,
	//! <b>Not teached in</b> 49
	NOT_TEACHED_IN = 0x31,
	//! <b>No response from controller</b> 53
	NO_RESPONSE_FROM_CONTROLLER = 0x35,
	//! <b>Teach in error</b> 54
	TEACH_IN_ERROR = 0x36
} HVCA_FAILURE_CODE;

//! Measurement status enums
typedef enum
{
	//! <b>Active</b> 0
	MEASUREMENT_ACTIVE = 0x00,
	//! <b>Inactive</b> 1
	MEASUREMENT_INACTIVE = 0x01
} HVCA_MEASUREMENT_STATUS;

//! Measurement control enums
typedef enum
{
	//! <b>Enable</b> 0
	MEASUREMENT_ENABLE = 0x00,
	//! <b>Disable</b> 1
	MEASUREMENT_DISABLE = 0x01
} HVCA_MEASUREMENT_CONTROL;

//! Status request enums
typedef enum
{
	//! <b>No change</b> 0
	STATUS_NO_CHANGE = 0x00,
	//! <b>Status requested</b> 1
	STATUS_REQUESTED = 0x01
} HVCA_STATUS_REQUEST;

//! Button lock status enums
typedef enum
{
	//! <b>Unlocked</b> 0
	BUTTON_UNLOCKED = 0x00,
	//! <b>Locked</b> 1
	BUTTON_LOCKED = 0x01
} HVCA_BUTTON_LOCK;

//! Temperature selection enums
typedef enum
{
	//! <b>Feed temperature</b> 0
	FEED_TEMP_SELECT = 0x00,
	//! <b>Temperature set point</b> 1
	TEMP_SETPOINT_SELECT = 0x01
} HVCA_TEMP_SELECTION;

//! Failure enums
typedef enum
{
	//! <b>No failure</b> 0
	NO_FAILURE_FLAG = 0x00,
	//! <b>Failure</b> 1
	FAILURE_FLAG = 0x01
} HVCA_FAILURE;

//! Wake-up cycle enums
typedef enum
{
	//! <b>10 sec</b> 0
	SEC_10 = 0x00,
	//! <b>60 sec</b> 1
	SEC_60 = 0x01,
	//! <b>90 sec</b> 2
	SEC_90 = 0x02,
	//! <b>120 sec</b> 3
	SEC_120 = 0x03,
	//! <b>150 sec</b> 4
	SEC_150 = 0x04,
	//! <b>180 sec</b> 5
	SEC_180 = 0x05,
	//! <b>210 sec</b> 6
	SEC_210 = 0x06,
	//! <b>240 sec</b> 7
	SEC_240 = 0x07,
	//! <b>270 sec</b> 8
	SEC_270 = 0x08,
	//! <b>300 sec</b> 9
	SEC_300 = 0x09,
	//! <b>330 sec</b> 10
	SEC_330 = 0x0A,
	//! <b>360 sec</b> 11
	SEC_360 = 0x0B,
	//! <b>390 sec</b> 12
	SEC_390 = 0x0C,
	//! <b>420 sec</b> 13
	SEC_420 = 0x0D,
	//! <b>450 sec</b> 14
	SEC_450 = 0x0E,
	//! <b>480 sec</b> 15
	SEC_480 = 0x0F,
	//! <b>510 sec</b> 16
	SEC_510 = 0x10,
	//! <b>540 sec</b> 17
	SEC_540 = 0x11,
	//! <b>570 sec</b> 18
	SEC_570 = 0x12,
	//! <b>600 sec</b> 19
	SEC_600 = 0x13,
	//! <b>630 sec</b> 20
	SEC_630 = 0x14,
	//! <b>660 sec</b> 21
	SEC_660 = 0x15,
	//! <b>690 sec</b> 22
	SEC_690 = 0x16,
	//! <b>720 sec</b> 23
	SEC_720 = 0x17,
	//! <b>750 sec</b> 24
	SEC_750 = 0x18,
	//! <b>780 sec</b> 25
	SEC_780 = 0x19,
	//! <b>810 sec</b> 26
	SEC_810 = 0x1A,
	//! <b>840 sec</b> 27
	SEC_840 = 0x1B,
	//! <b>870 sec</b> 28
	SEC_870 = 0x1C,
	//! <b>900 sec</b> 29
	SEC_900 = 0x1D,
	//! <b>930 sec</b> 30
	SEC_930 = 0x1E,
	//! <b>960 sec</b> 31
	SEC_960 = 0x1F,
	//! <b>990 sec</b> 32
	SEC_990 = 0x20,
	//! <b>1020 sec</b> 33
	SEC_1020 = 0x21,
	//! <b>1050 sec</b> 34
	SEC_1050 = 0x22,
	//! <b>1080 sec</b> 35
	SEC_1080 = 0x23,
	//! <b>1110 sec</b> 36
	SEC_1110 = 0x24,
	//! <b>1140 sec</b> 37
	SEC_1140 = 0x25,
	//! <b>1170 sec</b> 38
	SEC_1170 = 0x26,
	//! <b>1200 sec</b> 39
	SEC_1200 = 0x27,
	//! <b>1230 sec</b> 40
	SEC_1230 = 0x28,
	//! <b>1260 sec</b> 41
	SEC_1260 = 0x29,
	//! <b>1290 sec</b> 42
	SEC_1290 = 0x2A,
	//! <b>1320 sec</b> 43
	SEC_1320 = 0x2B,
	//! <b>1350 sec</b> 44
	SEC_1350 = 0x2C,
	//! <b>1380 sec</b> 45
	SEC_1380 = 0x2D,
	//! <b>1410 sec</b> 46
	SEC_1410 = 0x2E,
	//! <b>1440 sec</b> 47
	SEC_1440 = 0x2F,
	//! <b>1470 sec</b> 48
	SEC_1470 = 0x30,
	//! <b>1500 sec</b> 49
	SEC_1500 = 0x31,
	//! <b>3 hours</b> 50
	HRS_3 = 0x32,
	//! <b>6 hours</b> 51
	HRS_6 = 0x33,
	//! <b>9 hours</b> 52
	HRS_9 = 0x34,
	//! <b>12 hours</b> 53
	HRS_12 = 0x35,
	//! <b>15 hours</b> 54
	HRS_15 = 0x36,
	//! <b>18 hours</b> 55
	HRS_18 = 0x37,
	//! <b>21 hours</b> 56
	HRS_21 = 0x38,
	//! <b>24 hours</b> 57
	HRS_24 = 0x39,
	//! <b>27 hours</b> 58
	HRS_27 = 0x3A,
	//! <b>30 hours</b> 59
	HRS_30 = 0x3B,
	//! <b>33 hours</b> 60
	HRS_33 = 0x3C,
	//! <b>36 hours</b> 61
	HRS_36 = 0x3D,
	//! <b>39 hours</b> 62
	HRS_39 = 0x3E,
	//! <b>42 hours</b> 63
	HRS_42 = 0x3F
} HVCA_WAKEUP_CYCLE;

//! Display orientation enums
typedef enum
{
	//! <b>0</b> 0
	ORIENTATION_0 = 0x00,
	//! <b>90</b> 1
	ORIENTATION_90 = 0x01,
	//! <b>180</b> 2
	ORIENTATION_180 = 0x02,
	//! <b>270</b> 3
	ORIENTATION_270 = 0x03
} HVCA_DISPLAY_ORIENTATION;

//! Service command enums
typedef enum
{
	//! <b>No change</b> 0
	HVCA_NO_CHANGE = 0x00,
	//! <b>Open valve</b> 1
	HVCA_OPEN_VALVE = 0x01,
	//! <b>Run initialisation</b> 2
	HVCA_RUN_INIT = 0x02,
	//! <b>Close valve</b> 3
	HVCA_CLOSE_VALVE = 0x03
} HVCA_SERVICE_COMMAND;

//! Actual speed setting of ventilation unit
typedef enum
{
	//! <b>Minimum speed / away</b> 0
	HVCA_MIN_SPEED = 0x00,
	//! <b>Speed 1 / low</b> 1
	HVCA_SPEED_1 = 0x01,
	//! <b>Speed 2 / mid</b> 2
	HVCA_SPEED_2 = 0x02,
	//! <b>Speed 3 / high</b> 3
	HVCA_SPEED_3 = 0x03,
	//! <b>Maximum speed</b> 4
	HVCA_MAX_SPEED = 0x04,
	//! <b>Auto</b> 5
	HVCA_SPEED_AUTO = 0x05,
	//! <b>No change</b> 7
	HVCA_NO_CHANGE_SPEED = 0x07,
} HVCA_ACTUAL_SPEED_SETTING;

//! Actual timer setting of ventilation unit
typedef enum
{
	//! <b>No timer set or expired</b> 0
	HVCA_NO_TIMER_EXPIRED = 0x00,
	//! <b>1..10 min left</b> 1
	HVCA_1_10_MIN_LEFT = 0x01,
	//! <b>11..20 min left</b> 2
	HVCA_11_20_MIN_LEFT = 0x02,
	//! <b>21..30 min left</b> 3
	HVCA_21_30_MIN_LEFT = 0x03,
	//! <b>31..40 min left</b> 4
	HVCA_31_40_MIN_LEFT = 0x04,
	//! <b>41..50 min left</b> 5
	HVCA_41_50_MIN_LEFT = 0x05,
	//! <b>51..60 min left</b> 6
	HVCA_51_60_MIN_LEFT = 0x06,
	//! <b>>60 min left</b> 7
	HVCA_MORE_60_MIN_LEFT = 0x07
} HVCA_ACTUAL_TIMER_SETTING;

//! Actual timer setting of ventilation unit
typedef enum
{
	//! <b>No timer</b> 0
	HVCA_NO_TIMER = 0x00,
	//! <b>1..10 min left</b> 1
	HVCA_10_MIN_SET = 0x01,
	//! <b>20 min</b> 2
	HVCA_20_MIN_SET = 0x02,
	//! <b>30 min</b> 3
	HVCA_30_MIN_SET = 0x03,
	//! <b>40 min</b> 4
	HVCA_40_MIN_SET = 0x04,
	//! <b>50 min</b> 5
	HVCA_50_MIN_SET = 0x05,
	//! <b>60 min</b> 6
	HVCA_60_MIN_SET = 0x06,
	//! <b>2 hour</b> 7
	HVCA_2_HOUR_SET = 0x07,
	//! <b>3 hour</b> 8
	HVCA_3_HOUR_SET = 0x08,
	//! <b>4 hour</b> 9
	HVCA_4_HOUR_SET = 0x09,
	//! <b>5 hour</b> 10
	HVCA_5_HOUR_SET = 0x0A,
	//! <b>6 hour</b> 11
	HVCA_6_HOUR_SET = 0x0B,
	//! <b>7 hour</b> 12
	HVCA_7_HOUR_SET = 0x0C,
	//! <b>8 hour</b> 13
	HVCA_8_HOUR_SET = 0x0D,
	//! <b>9 hour</b> 14
	HVCA_9_HOUR_SET = 0x0E,
	//! <b>10 hour</b> 15
	HVCA_10_HOUR_SET = 0x0F,
	//! <b>11 hour</b> 16
	HVCA_11_HOUR_SET = 0x10,
	//! <b>12 hour</b> 17
	HVCA_12_HOUR_SET = 0x11,
	//! <b>13 hour</b> 18
	HVCA_13_HOUR_SET = 0x12,
	//! <b>14 hour</b> 19
	HVCA_14_HOUR_SET = 0x13,
	//! <b>15 hour</b> 20
	HVCA_15_HOUR_SET = 0x14,
	//! <b>16 hour</b> 21
	HVCA_16_HOUR_SET = 0x15,
	//! <b>17 hour</b> 22
	HVCA_17_HOUR_SET = 0x16,
	//! <b>18 hour</b> 23
	HVCA_18_HOUR_SET = 0x17,
	//! <b>19 hour</b> 24
	HVCA_19_HOUR_SET = 0x18,
	//! <b>20 hour</b> 25
	HVCA_20_HOUR_SET = 0x19,
	//! <b>21 hour</b> 26
	HVCA_21_HOUR_SET = 0x1A,
	//! <b>22 hour</b> 27
	HVCA_22_HOUR_SET = 0x1B,
	//! <b>23 hour</b> 28
	HVCA_23_HOUR_SET = 0x1C,
	//! <b>24 hour</b> 29
	HVCA_24_HOUR_SET = 0x1D,
} HVCA_NEW_TIMER_SETTING;

//! Error command enums
typedef enum
{
	//! <b>Don't reset error</b> 0
	HVCA_DO_NOT_RESET = 0x00,
	//! <b>Reset</b> 1
	HVCA_DO_RESET = 0x01
} HVCA_ERROR_RESET_COMMAND;


//! Direction enums
typedef enum
{
	//! <b>Direction 1</b> 0
	HVCA_DIRECTION_1 = 0x00,
	//! <b>Direction 2</b> 1
	HVCA_DIRECTION_2 = 0x01
} HVCA_DIRECTION;

class eoEEP_A520xx: public eoA5EEProfile, public eoISimpleBidirectionalProfile
{

private:
	eoMessage outMessage;
	eoEEPChannelInfo *outChannels;
	uint8_t outChannelCount;
	//internal helper tries to set the channel for Direction and type
	eoReturn SetChannels(SIMPLE_DIRECTION direction,uint8_t type);
public:
	eoReturn SetType(uint8_t type);
	eoEEP_A520xx();
	virtual ~eoEEP_A520xx();

	eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	eoReturn GetValue(CHANNEL_TYPE type, float &value);
	eoReturn SetValue(CHANNEL_TYPE type, float value);
	eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);
	virtual eoReturn Create(eoMessage &m);
	virtual eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t subFlag);

	virtual eoChannelInfo* GetOutChannel(CHANNEL_TYPE type, uint8_t subType);
	virtual eoChannelInfo* GetOutChannel(CHANNEL_TYPE type);
	virtual eoChannelInfo* GetOutChannel(uint8_t channelNumber);
	/**
	 * Sets the direction for this profile
	 * @note Deprecated funtion, the function from the Interface using the ::SIMPLE_DIRECTION should be used.
	 * @param direction
	 * @return
	 */
	eoReturn SetDirection(HVCA_DIRECTION direction);
	virtual eoReturn SetDirection(SIMPLE_DIRECTION directionToSet);
	virtual void ClearValues();
};

#endif
