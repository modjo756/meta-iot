/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if !defined(eoEEP_A538_H__INCLUDED_)
#define eoEEP_A538_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
/**\class eoEEP_A538xx
 * \brief The class to handle EEP a538 profiles
 * \details Allows the user to handle EEP a538 profiles, the following profiles are available:
 * 		- A5-38-08
 * 		- A5-38-09\n
 *
 * NOTE: set the command ID.
 *
 * The following channels are available in Switching:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_TIME	  	|float |  |
 * | 1             | ::F_ON_OFF   	|uint8_t | Lock/Unlock, ::CC_LOCK_UNLOCK |
 * | 2             | ::F_ON_OFF   	|uint8_t | Delay or duration, ::CC_DELAY_DURATION |
 * | 3             | ::F_ON_OFF   	|uint8_t | Switching command, ::CC_SWITCHING_COMMAND |
 * \n
 * The following channels are available in Dimming:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_DIMMING  	|float |   |
 * | 1             | ::S_TIME	  	|float |    |
 * | 2             | ::F_ON_OFF   	|uint8_t | Dimming range, ::CC_DIMMING_RANGE |
 * | 3             | ::F_ON_OFF   	|uint8_t | Store final value, ::CC_STORE_FINAL_VAL |
 * | 4             | ::F_ON_OFF   	|uint8_t | Switching command, ::CC_SWITCHING_COMMAND |
 * \n
 * The following channels are available in Setpoint shift:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_SETPOINT  	|float |
 * \n
 * The following channels are available in Basic Setpoint:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_TEMP_ABS  	|float |
 * \n
 * The following channels are available in Control variable:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_SETPOINT  			|float |      |
 * | 1             | ::E_CONTROLLER_MODE 	|::CC_CONTROLLER_MODE |     |
 * | 2             | ::F_ON_OFF   			|uint8_t | Controller state, ::CC_CONTROLLER_STATE |
 * | 3             | ::F_ON_OFF   			|uint8_t | Energy hold-off, ::CC_ENERGY_HOLDOFF |
 * | 4             | ::E_OCCUPANCY 			|::CC_ROOM_OCCUPANCY |  |
 * \n
 * The following channels are available in Fan stage:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_FANSPEED  	| |
 * \n
 * The following channels are available in Central Command:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PERCENTAGE			|float | Blind position, ::CC_BLIND_POSITION |
 * | 1             | ::S_ANGLE				|float | Blind angle, ::CC_ANGLE_BLIND_POSITION |
 * | 2             | ::S_TIME				|float | Blind open position, ::CC_BLIND_OPEN_POSITION |
 * | 3             | ::S_TIME	  			|float | Blind open angle, ::CC_BLIND_OPEN_ANGLE |
 * | 4             | ::S_TIME	  			|float | Blind close position, ::CC_BLIND_CLOSE_POSITION |
 * | 5             | ::S_TIME	  			|float | Blind close angle, ::CC_BLIND_CLOSE_ANGLE |
 * | 6             | ::S_TIME	  			|float | Runtime value to close, ::CC_RUNTIME_CLOSE |
 * | 7             | ::S_TIME	  			|float | Runtime value to open, ::CC_RUNTIME_OPEN |
 * | 8             | ::S_TIME	  			|float | Sunblind reversion time, ::CC_SUNBLIND_REVERSION |
 * | 9             | ::S_PERCENTAGE		 	|float | Set minimum position, ::CC_SET_MIN_POSITION |
 * | 10            | ::S_PERCENTAGE		 	|float | Set maximum position, ::CC_SET_MAX_POSITION |
 * | 11            | ::S_ANGLE   			|float | Fully shut angle, ::CC_FULLY_SHUT_ANGLE |
 * | 12            | ::S_ANGLE   			|float | Fully open angle, ::CC_FULLY_OPEN_ANGLE |
 * | 13            | ::F_ON_OFF   			|uint8_t | Position logic, ::CC_POSITION_LOGIC |
 * | 14            | ::E_USER_ACTION		|::CC_FUNCTIONS |   |
 * | 15            | ::F_ON_OFF   			|uint8_t | Send status flag |
 * | 16            | ::F_ON_OFF   			|uint8_t | Position and angle flag |
 * | 17            | ::F_ON_OFF   			|uint8_t | Service mode flag |
 * \n
 * The following channels are available in Extended Lightning control:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 1             | ::S_TIME				|float | Up ramping time, ::CC_UP_RAMPING_TIME |
 * | 2             | ::S_TIME	  			|float | Down ramping time, ::CC_DOWN_RAMPING_TIME |
 * | 3             | ::S_DIMMING			|float | Dimming value, ::CC_DIMMING_VALUE |
 * | 4             | ::S_TIME	  			|float | Set ramping time, ::CC_SET_RAMPING_TIME |
 * | 5             | ::S_RGB	  			|float | RGB red, ::CC_RGB_RED |
 * | 6             | ::S_RGB	  			|float | RGB green, ::CC_RGB_GREEN |
 * | 7             | ::S_RGB	  			|float | RGB blue, ::CC_RGB_BLUE |
 * | 8             | ::F_ON_OFF	  			|uint8_t | Scene function, ::CC_SCENE |
 * | 9             | ::S_VALUE	  			|float | Scene number, ::CC_SCENE_NUMBER |
 * | 10            | ::S_DIMMING		 	|float | Minimum dimming value, ::CC_MIN_DIM_VALUE |
 * | 11            | ::S_DIMMING		 	|float | Maximum dimming value, ::CC_MAX_DIM_VALUE |
 * | 12            | ::S_TIME	  			|float | Lamp operating hours, ::CC_LAMP_OPERATING_HOUR |
 * | 13            | ::E_STATE				|::CC_LOCKING_OPERATIONS |  |
 * | 14            | ::S_VALUE	  			|float | Energy metering value, ::CC_ENERGY_METERING_VALUE |
 * | 15            | ::E_UNITS				|::CC_ENERGY_UNITS |    |
 * | 16            | ::E_USER_ACTION		|::CC_FUNCTIONS |    |
 * | 17            | ::F_ON_OFF   			|uint8_t | Send status flag, ::CC_SEND_STATUS |
 * | 18            | ::F_ON_OFF   			|uint8_t | Store final value, ::CC_STORE_FINAL_VAL |
 * | 19            | ::F_ON_OFF   			|uint8_t | Service mode flag, ::CC_SERVICE_MODE |
 * \n
 */

/**
 * \file eoEEP_A538xx.h
 */
//! Index enums for A5-38-xx profiles
typedef enum
{
	//! <b>Lock/Unlock</b> 0
	CC_LOCK_UNLOCK = 0x00,
	//! <b>Delay or duration</b> 1
	CC_DELAY_DURATION = 0x01,
	//! <b>Switching commanf</b> 2
	CC_SWITCHING_COMMAND = 0x02,
	//! <b>Dimming range</b> 3
	CC_DIMMING_RANGE = 0x03,
	//! <b>Store final value</b> 4
	CC_STORE_FINAL_VAL = 0x04,
	//! <b>Controller state</b> 5
	CC_CONTROLLER_STATE = 0x05,
	//! <b>Energy hold-off</b> 6
	CC_ENERGY_HOLDOFF = 0x06,
	//! <b>Send status flag</b> 7
	CC_SEND_STATUS = 0x07,
	//! <b>Position and Angle flag</b> 8
	CC_POS_ANGLE_FLAG = 0x08,
	//! <b>Service mode flag</b> 9
	CC_SERVICE_MODE = 0x09,
	//! <b>Blind position</b> 10
	CC_BLIND_POSITION = 0x0A,
	//! <b>Blind angle position</b> 11
	CC_ANGLE_BLIND_POSITION = 0x0B,
	//! <b>Blind opens for time (position value)</b> 12
	CC_BLIND_OPEN_POSITION = 0x0C,
	//! <b>Blind opens for time (angle value)</b> 13
	CC_BLIND_OPEN_ANGLE = 0x0D,
	//! <b>Blind closes for time (position value)</b> 14
	CC_BLIND_CLOSE_POSITION = 0x0E,
	//! <b>Blind closes for time (angle value)</b> 15
	CC_BLIND_CLOSE_ANGLE = 0x0F,
	//! <b>Set runtime parameter (open)</b> 16
	CC_RUNTIME_OPEN = 0x10,
	//! <b>Set runtime parameter (close)</b> 17
	CC_RUNTIME_CLOSE = 0x11,
	//! <b>Sunblind reversion time</b> 18
	CC_SUNBLIND_REVERSION = 0x12,
	//! <b>Set minimum position</b> 19
	CC_SET_MIN_POSITION = 0x13,
	//! <b>Set maximum position</b> 20
	CC_SET_MAX_POSITION = 0x14,
	//! <b>Set slut angle for fully shut position</b> 21
	CC_FULLY_SHUT_ANGLE = 0x15,
	//! <b>Set slut angle for fully open position</b> 22
	CC_FULLY_OPEN_ANGLE = 0x16,
	//! <b>Position logic</b> 23 
	CC_POSITION_LOGIC = 0x17,
	//! <b>Set dimming value</b> 24
	CC_DIMMING_VALUE = 0x18,
	//! <b>Set ramping up time</b> 25
	CC_UP_RAMPING_TIME = 0x19,
	//! <b>Set ramping down time</b> 26
	CC_DOWN_RAMPING_TIME = 0x1A,
	//! <b>Set ramping time</b> 27
	CC_SET_RAMPING_TIME = 0x1B,
	//! <b>RGB red</b> 28
	CC_RGB_RED = 0x1C,
	//! <b>RGB green</b> 29
	CC_RGB_GREEN = 0x1D,
	//! <b>RGB blue</b> 30
	CC_RGB_BLUE = 0x1E,
	//! <b>Minimum dimming value</b> 31
	CC_MIN_DIM_VALUE = 0x1F,
	//! <b>Maximum dimming value</b> 32
	CC_MAX_DIM_VALUE = 0x20,
	//! <b>Lamp operating hours</b> 33
	CC_LAMP_OPERATING_HOUR = 0x21,
	//! <b>Scene number</b> 34
	CC_SCENE_NUMBER = 0x22,
	//! <b>Scene function</b> 35
	CC_SCENE = 0x23,
	//! <b>Energy metering value</b> 36
	CC_ENERGY_METERING_VALUE = 0x24
} CC_INDEXS;

//! Energy unit enums for A5-38-xx profiles
typedef enum
{
	//! <b>mW</b> 0
	MILI_W = 0x00,
	//! <b>W</b> 1
	W = 0x01,
	//! <b>kW</b> 2
	KILO_W = 0x02,
	//! <b>MW</b> 3
	MEGA_W = 0x03,
	//! <b>Wh</b> 4
	WH = 0x04,
	//! <b>kWh</b> 5
	KILO_WH = 0x05,
	//! <b>MWh</b> 6
	MEGA_WH = 0x06,
	//! <b>GWh</b> 7
	GIGA_WH = 0x07,
	//! <b>mA</b> 8
	MILI_A = 0x08,
	//! <b>1/10 A</b> 9
	A_1_10 = 0x09,
	//! <b>mV</b> 10
	MILI_V = 0x0A,
	//! <b>1/10 V</b> 11
	V_1_10 = 0x0B
} CC_ENERGY_UNITS;

//! Locking operation enums for A5-38-xx profiles
typedef enum
{
	//! <b>Unlock local operations</b> 0
	UNLOCK_LOCAL_OP = 0x00,
	//! <b>Locking switch on commands</b> 1
	LOCK_SWITCH_ON = 0x01,
	//! <b>Locking switch off commands</b> 2
	LOCK_SWITCH_OFF = 0x02,
	//! <b>Locking local operations</b> 3
	LOCK_LOCAL_OP = 0x03
} CC_LOCKING_OPERATIONS;

//! Function enums for A5-38-08 profile (command 0x07)
typedef enum
{
	//! <b>Do nothing, status request</b> 0
	DO_NOTHING = 0x00,
	//! <b>Blind stops</b> 1
	STOP_BLIND = 0x01,
	//! <b>Blind opens</b> 2
	OPEN_BLIND = 0x02,
	//! <b>Blind closes</b> 3
	CLOSE_BLIND = 0x03,
	//! <b>Blind drives to position with angle value</b> 4
	DRIVE_TO_POS = 0x04,
	//! <b>Blind opens for time (position value) and angle (angle value)</b> 5
	OPEN_FOR_TIME = 0x05,
	//! <b>Blind closes for time (posititon value) and angle (angle value)</b> 6
	CLOSE_FOR_TIME = 0x06,
	//! <b>Set runtime parameters</b> 7
	SET_RUNTIME_PARAM = 0x07,
	//! <b>Set angle configuration</b> 8
	SET_ANGLE = 0x08,
	//! <b>Set min, max values</b> 9
	SET_MIN_MAX = 0x09,
	//! <b>Set slat angle for shut and open position</b> 10
	SET_SLAT_ANGLE = 0x0A,
	//! <b>Set position logic</b> 11
	SET_LOGIC_POS = 0x0B
} CC_FUNCTIONS;

//! Function enums for A5-38-09 profile
typedef enum
{
	//! <b>Do nothing, status request</b> 0
	CC_DO_NOTHING = 0x00,
	//! <b>Swithced off</b> 1
	CC_SWITCHED_OFF = 0x01,
	//! <b>Swithced on</b> 2
	CC_SWITCHED_ON = 0x02,
	//! <b>Dimming up with ramping time</b> 3
	CC_DIMMING_UP = 0x03,
	//! <b>Dimming down with ramping time</b> 4
	CC_DIMMING_DOWN = 0x04,
	//! <b>Dimming stops</b> 5
	CC_DIMMING_STOP = 0x05,
	//! <b>Set dimemr value and ramping time</b> 6
	CC_SET_VALUES = 0x06,
	//! <b>Set RGB values</b> 7
	CC_SET_RGB_VALUES = 0x07,
	//! <b>Scene function</b> 8
	CC_SCENE_FUNCTION = 0x08,
	//! <b>Set minimal and maximal dimmer value</b> 9
	CC_SET_DIMMER_VALUE = 0x09,
	//! <b>Set the operating hours of the lamp</b> 10
	CC_SET_OP_HOURS = 0x0A,
	//! <b>Locking local operations</b> 11
	CC_LOCK_OPERATIONS = 0x0B,
	//! <b>Set a new value for the energy metering</b> 12
	CC_NEW_VALUE_METERING = 0x0C
} CC_FUNCTIONS_TYPE_09;

//! Fan stage enums for A5-38-xx profile
typedef enum
{
	//! <b>Stage 0</b> 0
	CC_STAGE_0 = 0,
	//! <b>Stage 1</b> 1
	CC_STAGE_1 = 1,
	//! <b>Stage 2</b> 2
	CC_STAGE_2 = 2,
	//! <b>Stage 3</b> 3
	CC_STAGE_3 = 3,
	//! <b>Stage Auto</b> 255
	CC_STAGE_AUTO = 255
} CC_FAN_SPEED_5_STAGE;

//! Room occupancy enums for A5-38-xx profile
typedef enum
{
	//! <b>Occupied</b> 0
	CC_OCCUPIED = 0,
	//! <b>Unoccupied</b> 1
	CC_UNOCCUPIED = 1,
	//! <b>StandBy</b> 2
	CC_STANDBY = 2
} CC_ROOM_OCCUPANCY;

//! Controller mode enums for A5-38-xx profile
typedef enum
{
	//! <b>Automatic mode</b> 0
	CC_AUTO = 0,
	//! <b>Heating</b> 1
	CC_HEATING = 1,
	//! <b>Cooling</b> 2
	CC_COOLING = 2,
	//! <b>Off</b> 3
	CC_OFF = 3
} CC_CONTROLLER_MODE;

class eoEEP_A538xx: public eoA5EEProfile
{
private:
	uint8_t cmd;

public:
	eoEEP_A538xx();
	virtual ~eoEEP_A538xx();

	eoReturn SetType(uint8_t type);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);

	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets and checks if the specified command is supported
	 * @param cmd
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	eoReturn SetCommand(uint8_t cmd);

	eoReturn Parse(const eoMessage &m);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
