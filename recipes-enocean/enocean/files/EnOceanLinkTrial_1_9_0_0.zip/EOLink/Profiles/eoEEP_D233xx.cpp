/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D233xx.h"

#include "eoChannelEnums.h"
#include <string.h>
const uint8_t numOfChan = 0x13;
const uint8_t numOfCommands = 0x09;
const uint8_t numOfProfiles = 0x01;

const EEP_ITEM listD233xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
		{ true, 4, 4, 0, 15, 0, 15, E_STATE, REQUEST_FRAME }, //Request frame
		{ true, 8, 9, 1, 500, 0.1, 50.0, S_TEMP, EXT_TEMPERATURE }, //Temperature
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:01
{
		{ true, 4, 1, 0, 1, 0, 1, F_ON_OFF, WINDOW_OPEN_DETECTION_STATUS }, //Window open detection status
		{ true, 5, 1, 0, 1, 0, 1, F_ON_OFF, PIR_STATUS_DETECTION }, //PIR status detection
		{ true, 6, 1, 0, 1, 0, 1, F_ON_OFF, REF_TEMP_STATUS}, //Reference temperature status
		{ true, 7, 1, 0, 1, 0, 1, F_ON_OFF, COV_SENSOR}, //COV sensor
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, CO_SENSOR}, //CO sensor
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, CO2_SENSOR}, //CO2 sensor
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, PARTICLES_1_SENSOR}, //Particles 1 sensor
		{ true, 11, 1, 0, 1, 0, 1, F_ON_OFF, PARTICLES_25_SENSOR}, //Particles 2.5 sensor
		{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, PARTICLES_10_SENSOR}, //Particles 10 sensor
		{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, RAD_ACTIVITY_SENSOR}, //Radio activity sensor
		{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, SOUND_SENSOR}, //Sound sensor
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, HYGROMETRY_SENSOR}, //Hygrometry sensor
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, AIR_MOVING_SENSOR}, //Air moving sensor
		{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, PRESSURE_SENSOR}, //Pressure sensor
		{ true, 18, 2, 0, 3, 0, 3, E_STATE, TEMP_SCALE_STATUS}, //Temperature scale status
		{ true, 20, 2, 0, 3, 0, 3, E_STATE, TIME_NOTATION_STATUS}, //Time notation status
		{ true, 22, 3, 0, 6, 0, 6, E_STATE, DISP_CONTENT_STATUS}, //Display content status
		{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, DEROGATION_STATUS}, //Derogation status
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
},
//COMMAND:02
{
		{ true, 4, 1, 0, 1, 0, 1, F_ON_OFF, SCHEDULED_ORDER_TYPE}, //Scheduled order type
		{ true, 5, 3, 0, 7, 0, 7, E_DAYS, DAY_TIME_END }, //End time day
		{ true, 8, 6, 0, 59, 0, 59, S_TIME, MINUTE_TIME_END }, //End time minute
		{ true, 14, 5, 0, 23, 0, 23, S_TIME, HOUR_TIME_END }, //End time hour
		{ true, 19, 3, 0, 7, 0, 7, E_DAYS, DAY_TIME_START }, //Start time day
		{ true, 22, 6, 0, 59, 0, 59, S_TIME, MINUTE_TIME_START }, //Start time minute
		{ true, 28, 5, 0, 23, 0, 23, S_TIME, HOUR_TIME_START }, //Start time hour
		{ true, 33, 9, 1, 500, 0.1, 50.0, S_TEMP_ABS, 0 }, //Temperature setpoint
		{ true, 42, 1, 0, 1, 0, 1, F_ON_OFF, CLEAR_SCHEDULE}, //Clear scheduled
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:03
{
		{ true, 4, 5, 1, 31, 1, 31, S_TIME, VLD_TIME_DAY }, //Day
		{ true, 9, 4, 1, 12, 1, 12, S_TIME, VLD_TIME_MONTH }, //Month
		{ true, 13, 12, 0, 4095, 0, 4095, S_TIME, VLD_TIME_YEAR }, //Year
		{ true, 25, 6, 0, 59, 0, 59, S_TIME, VLD_TIME_MINUTE }, //Minute
		{ true, 31, 5, 0, 23, 0, 23, S_TIME, VLD_TIME_HOUR }, //Hour
		{ true, 36, 3, 0, 7, 0, 7, E_DAYS, VLD_TIME_DAY_WEEK }, //Day week
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:04
{
		{ true, 4, 4, 0, 15, 0, 15, E_STATE, REQUEST_FRAME }, //Request frame
		{ true, 8, 16, 1, 0x8000, 1, 0x8000, E_ERROR_STATE, 0 }, //Error flag
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, HEATING_FLAG}, //Heating flag
		{ true, 25, 2, 0, 3, 0, 3, E_STATE, PILOT_WIRE_FLAG }, //Pilot wire flag
		{ true, 27, 2, 0, 3, 0, 3, E_STATE, WINDOW_DETECTION_FLAG }, //Window open detection flag
		{ true, 29, 2, 0, 3, 0, 3, E_STATE, PIR_STATUS_DETECTION }, //PIR flag
		{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, KEY_LOCK_STATUS}, //Key lock status
		{ true, 32, 1, 0, 1, 0, 1, F_ON_OFF, REF_TEMP_FLAG}, //Reference temperature flag
		{ true, 33, 1, 0, 1, 0, 1, F_ON_OFF, DEROGATION_FLAG}, //Derogation flag
		{ true, 34, 9, 1, 500, 0.1, 50.0, S_TEMP, INT_TEMPERATURE }, //Internal temperature
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:05
{
		{ true, 4, 24, 0, 16777215, 0, 167721, S_ENERGY, 0 }, //Energy measurement
		{ true, 28, 9, 1, 500, 0.1, 50.0, S_TEMP, DEROGATION_TEMP_SETPOINT }, //Derogation temperature setpoint
		{ true, 37, 10, 0, 1023, 0, 1023, S_VALUE, FIRMWARE_VERSION }, //Firmware version
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:06
{
		{ true, 4, 16, 0, 65535, 0, 65535, S_VALUE, COV_SENSOR }, //COV value
		{ true, 20, 8, 1, 255, 1, 255, S_VALUE, CO_SENSOR }, //CO value
		{ true, 28, 8, 1, 255, 1, 2550, S_VALUE, CO2_SENSOR}, //CO2 value
		{ true, 36, 7, 1, 127, 1, 127, S_VALUE, SOUND_SENSOR }, //Sound value
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:07
{
		{ true, 4, 9, 1, 511, 1, 511, S_PARTICLES, PARTICLES_1_SENSOR }, //Particle 1
		{ true, 13, 9, 1, 511, 1, 511, S_PARTICLES, PARTICLES_25_SENSOR }, //Particle 2.5
		{ true, 22, 9, 1, 511, 1, 511, S_PARTICLES, PARTICLES_10_SENSOR }, //Particle 10
		{ true, 31, 14, 1, 16383, 0.01, 163.83, S_VALUE, RADIO_ACTIVITY }, //Radio activity value
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:08
{
		{ true, 4, 4, 1, 15, 1, 15, S_VELOCITY, 0 }, //Air moving
		{ true, 15, 10, 1, 1023, 500, 1150, S_PRESSURE, 0 }, //Pressure
		{ true, 25, 8, 1, 200, 1, 100, S_PERCENTAGE, 0 }, //Hygrometry value
		{ true, 33, 11, 1, 500, 0.1, 50.0, S_TEMP, INT_TEMPERATURE_2 }, //Internal temperature
		{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
};

const EEP_ITEM typeListD233xx [numOfProfiles][34] =
{
	//Type 0x00
	{
			{ true, 4, 1, 0, 1, 0, 1, F_ON_OFF, WINDOW_OPEN_DETECTION_STATUS }, //Window open detection status
			{ true, 5, 1, 0, 1, 0, 1, F_ON_OFF, PIR_STATUS_DETECTION }, //PIR status detection
			{ true, 6, 1, 0, 1, 0, 1, F_ON_OFF, REF_TEMP_STATUS}, //Reference temperature status
			{ true, 18, 2, 0, 3, 0, 3, E_STATE, TEMP_SCALE_STATUS}, //Temperature scale status
			{ true, 20, 2, 0, 3, 0, 3, E_STATE, TIME_NOTATION_STATUS}, //Time notation status
			{ true, 22, 3, 0, 6, 0, 6, E_STATE, DISP_CONTENT_STATUS}, //Display content status
			{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, DEROGATION_STATUS}, //Derogation status
			{ true, 4, 1, 0, 1, 0, 1, F_ON_OFF, SCHEDULED_ORDER_TYPE}, //Scheduled order type
			{ true, 5, 3, 0, 6, 0, 6, E_DAYS, DAY_TIME_END }, //End time day
			{ true, 8, 6, 0, 59, 0, 59, S_TIME, MINUTE_TIME_END }, //End time minute
			{ true, 14, 5, 0, 23, 0, 23, S_TIME, HOUR_TIME_END }, //End time hour
			{ true, 19, 3, 0, 6, 0, 6, E_DAYS, DAY_TIME_START }, //Start time day
			{ true, 22, 6, 0, 59, 0, 59, S_TIME, MINUTE_TIME_START }, //Start time minute
			{ true, 28, 5, 0, 23, 0, 23, S_TIME, HOUR_TIME_START }, //Start time hour
			{ true, 33, 9, 1, 500, 0.1, 50.0, S_TEMP_ABS, 0 }, //Temperature setpoint
			{ true, 42, 1, 0, 1, 0, 1, F_ON_OFF, CLEAR_SCHEDULE}, //Clear scheduled
			{ true, 4, 5, 1, 31, 1, 31, S_TIME, VLD_TIME_DAY }, //Day
			{ true, 9, 4, 1, 12, 1, 12, S_TIME, VLD_TIME_MONTH }, //Month
			{ true, 13, 12, 0, 4095, 0, 4095, S_TIME, VLD_TIME_YEAR }, //Year
			{ true, 25, 6, 0, 59, 0, 59, S_TIME, VLD_TIME_MINUTE }, //Minute
			{ true, 31, 5, 0, 23, 0, 23, S_TIME, VLD_TIME_HOUR }, //Hour
			{ true, 36, 3, 0, 6, 0, 6, E_DAYS, VLD_TIME_DAY_WEEK }, //Day week
			{ true, 4, 4, 0, 15, 0, 15, E_STATE, REQUEST_FRAME }, //Request frame
			{ true, 8, 16, 1, 8, 1, 8, E_ERROR_STATE, 0 }, //Error flag
			{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, HEATING_FLAG}, //Heating flag
			{ true, 25, 2, 0, 3, 0, 3, E_STATE, PILOT_WIRE_FLAG }, //Pilot wire flag
			{ true, 27, 2, 0, 2, 0, 2, E_STATE, WINDOW_DETECTION_FLAG }, //Window open detection flag
			{ true, 29, 2, 0, 2, 0, 2, E_STATE, PIR_STATUS_DETECTION }, //PIR flag
			{ true, 32, 1, 0, 1, 0, 1, F_ON_OFF, REF_TEMP_FLAG}, //Reference temperature flag
			{ true, 33, 1, 0, 1, 0, 1, F_ON_OFF, DEROGATION_FLAG}, //Derogation flag
			{ true, 34, 9, 1, 500, 0.1, 50.0, S_TEMP, INT_TEMPERATURE }, //Internal temperature
			{ true, 28, 9, 1, 500, 0.1, 50.0, S_TEMP, DEROGATION_TEMP_SETPOINT }, //Derogation temperature setpoint
			{ true, 37, 10, 0, 1023, 0, 1023, S_VALUE, FIRMWARE_VERSION }, //Firmware version
			{ true, 0, 4, 0, 12, 0, 12, E_COMMAND, 0 }, //Command ID
	},
};

eoEEP_D233xx::eoEEP_D233xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x33;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D233xx::~eoEEP_D233xx()
{
	if (channel != NULL)
		delete[] channel;
	channel = NULL;
}

eoReturn eoEEP_D233xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 3 || m.GetDataLength() > 6)
		return NOT_SUPPORTED;

	if (SetCommand((m.data[0] >> 4) & 0x0F) != EO_OK)
		return NOT_SUPPORTED;

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D233xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	SetCommand(1);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D233xx::SetCommand(uint8_t cmd)
{
	if ((cmd > 0x03 && cmd < 0x08) ||
		(cmd > 0x0C))
		return NOT_SUPPORTED;

	msg.Clear();

	uint8_t tmpCmd = cmd;
	// Workaround, when more commands are intoduced this needs to be changed!
	if (cmd > 0x03)
		tmpCmd = cmd - 0x04;

	// Set the proper message length depending on the command type
	const uint8_t dataLength[] =
	{ 3, 4, 6, 5, 6, 6, 6, 6, 6 };
	msg.SetDataLength(dataLength[tmpCmd]);

	if(cmd == this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	uint8_t tmpChannelCount;
	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD233xx[tmpCmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD233xx[tmpCmd][tmpChannelCount].type;
			channel[channelCount].max = listD233xx[tmpCmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD233xx[tmpCmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD233xx[tmpCmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D233xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_COMMAND:
		case E_ERROR_STATE:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D233xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	uint32_t rawValue;
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_ERROR_STATE:
			rawValue = (uint32_t)value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D233xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_ENERGY:
		case S_TEMP_ABS:
		case S_VELOCITY:
		case S_PRESSURE:
		case S_PERCENTAGE:
			break;
		default:
			return NOT_SUPPORTED;
	}

	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoEEP_D233xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_ENERGY:
		case S_TEMP_ABS:
		case S_VELOCITY:
		case S_PRESSURE:
		case S_PERCENTAGE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D233xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
	{
		return NOT_SUPPORTED;
	}
	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize) != EO_OK)
	{

		return NOT_SUPPORTED;
	}
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_STATE:
			switch(index)
			{
				case REQUEST_FRAME:
				case TEMP_SCALE_STATUS:
				case TIME_NOTATION_STATUS:
				case DISP_CONTENT_STATUS:
				case PILOT_WIRE_FLAG:
				case WINDOW_DETECTION_FLAG:
				case PIR_STATUS_DETECTION:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case F_ON_OFF:
			switch(index)
			{
				case WINDOW_OPEN_DETECTION_STATUS:
				case PIR_STATUS_DETECTION:
				case REF_TEMP_STATUS:
				case COV_SENSOR:
				case CO_SENSOR:
				case CO2_SENSOR:
				case PARTICLES_1_SENSOR:
				case PARTICLES_25_SENSOR:
				case PARTICLES_10_SENSOR:
				case RAD_ACTIVITY_SENSOR:
				case SOUND_SENSOR:
				case HYGROMETRY_SENSOR:
				case AIR_MOVING_SENSOR:
				case PRESSURE_SENSOR:
				case DEROGATION_STATUS:
				case DEROGATION_FLAG:
				case SCHEDULED_ORDER_TYPE:
				case CLEAR_SCHEDULE:
				case HEATING_FLAG:
				case KEY_LOCK_STATUS:
				case REF_TEMP_FLAG:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_DAYS:
			switch(index)
			{
				case DAY_TIME_END:
				case DAY_TIME_START:
				case VLD_TIME_DAY_WEEK:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return GetValue(type, value);
	}

	value = (uint8_t)rawValue;
	return EO_OK;
}

eoReturn eoEEP_D233xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_STATE:
			switch(index)
			{
				case REQUEST_FRAME:
					if (this->cmd == 0x00)
					{
						if (value < 0x07 || value == 0x0E)
							return OUT_OF_RANGE;
					}
					else if (this->cmd == 0x08)
					{
						if (value > 0x04 && value < 0x0F)
							return OUT_OF_RANGE;
					}
					break;
				case TEMP_SCALE_STATUS:
				case TIME_NOTATION_STATUS:
				case DISP_CONTENT_STATUS:
				case PILOT_WIRE_FLAG:
				case WINDOW_DETECTION_FLAG:
				case PIR_STATUS_DETECTION:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case F_ON_OFF:
			switch(index)
			{
				case WINDOW_OPEN_DETECTION_STATUS:
				case PIR_STATUS_DETECTION:
				case REF_TEMP_STATUS:
				case COV_SENSOR:
				case CO_SENSOR:
				case CO2_SENSOR:
				case PARTICLES_1_SENSOR:
				case PARTICLES_25_SENSOR:
				case PARTICLES_10_SENSOR:
				case RAD_ACTIVITY_SENSOR:
				case SOUND_SENSOR:
				case HYGROMETRY_SENSOR:
				case AIR_MOVING_SENSOR:
				case PRESSURE_SENSOR:
				case DEROGATION_FLAG:
				case DEROGATION_STATUS:
				case SCHEDULED_ORDER_TYPE:
				case CLEAR_SCHEDULE:
				case HEATING_FLAG:
				case KEY_LOCK_STATUS:
				case REF_TEMP_FLAG:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_DAYS:
			switch(index)
			{
				case DAY_TIME_END:
				case DAY_TIME_START:
				case VLD_TIME_DAY_WEEK:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return SetValue(type, value);
	}

	rawValue = (uint32_t)value;
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D233xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	//Only channel in this profile is the Occupied channel, thats why we only check against NULL
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP:
			switch (index)
			{
				case EXT_TEMPERATURE:
				case INT_TEMPERATURE:
				case DEROGATION_TEMP_SETPOINT:
				case INT_TEMPERATURE_2:
					value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_TIME:
			switch (index)
			{
				case MINUTE_TIME_END:
				case HOUR_TIME_END:
				case MINUTE_TIME_START:
				case HOUR_TIME_START:
				case VLD_TIME_DAY:
				case VLD_TIME_MONTH:
				case VLD_TIME_YEAR:
				case VLD_TIME_MINUTE:
				case VLD_TIME_HOUR:

					value = (float)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_VALUE:
			switch (index)
			{
				case FIRMWARE_VERSION:
				case COV_SENSOR:
				case CO_SENSOR:
				case CO2_SENSOR:
				case SOUND_SENSOR:
				case RAD_ACTIVITY_SENSOR:
					value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_PARTICLES:
			switch (index)
			{
				case PARTICLES_1_SENSOR:
				case PARTICLES_25_SENSOR:
				case PARTICLES_10_SENSOR:
					value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return GetValue(type, value);
	}

	return EO_OK;
}

eoReturn eoEEP_D233xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP:
			switch (index)
			{
				case EXT_TEMPERATURE:
				case INT_TEMPERATURE:
				case DEROGATION_TEMP_SETPOINT:
				case INT_TEMPERATURE_2:
					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_TIME:
			switch (index)
			{
				case MINUTE_TIME_END:
				case HOUR_TIME_END:
				case MINUTE_TIME_START:
				case HOUR_TIME_START:
				case VLD_TIME_DAY:
				case VLD_TIME_MONTH:
				case VLD_TIME_YEAR:
				case VLD_TIME_MINUTE:
				case VLD_TIME_HOUR:
					rawValue = (uint32_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_VALUE:
			switch (index)
			{
				case FIRMWARE_VERSION:
				case COV_SENSOR:
				case CO_SENSOR:
				case CO2_SENSOR:
				case SOUND_SENSOR:
				case RAD_ACTIVITY_SENSOR:
					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_PARTICLES:
			switch (index)
			{
				case PARTICLES_1_SENSOR:
				case PARTICLES_25_SENSOR:
				case PARTICLES_10_SENSOR:
					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return SetValue(type, value);
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t) myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D233xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	uint8_t tmpCmd = cmd;
	if (cmd > 0x03)
		tmpCmd = cmd - 0x04;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD233xx[tmpCmd][tmpChannelCount].type == type && listD233xx[tmpCmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
