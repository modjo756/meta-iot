/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D201xx.h"

#include "eoChannelEnums.h"
#include <string.h>

const uint8_t numOfChan = 12;
const uint8_t numOfProfiles = 0x15;
const uint8_t numOfCommmands = 0x0E;

const EEP_ITEM listD201xx[numOfCommmands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:01
{
{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:02
{
{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current shut down
{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_OVER_CURRENT }, //Reset over shut down
{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 16, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_MEDIUM }, //Dimming timer medium
{ true, 20, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_SLOW }, //Dimming timer slow
{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, PWR_FAILURE }, //Power failure
{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
{ true, 28, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_FAST }, //Dimming timer fast
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, }, //Command ID
//COMMAND:03
{
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:04
{
{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, PWR_FAILURE }, //Power failure
{ true, 1, 1, 0, 1, 0, 1, F_POWERALARM, 0 }, //Power Failure detection
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current switch
{ true, 9, 2, 0, 3, 0, 3, E_ERROR_STATE, 0 }, //Error level
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0}, //I/O Channel
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:05
{
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 16, 4, 0, 4095, 0, 4095, S_POWER, POWER_W }, //Power value
{ true, 16, 4, 0, 4095, 0, 4095, S_POWER, POWER_KW }, //Power value
{ true, 16, 4, 0, 4095, 0, 4095, S_ENERGY, ENERGY_WS }, //Energy value
{ true, 16, 4, 0, 4095, 0, 4095, S_ENERGY, ENERGY_WH }, //Energy value
{ true, 16, 4, 0, 4095, 0, 4095, S_ENERGY, ENERGY_KWH }, //Energy value
{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:06
{
{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:07
{
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:08
{
{ true, 13, 3, 0, 5, 0, 5, E_CONTROLLER_MODE, 0 }, //Pilotwire mode
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:09
{
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:0A
{
{ true, 13, 3, 0, 5, 0, 5, E_CONTROLLER_MODE, 0 }, //Pilotwire mode
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:0B
{
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 16, 16, 0, 65535, 0, 6553.5, S_TIME, AUTO_OFF_TIMER }, //Auto Off timer
{ true, 32, 16, 0, 65535, 0, 6553.5, S_TIME, DELAY_OFF_TIMER }, //Auto Off timer
{ true, 48, 2, 0, 3, 0, 3, E_STATE, EXT_PUSH_BTN }, //External Push/Switch Button
{ true, 50, 1, 0, 1, 0, 1, F_ON_OFF, _2_STATE_SWITCH }, //2-state Switch
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:0C
{
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:0D
{
{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
{ true, 16, 16, 0, 65535, 0, 6553.5, S_TIME, AUTO_OFF_TIMER }, //Auto Off timer
{ true, 32, 16, 0, 65535, 0, 6553.5, S_TIME, DELAY_OFF_TIMER }, //Auto Off timer
{ true, 48, 2, 0, 3, 0, 3, E_STATE, EXT_PUSH_BTN }, //External Push/Switch Button
{ true, 50, 1, 0, 1, 0, 1, F_ON_OFF, _2_STATE_SWITCH }, //2-state Switch
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
};

const EEP_ITEM typeListD201xx [numOfProfiles][24] =
{
	//Type 0x00
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x01
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x02
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x03
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x04
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 16, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_MEDIUM }, //Dimming timer medium
		{ true, 20, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_SLOW }, //Dimming timer slow
		{ true, 28, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_FAST }, //Dimming timer fast
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current switch
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_OVER_CURRENT }, //Reset over shut down
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x05
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 16, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_MEDIUM }, //Dimming timer medium
		{ true, 20, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_SLOW }, //Dimming timer slow
		{ true, 28, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_FAST }, //Dimming timer fast
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current switch
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_OVER_CURRENT }, //Reset over shut down
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 9, 2, 0, 3, 0, 3, E_ERROR_STATE, 0 }, //Error level
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
	},
	//Type 0x06
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x07
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x08
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current switch
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_OVER_CURRENT }, //Reset over shut down
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 9, 2, 0, 3, 0, 3, E_ERROR_STATE, 0 }, //Error level
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x09
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 16, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_MEDIUM }, //Dimming timer medium
		{ true, 20, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_SLOW }, //Dimming timer slow
		{ true, 28, 4, 1, 15, 0.5, 7.5, S_TIME, DIMMING_FAST }, //Dimming timer fast
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current switch
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 9, 2, 0, 3, 0, 3, E_ERROR_STATE, 0  }, //Error level
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0A
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, PWR_FAILURE }, //Power failure
		{ true, 1, 1, 0, 1, 0, 1, F_POWERALARM, 0 }, //Power Failure detection
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0B
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0C
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, OVER_CURRENT_SHUT }, //Over current switch
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_OVER_CURRENT }, //Reset over shut down
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 9, 2, 0, 3, 0, 3, E_ERROR_STATE, 0  }, //Error level
		{ true, 13, 3, 0, 5, 0, 5, E_CONTROLLER_MODE, 0 }, //Pilotwire mode
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0D
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0E
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, PWR_FAILURE }, //Power failure
		{ true, 1, 1, 0, 1, 0, 1, F_POWERALARM, 0 }, //Power Failure detection
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0F
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, USER_INDICATION }, //User interface indication
		{ true, 32, 8, 1, 255, 10, 2550, S_TIME, MAX_SUB_TIME }, //Maximum time
		{ true, 40, 8, 1, 255, 1, 255, S_TIME, MIN_SUB_TIME }, //Minimum time
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 16, 16, 0, 65535, 0, 6553.5, S_TIME, AUTO_OFF_TIMER }, //Auto Off timer
		{ true, 32, 16, 0, 65535, 0, 6553.5, S_TIME, DELAY_OFF_TIMER }, //Auto Off timer
		{ true, 48, 2, 0, 3, 0, 3, E_STATE, EXT_PUSH_BTN }, //External Push/Switch Button
		{ true, 50, 1, 0, 1, 0, 1, F_ON_OFF, _2_STATE_SWITCH }, //2-state Switch
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x10
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, REPORT_MEASUREMENT }, //Report measurement
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, RESET_MEASUREMENT }, //Reset measurement
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, QUERY }, //Query
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_W }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_POWER, POWER_KW }, //Power value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WS }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_WH }, //Energy value
		{ true, 16, 32, 0, (uint32_t)4294967295u, 0, 4294967295.0F, S_ENERGY, ENERGY_KWH }, //Energy value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x11
	{
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x12
	{
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, PWR_FAILURE }, //Power failure
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, LOCAL_CONTROL }, //Local control
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, TAUGHT_IN_DEVICES }, //Taught-in devices
		{ true, 26, 2, 0, 2, 0, 2, E_STATE, DEFAULT_STATE }, //Default state
		{ true, 16, 16, 0, 65535, 0, 6553.5, S_TIME, AUTO_OFF_TIMER }, //Auto Off timer
		{ true, 32, 16, 0, 65535, 0, 6553.5, S_TIME, DELAY_OFF_TIMER }, //Auto Off timer
		{ true, 48, 2, 0, 3, 0, 3, E_STATE, EXT_PUSH_BTN }, //External Push/Switch Button
		{ true, 50, 1, 0, 1, 0, 1, F_ON_OFF, _2_STATE_SWITCH }, //2-state Switch
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x13
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x14
	{
		{ true, 8, 3, 0, 7, 0, 7, E_DIM_VALUE, 0 }, //Dim value
		{ true, 11, 5, 0, 31, 0, 31, E_IO_CHANNEL, 0 }, //I/O Channel
		{ true, 17, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Output value
		{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
};

eoEEP_D201xx::eoEEP_D201xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x01;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D201xx::~eoEEP_D201xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_D201xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 1 || m.GetDataLength() > 7)
		return NOT_SUPPORTED;

	if(SetCommand(m.data[0] & 0x0F)!=EO_OK)
		return NOT_SUPPORTED;

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D201xx::SetType(uint8_t type)
{
	this->type = type;
	if (type > numOfProfiles)
		return NOT_SUPPORTED;

	SetLength (type);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D201xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommmands||cmd==0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	msg.Clear();
	SetRawValue(msg, rawValue, 4, 4);
	const uint8_t dataLength [] = {0, 3, 4, 2, 3, 6, 2, 6, 2, 1, 2, 7, 2, 7};
	msg.SetDataLength(dataLength[cmd],true);
	if(cmd==this->cmd )
		return EO_OK;

	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD201xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD201xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD201xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD201xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD201xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if ( cmd == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	// Set the proper message length depending on the command type
	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D201xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_DIM_VALUE:
		case E_ERROR_STATE:
		case E_UNITS:
		case E_IO_CHANNEL:
		case F_POWERALARM:
		case E_CONTROLLER_MODE:
		case E_STATE:
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D201xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}
	if (this->cmd == 0 || this->cmd > 0x0A)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE;

	switch (type)
	{
		case E_UNITS:
		case E_DIM_VALUE:
			if (value < 0x05)
				rawValue = value;
			else
				return NOT_SUPPORTED;
			break;

		case E_ERROR_STATE:
			if (value < 0x03)
				rawValue = value;
			else
				return NOT_SUPPORTED;
			break;

		case E_IO_CHANNEL:
		case F_POWERALARM:
		case E_CONTROLLER_MODE:
		case E_STATE:
			rawValue = value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D201xx::GetValue(CHANNEL_TYPE type, float &value)
{
	//SetCommand(msg.data[0] & 0x0F);
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
			value = (float)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D201xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd == 0 || this->cmd > 0x0A)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
			rawValue = (uint32_t)value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D201xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;
		case E_STATE:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D201xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd == 0 || this->cmd > 0x0A)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;
		case E_STATE:
			rawValue = (uint32_t)value;
			break;
		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D201xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	//Only channel in this profile is the Occupied channel, thats why we only check against NULL
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TIME:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_ENERGY:
			if (this->cmd == 0x07)
			{
				switch (index)
				{
					case ENERGY_WS:
						if (((msg.data[1] >> 5) & 0x07) != 0x00)
							return NOT_SUPPORTED;
						break;
					case ENERGY_WH:
						if (((msg.data[1] >> 5) & 0x07) != 0x01)
							return NOT_SUPPORTED;
						break;
					case ENERGY_KWH:
						if (((msg.data[1] >> 5) & 0x07) != 0x02)
							return NOT_SUPPORTED;
						break;
					default:
						return NOT_SUPPORTED;
						break;
				}

				if (GetRawValue(msg, rawValue,myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
					return NOT_SUPPORTED;
			}

			else
			{
				if (((msg.data[1] >> 0x05) & 0x01) != 0x00)
					return NOT_SUPPORTED;
				switch (index)
				{
					case ENERGY_WS:
						if ((msg.data[2] & 0x07) != 0x00)
							return NOT_SUPPORTED;
						break;
					case ENERGY_WH:
						if ((msg.data[2] & 0x07) != 0x01)
							return NOT_SUPPORTED;
						break;
					case ENERGY_KWH:
						if ((msg.data[2] & 0x07) != 0x02)
							return NOT_SUPPORTED;
						break;
					default:
						return NOT_SUPPORTED;
				}

				if (GetRawValue(msg, tmpRawValue, 24, 8) != EO_OK)
					return NOT_SUPPORTED;
				rawValue = tmpRawValue << 4;
				if (GetRawValue(msg, tmpRawValue, 16, 4) != EO_OK)
					return NOT_SUPPORTED;
				rawValue |= tmpRawValue;
			}

			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_POWER:
			if (this->cmd == 0x07)
			{
				switch (index)
				{
					case POWER_W:
						if (((msg.data[1] >> 5) & 0x07) != 0x03)
							return NOT_SUPPORTED;
						break;
					case POWER_KW:
						if (((msg.data[1] >> 5) & 0x07) != 0x04)
							return NOT_SUPPORTED;
						break;
					default:
						return NOT_SUPPORTED;
						break;
				}

				if (GetRawValue(msg, rawValue,myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
					return NOT_SUPPORTED;
			}

			else
			{
				if (((msg.data[1] >> 0x05) & 0x01) != 0x01)
					return NOT_SUPPORTED;
				switch (index)
				{
					case POWER_W:
						if ((msg.data[2] & 0x07) != 0x03)
							return NOT_SUPPORTED;
						break;
					case POWER_KW:
						if ((msg.data[2] & 0x07) != 0x04)
							return NOT_SUPPORTED;
						break;
					default:
						return NOT_SUPPORTED;
				}

				if (GetRawValue(msg, tmpRawValue, 24, 8) != EO_OK)
					return NOT_SUPPORTED;
				rawValue = tmpRawValue << 4;
				if (GetRawValue(msg, tmpRawValue, 16, 4) != EO_OK)
					return NOT_SUPPORTED;
				rawValue |= tmpRawValue;
			}

			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			//return GetValue(type, value);
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D201xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd == 0 || this->cmd > 0x0A)
		return NOT_SUPPORTED;

	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TIME:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
			break;

		case S_ENERGY:
			switch (index)
			{
				case ENERGY_WS:
				case ENERGY_WH:
				case ENERGY_KWH:
					if (this->cmd == 0x07)
					{
						rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
						SetRawValue(msg, rawValue, 16, 32);

						msg.data[1] &= 0x01;
						msg.data[1] |= index << 5;
					}
					else
					{
						rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
						tmpRawValue = rawValue >> 4;
						SetRawValue(msg, tmpRawValue, 24, 8);
						tmpRawValue = rawValue & 0x0F;
						SetRawValue(msg, tmpRawValue, 16, 4);
						msg.data[2] |= index;
					}
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;

		case S_POWER:
			switch (index)
			{
				case POWER_W:
				case POWER_KW:
					if (this->cmd == 0x07)
					{
						rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
						SetRawValue(msg, rawValue, 16, 32);

						msg.data[1] &= 0x01;
						msg.data[1] |= index << 5;
					}
					else
					{
						rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
						tmpRawValue = rawValue >> 4;
						SetRawValue(msg, tmpRawValue, 24, 8);
						tmpRawValue = rawValue & 0x0F;
						SetRawValue(msg, tmpRawValue, 16, 4);
						msg.data[1] |= 0x20;
						msg.data[2] |= index;
					}
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D201xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD201xx[this->cmd][tmpChannelCount].type == type && listD201xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D201xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD201xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD201xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD201xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD201xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD201xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
