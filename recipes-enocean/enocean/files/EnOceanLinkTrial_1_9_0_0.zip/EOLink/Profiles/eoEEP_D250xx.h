/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D250_H__INCLUDED_)
#define eoEEP_D250_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D201xx
 * \brief The class to handle EEP D201 profiles
 * \details Allows the user to handle EEP D201 profiles, the following profiles are available:
 * 		- D2-50-00
 * 		- D2-50-01
 * 		- D2-50-10
 * 		- D2-50-11\n
 *
 * 	NOTE: set command before using the profile.
 *
 * The following channels are available in Ventilation Remote Transmission Request:
 * | Channel Index | Channel Type | Type | Note |
 * |:-------------:|:------------:|:----:|:----:|
 * | 0             | ::E_CONTROLLER_MODE	|::D250_REQUESTED_MSG_TYPE | ::REQUESTED_MSG_TYPE |
 *
 * The following channels are available in Ventilation Control:
 * | Channel Index | Channel Type | Type | Note |
 * |:-------------:|:------------:|:----:|:----:|
 * | 0             | ::E_CONTROLLER_MODE	|::D250_REQUESTED_MSG_TYPE | ::REQUESTED_MSG_TYPE |
 * | 1             | ::E_CONTROLLER_MODE	|::D250_OP_MODE | ::OP_MODE |
 * | 2             | ::E_CONTROLLER_MODE	|::D250_AIRFLAP_BYPASS | ::HEAT_EXCHANGE_CTRL |
 * | 3             | ::F_ON_OFF				| uint8_t | ::TIMER_OP_CTRL |
 * | 4             | ::S_PERCENTAGE			| float | ::CO2_TRHESHOLD |
 * | 5             | ::S_RELHUM				| float |  |
 * | 6             | ::S_PERCENTAGE			| float | ::AIR_QUALITY_TRHESHOLD |
 * | 7             | ::S_TEMP				| float | ::ROOM_TEMP |
 *
 * The following channels are available in Ventilation Basic Status:
 * | Channel Index | Channel Type | Type | Note |
 * |:-------------:|:------------:|:----:|:----:|
 * | 0             | ::E_CONTROLLER_MODE	|::D250_OP_MODE | ::OP_MODE_CTRL |
 * | 1             | ::F_ON_OFF				| uint8_t | ::SAFTEY_MODE |
 * | 2             | ::F_ON_OFF				| uint8_t | ::HEAT_EXCHANGE_CTRL |
 * | 3             | ::F_ON_OFF				| uint8_t | ::SUPPLY_AIR_POS |
 * | 4             | ::F_ON_OFF				| uint8_t | ::EXHAUST_AIR_POS |
 * | 5             | ::F_ON_OFF				| uint8_t | ::DEFROST_MODE |
 * | 6             | ::F_ON_OFF				| uint8_t | ::COOLING_PROTECTION |
 * | 7             | ::F_ON_OFF				| uint8_t | ::OUTDOOR_HEATER_STATUS |
 * | 8             | ::F_ON_OFF				| uint8_t | ::SUPPLY_HEATER_STATUS |
 * | 9             | ::F_ON_OFF				| uint8_t | ::DRAIN_HEATER_STATUS |
 * | 10            | ::F_ON_OFF				| uint8_t | ::TIMER_OP_CTRL_STATUS |
 * | 11            | ::F_ON_OFF				| uint8_t | ::FILTER_MAINTENANCE |
 * | 12            | ::F_ON_OFF				| uint8_t | ::WEEKLY_PROGRAM |
 * | 13            | ::F_ON_OFF				| uint8_t | ::ROOM_TEMP_CTRL |
 * | 14            | ::S_PERCENTAGE			| float | ::AIR_QUALITY_1 |
 * | 15            | ::F_ON_OFF				| uint8_t | ::MASTER_SLAVE_CONFIG |
 * | 16            | ::S_PERCENTAGE			| float | ::AIR_QUALITY_2 |
 * | 17            | ::S_TEMP				| float | ::OUTDOOR_TEMP |
 * | 18            | ::S_TEMP				| float | ::SUPPLY_TEMP |
 * | 19            | ::S_TEMP				| float | ::INDOOR_TEMP |
 * | 20            | ::S_TEMP				| float | ::EXHAUST_TEMP |
 * | 21            | ::S_VOLFLOW			| float | ::SUPPLY_FAN_RATE |
 * | 22            | ::S_VOLFLOW			| float | ::EXHAUST_FAN_RATE |
 * | 23            | ::S_ROTATION_PER_MIN	| float | ::SUPPLY_FAN_SPEED |
 * | 24            | ::S_ROTATION_PER_MIN	| float | ::EXHAUST_FAN_SPEED |
 *
 * The following channels are available in Ventilation Extended Status:
 * | Channel Index | Channel Type | Type | Note |
 * |:-------------:|:------------:|:----:|:----:|
 * | 0             | ::S_VALUE	| float | ::SW_VERSION |
 * | 1             | ::S_TIME	| float |  |
 * | 2             | ::S_VALUE	| float | ::DIGITAL_INPUT_STATUS |
 * | 3             | ::S_VALUE	| float | ::DIGITAL_OUTPUT_STATUS |
 * | 4             | ::S_VALUE	| float | ::INFO_MSG_STATUS |
 * | 5             | ::S_VALUE	| float | ::FAULT_STATUS |
 */

/**
 * \file eoEEP_D250xx.h
 */
//! Command enums for D2-50-xx profiles
typedef enum
{
	//! <b>Ventilation Remote Transmission Request</b> 0
	VENTILATION_REQUEST = 0x00,
	//! <b>Ventilation Control</b> 1
	VENTILATION_CONTROL = 0x01,
	//! <b>Ventilation Basic Status</b> 2
	VENTILATION_BASIC_STATUS = 0x02,
	//! <b>Ventilation Extended Status</b> 3
	VENTILATION_EXTENDED_STATUS = 0x03
} D250xx_COMMANDS;

//! Index enums for D2-50-xx profiles
typedef enum
{
	//! <b>Requested Message Type</b> 0
	REQUESTED_MSG_TYPE = 0x00,
	//! <b>Direct Operation Mode Control</b> 1
	DIRECT_OP_MODE = 0x01,
	//! <b>Operation Mode Control</b> 2
	OP_MODE_CTRL = 0x02,
	//! <b>Heat Exchanger Bypass Control</b> 3
	HEAT_EXCHANGE_CTRL = 0x03,
	//! <b>Timer Operation Mode Control</b> 4
	TIMER_OP_CTRL = 0x04,
	//! <b>Safety Mode Status</b> 5
	SAFTEY_MODE = 0x05,
	//! <b>Supply Air Flap Position</b> 6
	SUPPLY_AIR_POS = 0x06,
	//! <b>Exhaust Air Flap Position</b> 7
	EXHAUST_AIR_POS = 0x07,
	//! <b>Defrost Mode Status</b> 8
	DEFROST_MODE = 0x08,
	//! <b>Cooling Protection Status</b> 9
	COOLING_PROTECTION = 0x09,
	//! <b>Outdoor Air Heater Status</b> 10
	OUTDOOR_HEATER_STATUS = 0x0A,
	//! <b>Supply Air Heater Status</b> 11
	SUPPLY_HEATER_STATUS = 0x0B,
	//! <b>Drain Heater Status</b> 12
	DRAIN_HEATER_STATUS = 0x0C,
	//! <b>Timer Operation Mode Control Status</b> 13
	TIMER_OP_CTRL_STATUS = 0x0D,
	//! <b>Filter Maintenance Status</b> 14
	FILTER_MAINTENANCE = 0x0E,
	//! <b>Weekly Timer Program Status</b> 15
	WEEKLY_PROGRAM = 0x0F,
	//! <b>Room Temperature Control Status</b> 16
	ROOM_TEMP_CTRL = 0x10,
	//! <b>Air Quality Sensor 1</b> 17
	AIR_QUALITY_1 = 0x11,
	//! <b>Air Quality Sensor 2</b> 18
	AIR_QUALITY_2 = 0x12,
	//! <b>Master/Slave Configuration Status</b> 19
	MASTER_SLAVE_CONFIG = 0x13,
	//! <b>Outdoor Air Temperature</b> 20
	OUTDOOR_TEMP = 0x14,
	//! <b>Supply Air Temperature</b> 21
	SUPPLY_TEMP = 0x15,
	//! <b>Indoor Air Temperature</b> 22
	INDOOR_TEMP = 0x16,
	//! <b>Exhaust Air Temperature</b> 23
	EXHAUST_TEMP = 0x17,
	//! <b>Supply Air Fan Air Flow Rate</b> 24
	SUPPLY_FAN_RATE = 0x18,
	//! <b>Exhaust Air Fan Air Flow Rate</b> 25
	EXHAUST_FAN_RATE = 0x19,
	//! <b>Supply Fan Speed</b> 26
	SUPPLY_FAN_SPEED = 0x20,
	//! <b>Exhaust Fan Speed</b> 27
	EXHAUST_FAN_SPEED = 0x21,
	//! <b>Software Version Info</b> 28
	SW_VERSION = 0x22,
	//! <b>Digital Input Status</b> 29
	DIGITAL_INPUT_STATUS = 0x23,
	//! <b>Digital Output Status</b> 30
	DIGITAL_OUTPUT_STATUS = 0x24,
	//! <b>Info Message Status</b> 31
	INFO_MSG_STATUS = 0x25,
	//! <b>Fault Status</b> 32
	FAULT_STATUS = 0x26,
	//! <b>CO2 Threshold</b> 33
	CO2_TRHESHOLD = 0x27,
	//! <b>Air Quality Threshold</b> 34
	AIR_QUALITY_TRHESHOLD = 0x28,
	//! <b>Room Temperature</b> 35
	ROOM_TEMP = 0x29
} D250xx_INDEX;

//! Requested message enums for D2-50-xx profiles
typedef enum
{
	//! <b>Ventilation Basic Status</b> 0
	VENTILATION_BASIC = 0x00,
	//! <b>Ventilation Extended Status</b> 1
	VENTILATION_EXTENDED = 0x01
} D250_REQUESTED_MSG_TYPE;

//! Direct operation mode enums for D2-50-xx profiles
typedef enum
{
	//! <b>Off</b> 0
	DIRECT_MODE_OFF = 0x00,
	//! <b>Level 1</b> 1
	DIRECT_MODE_LEVEL_1 = 0x01,
	//! <b>Level 2</b>2
	DIRECT_MODE_LEVEL_2 = 0x02,
	//! <b>Level 3</b> 3
	DIRECT_MODE_LEVEL_3 = 0x03,
	//! <b>Level 4</b> 4
	DIRECT_MODE_LEVEL_4 = 0x04,
	//! <b>Automatic</b> 11
	DIRECT_MODE_AUTO = 0x0B,
	//! <b>Automatic on Demand</b> 12
	DIRECT_MODE_AUTO_OD = 0x0C,
	//! <b>Supply Air Only</b> 13
	DIRECT_MODE_SUPPLY_ONLY = 0x0D,
	//! <b>Exhaust Air Only</b> 14
	DIRECT_MODE_SEXHAUST_ONLY = 0x0E,
	//! <b>No Action/ Keep Current Mode</b> 15
	DIRECT_MODE_NO_ACTION = 0x0F
} D250_DIRECT_OP_MODE;

//! Operation mode enums for D2-50-xx profiles
typedef enum
{
	//! <b>No Action</b> 0
	OP_NO_ACTION = 0x00,
	//! <b>Select Next Operation Mode (edge-trigger)</b> 1
	OP_NEXT = 0x01,
	//! <b>Select Previous Operation Mode (edge-trigger)</b> 2
	OP_PREVIOUS = 0x02
} D250_OP_MODE;

//! Air flap and bypass enums for D2-50-xx profiles
typedef enum
{
	//! <b>Air flap and bypass close</b> 0
	AIRFLAP_BYPASS_CLOSE = 0x00,
	//! <b>Air flap and bypass open</b> 1
	AIRFLAP_BYPASS_OPEN = 0x01
} D250_AIRFLAP_BYPASS;

class eoEEP_D250xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D250xx(uint16_t size = 10);
	virtual ~eoEEP_D250xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
