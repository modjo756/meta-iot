/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoApiDef.h"
#include "eoProfileFactory.h"
#include "eoGenericProfile.h"
#include "eoEEP_D203xx.h"
#include "eoEEP_F601xx.h"
#include "eoEEP_F602xx.h"
#include "eoEEP_F603xx.h"
#include "eoEEP_F604xx.h"
#include "eoEEP_F605xx.h"
#include "eoEEP_F610xx.h"
#include "eoEEP_D500xx.h"
#include "eoEEP_A502xx.h"
#include "eoEEP_A504xx.h"
#include "eoEEP_A505xx.h"
#include "eoEEP_A506xx.h"
#include "eoEEP_A507xx.h"
#include "eoEEP_A508xx.h"
#include "eoEEP_A509xx.h"
#include "eoEEP_A510xx.h"
#include "eoEEP_A511xx.h"
#include "eoEEP_A512xx.h"
#include "eoEEP_A513xx.h"
#include "eoEEP_A514xx.h"
#include "eoEEP_A520xx.h"
#include "eoEEP_A530xx.h"
#include "eoEEP_A537xx.h"
#include "eoEEP_A538xx.h"
#include "eoEEP_D200xx.h"
#include "eoEEP_D201xx.h"
#include "eoEEP_D202xx.h"
#include "eoEEP_D203xx.h"
#include "eoEEP_D204xx.h"
#include "eoEEP_D205xx.h"
#include "eoEEP_D206xx.h"
#include "eoEEP_D210xx.h"
#include "eoEEP_D211xx.h"
#include "eoEEP_D220xx.h"
#include "eoEEP_D230xx.h"
#include "eoEEP_D231xx.h"
#include "eoEEP_D232xx.h"
#include "eoEEP_D233xx.h"
#include "eoEEP_D240xx.h"
#include "eoEEP_D250xx.h"
#include "eoEEP_D2A0xx.h"
#include "eoEEP_D2B0xx.h"

eoProfile* eoProfileFactory::CreateProfile(const eoMessage &msg)
{
	switch (msg.RORG)
	{
		case RORG_4BS:
			if ((msg.data[3] & 0x88) == 0x80) // Is Learn telegram?
			{
				uint8_t rorg = RORG_4BS;
				uint8_t func = msg.data[0] >> 2;
				uint8_t type = ((msg.data[0] & 3) << 5) | (msg.data[1] >> 3);

				eoProfile *profile = eoProfileFactory::CreateProfile(rorg, func, type);
				if (profile != NULL)
					profile->manufacturer = (msg.data[1] & 7) << 8 | msg.data[2];

				return profile;
			}
			break;

		case RORG_VLD:
		{
			uint8_t rorg = RORG_VLD;
			uint8_t func = msg.data[0] >> 2;
			uint8_t type = ((msg.data[0] & 3) << 5) | (msg.data[1] >> 3);

			eoProfile *profile = eoProfileFactory::CreateProfile(rorg, func, type);
			if (profile != NULL)
				profile->manufacturer = (msg.data[1] & 7) << 8 | msg.data[2];

			return profile;
		}
			break;
			//for gp via message only TeachIN telegram is allowed
		case GP_TI:
			eoGenericProfile* gp = new eoGenericProfile();
			gp->AllowTeachIN();
			if (gp->Parse(msg) == EO_OK)
				return gp;
			else
				delete gp;
			break;
	}

	return NULL;
}

eoProfile* eoProfileFactory::CreateProfile(const uint8_t rorg, const uint8_t func, const uint8_t type)
{
	eoProfile *eep = NULL;
#ifndef TPLINK
	switch (rorg)
	{
		case RORG_RPS:
			switch (func)
			{
				case 0x01:
					eep = new eoEEP_F601xx();
					break;
				case 0x02:
					eep = new eoEEP_F602xx();
					break;
#ifndef DEMO
				case 0x03:
					eep = new eoEEP_F603xx();
					break;
				case 0x04:
					eep = new eoEEP_F604xx();
					break;
				case 0x05:
					eep = new eoEEP_F605xx();
					break;
				case 0x10:
					eep = new eoEEP_F610xx();
					break;
#endif
				default:
					break;
			}
			break;
		case RORG_4BS:
			switch (func)
			{
				case 0x02:
					eep = new eoEEP_A502xx();
					break;
#ifndef DEMO
				case 0x04:
					eep = new eoEEP_A504xx();
					break;
				case 0x05:
					eep = new eoEEP_A505xx();
					break;
				case 0x06:
					eep = new eoEEP_A506xx();
					break;
				case 0x07:
					eep = new eoEEP_A507xx();
					break;
				case 0x08:
					eep = new eoEEP_A508xx();
					break;
				case 0x09:
					eep = new eoEEP_A509xx();
					break;
				case 0x10:
					eep = new eoEEP_A510xx();
					break;
				case 0x11:
					eep = new eoEEP_A511xx();
					break;
				case 0x12:
					eep = new eoEEP_A512xx();
					break;
				case 0x13:
					eep = new eoEEP_A513xx();
					break;
				case 0x14:
					eep = new eoEEP_A514xx();
					break;
				case 0x20:
					eep = new eoEEP_A520xx();
					break;
				case 0x30:
					eep = new eoEEP_A530xx();
					break;
				case 0x37:
					eep = new eoEEP_A537xx();
					break;
				case 0x38:
					eep = new eoEEP_A538xx();
					break;
#endif
				default:
					break;
			}

			break;
		case RORG_1BS:
			switch (func)
			{
				case 0x00:
					eep = new eoEEP_D500xx();
					break;
			}
			break;
		case RORG_VLD:
			switch (func)
			{
				case 0x00:
					eep = new eoEEP_D200xx();
					break;
				case 0x01:
					eep = new eoEEP_D201xx();
					break;
				case 0x02:
					eep = new eoEEP_D202xx();
					break;
				case 0x03:
					eep = new eoEEP_D203xx();
					break;
				case 0x04:
					eep = new eoEEP_D204xx();
					break;
				case 0x05:
					eep = new eoEEP_D205xx();
					break;
				case 0x06:
					eep = new eoEEP_D206xx();
					break;
				case 0x10:
					eep = new eoEEP_D210xx();
					break;
				case 0x11:
					eep = new eoEEP_D211xx();
					break;
				case 0x20:
					eep = new eoEEP_D220xx();
					break;
				case 0x30:
					eep = new eoEEP_D230xx();
					break;
				case 0x31:
					eep = new eoEEP_D231xx();
					break;
				case 0x32:
					eep = new eoEEP_D232xx();
					break;
				case 0x33:
					eep = new eoEEP_D233xx();
					break;
				case 0x40:
					eep = new eoEEP_D240xx();
					break;
				case 0x50:
					eep = new eoEEP_D250xx();
					break;
				case 0xA0:
					eep = new eoEEP_D2A0xx();
					break;
				case 0xB0:
					eep = new eoEEP_D2B0xx();
					break;
			}
			break;

		case GP_TI:
		case GP_TR:
		case GP_CD:
		case GP_SD:
			eep = new eoGenericProfile();
			break;
		default:
			break;

	}
#endif
	//Not supported types will deleted
	if (eep != NULL && eep->SetType(type) != EO_OK)
	{
		delete eep;
		eep = NULL;
	}

	return eep;
}
