/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D210xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 22;
const uint8_t numOfProfiles = 0x03;
const uint8_t numOfCommands = 0x05;

const EEP_ITEM listD210xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//General message
{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 10, 3, 0, 4, 0, 4, E_STATE, INFO_REQUEST_CLASS }, //Information request classifier
		{ true, 13, 2, 0, 2, 0, 2, E_STATE, FEEDBACK_CLASS }, //Feedback classifier
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, GENERAL_MSG_TYPE }, //General message type
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Data message
{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 8, 8, 0, 255, 0, 100, S_RELHUM, 0 }, //Humidity
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, RELHUM_VALIDITY }, //Humidity validity flag
		{ true, 17, 7, 0, 100, 0, 100, S_VALUE, 0 }, //Fan speed control
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, FANSPEED_VALIDITY }, //Fan speed validity flag
		{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, FANSPEED_MODE }, //Fan speed mode
		{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_2 }, //Custom warning 2
		{ true, 28, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_1 }, //Custom warning 1
		{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, MOLD_WARNING }, //Mold warning
		{ true, 30, 2, 0, 2, 0, 2, E_STATE, WINDOW_OPEN_DETECTION }, //Window open detection
		{ true, 33, 2, 0, 3, 0, 3, E_STATE, BATTERY_STATUS }, //Battery status
		{ true, 35, 1, 0, 1, 0, 1, F_ON_OFF, SOLAR_POWERED_STATUS }, //Solar-powered status
		{ true, 36, 2, 0, 3, 0, 3, E_STATE, PIR_STATUS }, //PIR status
		{ true, 38, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //PIR status
		{ true, 40, 2, 0, 3, 0, 3, E_STATE, COOLING_STATUS }, //Cooling operation status
		{ true, 42, 2, 0, 3, 0, 3, E_STATE, HEATING_STATUS }, //Heating operation status
		{ true, 44, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Room control mode
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_VALIDITY }, //Temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_VALIDITY }, //Temperature validity flag
		{ true, 48, 8, 0, 255, 0, 40, S_TEMP_ABS, RECENT_TEMP_SETPOINT }, //Recent temperature set point
		{ true, 56, 8, 0, 255, 0, 40, S_TEMP, 0 } //Room temperature
},
//Configuration message
{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, PIR_LOCK }, //PIR status lock
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_LOCK }, //Temperature scale lock
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_LOCK }, //Display content lock
		{ true, 11, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_LOCK }, //Date / time lock
		{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_LOCK }, //Time program lock
		{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, OCCUPANCY_LOCK }, //Occupancy button lock
		{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_LOCK }, //Temperature set point lock
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, FAN_SPEED_LOCK }, //Fan speed lock
		{ true, 16, 6, 0, 63, 0, 63, S_TIME, RADIO_COM_INTERVAL }, //Radio communication interval
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, KEY_LOCK }, //Key lock
		{ true, 24, 3, 0, 7, 0, 7, E_STATE, DISPLAY_CONTENT }, //Display content
		{ true, 27, 2, 0, 3, 0, 3, E_STATE, TEMP_SCALE }, //Temperature scale
		{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGHT_SAVE }, //Daylight saving time flag
		{ true, 30, 2, 0, 3, 0, 3, E_STATE, TIME_NOTATION }, //Time notation
		{ true, 32, 5, 1, 31, 1, 31, S_TIME, TIME_CURRENT_DAY }, //Day
		{ true, 37, 4, 1, 12, 1, 12, S_TIME, TIME_CURRENT_MONTH }, //Month
		{ true, 41, 7, 0, 127, 2000, 2127, S_TIME, TIME_CURRENT_YEAR }, //Year
		{ true, 48, 6, 0, 59, 0, 59, S_TIME, TIME_CURRENT_MINUTE }, //Minute
		{ true, 56, 5, 0, 23, 0, 23, S_TIME, TIME_CURRENT_HOUR }, //Hour
		{ true, 63, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_UPDATE_FLAG } //Day / time update flag
},
//Room control setup message
{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 8, 8, 0, 255, 0, 40, S_TEMP_ABS, BUILDING_PROTECT_TEMP_SETPOINT }, //Building protection temperature set point
		{ true, 16, 8, 0, 255, 0, 40, S_TEMP_ABS, PRECOMFORT_TEMP_SETPOINT }, //Pre-comfort temperature set point
		{ true, 24, 8, 0, 255, 0, 40, S_TEMP_ABS, ECONOMY_TEMP_SETPOINT }, //Economy temperature set point
		{ true, 32, 8, 0, 255, 0, 40, S_TEMP_ABS, COMFORT_TEMP_SETPOINT }, //Comfort temperature set point
		{ true, 44, 1, 0, 1, 0, 1, F_ON_OFF, BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY }, //Building protection temperature set point validity flag
		{ true, 45, 1, 0, 1, 0, 1, F_ON_OFF, PRECOMFORT_TEMP_SETPOINT_VALIDITY }, //Pre-comfort  temperature set point validity flag
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY }, //Economy temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, COMFORT_TEMP_SETPOINT_VALIDITY }, //Comfort temperature set point validity flag
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Time program setup message
{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 10, 6, 0, 59, 0, 59, S_TIME, END_TIME_MINUTE }, //End Minute
		{ true, 19, 5, 0, 23, 0, 23, S_TIME, END_TIME_HOUR }, //End Hour
		{ true, 26, 6, 0, 59, 0, 59, S_TIME, START_TIME_MINUTE }, //Start Minute
		{ true, 35, 5, 0, 23, 0, 23, S_TIME, START_TIME_HOUR }, //Start Hour
		{ true, 40, 4, 0, 15, 0, 15, E_DAYS, 0 }, //Period
		{ true, 44, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Room control mode
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_DELETION }, //Time program deletion
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
}
};

const EEP_ITEM typeListD210xx [numOfProfiles][59] =
{
	//Type 0x00
	{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 10, 3, 0, 4, 0, 4, E_STATE, INFO_REQUEST_CLASS }, //Information request classifier
		{ true, 13, 2, 0, 2, 0, 2, E_STATE, FEEDBACK_CLASS }, //Feedback classifier
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, GENERAL_MSG_TYPE }, //General message type
		{ true, 8, 8, 0, 255, 0, 100, S_RELHUM, 0 }, //Humidity
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, RELHUM_VALIDITY }, //Humidity validity flag
		{ true, 17, 7, 0, 100, 0, 100, S_VALUE, 0 }, //Fan speed control
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, FANSPEED_VALIDITY }, //Fan speed validity flag
		{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, FANSPEED_MODE }, //Fan speed mode
		{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_1 }, //Custom warning 1
		{ true, 28, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_2 }, //Custom warning 2
		{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, MOLD_WARNING }, //Mold warning
		{ true, 30, 2, 0, 2, 0, 2, E_STATE, WINDOW_OPEN_DETECTION }, //Window open detection
		{ true, 33, 2, 0, 3, 0, 3, E_STATE, BATTERY_STATUS }, //Battery status
		{ true, 35, 1, 0, 1, 0, 1, F_ON_OFF, SOLAR_POWERED_STATUS }, //Solar-powered status
		{ true, 36, 2, 0, 3, 0, 3, E_STATE, PIR_STATUS }, //PIR status
		{ true, 38, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy button
		{ true, 40, 2, 0, 3, 0, 3, E_STATE, COOLING_STATUS }, //Cooling operation status
		{ true, 42, 2, 0, 3, 0, 3, E_STATE, HEATING_STATUS }, //Heating operation status
		{ true, 44, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Room control mode
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_VALIDITY }, //Temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_VALIDITY }, //Temperature validity flag
		{ true, 48, 8, 0, 255, 0, 40, S_TEMP_ABS, RECENT_TEMP_SETPOINT }, //Recent temperature set point
		{ true, 56, 8, 0, 255, 0, 40, S_TEMP, 0 }, //Room temperature
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, PIR_LOCK }, //PIR status lock
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_LOCK }, //Temperature scale lock
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_LOCK }, //Display content lock
		{ true, 11, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_LOCK }, //Date / time lock
		{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_LOCK }, //Time program lock
		{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, OCCUPANCY_LOCK }, //Occupancy button lock
		{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_LOCK }, //Temperature set point lock
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, FAN_SPEED_LOCK }, //Fan speed lock
		{ true, 16, 6, 0, 63, 0, 63, S_TIME, RADIO_COM_INTERVAL }, //Radio communication interval
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, KEY_LOCK }, //Key lock
		{ true, 24, 3, 0, 7, 0, 7, E_STATE, DISPLAY_CONTENT }, //Display content
		{ true, 27, 2, 0, 3, 0, 3, E_STATE, TEMP_SCALE }, //Temperature scale
		{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGHT_SAVE }, //Daylight saving time flag
		{ true, 30, 2, 0, 3, 0, 3, E_STATE, TIME_NOTATION }, //Time notation
		{ true, 32, 5, 1, 31, 1, 31, S_TIME, TIME_CURRENT_DAY }, //Day
		{ true, 37, 4, 1, 12, 1, 12, S_TIME, TIME_CURRENT_MONTH }, //Month
		{ true, 41, 7, 0, 127, 2000, 2127, S_TIME, TIME_CURRENT_YEAR }, //Year
		{ true, 48, 6, 0, 59, 0, 59, S_TIME, TIME_CURRENT_MINUTE }, //Minute
		{ true, 56, 5, 0, 23, 0, 23, S_TIME, TIME_CURRENT_HOUR }, //Hour
		{ true, 63, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_UPDATE_FLAG }, //Day / time update flag
		{ true, 8, 8, 0, 255, 0, 40, S_TEMP_ABS, BUILDING_PROTECT_TEMP_SETPOINT }, //Building protection temperature set point
		{ true, 16, 8, 0, 255, 0, 40, S_TEMP_ABS, PRECOMFORT_TEMP_SETPOINT }, //Pre-comfort temperature set point
		{ true, 24, 8, 0, 255, 0, 40, S_TEMP_ABS, ECONOMY_TEMP_SETPOINT }, //Economy temperature set point
		{ true, 32, 8, 0, 255, 0, 40, S_TEMP_ABS, COMFORT_TEMP_SETPOINT }, //Comfort temperature set point
		{ true, 44, 1, 0, 1, 0, 1, F_ON_OFF, BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY }, //Building protection temperature set point validity flag
		{ true, 45, 1, 0, 1, 0, 1, F_ON_OFF, PRECOMFORT_TEMP_SETPOINT_VALIDITY }, //Pre-comfrt temperature set point validity flag
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY }, //Economy temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, COMFORT_TEMP_SETPOINT_VALIDITY }, //Comfort temperature set point validity flag
		{ true, 10, 6, 0, 59, 0, 59, S_TIME, END_TIME_MINUTE }, //End Minute
		{ true, 19, 5, 0, 23, 0, 23, S_TIME, END_TIME_HOUR }, //End Hour
		{ true, 26, 6, 0, 59, 0, 59, S_TIME, START_TIME_MINUTE }, //Start Minute
		{ true, 35, 5, 0, 23, 0, 23, S_TIME, START_TIME_HOUR }, //Start Hour
		{ true, 40, 4, 0, 3, 0, 3, E_DAYS, 0 }, //Period
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_DELETION } //Time program deletion
	},
	//Type 0x01
	{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 10, 3, 0, 4, 0, 4, E_STATE, INFO_REQUEST_CLASS }, //Information request classifier
		{ true, 13, 2, 0, 2, 0, 2, E_STATE, FEEDBACK_CLASS }, //Feedback classifier
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, GENERAL_MSG_TYPE }, //General message type
		{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_1 }, //Custom warning 1
		{ true, 28, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_2 }, //Custom warning 2
		{ true, 30, 2, 0, 2, 0, 2, E_STATE, WINDOW_OPEN_DETECTION }, //Window open detection
		{ true, 33, 2, 0, 3, 0, 3, E_STATE, BATTERY_STATUS }, //Battery status
		{ true, 38, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy button
		{ true, 44, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Room control mode
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_VALIDITY }, //Temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_VALIDITY }, //Temperature validity flag
		{ true, 48, 8, 0, 255, 0, 40, S_TEMP_ABS, RECENT_TEMP_SETPOINT }, //Recent temperature set point
		{ true, 56, 8, 0, 255, 0, 40, S_TEMP, 0 }, //Room temperature
		{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_LOCK }, //Temperature scale lock
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_LOCK }, //Display content lock
		{ true, 11, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_LOCK }, //Date / time lock
		{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_LOCK }, //Time program lock
		{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, OCCUPANCY_LOCK }, //Occupancy button lock
		{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_LOCK }, //Temperature set point lock
		{ true, 16, 6, 0, 63, 0, 63, S_TIME, RADIO_COM_INTERVAL }, //Radio communication interval
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, KEY_LOCK }, //Key lock
		{ true, 24, 3, 0, 7, 0, 7, E_STATE, DISPLAY_CONTENT }, //Display content
		{ true, 27, 2, 0, 3, 0, 3, E_STATE, TEMP_SCALE }, //Temperature scale
		{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGHT_SAVE }, //Daylight saving time flag
		{ true, 30, 2, 0, 3, 0, 3, E_STATE, TIME_NOTATION }, //Time notation
		{ true, 32, 5, 1, 31, 1, 31, S_TIME, TIME_CURRENT_DAY }, //Day
		{ true, 37, 4, 1, 12, 1, 12, S_TIME, TIME_CURRENT_MONTH }, //Month
		{ true, 41, 7, 0, 127, 2000, 2127, S_TIME, TIME_CURRENT_YEAR }, //Year
		{ true, 48, 6, 0, 59, 0, 59, S_TIME, TIME_CURRENT_MINUTE }, //Minute
		{ true, 56, 5, 0, 23, 0, 23, S_TIME, TIME_CURRENT_HOUR }, //Hour
		{ true, 63, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_UPDATE_FLAG }, //Day / time update flag
		{ true, 8, 8, 0, 255, 0, 40, S_TEMP_ABS, BUILDING_PROTECT_TEMP_SETPOINT }, //Building protection temperature set point
		{ true, 24, 8, 0, 255, 0, 40, S_TEMP_ABS, ECONOMY_TEMP_SETPOINT }, //Economy temperature set point
		{ true, 32, 8, 0, 255, 0, 40, S_TEMP_ABS, COMFORT_TEMP_SETPOINT }, //Comfort temperature set point
		{ true, 44, 1, 0, 1, 0, 1, F_ON_OFF, BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY }, //Building protection temperature set point validity flag
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY }, //Economy temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, COMFORT_TEMP_SETPOINT_VALIDITY }, //Comfort temperature set point validity flag
		{ true, 10, 6, 0, 59, 0, 59, S_TIME, END_TIME_MINUTE }, //End Minute
		{ true, 19, 5, 0, 23, 0, 23, S_TIME, END_TIME_HOUR }, //End Hour
		{ true, 26, 6, 0, 59, 0, 59, S_TIME, START_TIME_MINUTE }, //Start Minute
		{ true, 35, 5, 0, 23, 0, 23, S_TIME, START_TIME_HOUR }, //Start Hour
		{ true, 40, 4, 0, 3, 0, 3, E_DAYS, 0 }, //Period
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_DELETION}, //Time program deletion
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x02
	{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 6, 2, 0, 2, 0, 2, E_STATE, MSG_CONTINUATION }, //Message continuation flag
		{ true, 10, 3, 0, 4, 0, 4, E_STATE, INFO_REQUEST_CLASS }, //Information request classifier
		{ true, 13, 2, 0, 2, 0, 2, E_STATE, FEEDBACK_CLASS }, //Feedback classifier
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, GENERAL_MSG_TYPE }, //General message type
		{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_1 }, //Custom warning 1
		{ true, 28, 1, 0, 1, 0, 1, F_ON_OFF, CUSTOM_WARNING_2 }, //Custom warning 2
		{ true, 30, 2, 0, 2, 0, 2, E_STATE, WINDOW_OPEN_DETECTION }, //Window open detection
		{ true, 33, 2, 0, 3, 0, 3, E_STATE, BATTERY_STATUS }, //Battery status
		{ true, 35, 1, 0, 1, 0, 1, F_ON_OFF, SOLAR_POWERED_STATUS }, //Solar-powered status
		{ true, 36, 2, 0, 3, 0, 3, E_STATE, PIR_STATUS }, //PIR status
		{ true, 38, 2, 0, 2, 0, 2, E_OCCUPANCY, 0 }, //Occupancy button
		{ true, 44, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Room control mode
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_SETPOINT_VALIDITY }, //Temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, TEMP_VALIDITY }, //Temperature validity flag
		{ true, 48, 8, 0, 255, 0, 40, S_TEMP_ABS, RECENT_TEMP_SETPOINT }, //Recent temperature set point
		{ true, 56, 8, 0, 255, 0, 40, S_TEMP, 0 }, //Room temperature
		{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, PIR_LOCK }, //PIR status lock
		{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_LOCK }, //Display content lock
		{ true, 11, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_LOCK }, //Date / time lock
		{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, TIME_PROG_LOCK }, //Time program lock
		{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, OCCUPANCY_LOCK }, //Occupancy button lock
		{ true, 16, 6, 0, 63, 0, 63, S_TIME, RADIO_COM_INTERVAL }, //Radio communication interval
		{ true, 24, 3, 0, 7, 0, 7, E_STATE, DISPLAY_CONTENT }, //Display content
		{ true, 27, 2, 0, 3, 0, 3, E_STATE, TEMP_SCALE }, //Temperature scale
		{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, DAYLIGHT_SAVE }, //Daylight saving time flag
		{ true, 30, 2, 0, 3, 0, 3, E_STATE, TIME_NOTATION }, //Time notation
		{ true, 32, 5, 1, 31, 1, 31, S_TIME, TIME_CURRENT_DAY }, //Day
		{ true, 37, 4, 1, 12, 1, 12, S_TIME, TIME_CURRENT_MONTH }, //Month
		{ true, 41, 7, 0, 127, 2000, 2127, S_TIME, TIME_CURRENT_YEAR }, //Year
		{ true, 48, 6, 0, 59, 0, 59, S_TIME, TIME_CURRENT_MINUTE }, //Minute
		{ true, 56, 5, 0, 23, 0, 23, S_TIME, TIME_CURRENT_HOUR }, //Hour
		{ true, 63, 1, 0, 1, 0, 1, F_ON_OFF, DATE_TIME_UPDATE_FLAG }, //Day / time update flag
		{ true, 24, 8, 0, 255, 0, 40, S_TEMP_ABS, ECONOMY_TEMP_SETPOINT }, //Economy temperature set point
		{ true, 32, 8, 0, 255, 0, 40, S_TEMP_ABS, COMFORT_TEMP_SETPOINT }, //Comfort temperature set point
		{ true, 46, 1, 0, 1, 0, 1, F_ON_OFF, ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY }, //Economy temperature set point validity flag
		{ true, 47, 1, 0, 1, 0, 1, F_ON_OFF, COMFORT_TEMP_SETPOINT_VALIDITY }, //Comfort temperature set point validity flag
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	}
};

eoEEP_D210xx::eoEEP_D210xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x10;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D210xx::~eoEEP_D210xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D210xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 2 || m.GetDataLength() > 8)
		return NOT_SUPPORTED;

	SetCommand((m.data[0] >> 5) & 0x07);

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D210xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	SetLength(type);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D210xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommands)
		return NOT_SUPPORTED;

	if (this->type == 0x02 && cmd == TIME_PROG_MSG)
		return NOT_SUPPORTED;

	msg.Clear();

	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {2, 8, 8, 6, 6};
	msg.SetDataLength(dataLength[cmd]);

	if(cmd==this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD210xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD210xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD210xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD210xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD210xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D210xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_DAYS:
		case E_COMMAND:
		case E_CONTROLLER_MODE:
		case E_OCCUPANCY:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D210xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_DAYS:
		case E_CONTROLLER_MODE:
		case E_OCCUPANCY:
			rawValue = (uint32_t)value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D210xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}
	switch (type)
	{
		case S_VALUE:
			if (this->type != 0x00)
				return NOT_SUPPORTED;
			value = (float)rawValue;
			break;
		case S_RELHUM:
			if (this->type != 0x00)
				return NOT_SUPPORTED;
			value = (float)ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TEMP:
			value = (float)ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D210xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd > 4)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_VALUE:
			if (this->type != 0x00)
				return NOT_SUPPORTED;
			rawValue = value;
			break;
		case S_RELHUM:
			if (this->type != 0x00)
				return NOT_SUPPORTED;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TEMP:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D210xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case GENERAL_MSG_TYPE:
				case CUSTOM_WARNING_1:
				case CUSTOM_WARNING_2:
				case TEMP_SETPOINT_VALIDITY:
				case TEMP_VALIDITY:
				case DAYLIGHT_SAVE:
				case DATE_TIME_UPDATE_FLAG:
				case ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY:
				case COMFORT_TEMP_SETPOINT_VALIDITY:
				case TIME_PROG_DELETION:
				case DISPLAY_LOCK:
				case DATE_TIME_LOCK:
				case TIME_PROG_LOCK:
				case OCCUPANCY_LOCK:
					break;
				case RELHUM_VALIDITY:
				case FANSPEED_VALIDITY:
				case FANSPEED_MODE:
				case MOLD_WARNING:
				case PRECOMFORT_TEMP_SETPOINT_VALIDITY:
				case FAN_SPEED_LOCK:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				case SOLAR_POWERED_STATUS:
				case PIR_LOCK:
					if (this->type == 0x01)
						return NOT_SUPPORTED;
					break;
				case BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY:
				case TEMP_LOCK:
				case TEMP_SETPOINT_LOCK:
				case KEY_LOCK:
					if (this->type == 0x02)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_STATE:
			switch (index)
			{
				case MSG_CONTINUATION:
				case INFO_REQUEST_CLASS:
				case FEEDBACK_CLASS:
				case WINDOW_OPEN_DETECTION:
				case BATTERY_STATUS:
				case DISPLAY_CONTENT:
				case TEMP_SCALE:
				case TIME_NOTATION:
					break;
				case PIR_STATUS:
					if (this->type == 0x01)
						return NOT_SUPPORTED;
					break;
				case COOLING_STATUS:
				case HEATING_STATUS:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return GetValue(type, value);
	}

	value = (uint8_t)rawValue;
	return EO_OK;
}

eoReturn eoEEP_D210xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd > 4)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case GENERAL_MSG_TYPE:
				case CUSTOM_WARNING_1:
				case CUSTOM_WARNING_2:
				case TEMP_SETPOINT_VALIDITY:
				case TEMP_VALIDITY:
				case DAYLIGHT_SAVE:
				case DATE_TIME_UPDATE_FLAG:
				case ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY:
				case COMFORT_TEMP_SETPOINT_VALIDITY:
				case TIME_PROG_DELETION:
				case DISPLAY_LOCK:
				case DATE_TIME_LOCK:
				case TIME_PROG_LOCK:
				case OCCUPANCY_LOCK:
					break;
				case RELHUM_VALIDITY:
				case FANSPEED_VALIDITY:
				case FANSPEED_MODE:
				case MOLD_WARNING:
				case PRECOMFORT_TEMP_SETPOINT_VALIDITY:
				case FAN_SPEED_LOCK:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				case SOLAR_POWERED_STATUS:
				case PIR_LOCK:
					if (this->type == 0x01)
						return NOT_SUPPORTED;
					break;
				case BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY:
				case TEMP_LOCK:
				case TEMP_SETPOINT_LOCK:
				case KEY_LOCK:
					if (this->type == 0x02)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_STATE:
			switch (index)
			{
				case MSG_CONTINUATION:
				case INFO_REQUEST_CLASS:
				case FEEDBACK_CLASS:
				case WINDOW_OPEN_DETECTION:
				case BATTERY_STATUS:
				case DISPLAY_CONTENT:
				case TEMP_SCALE:
				case TIME_NOTATION:
					break;
				case PIR_STATUS:
					if (this->type == 0x01)
						return NOT_SUPPORTED;
					break;
				case COOLING_STATUS:
				case HEATING_STATUS:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return SetValue(type, value);
			break;
	}

	rawValue = (uint32_t)value;
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D210xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP_ABS:
			switch (index)
			{
				case RECENT_TEMP_SETPOINT:
				case ECONOMY_TEMP_SETPOINT:
				case COMFORT_TEMP_SETPOINT:
					break;
				case BUILDING_PROTECT_TEMP_SETPOINT:
					if (this->type == 0x02)
						return NOT_SUPPORTED;
					break;
				case PRECOMFORT_TEMP_SETPOINT:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}

			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TIME:
			if (index == TIME_CURRENT_YEAR)
				value = rawValue + 2000;
			else
				value = rawValue;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_D210xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd > 4)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP_ABS:
			switch (index)
			{
				case RECENT_TEMP_SETPOINT:
				case ECONOMY_TEMP_SETPOINT:
				case COMFORT_TEMP_SETPOINT:
					break;
				case BUILDING_PROTECT_TEMP_SETPOINT:
					if (this->type == 0x02)
						return NOT_SUPPORTED;
					break;
				case PRECOMFORT_TEMP_SETPOINT:
					if (this->type != 0x00)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TIME:
			if (index == TIME_CURRENT_YEAR)
				rawValue = value - 2000;
			else
				rawValue = value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D210xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD210xx[this->cmd][tmpChannelCount].type == type && listD210xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D210xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD210xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD210xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD210xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD210xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD210xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
