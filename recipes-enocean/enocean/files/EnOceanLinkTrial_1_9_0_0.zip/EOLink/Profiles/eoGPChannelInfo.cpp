/*
 * eoGPChannelInfo.cpp
 *
 *  Created on: 23.11.2012
 *      Author: tobi
 */
#include "eoGPChannelInfo.h"
#include "eoArchive.h"
const float scaleToDouble[16] =
{ 0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 0.1F, 0.01F, 0.001F, 0.000001F, 0.000000001F, 0, 0 };

const float resToDouble[15] =
{ 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 0, 0 };

eoGPChannelInfo::eoGPChannelInfo()
{
	res = GP_RES_RES;
	scaleMin = GP_SCAL_RES;
	scaleMax = GP_SCAL_RES;
	engMax = 0;
	engMin = 0;
	bitoffs=0;
	rejected = false;
}

eoGPChannelInfo::eoGPChannelInfo(CHANNEL_TYPE type, GP_RESOLUTION resolution, int8_t engMaximum, int8_t engMinimum, GP_SCALING scaleMaximum, GP_SCALING scaleMinimum)
{

	this->type = type;
	res = resolution;
	scaleMin = scaleMinimum;
	scaleMax = scaleMaximum;
	engMax = engMaximum;
	engMin = engMinimum;
	CalculateMin();
	CalculateMax();
	bitoffs=0;
	rejected = false;
}

void eoGPChannelInfo::CalculateMin()
{
	//enum type
	if(this->type>=GP_ENUM)
		min=0;
	else
		min = engMin * ScaleToFloat(scaleMin);
}

void eoGPChannelInfo::CalculateMax()
{
	if(this->type>=GP_ENUM)
		max=resToDouble[res];
	else
		max = engMax * ScaleToFloat(scaleMax);
}

GP_CHANNELTYPE eoGPChannelInfo::GetGPChannelType() const
{
	GP_CHANNELTYPE retype;
	if (type < T_FLAG)
		retype = GP_DATA;
	else if (type < GP_ENUM)
		retype = GP_FLAG;
	else
		retype = GP_ENUMERATION;
	return retype;
}

GP_RESOLUTION eoGPChannelInfo::GetResolution() const
{
	return res;
}

int8_t eoGPChannelInfo::GetEngMax() const
{
	return engMax;
}

int8_t eoGPChannelInfo::GetEngMin() const
{
	return engMin;
}

GP_SCALING eoGPChannelInfo::GetScaleMax() const
{
	return scaleMax;
}

GP_SCALING eoGPChannelInfo::GetScaleMin() const
{
	return scaleMin;
}

float eoGPChannelInfo::ScaleToFloat(GP_SCALING scale)
{
	float ret = 0;
	if (scale <= 0xF)
		ret = scaleToDouble[scale];
	return ret;
}

void eoGPChannelInfo::SetRejected(uint8_t rejected)
{
	this->rejected = rejected;
}

uint8_t eoGPChannelInfo::GetRejected()
{
	return this->rejected;
}

uint8_t eoGPChannelInfo::Serialize(eoArchive &a)
{
	uint32_t tmp=0;
	if(a.isStoring)
	{
		tmp = scaleMin;
		a & "scaleMin" & tmp;
		tmp = scaleMax;
		a & "scaleMax" & tmp;
		tmp = type;
		a & "type" & tmp;
		tmp = signalType;
		a & "signalType" & tmp;
		tmp = res;
		a & "res" & tmp;
	}
	else
	{
		a & "scaleMin" & tmp;
		scaleMin = (GP_SCALING)tmp;
		a & "scaleMax" & tmp;
		scaleMax = (GP_SCALING)tmp;
		a & "type" & tmp;
		type = (CHANNEL_TYPE)tmp;
		a & "signalType" & tmp;
		signalType = (VALUE_TYPE)((uint8_t)tmp);

		a & "res" & tmp;
		res = (GP_RESOLUTION)((uint8_t)tmp);
	}
	a & "engMax" & engMax;
	a & "engMin" & engMin;
	a & "bitoffs"  & bitoffs;
	a & "min" & min;
	a & "max" & max;
	return EO_OK;
}
