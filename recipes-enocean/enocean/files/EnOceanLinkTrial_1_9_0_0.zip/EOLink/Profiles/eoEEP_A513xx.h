/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//! \file eoEEP_A513xx.h

#if !defined(eoEEP_A513_H__INCLUDED_)
#define eoEEP_A513_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
/**\class eoEEP_A513xx
 * \brief The class to handle EEP a513 profiles
 * \details Allows the user to handle EEP a513 profiles, the following profiles are available:
 * 		- A5-13-01
 * 		- A5-13-02
 * 		- A5-13-03
 * 		- A5-13-04
 * 		- A5-13-05
 * 		- A5-13-06
 * 		- A5-13-07
 * 		- A5-13-08
 * 		- A5-13-10\n\n
 *
 * The following channels are available for 01 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_LUMINANCE   	|float |  |
 * | 1             | ::S_TEMP		 	|float |  |
 * | 3             | ::S_VELOCITY	   	|float |  |
 * | 4             | ::F_DAY_NIGHT 		|uint8_t |    |
 * | 5             | ::F_ON_OFF   		|uint8_t | Rain/ no rain, ::RAIN_NORAIN |
 * \n
 * The following channels are available for 02 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_LUMINANCE   	|float | Sun West, ::SUN_WEST |
 * | 1             | ::S_LUMINANCE	 	|float | Sun South, ::SUN_SOUTH |
 * | 2             | ::S_LUMINANCE     	|float | Sun East, ::SUN_EAST |
 * | 5             | ::F_ON_OFF   		|::EA_HEMISPHERE | |
 * \n
 * The following channels are available for 03 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_TIME		   	|float | Time day, ::TIME_DAY |
 * | 1             | ::S_TIME			|float | Time month, ::TIME_MONTH |
 * | 2             | ::S_TIME 	     	|float | Time year, ::TIME_YEAR |
 * | 3             | ::F_ON_OFF		   	|uint8_t | Time source |
 * \n
 * The following channels are available for 04 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_DAYS		   	|::EA_ENUM_DAYS |   |
 * | 1             | ::S_TIME			|float | Time hour, ::TIME_HOUR |
 * | 2             | ::S_TIME 	     	|float | Time minute, ::TIME_MINUTE |
 * | 3             | ::S_TIME 	     	|float | Time second, ::TIME_SECOND |
 * | 4             | ::F_ON_OFF		   	|::EA_TIME_SOURCE | Time source, ::TIME_SOURCE |
 * | 5             | ::F_ON_OFF		   	|::EA_AM_PM | AM/PM, ::AM_PM |
 * | 4             | ::F_ON_OFF		   	|::EA_TIME_FORMAT | Time format, ::TIME_FORMAT |
 * \n
 * The following channels are available for 05 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_ANGLE		   	|float | Elevation, ::ELEVATION |
 * | 1             | ::S_ANGLE		 	|float | Azimuth, ::AZIMUTH |
 * \n
 * The following channels are available for 06 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_ANGLE	  |float | Latitude, ::LATITUDE |
 * | 1             | ::S_ANGLE	  |float | Longitude, ::LONGITUDE |
 * \n
 * The following channels are available for 07 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_DIRECTION	   	|::EA_ENUM_WIND_DIR |  |
 * | 1             | ::S_VALUE 			|float | Average wind speed, ::AVG_WIND_SPEED  |
 * | 2             | ::S_VALUE		 	|float | Maximum wind speed, ::MAX_WIND_SPEED |
 * | 3             | ::E_STATE		 	|uint8_t |
 * \n
 * The following channels are available for 08 profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_PERCENTAGE		|float |
 * | 1             | ::S_COUNTER 		|float |
 * | 2             | ::E_STATE		 	|uint8_t |
 * \n
 * The following channels are available for 10 profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_ANGLE		   	|float | Elevation, ::ELEVATION |
 * | 1             | ::F_DAY_NIGHT 		|uint8_t |   |
 * | 2             | ::S_ANGLE		 	|float | Azimuth, ::AZIMUTH |
 * | 3             | ::S_SOLAR_RAD		|float |  |
 * \n
 */

/**
 * \typedef EA_INDEXS
 * \brief Indexes for A513xx profiles
 */
typedef enum
{
	//! Rain / No rain
	RAIN_NORAIN = 0x00,
	//! Sun - West
	SUN_WEST = 0x01,
	//! Sun - South
	SUN_SOUTH = 0x02,
	//! Sun - East
	SUN_EAST = 0x03,
	//! Time - second
	TIME_SECOND = 0x04,
	//! Time - minute
	TIME_MINUTE = 0x05,
	//! Time - hour
	TIME_HOUR = 0x06,
	//! Time - day
	TIME_DAY = 0x07,
	//! Time - month
	TIME_MONTH = 0x08,
	//! Time - year
	TIME_YEAR = 0x09,
	//! Time source
	TIME_SOURCE = 0x0A,
	//! AM or PM
	AM_PM = 0x0B,
	//! Elevation
	ELEVATION = 0x0C,
	//! Azimuth
	AZIMUTH = 0x0D,
	//! Latitude
	LATITUDE = 0x0E,
	//! Longitude
	LONGITUDE = 0x0F,
	//! Time format
	TIME_FORMAT = 0x10,
	//! Average wind speed
	AVG_WIND_SPEED = 0x11,
	//! Maximum wind speed
	MAX_WIND_SPEED = 0x12
} EA_INDEXS;

/**
 * \typedef EA_ENUM_DAYS
 * \brief Days definition.
 */
typedef enum
{
	//! Monday
	MONDAY = 0x01,
	//! Tuesday
	TUESDAY = 0x02,
	//! Wednesday
	WEDNESDAY = 0x03,
	//! Thursday
	THURSDAY = 0x04,
	//! Friday
	FRIDAY = 0x05,
	//! Saturday
	SATURDAY = 0x06,
	//! Sunday
	SUNDAY = 0x07
} EA_ENUM_DAYS;

/**
 * \typedef EA_TIME_SOURCE
 * \brief Time source
 */
typedef enum
{
	//! Real time clock
	REAL_TIME_CLOCK = 0x00,
	//! GPS or equivalent
	GPS = 0x01
} EA_TIME_SOURCE;

/**
 * \typedef EA_AM_PM
 * \brief AM or PM
 */
typedef enum
{
	//! AM
	TIME_AM = 0x00,
	//! PM
	TIME_PM = 0x01
} EA_AM_PM;

/**
 * \typedef EA_TIME_FORMAT
 * \brief 24 hours or 12 hours
 */
typedef enum
{
	//! 24 hours
	FORMAT_24 = 0x00,
	//! 12 hours
	FORMAT_12 = 0x01
} EA_TIME_FORMAT;

/**
 * \typedef EA_HEMISPHERE
 * \brief Hemisphere source
 */
typedef enum
{
	//! North
	NORTH = 0x00,
	//! South
	SOUTH = 0x01
} EA_HEMISPHERE;

/**
 * \typedef EA_ENUM_WIND_DIR
 * \brief Win direction definitions
 */
typedef enum
{
	//! North - North East
	WIND_NNE = 0x00,
	//! North East
	WIND_NE = 0x01,
	//! East - North East
	WIND_ENE = 0x02,
	//! East
	WIND_E = 0x03,
	//! East - South East
	WIND_ESE = 0x04,
	//! South East
	WIND_SE = 0x05,
	//! South - South East
	WIND_SSE = 0x06,
	//! South
	WIND_S = 0x07,
	//! South - South West
	WIND_SSW = 0x08,
	//! South West
	WIND_SW = 0x09,
	//! West - South West
	WIND_WSW = 0x0A,
	//! West
	WIND_W = 0x0B,
	//! West - North West
	WIND_WNW = 0x0C,
	//! North West
	WIND_NW = 0x0D,
	//! North - North West
	WIND_NNW = 0x0E,
	//! North
	WIND_N = 0x0F
} EA_ENUM_WIND_DIR;

class eoEEP_A513xx: public eoA5EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoEEP_A513xx();
	virtual ~eoEEP_A513xx();

	eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	eoReturn GetValue(CHANNEL_TYPE type, float &value);
	eoReturn SetValue(CHANNEL_TYPE type, float value);

	eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets and checks if the specified command is supported
	 * @param cmd
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	eoReturn SetCommand(uint8_t cmd);

	eoReturn Parse(const eoMessage &m);
};

#endif
