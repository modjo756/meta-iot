/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D220_H__INCLUDED_)
#define eoEEP_D220_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D220xx
 * \brief The class to handle EEP D220 profiles
 * \details Allows the user to handle EEP D220 profiles, the following profiles are available:
 * 		- D2-20-00 (two directions)
 * 		- D2-20-01 (two directions)
 * 		- D2-20-02 (two directions)\n
 *
 * \note Direction 1 is set with E_DIRECTION,0 and Direction 2 is set with E_DIRECTION,1
 *
 * The following channels are available for 00 profile, Fan Control Message (direction 1):
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_FC_OP_MODE	 	| ::OP_MODE |
 * | 1             | ::E_STATE    	     |::VLD_FC_TEMP_LEVEL 	| ::TEMP_LEVEL |
 * | 2             | ::E_CONTROLLER_MODE |::VLD_FC_RELHUM_CONTROL| ::RELHUM_CONTROL |
 * | 3             | ::E_STATE			|::VLD_FC_ROOM_SIZE_REF	| ::ROOM_SIZE_REFERENCE |
 * | 4             | ::E_ROOM_SIZE 		|::VLD_FC_ROOM_SIZE |  |
 * | 5             | ::E_STATE			|::VLD_FC_STAGE | ::RELHUM_THRESHOLD, between 0-100% float number |
 * | 6             | ::S_RELHUM			|float |  |
 * | 7             | ::E_FANSPEED		|::VLD_FC_STAGE | Enum of fan speed, ::VLD_FC_STAGE |
 * | 8             | ::S_PERCENTAGE		|float | Percentage of fan speed between 0-100% |
 *
 * The following channels are available for 00 profile, Fan Control Message (direction 2):
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_FC_OP_MODE	 			| ::OP_MODE |
 * | 1             | ::E_STATE    	     |::VLD_FC_SERVICE_INFORMATION 	| ::SERVICE_INFO |
 * | 2             | ::E_STATE			 |::VLD_FC_RELHUM_CONTROL		| ::RELHUM_THRESHOLD |
 * | 3             | ::S_RELHUM			| float	|  |
 * | 4             | ::E_STATE	 		|::VLD_FC_ROOM_SIZE_REF			| ::ROOM_SIZE_REFERENCE |
 * | 5             | ::E_ROOM_SIZE		|::VLD_FC_ROOM_SIZE |  |
 * | 6             | ::E_FANSPEED		|::VLD_FC_STAGE | Enum of fan speed, ::VLD_FC_STAGE |
 * | 7             | ::S_PERCENTAGE		|float | Percentage of fan speed between 0-100% |
 *
 * The following channels are available for 01 profile, Fan Control Message (direction 1):
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			 |::VLD_FC_ROOM_SIZE_REF	| ::ROOM_SIZE_REFERENCE |
 * | 1             | ::E_ROOM_SIZE 	     |::VLD_FC_ROOM_SIZE 		|  |
 * | 2             | ::E_FANSPEED		 |::VLD_FC_STAGE			|  |
 * | 3             | ::S_PERCENTAGE		| float						|  |
 *
 * The following channels are available for 01 profile, Fan Control Message (direction 2):
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_FC_OP_MODE	 			| ::OP_MODE |
 * | 1             | ::E_STATE    	     |::VLD_FC_ROOM_SIZE_REF 		| ::ROOM_SIZE_REFERENCE |
 * | 2             | ::E_ROOM_SIZE		 |::VLD_FC_ROOM_SIZE			|  |
 * | 3             | ::E_FANSPEED		| ::VLD_FC_STAGE				|  |
 * | 4             | ::S_PERCENTAGE		| float							|  |
 *
 * The following channels are available for 02 profile, Fan Control Message (direction 1):
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			 |::VLD_FC_ROOM_SIZE_REF	| ::ROOM_SIZE_REFERENCE |
 * | 1             | ::E_ROOM_SIZE 	     |::VLD_FC_ROOM_SIZE 		|  |
 * | 2             | ::E_FANSPEED		 |::VLD_FC_STAGE			|  |
 * | 3             | ::S_PERCENTAGE		| float						|  |
 *
 * The following channels are available for 02 profile, Fan Control Message (direction 2):
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_FC_OP_MODE	 			| ::OP_MODE |
 * | 1             | ::E_STATE    	     |::VLD_FC_ROOM_SIZE_REF 		| ::ROOM_SIZE_REFERENCE |
 * | 2             | ::E_ROOM_SIZE		 |::VLD_FC_ROOM_SIZE			|  |
 * | 3             | ::E_FANSPEED		| ::VLD_FC_STAGE				|  |
 * | 4             | ::S_PERCENTAGE		| float							|  |
 * \n
 */

/**
 * \file eoEEP_D220xx.h
 */
//! Index enums for D2-20-xx profiles
typedef enum
{
	//! <b>Operating Mode</b> 0
	OP_MODE			= 0x00,
	//! <b>Temperature Level</b> 1
	TEMP_LEVEL		= 0x01,
	//! <b>Humidity Control</b> 2
	RELHUM_CONTROL	= 0x02,
	//! <b>Room Size Reference</b> 3
	ROOM_SIZE_REFERENCE	= 0x03,
	//! <b>Humidity Threshold</b> 4
	RELHUM_THRESHOLD	= 0x04,
	//! <b>Service Information</b> 5
	SERVICE_INFO	= 0x05
} VLD_FC_INDEXS;

//! Operating mode enums
typedef enum
{
	//! <b>Disabled</b> 0
	OP_MODE_DISABLED = 0x00,
	//! <b>Standard Compliant</b> 1
	OP_MODE_STANDARD_COMPLIANT = 0x01,
	//! <b>No Change</b> 15
	OP_MODE_NO_CHANGE = 0x0F
} VLD_FC_OP_MODE;

//! Temperature level enums
typedef enum
{
	//! <b>Too Low</b> 0
	TEMP_LEVEL_LOW = 0x00,
	//! <b>Normal</b> 1
	TEMP_LEVEL_NORMAL = 0x01,
	//! <b>Too High</b> 2
	TEMP_LEVEL_HIGH = 0x02,
	//! <b>No Change</b> 3
	TEMP_LEVEL_NO_CHANGE = 0x03
} VLD_FC_TEMP_LEVEL;

//! Room size reference enums
typedef enum
{
	//! <b>Used</b> 0
	ROOM_SIZE_REF_USED = 0x00,
	//! <b>Not Used</b> 1
	ROOM_SIZE_REF_NOT_USED = 0x01,
	//! <b>Default</b> 2
	ROOM_SIZE_REF_DEFAULT = 0x02,
	//! <b>No Change</b> 3
	ROOM_SIZE_REF_NO_CHANGE = 0x03
} VLD_FC_ROOM_SIZE_REF;

//! Room size enums
typedef enum
{
	//! <b>< 25 m²</b> 0
	ROOM_SIZE_25 = 0x00,
	//! <b>25...50 m²</b> 1
	ROOM_SIZE_25_50 = 0x01,
	//! <b>50...75 m²</b> 2
	ROOM_SIZE_50_75 = 0x02,
	//! <b>75...100 m²</b> 3
	ROOM_SIZE_75_100 = 0x03,
	//! <b>100...125 m²</b> 4
	ROOM_SIZE_100_125 = 0x04,
	//! <b>125...150 m²</b> 5
	ROOM_SIZE_125_150 = 0x05,
	//! <b>150...175 m²</b> 6
	ROOM_SIZE_150_175 = 0x06,
	//! <b>175...200 m²</b> 7
	ROOM_SIZE_175_200 = 0x07,
	//! <b>200...225 m²</b> 8
	ROOM_SIZE_200_225 = 0x08,
	//! <b>225...250 m²</b> 9
	ROOM_SIZE_225_250 = 0x09,
	//! <b>250...275 m²</b> 10
	ROOM_SIZE_250_275 = 0x0A,
	//! <b>275...300 m²</b> 11
	ROOM_SIZE_275_300 = 0x0B,
	//! <b>300...325 m²</b> 12
	ROOM_SIZE_300_325 = 0x0C,
	//! <b>325...350 m²</b> 13
	ROOM_SIZE_325_350 = 0x0D,
	//! <b>> 375 m²</b> 14
	ROOM_SIZE_350 = 0x0E,
	//! <b>No Change</b> 15
	ROOM_SIZE_NO_CHANGE = 0x0F
} VLD_FC_ROOM_SIZE;

//! Fan speed stage enums
typedef enum
{
	//! <b>Fan speed - Auto</b> 253
	FC_STAGE_AUTO = 0xFD,
	//! <b>Fan speed - Default</b> 254
	FC_STAGE_DEFAULT = 0xFE,
	//! <b>Fan speed - No changed</b> 255
	FC_STAGE_NO_CHANGE = 0xFF
} VLD_FC_STAGE;

//! Humidity control enums
typedef enum
{
	//! <b>Disabled</b> 0
	FC_RELHUM_DISABLED = 0x00,
	//! <b>Enabled</b> 1
	FC_RELHUM_ENABLED = 0x01,
	//! <b>Default</b> 2
	FC_RELHUM_DEFAULT = 0x02
} VLD_FC_RELHUM_CONTROL;

//! Service information enums
typedef enum
{
	//! <b>Nothing to report</b> 0
	FC_SERVICE_NO_REPORT = 0x00,
	//! <b>Air filter error</b> 1
	FC_SERVICE_AIR_FILTER = 0x01,
	//! <b>Hardware error</b> 2
	FC_SERVICE_HW_ERROR = 0x02,
	//! <b>Not supported</b> 7
	FC_SERVICE_NOT_SUPPORTED = 0x07
} VLD_FC_SERVICE_INFORMATION;

class eoEEP_D220xx: public eoD2EEProfile
{
private:
	uint8_t direction;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D220xx(uint16_t size = 4);
	virtual ~eoEEP_D220xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
