/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D250xx.h"

#include "eoChannelEnums.h"
#include <string.h>

const uint8_t numOfChan = 26;
const uint8_t numOfProfiles = 0x04;
const uint8_t numOfCommmands = 0x04;

const EEP_ITEM listD250xx[numOfCommmands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
{ true, 5, 3, 0, 1, 0, 1, E_CONTROLLER_MODE, REQUESTED_MSG_TYPE }, //Requested Message Type
{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:01
{
{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, DIRECT_OP_MODE }, //Direct Operation Mode
{ true, 8, 2, 0, 2, 0, 2, E_CONTROLLER_MODE, OP_MODE_CTRL }, //Operation Mode
{ true, 10, 2, 0, 2, 0, 2, E_CONTROLLER_MODE, HEAT_EXCHANGE_CTRL }, //Heat Exchanger Bypass Control
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL }, //Timer Operation Control
{ true, 17, 7, 0, 127, 0, 127, S_PERCENTAGE, CO2_TRHESHOLD }, //CO2 Threshold
{ true, 25, 7, 0, 127, 0, 127, S_RELHUM, 0 }, //Humidity Threshold
{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_TRHESHOLD }, //Air Quality Threshold
{ true, 41, 7, 0, 127, -63.0, 64, S_TEMP, ROOM_TEMP }, //Room Temperature Threshold
{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//COMMAND:02
{
{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE_CTRL }, //Operation Mode
{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, SAFTEY_MODE }, //Safety Mode Status
{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, HEAT_EXCHANGE_CTRL }, //Heat Exchanger Bypass Control
{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, SUPPLY_AIR_POS }, //Supply Air Flap Position
{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, EXHAUST_AIR_POS }, //Exhaust Air Flap Position
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, DEFROST_MODE }, //Defrost Mode Status
{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, COOLING_PROTECTION }, //Cooling Protection Status
{ true, 18, 1, 0, 1, 0, 1, F_ON_OFF, OUTDOOR_HEATER_STATUS }, //Outdoor Air Heather Status
{ true, 19, 1, 0, 1, 0, 1, F_ON_OFF, SUPPLY_HEATER_STATUS }, //Supply Air Heather Status
{ true, 20, 1, 0, 1, 0, 1, F_ON_OFF, DRAIN_HEATER_STATUS }, //Drain Heather Status
{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL_STATUS }, //Timer Operation Mode Status
{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, FILTER_MAINTENANCE }, //Filter Maintenance Status
{ true, 23, 1, 0, 1, 0, 1, F_ON_OFF, WEEKLY_PROGRAM }, //Weekly Timer Program Status
{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, ROOM_TEMP_CTRL }, //Room Temperature Control Status
{ true, 25, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_1 }, //Air Quality Threshold 1
{ true, 32, 1, 0, 1, 0, 1, F_ON_OFF, MASTER_SLAVE_CONFIG }, //Master Slave Configuration Status
{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_2 }, //Air Quality Threshold 2
{ true, 40, 7, 0, 127, -64.0, 63, S_TEMP, OUTDOOR_TEMP }, //Outdoor Air Temperature
{ true, 47, 7, 0, 127, -64.0, 63, S_TEMP, SUPPLY_TEMP }, //Supply Air Temperature
{ true, 54, 7, 0, 127, -64.0, 63, S_TEMP, INDOOR_TEMP }, //Indoor Air Temperature
{ true, 61, 7, 0, 127, -64.0, 63, S_TEMP, EXHAUST_TEMP }, //Exhaust Air Temperature
{ true, 68, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, SUPPLY_FAN_RATE }, //Supply Air Fan Air Flow Rate
{ true, 78, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, EXHAUST_FAN_RATE }, //Exhaust Air Fan Air Flow Rate
{ true, 88, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, SUPPLY_FAN_SPEED }, //Supply Fan Speed
{ true, 100, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, EXHAUST_FAN_SPEED }, //Exhaust Fan Speed
{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
},
//COMMAND:03
{
{ true, 4, 12, 0, 4095, 0, 4095, S_VALUE, SW_VERSION }, //Software Version Info
{ true, 16, 16, 0, 65535, 0, 196605, S_TIME, 0 }, //Operation Hours Counter
{ true, 32, 16, 0, 65535, 0, 65535, S_VALUE, DIGITAL_INPUT_STATUS }, //Digital Input Status
{ true, 48, 16, 0, 65535, 0, 65535, S_VALUE, DIGITAL_OUTPUT_STATUS }, //Digital Output Status
{ true, 64, 16, 0, 65535, 0, 65535, S_VALUE, INFO_MSG_STATUS }, //Info Message Status
{ true, 80, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_VALUE, FAULT_STATUS }, //Fault Status
{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
};

const EEP_ITEM typeListD250xx [18][35] =
{
	//Type 0x00
	{
		{ true, 5, 3, 0, 2, 0, 2, E_CONTROLLER_MODE, REQUESTED_MSG_TYPE }, //Requested Message Type
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, DIRECT_OP_MODE }, //Direct Operation Mode
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL }, //Timer Operation Control
		{ true, 17, 7, 0, 127, 0, 127, S_PERCENTAGE, CO2_TRHESHOLD }, //CO2 Threshold
		{ true, 25, 7, 0, 127, 0, 127, S_RELHUM, 0 }, //Humidity Threshold
		{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_TRHESHOLD }, //Air Quality Threshold
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE_CTRL }, //Operation Mode
		{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, SUPPLY_AIR_POS }, //Supply Air Flap Position
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, EXHAUST_AIR_POS }, //Exhaust Air Flap Position
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, DEFROST_MODE }, //Defrost Mode Status
		{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, COOLING_PROTECTION }, //Cooling Protection Status
		{ true, 20, 1, 0, 1, 0, 1, F_ON_OFF, DRAIN_HEATER_STATUS }, //Drain Heather Status
		{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL_STATUS }, //Timer Operation Mode Status
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, FILTER_MAINTENANCE }, //Filter Maintenance Status
		{ true, 25, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_1 }, //Air Quality Threshold 1
		{ true, 32, 1, 0, 1, 0, 1, F_ON_OFF, MASTER_SLAVE_CONFIG }, //Master Slave Configuration Status
		{ true, 40, 7, 0, 127, -64.0, 63, S_TEMP, OUTDOOR_TEMP }, //Outdoor Air Temperature
		{ true, 47, 7, 0, 127, -64.0, 63, S_TEMP, SUPPLY_TEMP }, //Supply Air Temperature
		{ true, 68, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, SUPPLY_FAN_RATE }, //Supply Air Fan Air Flow Rate
		{ true, 78, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, EXHAUST_FAN_RATE }, //Exhaust Air Fan Air Flow Rate
		{ true, 88, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, SUPPLY_FAN_SPEED }, //Supply Fan Speed
		{ true, 100, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, EXHAUST_FAN_SPEED }, //Exhaust Fan Speed
		{ true, 4, 12, 0, 4095, 0, 4095, S_VALUE, SW_VERSION }, //Software Version Info
		{ true, 16, 16, 0, 65535, 0, 196605, S_TIME, 0 }, //Operation Hours Counter
		{ true, 64, 16, 0, 65535, 0, 65535, S_VALUE, INFO_MSG_STATUS }, //Info Message Status
		{ true, 80, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_VALUE, FAULT_STATUS }, //Fault Status
		{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x01
	{
		{ true, 5, 3, 0, 2, 0, 2, E_CONTROLLER_MODE, REQUESTED_MSG_TYPE }, //Requested Message Type
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, DIRECT_OP_MODE }, //Direct Operation Mode
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL }, //Timer Operation Control
		{ true, 17, 7, 0, 127, 0, 127, S_PERCENTAGE, CO2_TRHESHOLD }, //CO2 Threshold
		{ true, 25, 7, 0, 127, 0, 127, S_RELHUM, 0 }, //Humidity Threshold
		{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_TRHESHOLD }, //Air Quality Threshold
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE_CTRL }, //Operation Mode
		{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, SUPPLY_AIR_POS }, //Supply Air Flap Position
		{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, EXHAUST_AIR_POS }, //Exhaust Air Flap Position
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, DEFROST_MODE }, //Defrost Mode Status
		{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, COOLING_PROTECTION }, //Cooling Protection Status
		{ true, 18, 1, 0, 1, 0, 1, F_ON_OFF, OUTDOOR_HEATER_STATUS }, //Outdoor Air Heather Status
		{ true, 20, 1, 0, 1, 0, 1, F_ON_OFF, DRAIN_HEATER_STATUS }, //Drain Heather Status
		{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL_STATUS }, //Timer Operation Mode Status
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, FILTER_MAINTENANCE }, //Filter Maintenance Status
		{ true, 25, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_1 }, //Air Quality Threshold 1
		{ true, 32, 1, 0, 1, 0, 1, F_ON_OFF, MASTER_SLAVE_CONFIG }, //Master Slave Configuration Status
		{ true, 40, 7, 0, 127, -64.0, 63, S_TEMP, OUTDOOR_TEMP }, //Outdoor Air Temperature
		{ true, 47, 7, 0, 127, -64.0, 63, S_TEMP, SUPPLY_TEMP }, //Supply Air Temperature
		{ true, 68, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, SUPPLY_FAN_RATE }, //Supply Air Fan Air Flow Rate
		{ true, 78, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, EXHAUST_FAN_RATE }, //Exhaust Air Fan Air Flow Rate
		{ true, 88, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, SUPPLY_FAN_SPEED }, //Supply Fan Speed
		{ true, 100, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, EXHAUST_FAN_SPEED }, //Exhaust Fan Speed
		{ true, 4, 12, 0, 4095, 0, 4095, S_VALUE, SW_VERSION }, //Software Version Info
		{ true, 16, 16, 0, 65535, 0, 196605, S_TIME, 0 }, //Operation Hours Counter
		{ true, 64, 16, 0, 65535, 0, 65535, S_VALUE, INFO_MSG_STATUS }, //Info Message Status
		{ true, 80, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_VALUE, FAULT_STATUS }, //Fault Status
		{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x02
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x03
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x04
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x05
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x06
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x07
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x08
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x09
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0A
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0B
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0C
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0D
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0E
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//TYPE 0x0F
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	},
	//Type 0x10
	{
		{ true, 5, 3, 0, 2, 0, 2, E_CONTROLLER_MODE, REQUESTED_MSG_TYPE }, //Requested Message Type
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, DIRECT_OP_MODE }, //Direct Operation Mode
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL }, //Timer Operation Control
		{ true, 17, 7, 0, 127, 0, 127, S_PERCENTAGE, CO2_TRHESHOLD }, //CO2 Threshold
		{ true, 25, 7, 0, 127, 0, 127, S_RELHUM, 0 }, //Humidity Threshold
		{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_TRHESHOLD }, //Air Quality Threshold
		{ true, 41, 7, 0, 127, -63.0, 64, S_TEMP, ROOM_TEMP }, //Room Temperature Threshold
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE_CTRL }, //Operation Mode
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, DEFROST_MODE }, //Defrost Mode Status
		{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, COOLING_PROTECTION }, //Cooling Protection Status
		{ true, 18, 1, 0, 1, 0, 1, F_ON_OFF, OUTDOOR_HEATER_STATUS }, //Outdoor Air Heather Status
		{ true, 19, 1, 0, 1, 0, 1, F_ON_OFF, SUPPLY_HEATER_STATUS }, //Supply Air Heather Status
		{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL_STATUS }, //Timer Operation Mode Status
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, FILTER_MAINTENANCE }, //Filter Maintenance Status
		{ true, 23, 1, 0, 1, 0, 1, F_ON_OFF, WEEKLY_PROGRAM }, //Weekly Timer Program Status
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, ROOM_TEMP_CTRL }, //Room Temperature Control Status
		{ true, 25, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_1 }, //Air Quality Threshold 1
		{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_2 }, //Air Quality Threshold 2
		{ true, 40, 7, 0, 127, -64.0, 63, S_TEMP, OUTDOOR_TEMP }, //Outdoor Air Temperature
		{ true, 47, 7, 0, 127, -64.0, 63, S_TEMP, SUPPLY_TEMP }, //Supply Air Temperature
		{ true, 54, 7, 0, 127, -64.0, 63, S_TEMP, INDOOR_TEMP }, //Indoor Air Temperature
		{ true, 61, 7, 0, 127, -64.0, 63, S_TEMP, EXHAUST_TEMP }, //Exhaust Air Temperature
		{ true, 68, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, SUPPLY_FAN_RATE }, //Supply Air Fan Air Flow Rate
		{ true, 78, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, EXHAUST_FAN_RATE }, //Exhaust Air Fan Air Flow Rate
		{ true, 88, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, SUPPLY_FAN_SPEED }, //Supply Fan Speed
		{ true, 100, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, EXHAUST_FAN_SPEED }, //Exhaust Fan Speed
		{ true, 4, 12, 0, 4095, 0, 4095, S_VALUE, SW_VERSION }, //Software Version Info
		{ true, 16, 16, 0, 65535, 0, 196605, S_TIME, 0 }, //Operation Hours Counter
		{ true, 32, 16, 0, 65535, 0, 65535, S_VALUE, DIGITAL_INPUT_STATUS }, //Digital Input Status
		{ true, 48, 16, 0, 65535, 0, 65535, S_VALUE, DIGITAL_OUTPUT_STATUS }, //Digital Output Status
		{ true, 64, 16, 0, 65535, 0, 65535, S_VALUE, INFO_MSG_STATUS }, //Info Message Status
		{ true, 80, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_VALUE, FAULT_STATUS }, //Fault Status
		{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
	},
	//Type 0x11
	{
		{ true, 5, 3, 0, 2, 0, 2, E_CONTROLLER_MODE, REQUESTED_MSG_TYPE }, //Requested Message Type
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, DIRECT_OP_MODE }, //Direct Operation Mode
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL }, //Timer Operation Control
		{ true, 17, 7, 0, 127, 0, 127, S_PERCENTAGE, CO2_TRHESHOLD }, //CO2 Threshold
		{ true, 25, 7, 0, 127, 0, 127, S_RELHUM, 0 }, //Humidity Threshold
		{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_TRHESHOLD }, //Air Quality Threshold
		{ true, 41, 7, 0, 127, -63.0, 64, S_TEMP, ROOM_TEMP }, //Room Temperature Threshold
		{ true, 4, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE_CTRL }, //Operation Mode
		{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, SAFTEY_MODE }, //Safety Mode Status
		{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, HEAT_EXCHANGE_CTRL }, //Heat Exchanger Bypass Control
		{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, DEFROST_MODE }, //Defrost Mode Status
		{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, COOLING_PROTECTION }, //Cooling Protection Status
		{ true, 18, 1, 0, 1, 0, 1, F_ON_OFF, OUTDOOR_HEATER_STATUS }, //Outdoor Air Heather Status
		{ true, 19, 1, 0, 1, 0, 1, F_ON_OFF, SUPPLY_HEATER_STATUS }, //Supply Air Heather Status
		{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, TIMER_OP_CTRL_STATUS }, //Timer Operation Mode Status
		{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, FILTER_MAINTENANCE }, //Filter Maintenance Status
		{ true, 23, 1, 0, 1, 0, 1, F_ON_OFF, WEEKLY_PROGRAM }, //Weekly Timer Program Status
		{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, ROOM_TEMP_CTRL }, //Room Temperature Control Status
		{ true, 25, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_1 }, //Air Quality Threshold 1
		{ true, 33, 7, 0, 127, 0, 127, S_PERCENTAGE, AIR_QUALITY_2 }, //Air Quality Threshold 2
		{ true, 40, 7, 0, 127, -64.0, 63, S_TEMP, OUTDOOR_TEMP }, //Outdoor Air Temperature
		{ true, 47, 7, 0, 127, -64.0, 63, S_TEMP, SUPPLY_TEMP }, //Supply Air Temperature
		{ true, 54, 7, 0, 127, -64.0, 63, S_TEMP, INDOOR_TEMP }, //Indoor Air Temperature
		{ true, 61, 7, 0, 127, -64.0, 63, S_TEMP, EXHAUST_TEMP }, //Exhaust Air Temperature
		{ true, 68, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, SUPPLY_FAN_RATE }, //Supply Air Fan Air Flow Rate
		{ true, 78, 10, 0, 1023, 0.0, 1023.0, S_VOLFLOW, EXHAUST_FAN_RATE }, //Exhaust Air Fan Air Flow Rate
		{ true, 88, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, SUPPLY_FAN_SPEED }, //Supply Fan Speed
		{ true, 100, 12, 0, 4095, 0.0, 4095.0, S_ROTATION_PER_MIN, EXHAUST_FAN_SPEED }, //Exhaust Fan Speed
		{ true, 4, 12, 0, 4095, 0, 4095, S_VALUE, SW_VERSION }, //Software Version Info
		{ true, 16, 16, 0, 65535, 0, 196605, S_TIME, 0 }, //Operation Hours Counter
		{ true, 32, 16, 0, 65535, 0, 65535, S_VALUE, DIGITAL_INPUT_STATUS }, //Digital Input Status
		{ true, 48, 16, 0, 65535, 0, 65535, S_VALUE, DIGITAL_OUTPUT_STATUS }, //Digital Output Status
		{ true, 64, 16, 0, 65535, 0, 65535, S_VALUE, INFO_MSG_STATUS }, //Info Message Status
		{ true, 80, 32, 0, 0xFFFFFFFF, 0, 4294967295.0f, S_VALUE, FAULT_STATUS }, //Fault Status
		{ true, 0, 3, 0, 3, 0, 3, E_COMMAND, 0 }, //Command ID
	},
};

eoEEP_D250xx::eoEEP_D250xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x50;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D250xx::~eoEEP_D250xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_D250xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 1 || m.GetDataLength() > 14)
		return NOT_SUPPORTED;

	uint8_t cmd = (m.data[0] >> 5 & 0x07);
	if(SetCommand(cmd)!=EO_OK)
		return NOT_SUPPORTED;

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D250xx::SetType(uint8_t type)
{
	this->type = type;
	if (type != 0x00 && type != 0x01 && type != 0x10 && type != 0x11)
		return NOT_SUPPORTED;

	SetLength (type);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D250xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommmands)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	msg.Clear();
	SetRawValue(msg, rawValue, 0, 3);
	const uint8_t dataLength [] = {1, 6, 14, 14};
	msg.SetDataLength(dataLength[cmd],true);
	if(cmd==this->cmd )
		return EO_OK;

	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD250xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD250xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD250xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD250xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD250xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	// Set the proper message length depending on the command type
	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D250xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	return NOT_SUPPORTED;
}

eoReturn eoEEP_D250xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	return NOT_SUPPORTED;
}

eoReturn eoEEP_D250xx::GetValue(CHANNEL_TYPE type, float &value)
{
	//SetCommand(msg.data[0] & 0x0F);
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
		case S_RELHUM:
		case S_TEMP:
		case S_VOLFLOW:
		case S_ROTATION_PER_MIN:
		case S_VALUE:
		case S_TIME:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D250xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd > 0x03)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
		case S_RELHUM:
		case S_TEMP:
		case S_VOLFLOW:
		case S_ROTATION_PER_MIN:
		case S_VALUE:
		case S_TIME:
			break;
		default:
			return NOT_SUPPORTED;
	}

	rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D250xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_CONTROLLER_MODE:
			switch(index)
			{
				case REQUESTED_MSG_TYPE:
				case DIRECT_OP_MODE:
				case OP_MODE_CTRL:
				case HEAT_EXCHANGE_CTRL:
					value = (uint8_t)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case F_ON_OFF:
			switch(index)
			{
				case TIMER_OP_CTRL:
				case SAFTEY_MODE:
				case HEAT_EXCHANGE_CTRL:
				case SUPPLY_AIR_POS:
				case EXHAUST_AIR_POS:
				case DEFROST_MODE:
				case COOLING_PROTECTION:
				case OUTDOOR_HEATER_STATUS:
				case SUPPLY_HEATER_STATUS:
				case DRAIN_HEATER_STATUS:
				case TIMER_OP_CTRL_STATUS:
				case FILTER_MAINTENANCE:
				case WEEKLY_PROGRAM:
				case ROOM_TEMP_CTRL:
				case MASTER_SLAVE_CONFIG:
					value = rawValue ? 1 : 0;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D250xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd > 0x03)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_CONTROLLER_MODE:
			switch(index)
			{
				case REQUESTED_MSG_TYPE:
				case DIRECT_OP_MODE:
				case OP_MODE_CTRL:
				case HEAT_EXCHANGE_CTRL:
					rawValue = (uint8_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case F_ON_OFF:
			switch(index)
			{
				case TIMER_OP_CTRL:
				case SAFTEY_MODE:
				case HEAT_EXCHANGE_CTRL:
				case SUPPLY_AIR_POS:
				case EXHAUST_AIR_POS:
				case DEFROST_MODE:
				case COOLING_PROTECTION:
				case OUTDOOR_HEATER_STATUS:
				case SUPPLY_HEATER_STATUS:
				case DRAIN_HEATER_STATUS:
				case TIMER_OP_CTRL_STATUS:
				case FILTER_MAINTENANCE:
				case WEEKLY_PROGRAM:
				case ROOM_TEMP_CTRL:
				case MASTER_SLAVE_CONFIG:
					rawValue = value ? 1 : 0;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return SetValue(type, value);
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D250xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	//Only channel in this profile is the Occupied channel, thats why we only check against NULL
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
			switch (index)
			{
				case CO2_TRHESHOLD:
				case AIR_QUALITY_TRHESHOLD:
				case AIR_QUALITY_1:
				case AIR_QUALITY_2:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_TEMP:
			switch (index)
			{
				case ROOM_TEMP:
				case OUTDOOR_TEMP:
				case SUPPLY_TEMP:
				case INDOOR_TEMP:
				case EXHAUST_TEMP:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_VOLFLOW:
			switch (index)
			{
				case SUPPLY_FAN_RATE:
				case EXHAUST_FAN_RATE:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_ROTATION_PER_MIN:
			switch (index)
			{
				case SUPPLY_FAN_SPEED:
				case EXHAUST_FAN_SPEED:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_VALUE:
			switch (index)
			{
				case SW_VERSION:
				case DIGITAL_INPUT_STATUS:
				case DIGITAL_OUTPUT_STATUS:
				case INFO_MSG_STATUS:
				case FAULT_STATUS:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			//return GetValue(type, value);
			return NOT_SUPPORTED;
	}
	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoEEP_D250xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd > 0x03)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
			switch (index)
			{
				case CO2_TRHESHOLD:
				case AIR_QUALITY_TRHESHOLD:
				case AIR_QUALITY_1:
				case AIR_QUALITY_2:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_TEMP:
			switch (index)
			{
				case ROOM_TEMP:
				case OUTDOOR_TEMP:
				case SUPPLY_TEMP:
				case INDOOR_TEMP:
				case EXHAUST_TEMP:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_VOLFLOW:
			switch (index)
			{
				case SUPPLY_FAN_RATE:
				case EXHAUST_FAN_RATE:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_ROTATION_PER_MIN:
			switch (index)
			{
				case SUPPLY_FAN_SPEED:
				case EXHAUST_FAN_SPEED:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_VALUE:
			switch (index)
			{
				case SW_VERSION:
				case DIGITAL_INPUT_STATUS:
				case DIGITAL_OUTPUT_STATUS:
				case INFO_MSG_STATUS:
				case FAULT_STATUS:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}
	rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D250xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD250xx[this->cmd][tmpChannelCount].type == type && listD250xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D250xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD250xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD250xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD250xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD250xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD250xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
