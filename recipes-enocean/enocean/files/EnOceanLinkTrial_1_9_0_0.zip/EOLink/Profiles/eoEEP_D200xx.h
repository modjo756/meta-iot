/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D200_H__INCLUDED_)
#define eoEEP_D200_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D200xx
 * \brief The class to handle EEP D200 profiles
 * \details Allows the user to handle EEP D200 profiles, the following profiles are available:
 * 		- D2-00-01\n
 *
 * 	NOTE: set command before using the profile.\n
 *
 * The following channels are available in First User Action on RCP:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|uint8_t | Valid configuration, ::RCP_CONFIG_VALID |
 * | 1             | ::E_USER_ACTION	|::RCP_USER_ACTION |  |
 * \n
 *
 * The following channels are available in Display Content:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|uint8_t | User notification, ::RCP_USER_NOTIFICATION |
 * | 1             | ::F_OPEN_CLOSED	|uint8_t |  |
 * | 2             | ::F_ON_OFF			|uint8_t | Dew point, ::RCP_DEW_POINT |
 * | 3             | ::F_ON_OFF			|uint8_t | Cooling, ::RCP_COOLING |
 * | 4             | ::F_ON_OFF			|uint8_t | Heating, ::RCP_HEATING |
 * | 5             | ::S_TEMP			|float | Room temperature °C, ::RCP_ROOM_TEMPERATURE_C |
 * | 6             | ::S_TEMP			|float | Room temperature °F, ::RCP_ROOM_TEMPERATURE_F |
 * | 7             | ::S_TEMP			|float | Nominal temperature °C, ::RCP_NOMINAL_TEMPERATURE_C |
 * | 8             | ::S_TEMP			|float | Nominal temperature °F, ::RCP_NOMINAL_TEMPERATURE_F |
 * | 9             | ::S_TEMP_ABS		|float | Delta Temperature Set Point °C, ::RCP_DELTA_TEMP_SETPOINT_C |
 * | 10            | ::S_TEMP_ABS		|float | Delta Temperature Set Point °F, ::RCP_DELTA_TEMP_SETPOINT_F |
 * | 11            | ::S_TEMP_ABS		|float | Delta Temperature Set Point (graphical), ::RCP_DELTA_TEMP_GRAPHIC |
 * | 12            | ::S_TIME			|float | Hours in 24h format, ::RCP_TIME_24_HOURS |
 * | 13            | ::S_TIME			|float | AM hours in 12h format, ::RCP_TIME_AM_HOURS |
 * | 14            | ::S_TIME			|float | PM hours in 12h format, ::RCP_TIME_PM_HOURS |
 * | 15            | ::S_TIME			|float | Date [DD.MM], ::RCP_TIME_DAY_MONTH |
 * | 16            | ::S_TIME			|float | Date [MM.DD], ::RCP_TIME_MONTH_DAY |
 * | 17            | ::S_LUMINANCE		|float |  |
 * | 18            | ::S_PERCENTAGE		|float |  |
 * | 19            | ::S_CONC			|float |   |
 * | 20            | ::S_RELHUM			|float |    |
 * | 21            | ::F_ON_OFF			|uint8_t | Fan manual, ::RCP_FAN_MANUAL |
 * | 22            | ::E_FANSPEED		|::RCP_5_LEVEL_FANSPEED |  |
 * | 23            | ::F_ON_OFF			|uint8_t | More data will follow, ::RCP_MORE_DATA |
 * \n
 *
 * The following channels are available in Repeated User Action on RCP:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_TEMP_ABS		|float |
 * | 1             | ::E_PRESENCE		|::RCP_PRESENCE |
 * | 2             | ::E_FANSPEED		|::RCP_6_LEVEL_FANSPEED |
 * \n
 *
 * The following channels are available in Measurement result:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_TEMP	|float |
 * \n
 *
 * The following channels are available in Sensor configuration:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_TEMP_ABS		|float | Temperature difference between two subsequent measurements to trigger a Message Type D |
 * | 1             | ::S_TIME			|float | Keep alive timing, ::RCP_KEEP_ALIVE_TIME |
 * | 2             | ::E_PRESENCE		|uint8_t | User defined |
 * | 3             | ::E_FANSPEED		|uint8_t | User defined |
 * | 4             | ::S_TIME			|float | Temperature measurement timing, ::RCP_TEMP_MEASUREMENT_TIMING |
 * | 5             | ::S_SETPOINT		|float | Set pointSteps, ::RCP_SETPOINT_STEPS |
 * | 6             | ::S_SETPOINT		|float | Set point range limit, ::RCP_SETPOINT_RANGE_LIMIT |
 * | 7             | ::F_ON_OFF			|uint8_t | More data will follow, ::RCP_MORE_DATA |
 * \n
 */

/**
 * \file eoEEP_D200xx.h
 */
//! Index enums for D2-00-xx profiles
typedef enum
{
	//! <b>Config valid</b> 0
	RCP_CONFIG_VALID = 0x00,
	//! <b>User notification</b> 1
	RCP_USER_NOTIFICATION = 0x01,
	//! <b>Dew point</b> 2
	RCP_DEW_POINT = 0x02,
	//! <b>Cooling</b> 3
	RCP_COOLING = 0x03,
	//! <b>Heating</b> 4
	RCP_HEATING = 0x04,
	//! <b>Fan manual</b> 5
	RCP_FAN_MANUAL = 0x05,
	//! <b>More data</b> 6
	RCP_MORE_DATA = 0x06,
	//! <b>Kepp alive timing</b> 7
	RCP_KEEP_ALIVE_TIME = 0x07,
	//! <b>Temperature measurement timing</b> 8
	RCP_TEMP_MEASUREMENT_TIMING = 0x08,
	//! <b>Set point steps</b> 9
	RCP_SETPOINT_STEPS = 0x09,
	//! <b>Set point range limit</b> 10
	RCP_SETPOINT_RANGE_LIMIT = 0x0A,
	//! <b>Do not display</b> 11
	RCP_NO_DISPLAY = 0x0B,
	//! <b>Room temperature in °C</b> 12
	RCP_ROOM_TEMPERATURE_C = 0x0C,
	//! <b>Room temperature in °F</b> 13
	RCP_ROOM_TEMPERATURE_F = 0x0D,
	//! <b>Nominal temperature in °C</b> 14
	RCP_NOMINAL_TEMPERATURE_C = 0x0E,
	//! <b>Nominal temperature in °F</b> 15
	RCP_NOMINAL_TEMPERATURE_F = 0x0F,
	//! <b>Delta temperature set point in °C</b> 16
	RCP_DELTA_TEMP_SETPOINT_C = 0x10,
	//! <b>Delta temperature set point in °F</b> 17
	RCP_DELTA_TEMP_SETPOINT_F = 0x11,
	//! <b>Delta temperature set point (graphical)</b> 17
	RCP_DELTA_TEMP_GRAPHIC = 0x12,
	//! <b>Time in 24h format</b> 18
	RCP_TIME_24_HOURS = 0x13,
	//! <b>Time in 12h format (AM)</b> 19
	RCP_TIME_AM_HOURS = 0x14,
	//! <b>Time in 12h format (PM)</b> 20
	RCP_TIME_PM_HOURS = 0x15,
	//! <b>Date in dd.mm format</b> 21
	RCP_TIME_DAY_MONTH = 0x16,
	//! <b>Date in mm.dd format</b> 22
	RCP_TIME_MONTH_DAY = 0x17
} RCP_INDEXS;

//! Command enums for D2-00-xx profiles
typedef enum
{
	//! <b>First user action on RCP</b> 1
	RCP_FIRST_USER_ACTION = 0x01,
	//! <b>Display content</b> 2
	RCP_DISPLAY_CONTENT = 0x02,
	//! <b>Repeated user action on RCP</b> 3
	RCP_REPEATED_USER_ACTION = 0x03,
	//! <b>Measurement result</b> 4
	RCP_MEASUREMENT_RESULT = 0x04,
	//! <b>Sensor configuration</b> 5
	RCP_SENSOR_CONFIG = 0x05
} RCP_COMMANDS;

//! User action enums for D2-00-xx profiles
typedef enum
{
	//! <b>Presence</b> 1
	PRESENCE = 0x01,
	//! <b>Temperature set point "down" or "-"</b> 2
	TEMP_DOWN = 0x02,
	//! <b>Temperature set point "up" or "+"</b> 5
	TEMP_UP = 0x05,
	//! <b>Fan</b> 6
	FAN = 0x06
} RCP_USER_ACTION;

//! Presence enums for D2-00-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	NO_CHANGE = 0x00,
	//! <b>Present</b> 1
	PRESENT = 0x01,
	//! <b>Not present</b> 2
	NOT_PRESENT = 0x02,
	//! <b>Night time reduction</b> 3
	NIGHT_TIME = 0x03
} RCP_PRESENCE;

//! 5 level fan speed enums for D2-00-xx profiles
typedef enum
{
	//! <b>Do not display</b> 0
	RCP_DO_NOT_DISPLAY = 0x00,
	//! <b>Speed level 0</b> 1
	RCP_SPEED_LEVEL_0 = 0x01,
	//! <b>Speed level 1</b> 2
	RCP_SPEED_LEVEL_1 = 0x02,
	//! <b>Speed level 2</b> 3
	RCP_SPEED_LEVEL_2 = 0x03,
	//! <b>Speed level 3</b> 4
	RCP_SPEED_LEVEL_3 = 0x04
} RCP_5_LEVEL_FANSPEED;

//! 6 level fan speed enums for D2-00-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	FAN_NO_CHANGE = 0x00,
	//! <b>Speed level 0</b> 1
	SPEED_LEVEL_0 = 0x01,
	//! <b>Speed level 1</b> 2
	SPEED_LEVEL_1 = 0x02,
	//! <b>Speed level 2</b> 3
	SPEED_LEVEL_2 = 0x03,
	//! <b>Speed level 3</b> 4
	SPEED_LEVEL_3 = 0x04,
	//! <b>Speed level Auto</b> 5
	SPEED_LEVEL_AUTO = 0x05
} RCP_6_LEVEL_FANSPEED;

class eoEEP_D200xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D200xx(uint16_t size = 10);
	virtual ~eoEEP_D200xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
