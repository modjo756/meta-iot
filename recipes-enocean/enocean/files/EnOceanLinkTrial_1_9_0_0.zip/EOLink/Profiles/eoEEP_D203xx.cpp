/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D203xx.h"

#include "eoChannelEnums.h"
#include <string.h>
#include <typeinfo>
const uint8_t numOfChan = 4;
const uint8_t numOfProfiles = 3;

//Channels have to be in the right order for the getChannel function
const EEP_ITEM listD203xx[numOfProfiles][numOfChan] =
{
// exist,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00
{
//Temperature
	{ true, 4, 4, 0, 4, 0.0, 4.0, E_ROCKER_A, 0 },
	{ true, 4, 4, 0, 4, 0.0, 4.0, E_ROCKER_B, 0 },
	{ true, 4, 4, 0, 4, 0.0, 4.0, E_ENERGYBOW, 0 },
	{ true, 4, 4, 0, 4, 0.0, 4.0, E_MULTIPRESS, 0 },
},

//TYPE:10
{
	{ true, 0, 8, 0, 8, 0.0, 255.0, E_WINDOWHANDLE, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},

//TYPE:20
{
	{ true, 0, 1, 0, 1, 0, 1, E_STATE, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
};
//Channels have to be in the right order for the getChannel function

eoEEP_D203xx::eoEEP_D203xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x03;
	msg.dataLength=1;
	msg.RORG = RORG_VLD;

	ClearValues();
}

uint8_t eoEEP_D203xx::RockerSetHelper()
{
	uint8_t rawValue=0;
	if (energybowReleased)
		rawValue = 0x0F;
	else if(multipress)
		rawValue = 0x06;
	else
	{
		switch(rockerA)
		{
			case STATE_I:
			switch(rockerB)
			{
				case STATE_I:
					rawValue=9;
					break;
				case STATE_O:
					rawValue=5;
					break;
				default:
					rawValue=13;
					break;
			}
			break;

			case STATE_O:
			switch(rockerB)
			{
				case STATE_I:
					rawValue=10;
					break;
				case STATE_O:
					rawValue=7;
					break;
				default:
					rawValue=14;
					break;
			}
			break;

			default:
				switch(rockerB)
				{
					case STATE_I:
						rawValue=11;
						break;
					case STATE_O:
						rawValue=12;
						break;
					default:
						rawValue=8;
						break;
				}
				break;
		}
	}
	return rawValue;

}
eoEEP_D203xx::~eoEEP_D203xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

void eoEEP_D203xx::ClearValues()
{
	eoD2EEProfile::ClearValues();
	rockerA = STATE_NP;
	rockerB = STATE_NP;
	multipress = false;
	energybowReleased = false;
}
eoReturn eoEEP_D203xx::Parse(const eoMessage &msg)
{
	if (msg.GetDataLength() == 1 && ( msg.RORG == RORG_VLD || IsSecDData(msg)))
	{
		return eoProfile::Parse(msg);
	}
	return NOT_SUPPORTED;
}

eoReturn eoEEP_D203xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;
	if (!(type == 0 || type == 0x10 || type == 0x20))
		return NOT_SUPPORTED;
	uint8_t virtualType;

	switch (type)
	{
		case 0x00:
			virtualType = 0;
			break;
		case 0x10:
			virtualType = 1;
			break;
		case 0x20:
			virtualType = 2;
			break;
		default:
			return NOT_SUPPORTED;
	}

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD203xx[virtualType][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD203xx[virtualType][tmpChannelCount].type;
			channel[channelCount].max = listD203xx[virtualType][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD203xx[virtualType][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD203xx[virtualType][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;
	this->type = type;

	return EO_OK;
}


eoReturn eoEEP_D203xx::RockerHelper()
{
	eoReturn ret = EO_OK;
	rockerA = STATE_NP;
	rockerB = STATE_NP;
	energybowReleased = true;
	multipress = false;

	switch (msg.data[0])
	{
		case 0x05:
			rockerA = STATE_I;
			rockerB = STATE_O;
			break;
		case 0x06:
			multipress = true;
			break;
		case 0x07:
			rockerA = STATE_O;
			rockerB = STATE_O;
			break;
		case 0x08:
			rockerA = STATE_NP;
			rockerB = STATE_NP;
			break;
		case 0x09:
			rockerA = STATE_I;
			rockerB = STATE_I;
			break;
		case 0x0A:
			rockerA = STATE_O;
			rockerB = STATE_I;
			break;
		case 0x0B:
			rockerA = STATE_NP;
			rockerB = STATE_I;
			break;
		case 0x0C:
			rockerA = STATE_NP;
			rockerB = STATE_O;
			break;
		case 0x0D:
			rockerA = STATE_I;
			rockerB = STATE_NP;
			break;
		case 0x0E:
			rockerA = STATE_O;
			rockerB = STATE_NP;
			break;
		case 0x0F:
			energybowReleased = false;
			break;
		default:
			ret = NOT_SUPPORTED;
			break;
	}

	return ret;
}

eoReturn eoEEP_D203xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	eoReturn ret = EO_OK;
	eoEEPChannelInfo *chan = (eoEEPChannelInfo *) GetChannel(type);
	uint32_t rawValue;
	if (chan == NULL)
		return NOT_SUPPORTED;

	switch (type)
	{
		case E_ROCKER_A:
			if (RockerHelper() == EO_OK)
				value = rockerA;
			else
				ret = NOT_SUPPORTED;
			break;
		case E_ROCKER_B:
			if (RockerHelper() == EO_OK)
				value = rockerB;
			else
				ret = NOT_SUPPORTED;
			break;
		case E_ENERGYBOW:
			if (RockerHelper() == EO_OK)
				value = energybowReleased;
			else
				ret = NOT_SUPPORTED;
			break;
		case E_MULTIPRESS:
			if (RockerHelper() == EO_OK)
				value = multipress;
			else
				ret = NOT_SUPPORTED;
			break;
		case E_WINDOWHANDLE:
				GetRawValue(msg, rawValue, chan->eepItem->bitoffs, (uint8_t)chan->eepItem->bitsize);
				switch(rawValue)
				{
					case 1:
					case 3:
						value = WINDOW_MIDDLE;
						break;
					case 4:
						value = WINDOW_UP;
						break;
					case 2:
						value = WINDOW_DOWN;
						break;
					default:
						ret = NOT_SUPPORTED;
				}
			break;
			case E_STATE:
				GetRawValue(msg, rawValue, chan->eepItem->bitoffs, (uint8_t)chan->eepItem->bitsize);
				value = (uint8_t)rawValue;
				break;
		default:
			ret = NOT_SUPPORTED;
			break;
	}

	return ret;
}

eoReturn eoEEP_D203xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	eoReturn ret = EO_OK;
	eoEEPChannelInfo *chan = (eoEEPChannelInfo *) GetChannel(type);
	if (chan == NULL)
		return NOT_SUPPORTED;

	uint32_t rawValue = 0;
	switch (type)
	{
		case E_ROCKER_A:
			rockerA = value;
			break;

		case E_ROCKER_B:
			rockerB = value;
			break;

			break;
		case E_ENERGYBOW:
			energybowReleased = value == ENERGY_RELEASED;
			break;
		case E_MULTIPRESS:
			multipress = value == MULTIPRESS_YES;
			break;
		case E_WINDOWHANDLE:
			switch(value)
			{
				case WINDOW_MIDDLE:
					rawValue = 1;
					break;
				case WINDOW_UP:
					 rawValue = 4;
					break;
				case WINDOW_DOWN:
					rawValue = 2;
					break;
				default:
					ret = NOT_SUPPORTED;
					break;
			}
			break;
			case E_STATE:
				rawValue = (uint32_t)value;
				break;
		default:
			return NOT_SUPPORTED;
			break;
	}
	if(this->type==0)
		rawValue = RockerSetHelper();

	if(rawValue==0 && this->type != 0x20)
		return NOT_SUPPORTED;

	ret = SetRawValue(msg, rawValue,  chan->eepItem->bitoffs, (uint8_t)chan->eepItem->bitsize);
	return ret;
}
