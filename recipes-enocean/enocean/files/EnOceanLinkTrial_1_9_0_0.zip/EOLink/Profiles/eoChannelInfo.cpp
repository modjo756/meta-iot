#include "eoChannelInfo.h"

const char* eoChannelInfo::ToString(uint8_t strType)
{
	if (strType == UNIT)
	{
		if (type < T_FLAG && (type & 0x00FF)<NUM_SIGNAL_STRINGS )
			return signalStrings[type & 0x00FF][1];
	}
	else
	{
		uint8_t reducedType = type & 0x00FF;
		if (type < T_FLAG &&  reducedType < NUM_SIGNAL_STRINGS)
			return signalStrings[reducedType][0];
		if (type < GP_ENUM && (reducedType)<NUM_GP_ENUMS_STRING)
			return flagStrings[reducedType];
		if (type < T_ENUM && (reducedType)<NUM_FLAG_STRINGS)
			return gpEnumString[reducedType];
		if((type & 0x00FF)<NUM_ENUMS_STRINGS)
			return enumStrings[reducedType];
	}
	return signalStrings[0][0];
}
