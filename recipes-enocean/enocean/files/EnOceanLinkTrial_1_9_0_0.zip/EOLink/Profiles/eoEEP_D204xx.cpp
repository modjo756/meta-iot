/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D204xx.h"

#include "eoChannelEnums.h"
#include <string.h>
#include <typeinfo>

const uint8_t numOfChan = 5;
const uint8_t numOfProfiles = 0x1F;
const EEP_ITEM listD204xx[numOfProfiles][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 8, 8, 0, 200, 0, 100.0, S_RELHUM, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 }, },
//TYPE:01
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 8, 8, 0, 200, 0, 100.0, S_RELHUM, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:02
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:03
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:04
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:05
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:06
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:07
{
{ true, 0, 8, 0, 255, 0, 2000.0, S_CONC, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:08
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 8, 8, 0, 200, 0, 100.0, S_RELHUM, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 }, },
//TYPE:09
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 8, 8, 0, 200, 0, 100.0, S_RELHUM, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:0A
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:0B
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:0C
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:0D
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:0E
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:0F
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:10
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:11
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:12
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:13
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:14
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:15
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:16
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:17
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:18
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:19
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:1A
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:1B
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:1C
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:1D
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//TYPE:1E
{
{ true, 0, 8, 0, 255, 0, 5000.0, S_CONC, 0 },
{ true, 24, 1, 0, 1, 0, 1, F_DAY_NIGHT, 0 },
{ true, 25, 3, 0, 7, 0, 7, E_STATE, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
};

eoEEP_D204xx::eoEEP_D204xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x04;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(size);
}

eoEEP_D204xx::~eoEEP_D204xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_D204xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD204xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD204xx[type][tmpChannelCount].type;
			channel[channelCount].max = listD204xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD204xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD204xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;
	this->type = type;

	return EO_OK;
}

eoReturn eoEEP_D204xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_CONC:
		case S_RELHUM:
		case S_TEMP:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;

	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoReturn eoEEP_D204xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	//SEE EEP SPEC
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_CONC:
		case S_RELHUM:
		case S_TEMP:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
	}
	return EO_OK;
}

eoReturn eoEEP_D204xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_DAY_NIGHT:
		case E_STATE:
			value = (uint8_t) rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D204xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_DAY_NIGHT:
		case E_STATE:
			rawValue = (uint32_t)value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK;
}
