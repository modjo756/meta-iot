/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoGenericProfile.h"
#include "eoConverter.h"

const GP_RESOLUTION RESTOGPRES[15] =
{ GP_RES_RES, GP_RES_2BIT, GP_RES_3BIT, GP_RES_4BIT, GP_RES_5BIT, GP_RES_6BIT, GP_RES_8BIT, GP_RES_10BIT, GP_RES_12BIT, GP_RES_16BIT, GP_RES_20BIT, GP_RES_24BIT, GP_RES_32BIT, GP_RES_RES, GP_RES_RES };
const uint8_t GPRESTORES[33] =
{0x00, 0x00,0x01,0x02,0x03,0x04,0x05,0x00,0x06,0x00,0x07,0x00,0x08,0x00,0x00,0x00,0x09,0x00,0x00,0x00,0x0A,0x00,0x00,0x00,0x0B,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0C};

//size according to eoProfiles...
eoGenericProfile::eoGenericProfile()
	: eoProfile(256)
{
	curBitOffset = 0;
	curBitOffsetOut = 0;
	msg.SetDataLength(0);
	dataDirection = UNIDIRECTIONAL;
	purpose = RESP_NA;

	parseTeachIn = false;
	productId = 0;
	this->rorg = 0xB0;
}

eoGenericProfile::eoGenericProfile(uint16_t msgLength)
	: eoProfile(msgLength)
{
	curBitOffset = 0;
	curBitOffsetOut = 0;
	parseTeachIn = false;
	msg.SetDataLength(0);
	dataDirection = UNIDIRECTIONAL;
	purpose = RESP_NA;
	productId = 0;
	this->rorg = 0xB0;
	func = 0;
	type = 0;
}

void eoGenericProfile::AllowTeachIN()
{
	parseTeachIn = true;
}

eoGenericProfile::~eoGenericProfile()
{

}
bool eoGenericProfile::operator==(const eoGenericProfile &othProfile) const
{
	return false;
}
bool eoGenericProfile::operator!=(const eoGenericProfile &othProfile) const
{
	return true;
}

eoReturn eoGenericProfile::CreateTeachIN(eoMessage &msg)
{
	//Just copy the changed values into the msg...
	eoReturn ret = EO_OK;
	uint32_t tmpvalue;
	uint16_t curChanOffset = 0;
	uint16_t numChannels = 0;
	uint16_t numOutChannels = 0;
	uint16_t dateLen = 0;
	//calculate the needed datalength in bits, header is 16bits long
	uint32_t bitsize = 16;
	msg.Clear();
	msg.RORG = GP_TI;
	msg.destinationID = BROADCAST_ID;
	while (numChannels < gpChannels.size() && ret == EO_OK)
	{
		switch (gpChannels[numChannels].GetGPChannelType())
		{
			case GP_DATA:
				bitsize += 40;
				break;
			case GP_FLAG:
				bitsize += 12;
				break;
			case GP_ENUMERATION:
				bitsize += 16;
				break;
			default:
				break;
		}
		numChannels++;
	}
	while (numOutChannels < gpChannelsOut.size() && ret == EO_OK)
	{
		switch (gpChannelsOut[numOutChannels].GetGPChannelType())
		{
			case GP_DATA:
				bitsize += 40;
				break;
			case GP_FLAG:
				bitsize += 12;
				break;
			case GP_ENUMERATION:
				bitsize += 16;
				break;
			default:
				break;
		}
		numOutChannels++;
	}

	if (numChannels != 0)
	{
		dataDirection=BIDIRECTIONAL;
		bitsize += 18;
	}

	if (productId != 0x00)
		bitsize += 50;

	if (bitsize % 8 == 0)
		dateLen = (uint16_t)(bitsize / 8);
	else
		dateLen = (uint16_t)(bitsize / 8 + 1);

	ret = msg.SetDataLength(dateLen);

	if (ret == EO_OK)
	{
		tmpvalue = (uint32_t) manufacturer;
		SetRawValue(msg, tmpvalue, GP_MANUFACTURER_OFF, GP_MANUFACTURER_LEN);

		tmpvalue = (uint32_t) GP_TEACH_IN;
		SetRawValue(msg, tmpvalue, GP_PURPOSE_OFF, GP_PURPOSE_LEN);

		tmpvalue = (uint32_t) dataDirection;
		SetRawValue(msg, tmpvalue, GP_DATA_DIRECTION_OFF, GP_DATA_DIRECTION_LEN);

		//Writing in Teach-in Information
		if (productId != 0)
		{
			tmpvalue = (uint32_t)0;
			SetRawValue(msg, tmpvalue, 16, 2);
			tmpvalue = (uint32_t)2;
			SetRawValue(msg, tmpvalue, 18, 8);
			tmpvalue = (uint32_t)4;
			SetRawValue(msg, tmpvalue, 26, 8);
			tmpvalue = (uint32_t)((productId & 0xFF000000) >> 24);
			SetRawValue(msg, tmpvalue, 34, 8);
			tmpvalue = (uint32_t)((productId & 0xFF0000) >> 16);
			SetRawValue(msg, tmpvalue, 42, 8);
			tmpvalue = (uint32_t)((productId & 0xFF00) >> 8);
			SetRawValue(msg, tmpvalue, 50, 8);
			tmpvalue = (uint32_t)(productId & 0xFF);
			SetRawValue(msg, tmpvalue, 58, 8);
			curChanOffset += 50;
		}
	}
	//Channel Information start
	curChanOffset += 16;
	if (numOutChannels != 0)
	{
		numOutChannels = 0;
		while (numOutChannels < gpChannelsOut.size() && ret == EO_OK)
		{
			tmpvalue = gpChannelsOut[numOutChannels].GetGPChannelType();
			SetRawValue(msg, tmpvalue, curChanOffset, 2);
			curChanOffset += 2;
			tmpvalue = gpChannelsOut[numOutChannels].type & 0x00FF;
			SetRawValue(msg, tmpvalue, curChanOffset, 8);
			curChanOffset += 8;
			tmpvalue = gpChannelsOut[numOutChannels].signalType;
			SetRawValue(msg, tmpvalue, curChanOffset, 2);
			curChanOffset += 2;

			switch (gpChannelsOut[numOutChannels].GetGPChannelType())
			{
				case GP_DATA:
					//RESOLUTION
					tmpvalue = GPRESTORES[gpChannelsOut[numOutChannels].GetResolution()];
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					//Eng Min
					curChanOffset += 4;
					tmpvalue = gpChannelsOut[numOutChannels].GetEngMin();
					SetRawValue(msg, tmpvalue, curChanOffset, 8);
					//Scal Min
					curChanOffset += 8;
					tmpvalue = gpChannelsOut[numOutChannels].GetScaleMin();
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					//Eng Max
					curChanOffset += 4;
					tmpvalue = gpChannelsOut[numOutChannels].GetEngMax();
					SetRawValue(msg, tmpvalue, curChanOffset, 8);
					//Scal Max
					curChanOffset += 8;
					tmpvalue = gpChannelsOut[numOutChannels].GetScaleMax();
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					//next channelstart
					curChanOffset += 4;
					break;
				case GP_FLAG:
					//flag is nothing special
					break;
				case GP_ENUMERATION:
					//RESOLUTION
					tmpvalue = GPRESTORES[gpChannelsOut[numOutChannels].GetResolution()];
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					curChanOffset += 4;
					break;
				default:
					break;
			}

			numOutChannels++;
		}
	}

	if (numChannels != 0)
	{
		tmpvalue = (uint32_t)0;
		SetRawValue(msg, tmpvalue, curChanOffset, 2);
		curChanOffset += 2;
		tmpvalue = (uint32_t)1;
		SetRawValue(msg, tmpvalue, curChanOffset, 8);
		curChanOffset += 8;
		tmpvalue = (uint32_t)0;
		uint16_t dataLenOffset=curChanOffset;

		curChanOffset += 8;

		numChannels = 0;
		while (numChannels < gpChannels.size() && ret == EO_OK)
		{
			tmpvalue = gpChannels[numChannels].GetGPChannelType();
			SetRawValue(msg, tmpvalue, curChanOffset, 2);
			curChanOffset += 2;
			tmpvalue = gpChannels[numChannels].type & 0x00FF;
			SetRawValue(msg, tmpvalue, curChanOffset, 8);
			curChanOffset += 8;
			tmpvalue = gpChannels[numChannels].signalType;
			SetRawValue(msg, tmpvalue, curChanOffset, 2);
			curChanOffset += 2;

			switch (gpChannels[numChannels].GetGPChannelType())
			{
				case GP_DATA:
					//RESOLUTION
					tmpvalue = GPRESTORES[gpChannels[numChannels].GetResolution()];
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					//Eng Min
					curChanOffset += 4;
					tmpvalue = gpChannels[numChannels].GetEngMin();
					SetRawValue(msg, tmpvalue, curChanOffset, 8);
					//Scal Min
					curChanOffset += 8;
					tmpvalue = gpChannels[numChannels].GetScaleMin();
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					//Eng Max
					curChanOffset += 4;
					tmpvalue = gpChannels[numChannels].GetEngMax();
					SetRawValue(msg, tmpvalue, curChanOffset, 8);
					//Scal Max
					curChanOffset += 8;
					tmpvalue = gpChannels[numChannels].GetScaleMax();
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					//next channelstart
					curChanOffset += 4;
					break;
				case GP_FLAG:
					//flag is nothing special
					break;
				case GP_ENUMERATION:
					//RESOLUTION
					tmpvalue = GPRESTORES[gpChannels[numChannels].GetResolution()];
					SetRawValue(msg, tmpvalue, curChanOffset, 4);
					curChanOffset += 4;
					break;
				default:
					break;
			}

			numChannels++;
		}
		uint32_t dataLen=(curChanOffset-dataLenOffset)/8-1;//we've added 1byte
		if((curChanOffset-dataLenOffset)%8!=0)
			dataLen+=1;
		SetRawValue(msg, dataLen, dataLenOffset, 8);
	}

	return ret;
}
eoReturn eoGenericProfile::SetType(uint8_t type)
{
	return EO_OK; //FALLback
}
eoReturn eoGenericProfile::Create(eoMessage &m,std::vector<int> channelNumbers)
{
	if (channelNumbers.size() == 0)
		return OUT_OF_RANGE;

	eoMessage tmpMsg (512);
	tmpMsg.Clear();
	tmpMsg.RORG = GP_SD;
	tmpMsg.destinationID = BROADCAST_ID;

	uint16_t bitsize = 4 + channelNumbers.size() * 6;
	uint16_t dataLength;
	for (uint8_t i = 0; i < channelNumbers.size(); i++)
		bitsize += (uint16_t)gpChannelsOut[channelNumbers[i]].GetResolution();

	if (bitsize % 8 == 0)
		dataLength = (uint16_t)(bitsize / 8);
	else
		dataLength = (uint16_t)(bitsize / 8 + 1);
	tmpMsg.SetDataLength(dataLength,true);

	uint16_t curChanOffset = 0;
	uint32_t rawValue = (uint32_t)channelNumbers.size();
	SetRawValue(tmpMsg, rawValue, curChanOffset, (uint8_t)4);
	curChanOffset += 4;

	for (uint8_t i = 0; i < channelNumbers.size(); i++)
	{
		rawValue = channelNumbers[i];
		eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannelOut(rawValue);
		if (myChan == NULL)
			continue;

		SetRawValue(tmpMsg, rawValue, curChanOffset, (uint8_t)6);
		curChanOffset += 6;
		GetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution());
		SetRawValue(tmpMsg, rawValue, curChanOffset, (uint8_t)myChan->GetResolution());
		curChanOffset += (uint8_t)myChan->GetResolution();
	}

	if(tmpMsg.copyTo(m) != EO_OK)
		return OUT_OF_RANGE;
	return EO_OK;
}

eoReturn eoGenericProfile::ParseSelData(const eoMessage &msg)
{
	//get number of Channels
	uint32_t tmpValue;
	uint16_t curChanOffset = 0;
	uint8_t numChannels;

	GetRawValue(msg, tmpValue, curChanOffset, 4);
	numChannels = (uint8_t) tmpValue;
	curChanOffset += 4;
	//In the Worst Case we get a non valid Generic Profile Message and try to parse it
	while (numChannels-- && curChanOffset < (msg.GetDataLength() * 8))
	{
		uint8_t curChannel;
		GetRawValue(msg, tmpValue, curChanOffset, 6);
		curChannel = (uint8_t) tmpValue;
		curChanOffset += 6;
		//get CurrentCHannelInfo
		eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannel(curChannel);
		if (myChan != NULL)
		{
			GetRawValue(msg, tmpValue, curChanOffset, (uint8_t) myChan->GetResolution());
			SetRawValue(this->msg, tmpValue, myChan->bitoffs, (uint8_t) myChan->GetResolution());
			curChanOffset += (uint8_t) myChan->GetResolution();
		}
	}

	return EO_OK;
}
eoReturn eoGenericProfile::CreateChannels(const eoMessage &msg)
{

	uint8_t scaleLookUp [] =
	{
			GP_SCAL_RES,
			GP_SCAL_1,
			GP_SCAL_10,
			GP_SCAL_100,
			GP_SCAL_1000,
			GP_SCAL_10000,
			GP_SCAL_100000,
			GP_SCAL_1000000,
			GP_SCAL_10000000,
			GP_SCAL_0_1,
			GP_SCAL_0_01,
			GP_SCAL_0_001,
			GP_SCAL_0_000001,
			GP_SCAL_0_000000001
	};

	eoReturn ret = EO_OK;
	bool isOutChannel = false;
	//First 2Bytes header
	uint16_t curChanOffset = 16;
	uint32_t rawvalue;
	GP_CHANNELTYPE gpChannelType;
	CHANNEL_TYPE channelType;
	VALUE_TYPE valueType;
	GP_RESOLUTION resolution = GP_RES_RES;
	int8_t engMaximum = 0;
	int8_t engMinimum = 0;
	GP_SCALING scaleMaximum = GP_SCAL_RES;
	GP_SCALING scaleMinimum = GP_SCAL_RES;

	while (curChanOffset != 0 && (curChanOffset + 8) < (msg.GetDataLength() * 8) && ret == EO_OK)
	{
		GetRawValue(msg, rawvalue, curChanOffset, 2);
		gpChannelType = (GP_CHANNELTYPE) rawvalue;
		curChanOffset += 2;
		//SIGNAL TYPE
		GetRawValue(msg, rawvalue, curChanOffset, 8);
		channelType = (CHANNEL_TYPE) rawvalue;
		//VALUE TYPE
		curChanOffset += 8;
		GetRawValue(msg, rawvalue, curChanOffset, 2);
		valueType = (VALUE_TYPE) rawvalue;
		curChanOffset += 2;

		switch (gpChannelType)
		{
			case GP_DATA:

				switch (valueType)
				{
					case VAL_SP_ABS:
						channelType = (CHANNEL_TYPE) (channelType + SP_ABS);
						break;
					case VAL_SP_REL:
						channelType = (CHANNEL_TYPE) (channelType + SP_REL);
						break;
					default:
						break;
				}
				//RESOLUTION
				GetRawValue(msg, rawvalue, curChanOffset, 4);
				resolution = (GP_RESOLUTION) RESTOGPRES[rawvalue];
				//Eng Min
				curChanOffset += 4;
				GetRawValue(msg, rawvalue, curChanOffset, 8);
				engMinimum = (int8_t)rawvalue;
				//Scal Min
				curChanOffset += 8;
				GetRawValue(msg, rawvalue, curChanOffset, 4);
				scaleMinimum = (GP_SCALING) scaleLookUp[rawvalue];
				//Eng Max
				curChanOffset += 4;
				GetRawValue(msg, rawvalue, curChanOffset, 8);
				engMaximum = (int8_t) rawvalue;
				//Scal Max
				curChanOffset += 8;
				GetRawValue(msg, rawvalue, curChanOffset, 4);
				scaleMaximum = (GP_SCALING) scaleLookUp[rawvalue];
				//next channelstart
				curChanOffset += 4;
				//curChanOffset+=40;
				break;
			case GP_FLAG:
				//Flag - 1bit Value Information are needed for parsing
				resolution = GP_RES_1BIT;
				engMaximum = 1;
				engMinimum = 0;
				scaleMaximum = GP_SCAL_1;
				scaleMinimum = GP_SCAL_1;
				channelType = (CHANNEL_TYPE)((int)channelType + 0xF00);

				break;
			case GP_ENUMERATION:
				//RESOLUTION
				GetRawValue(msg, rawvalue, curChanOffset, 4);
				resolution = (GP_RESOLUTION) RESTOGPRES[rawvalue];
				curChanOffset += 4;
				//ENUM - resolution bit Value Information:min=0, theoretical max = every resolutionbit=1;
				scaleMaximum = GP_SCAL_1;
				scaleMinimum = GP_SCAL_1;
				engMaximum = (int8_t)resolution;
				engMinimum = 0;
				channelType = (CHANNEL_TYPE)((int)channelType + GP_ENUM);
				break;
			case GP_TEACHIN_INFO:
				curChanOffset -= 2;
				GetRawValue(msg,rawvalue,curChanOffset,8);
				curChanOffset += 8;
				if (channelType == 2)
				{
					GetRawValue(msg,rawvalue,curChanOffset,8);
					curChanOffset += 8;
					productId = rawvalue << 24;
					GetRawValue(msg,rawvalue,curChanOffset,8);
					curChanOffset += 8;
					productId |= rawvalue << 16;
					GetRawValue(msg,rawvalue,curChanOffset,8);
					curChanOffset += 8;
					productId |= rawvalue << 8;
					GetRawValue(msg,rawvalue,curChanOffset,8);
					curChanOffset += 8;
					productId |= rawvalue;
				}
				else if (channelType == 1)
					isOutChannel = true;

				continue;
			default:
				ret = NOT_SUPPORTED;
				break;
		}

		if (ret == EO_OK)
		{
			if (isOutChannel)
				AddChannelOut(channelType, resolution, engMaximum, engMinimum, scaleMaximum, scaleMinimum, valueType);
			else
				AddChannel(channelType, resolution, engMaximum, engMinimum, scaleMaximum, scaleMinimum, valueType);
		}

	}
	return ret;
}

eoReturn eoGenericProfile::ParseTeachIN(const eoMessage &msg)
{
	//Just copy the changed values into the msg...
	eoReturn ret = EO_OK;
	if (msg.RORG != GP_TI)
	{
		ret = NOT_SUPPORTED;
	}
	else
	{
		uint32_t tmpvalue;

		GetRawValue(msg, tmpvalue, GP_MANUFACTURER_OFF, GP_MANUFACTURER_LEN);
		manufacturer = (uint16_t) tmpvalue;

		GetRawValue(msg, tmpvalue, GP_PURPOSE_OFF, GP_PURPOSE_LEN);
		purpose = (GP_HEADER_PURPOSE) tmpvalue;

		GetRawValue(msg, tmpvalue, GP_DATA_DIRECTION_OFF, GP_DATA_DIRECTION_LEN);
		dataDirection = (GP_DATA_DIRECTION) tmpvalue;

		switch (purpose)
		{
			case GP_TEACH_IN:
			case GP_TEACH_IN_OUT:
				ClearChannels();
				ClearChannelsOut();
				ret = CreateChannels(msg);
				break;

			case GP_TEACH_OUT:
				ClearChannels();
				ClearChannelsOut();
				break;
			default:
				ret = NOT_SUPPORTED;
				break;
		}
	}
	parseTeachIn = false;
	return ret;
}

eoReturn eoGenericProfile::Parse(const eoMessage &msg)
{
	eoReturn ret = EO_OK;
	switch (msg.RORG)
	{
		case GP_TI:
			ret = ParseTeachIN(msg);
			break;
		case GP_CD:
			ret = msg.copyTo(this->msg);
			break;
		case GP_SD:
			ret = ParseSelData(msg);
			break;
		default:
			ret = NOT_SUPPORTED;
			break;
	}
	return ret;
}

eoReturn eoGenericProfile::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	//if type is enum or digital flag it can not be scaled as a float in this method
	if (((type >= T_FLAG) && (type < SP_ABS)) || (type >= T_ENUM) || (type >= GP_ENUM))
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution()) != EO_OK)
		return NOT_SUPPORTED;

	value = ScaleFromRAW(rawValue, 0, (uint32_t)(((uint64_t)1<<myChan->GetResolution())-1), myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoGenericProfile::GetValue(CHANNEL_TYPE type, float &value, uint8_t subFlag)
{
	uint32_t rawValue;
	eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannel(type, subFlag);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	//if type is enum or digital flag it can not be scaled as a float in this method
	if (((type >= T_FLAG) && (type < SP_ABS)) || (type >= T_ENUM) || (type >= GP_ENUM))
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution()) != EO_OK)
		return NOT_SUPPORTED;

	value = ScaleFromRAW(rawValue, 0, (uint32_t)(((uint64_t)1<<myChan->GetResolution())-1), myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoGenericProfile::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	//if type is enum or digital flag it can not be scaled as a float in this method
	if (type <= T_FLAG)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution()) != EO_OK)
		return NOT_SUPPORTED;

	value = (uint8_t) rawValue;

	return EO_OK;
}

eoReturn eoGenericProfile::SetValue(CHANNEL_TYPE type, float value, uint8_t subFlag)
{
	uint32_t rawValue;
	eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannelOut(type, subFlag);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	//if type is enum or digital flag it can not be scaled as a float in this method
	if (((type >= T_FLAG) && (type < SP_ABS)) || (type >= T_ENUM) || (type >= GP_ENUM))
		return NOT_SUPPORTED;
	if (value < myChan->min || value > myChan->max)
		return OUT_OF_RANGE;
	//Converting after GP Spec(float value, uint32_t rangeMin, uint32_t rangeMax, float scaleMin, float scaleMax)
	rawValue = ScaleToRAW(value, 0, (uint32_t)(((uint64_t)1<<myChan->GetResolution())-1), myChan->min, myChan->max);

	if (SetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution()) != EO_OK)
		return NOT_SUPPORTED;

	return EO_OK;
}

eoReturn eoGenericProfile::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannelOut(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	//if type is enum or digital flag it can not be scaled as a float in this method
	if (((type >= T_FLAG) && (type < SP_ABS)) || (type >= T_ENUM) || (type >= GP_ENUM))
		return NOT_SUPPORTED;
	if (value < myChan->min || value > myChan->max)
		return OUT_OF_RANGE;
	//Converting after GP Spec
	//ScaleFromRAW(uint32_t rawValue, uint32_t rangeMin, uint32_t rangeMax, float scaleMin, float scaleMax)
	rawValue = ScaleToRAW(value, 0, (uint32_t)(((uint64_t)1<<myChan->GetResolution())-1), myChan->min, myChan->max);

	if (SetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution()) != EO_OK)
		return NOT_SUPPORTED;

	return EO_OK;
}

eoReturn eoGenericProfile::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	//Just copy the changed values into the msg...
	uint32_t rawValue = (uint32_t) value;
	eoGPChannelInfo* myChan = (eoGPChannelInfo*) GetChannelOut(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	//if type is enum or digital flag it can not be scaled as a float in this method
	if (type <= T_FLAG)
		return NOT_SUPPORTED;
	return SetRawValue(msg, rawValue, myChan->bitoffs, (uint8_t) myChan->GetResolution());
}

eoChannelInfo* eoGenericProfile::GetChannel(CHANNEL_TYPE type)
{
	uint8_t tmpChanCnt;
	for (tmpChanCnt = 0; tmpChanCnt < gpChannels.size(); tmpChanCnt++)
	{
		if (gpChannels[tmpChanCnt].type == type && gpChannels[tmpChanCnt].GetRejected() != 1)
			return (eoChannelInfo*) &gpChannels[tmpChanCnt];
	}
	return NULL;
}
eoChannelInfo* eoGenericProfile::GetChannel(uint8_t channelNumber)
{
	eoChannelInfo* retChannel = NULL;
	if (channelNumber < gpChannels.size() && gpChannels[channelNumber].GetRejected() != 1)
		retChannel = (eoChannelInfo*) (&gpChannels[channelNumber]);
	return retChannel;
}
eoChannelInfo* eoGenericProfile::GetChannel(CHANNEL_TYPE type, uint8_t subType)
{
	uint8_t tmpChanCnt;
	uint8_t tmpSubType = 0;
	for (tmpChanCnt = 0; tmpChanCnt < gpChannels.size(); tmpChanCnt++)
	{
		if (gpChannels[tmpChanCnt].type == type && gpChannels[tmpChanCnt].GetRejected() != 1)
		{
			if (subType == tmpSubType)
				return (eoChannelInfo*) &gpChannels[tmpChanCnt];
			else
				tmpSubType++;
		}
	}
	return NULL;
}

eoChannelInfo* eoGenericProfile::GetChannelOut(CHANNEL_TYPE type)
{
	uint8_t tmpChanCnt;
	for (tmpChanCnt = 0; tmpChanCnt < gpChannelsOut.size(); tmpChanCnt++)
	{
		if (gpChannelsOut[tmpChanCnt].type == type && gpChannelsOut[tmpChanCnt].GetRejected() != 1)
			return (eoChannelInfo*) &gpChannelsOut[tmpChanCnt];
	}
	return NULL;
}
eoChannelInfo* eoGenericProfile::GetChannelOut(uint8_t channelNumber)
{
	eoChannelInfo* retChannel = NULL;
	if (channelNumber < gpChannelsOut.size() && gpChannelsOut[channelNumber].GetRejected() != 1)
		retChannel = (eoChannelInfo*) (&gpChannelsOut[channelNumber]);
	return retChannel;
}
eoChannelInfo* eoGenericProfile::GetChannelOut(CHANNEL_TYPE type, uint8_t subType)
{
	uint8_t tmpChanCnt;
	uint8_t tmpSubType = 0;
	for (tmpChanCnt = 0; tmpChanCnt < gpChannelsOut.size(); tmpChanCnt++)
	{
		if (gpChannelsOut[tmpChanCnt].type == type)
		{
			if (subType == tmpSubType && gpChannelsOut[tmpChanCnt].GetRejected() != 1)
				return (eoChannelInfo*) &gpChannelsOut[tmpChanCnt];
			else
				tmpSubType++;
		}
	}
	return NULL;
}

uint8_t eoGenericProfile::Serialize(eoArchive &a)
{
	eoReturn ret = EO_OK;
	std::vector<eoGPChannelInfo>::iterator it;
	a & "rorg" & rorg;
	a & "func" & func;
	a & "type" & type;
	a & "manufacturer" & manufacturer;
	if (a.isStoring)
	{
		//TODO "virtual rorg b0-0-0
		uint32_t tmpCnt = (int32_t) gpChannels.size();
		a & "Counter" & tmpCnt;
		tmpCnt = (int32_t)gpChannelsOut.size();
		a & "OutCounter" & tmpCnt;
		if (tmpCnt == 0)
			return EO_OK;
		if (tmpCnt > 0x0000FFFF)
			return EO_ERROR;
		tmpCnt = 0;
		for (it = gpChannels.begin(); it != gpChannels.end(); ++it)
		{
			char tmpName[14] = "Channel_0000\0";
			tmpName[8] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 12));
			tmpName[9] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 8));
			tmpName[10] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 4));
			tmpName[11] = *eoConverter::NumToHex((uint8_t)(tmpCnt));
			tmpCnt++;
			//could be a NULL pointer, shouldn't be...
			a & tmpName & (*it);
		}
		tmpCnt = 0;
		for (it = gpChannelsOut.begin(); it != gpChannelsOut.end(); ++it)
		{
			char tmpName[17] = "OutChannel_0000\0";
			tmpName[11] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 12));
			tmpName[12] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 8));
			tmpName[13] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 4));
			tmpName[14] = *eoConverter::NumToHex((uint8_t)(tmpCnt));
			tmpCnt++;
			//could be a NULL pointer, shouldn't be...
			a & tmpName & (*it);
		}
	}
	else
	{
		uint32_t tmpCnt;
		uint32_t cnt = 0;
		a & "Counter" & cnt;
		for (tmpCnt = 0; tmpCnt < cnt; tmpCnt++)
		{
			char tmpName[14] = "Channel_0000\0";
			tmpName[8] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 12));
			tmpName[9] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 8));
			tmpName[10] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 4));
			tmpName[11] = *eoConverter::NumToHex((uint8_t)(tmpCnt));
			eoGPChannelInfo myChan;
			a & tmpName & myChan;
			gpChannels.push_back(myChan);
		}
		a & "OutCounter" & cnt;
		for (tmpCnt = 0; tmpCnt < cnt; tmpCnt++)
		{
			char tmpName[17] = "OutChannel_0000\0";
			tmpName[11] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 12));
			tmpName[12] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 8));
			tmpName[13] = *eoConverter::NumToHex((uint8_t)(tmpCnt >> 4));
			tmpName[14] = *eoConverter::NumToHex((uint8_t)(tmpCnt));
			eoGPChannelInfo myChan;
			a & tmpName & myChan;
			gpChannelsOut.push_back(myChan);
		}

	}
	return (uint8_t)ret;
}
void eoGenericProfile::ClearValues()
{
	eoProfile::ClearValues();
	msg.SetDataLength(curBitOffset / 8);
	if (curBitOffset % 8 != 0)
		msg.SetDataLength(msg.GetDataLength()+1);
	msg.RORG = GP_DATA;
}

void eoGenericProfile::ClearChannels()
{
	ClearValues();
	gpChannels.clear();
	curBitOffset = 0;
}

uint8_t eoGenericProfile::GetChannelCount() const
{
	return (uint8_t) gpChannels.size();
}

void eoGenericProfile::ClearChannelsOut()
{
	ClearValues();
	gpChannelsOut.clear();
	curBitOffsetOut = 0;
}

uint8_t eoGenericProfile::GetChannelCountOut() const
{
	return (uint8_t) gpChannelsOut.size();
}

eoReturn eoGenericProfile::AddChannel(CHANNEL_TYPE type, GP_RESOLUTION resolution, int8_t engMaximum, int8_t engMinimum, GP_SCALING scaleMaximum, GP_SCALING scaleMinimum, VALUE_TYPE valueType)
{
	eoReturn ret = EO_OK;
	gpChannels.push_back(eoGPChannelInfo(type, resolution, engMaximum, engMinimum, scaleMaximum, scaleMinimum));
	gpChannels.back().bitoffs = curBitOffset;
	gpChannels.back().signalType = valueType;
	if(msg.SetDataLength((uint16_t)(msg.GetDataLength() + resolution))==EO_OK)
		curBitOffset += (uint16_t)resolution;
	else
		ret = BUFF_FULL;
	return ret;
}
eoReturn eoGenericProfile::AddChannel(CHANNEL_TYPE type, VALUE_TYPE valueType)
{
	eoReturn ret = EO_OK;
	if (type < T_FLAG)
		ret = NOT_SUPPORTED;
	else if (type < T_ENUM)
	{
		gpChannels.push_back(eoGPChannelInfo(type, GP_RES_1BIT, 1, 0, GP_SCAL_1, GP_SCAL_1));
		gpChannels.back().bitoffs = curBitOffset;
		gpChannels.back().signalType = valueType;
		msg.SetDataLength(msg.GetDataLength() + 1);
		curBitOffset += 1;
	}
	else
		ret = NOT_SUPPORTED;

	return ret;
}

eoReturn eoGenericProfile::AddChannel(CHANNEL_TYPE type, GP_RESOLUTION resolution, VALUE_TYPE valueType)
{
	eoReturn ret = EO_OK;
	if(type >= GP_ENUM  && type <= GP_ENUM+0xFF )
	{
		gpChannels.push_back(eoGPChannelInfo(type, resolution, (uint8_t)resolution, 0, GP_SCAL_1, GP_SCAL_1));
		gpChannels.back().bitoffs = curBitOffset;
		gpChannels.back().signalType = valueType;
		msg.SetDataLength((uint16_t)(msg.GetDataLength() + resolution));
		curBitOffset += (uint16_t)resolution;
	}
	else
	{
		ret = NOT_SUPPORTED;
	}
	return ret;
}

eoReturn eoGenericProfile::AddChannelOut(CHANNEL_TYPE type, GP_RESOLUTION resolution, int8_t engMaximum, int8_t engMinimum, GP_SCALING scaleMaximum, GP_SCALING scaleMinimum, VALUE_TYPE valueType)
{
	eoReturn ret = EO_OK;
	gpChannelsOut.push_back(eoGPChannelInfo(type, resolution, engMaximum, engMinimum, scaleMaximum, scaleMinimum));
	gpChannelsOut.back().bitoffs = curBitOffsetOut;
	gpChannelsOut.back().signalType = valueType;
	if(msg.SetDataLength((uint16_t)(msg.GetDataLength() + resolution))==EO_OK)
		curBitOffsetOut += (uint16_t)resolution;
	else
		ret = BUFF_FULL;
	return ret;
}
eoReturn eoGenericProfile::AddChannelOut(CHANNEL_TYPE type, VALUE_TYPE valueType)
{
	eoReturn ret = EO_OK;
	if (type < T_FLAG)
		ret = NOT_SUPPORTED;
	else if (type < T_ENUM)
	{
		gpChannelsOut.push_back(eoGPChannelInfo(type, GP_RES_1BIT, 1, 0, GP_SCAL_1, GP_SCAL_1));
		gpChannelsOut.back().bitoffs = curBitOffsetOut;
		gpChannelsOut.back().signalType = valueType;
		msg.SetDataLength(msg.GetDataLength() + 1);
		curBitOffsetOut += 1;
	}
	else
		ret = NOT_SUPPORTED;

	return ret;
}

eoReturn eoGenericProfile::AddChannelOut(CHANNEL_TYPE type, GP_RESOLUTION resolution, VALUE_TYPE valueType)
{
	eoReturn ret = EO_OK;
	if (type < T_FLAG)
		ret = NOT_SUPPORTED;
	else if (type < GP_ENUM)
	{
		ret = NOT_SUPPORTED;
	}
	else
	{
		gpChannelsOut.push_back(eoGPChannelInfo(type, resolution, (uint8_t)resolution, 0, GP_SCAL_1, GP_SCAL_1));
		gpChannelsOut.back().bitoffs = curBitOffsetOut;
		gpChannelsOut.back().signalType = valueType;
		msg.SetDataLength((uint16_t)(msg.GetDataLength() + resolution));
		curBitOffsetOut += (uint16_t)resolution;
	}

	return ret;
}

uint32_t eoGenericProfile::GetProductId()
{
	return productId;
}

void eoGenericProfile::SetProductId(const uint32_t prodId)
{
	productId = prodId;
}


eoReturn eoGenericProfile::Create(eoMessage &m)
{
	eoReturn ret=EO_OK;

	if ((curBitOffsetOut % 8) == 0)
		msg.dataLength = (curBitOffsetOut / 8);
	else
		msg.dataLength = (curBitOffsetOut / 8) + 1;

	ret=msg.copyTo(m);
	if(ret!=EO_OK)
		return ret;
	m.RORG = GP_CD;
	m.destinationID = BROADCAST_ID;
	m.sourceID = 0;

	return ret;
}
