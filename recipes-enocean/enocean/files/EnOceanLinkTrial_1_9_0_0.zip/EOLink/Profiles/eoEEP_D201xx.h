/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D201_H__INCLUDED_)
#define eoEEP_D201_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D201xx
 * \brief The class to handle EEP D201 profiles
 * \details Allows the user to handle EEP D201 profiles, the following profiles are available:
 * 		- D2-01-00
 * 		- D2-01-01
 * 		- D2-01-02
 * 		- D2-01-03
 * 		- D2-01-04
 * 		- D2-01-05
 * 		- D2-01-06
 * 		- D2-01-07
 * 		- D2-01-08
 * 		- D2-01-09
 * 		- D2-01-0A
 * 		- D2-01-0B
 * 		- D2-01-0D
 * 		- D2-01-0C
 * 		- D2-01-10
 * 		- D2-01-11
 * 		- D2-01-12
 * 		- D2-01-13
 * 		- D2-01-14\n
 *
 * 	NOTE: set command before using the profile.
 *
 * The following channels are available in Actuator Set Output:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_DIM_VALUE		|::VLD_DIM_VALUE |
 * | 1             | ::E_IO_CHANNEL 	|::VLD_IO_CHANNEL |
 * | 2             | ::S_PERCENTAGE		|float |
 * \n
 *
 * The following channels are available in Actuator Set Local:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF		|uint8_t | Taught in devices, ::TAUGHT_IN_DEVICES |
 * | 1             | ::F_ON_OFF 	|uint8_t | Over current shut down, ::OVER_CURRENT_SHUT |
 * | 2             | ::F_ON_OFF		|uint8_t | Reset over current shut down, ::RESET_OVER_CURRENT |
 * | 3             | ::F_ON_OFF 	|uint8_t | Local control, ::LOCAL_CONTROL |
 * | 4             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL |   |
 * | 5             | ::S_TIME	 	|float | Dimming timer medium, ::DIMMING_MEDIUM |
 * | 6             | ::S_TIME		|float | Dimming timer slow, ::DIMMING_SLOW |
 * | 7             | ::F_ON_OFF 	|uint8_t | User interface indication, ::USER_INDICATION |
 * | 8             | ::E_STATE		|::VLD_DEFAULT_STATE |  |
 * | 9             | ::S_TIME		|float | Dimming timer fast, ::DIMMING_FAST |
 * \n
 *
 * The following channels are available in Actuator Status Query:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL |
 * \n
 *
 * The following channels are available in Actuator Status Response:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF		|uint8_t | Over current switch off, ::OVER_CURRENT_SHUT |
 * | 1             | ::E_ERROR_STATE|::VLD_ERROR_LEVEL |   |
 * | 2             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL |   |
 * | 3             | ::F_ON_OFF		|uint8_t | Local control, ::LOCAL_CONTROL |
 * | 4             | ::S_PERCENTAGE	|float |        |
 * \n
 *
 * The following channels are available in Actuator Set Measurement:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF		|uint8_t | Report measurement, ::REPORT_MEASUREMENT |
 * | 1             | ::F_ON_OFF		|uint8_t | Reset measurement, ::RESET_MEASUREMENT |
 * | 2             | ::F_ON_OFF		|uint8_t | Measurement mode, ::MEASUREMENT_MODE |
 * | 3             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL |   |
 * | 4             | ::S_POWER		|float | Power in W, ::POWER_W |
 * | 5             | ::S_POWER		|float | Power in kW, ::POWER_KW |
 * | 6             | ::S_ENERGY		|float | Energy in Ws, ::ENERGY_WS |
 * | 7             | ::S_ENERGY		|float | Energy in Wh, ::ENERGY_WH |
 * | 8             | ::S_ENERGY		|float | Energy in kWh, ::ENERGY_KWH |
 * | 9             | ::S_TIME	 	|float | Maximum time between two subsequent Actuator, ::MAX_SUB_TIME |
 * | 10            | ::S_TIME		|float | Minimum time between two subsequent Actuator, ::MIN_SUB_TIME |
 * \n
 *
 * The following channels are available in Actuator Measurement Query:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF		|uint8_t |Query, ::QUERY |
 * | 1             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL |  |
 * \n
 *
 * The following channels are available in Actuator Measurement Response:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL |   |
 * | 1             | ::S_POWER		|float | Power in W, ::POWER_W |
 * | 2             | ::S_POWER		|float | Power in kW, ::POWER_KW |
 * | 3             | ::S_ENERGY		|float | Energy in Ws, ::ENERGY_WS |
 * | 4             | ::S_ENERGY		|float | Energy in Wh, ::ENERGY_WH|
 * | 5             | ::S_ENERGY		|float | Energy in kWh, ::ENERGY_KWH |
 * \n
 *
 * The following channels are available in Actuator Set Pilot Wire Mode:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_PILOTWIRE_MODE |
 * \n
 *
 * The following channels are available in Actuator Pilot Wire Mode Query:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * \n
 *
 * The following channels are available in Actuator Set Pilot Wire Response:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_PILOTWIRE_MODE |
 * \n
 *
 * The following channels are available in Actuator Set External Interface Settings:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL | |
 * | 1             | ::S_TIME | float | ::AUTO_OFF_TIMER|
 * | 2             | ::S_TIME | float | ::DELAY_OFF_TIMER|
 * | 3             | ::E_STATE | ::VLD_EXT_BTN_CHANNEL | ::EXT_PUSH_BTN|
 * | 4             | ::F_ON_OFF | uint8_t | ::_2_STATE_SWITCH|
 * \n
 *
 * The following channels are available in Actuator External Interface Settings Query:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_CONTROLLER_MODE |::VLD_PILOTWIRE_MODE |
 * \n
 *
 * The following channels are available in Actuator External Interface Settings Response:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_IO_CHANNEL |::VLD_IO_CHANNEL | |
 * | 1             | ::S_TIME | float | ::AUTO_OFF_TIMER|
 * | 2             | ::S_TIME | float | ::DELAY_OFF_TIMER|
 * | 3             | ::E_STATE | ::VLD_EXT_BTN_CHANNEL | ::EXT_PUSH_BTN|
 * | 4             | ::F_ON_OFF | uint8_t | ::_2_STATE_SWITCH|
 * \n
 */

/**
 * \file eoEEP_D201xx.h
 */
//! Command enums for D2-01-xx profiles
typedef enum
{
	//! <b>Actuator Set Output</b> 1
	ACTUATOR_SET_OUTPUT = 0x01,
	//! <b>Actuator Set Local</b> 2
	ACTUATOR_SET_LOCAL = 0x02,
	//! <b>Actuator Status Query</b> 3
	ACTUATOR_STATUS_QUERY = 0x03,
	//! <b>Actuator Status Response</b> 4
	ACTUATOR_STATUS_RESPONSE = 0x04,
	//! <b>Actuator Set Measurement</b> 5
	ACTUATOR_SET_MEASUREMENT = 0x05,
	//! <b>Actuator Measurement Query</b> 6
	ACTUATOR_MEASUREMENT_QUERY = 0x06,
	//! <b>Actuator Measurement Response</b> 7
	ACTUATOR_MEASUREMENT_RESPONSE = 0x07,
	//! <b>Actuator Set Pilot Wire Mode</b> 8
	ACTUATOR_PILOTWIRE_SET = 0x08,
	//! <b>Actuator Pilot Wire Mode Query</b> 9
	ACTUATOR_PILOTWIRE_QUERY = 0x09,
	//! <b>Actuator Pilot Wire Mode Response</b> 10
	ACTUATOR_PILOTWIRE_RESPONSE = 0x0A,
	//! <b>Actuator Set External Interface Settings</b> 11
	ACTUATOR_SET_EXT_INTERFACE_SETTINGS = 0x0B,
	//! <b>Actuator External Interface Settings Query</b> 12
	ACTUATOR_EXT_INTERFACE_SETTINGS_QUERY = 0x0C,
	//! <b>Actuator External Interface Settings Response</b> 13
	ACTUATOR_EXT_INTERFACE_SETTINGS_RESPONSE = 0x0D
} COMMANDS;

//! Index enums for D2-01-xx profiles
typedef enum
{
	//! <b>Taught-in devices</b> 0
	TAUGHT_IN_DEVICES = 0x00,
	//! <b>Over current shut down</b> 1
	OVER_CURRENT_SHUT = 0x01,
	//! <b>Reset over current shut down</b> 2
	RESET_OVER_CURRENT = 0x02,
	//! <b>Local control</b> 3
	LOCAL_CONTROL = 0x03,
	//! <b>User interface indication</b> 4
	USER_INDICATION = 0x04,
	//! <b>Report measurement</b> 5
	REPORT_MEASUREMENT = 0x05,
	//! <b>Reset measurement</b> 6
	RESET_MEASUREMENT = 0x06,
	//! <b>Measurement mode</b> 7
	MEASUREMENT_MODE = 0x07,
	//! <b>Query</b> 8
	QUERY = 0x08,
	//! <b>Power failure</b> 9
	PWR_FAILURE = 0x09,
	//! <b>Auto Off Timer</b> 10
	AUTO_OFF_TIMER = 0x0A,
	//! <b>Delay Off Timer</b> 11
	DELAY_OFF_TIMER = 0x0B,
	//! <b>External Switch/Push Button</b> 12
	EXT_PUSH_BTN = 0x0C,
	//! <b>2-state Switch</b> 13
	_2_STATE_SWITCH = 0x0D,
	//! <b>Default State</b> 14
	DEFAULT_STATE = 0x0E
} VLD_ON_OFF_INDEX;

//! Time index enums for D2-01-xx profiles
typedef enum
{
	//! <b>Dimming timer slow</b> 0
	DIMMING_SLOW = 0x00,
	//! <b>Dimming timer medium</b> 1
	DIMMING_MEDIUM = 0x01,
	//! <b>Dimming timer fast</b> 2
	DIMMING_FAST = 0x02,
	//! <b>Maximum time between two subsequent actuator</b> 3
	MAX_SUB_TIME = 0x03,
	//! <b>Minimum time between two subsequent actuator</b> 4
	MIN_SUB_TIME = 0x04
} VLD_TIME_INDEX;

//! Unit enums for D2-01-xx profiles
typedef enum
{
	//! <b>Energy in Ws</b> 0
	ENERGY_WS = 0x00,
	//! <b>Energy in Wh</b> 1
	ENERGY_WH = 0x01,
	//! <b>Energy in kWh</b> 2
	ENERGY_KWH = 0x02,
	//! <b>Power in W</b> 3
	POWER_W = 0x03,
	//! <b>Power in kW</b> 4
	POWER_KW = 0x04
} VLD_UNITS;

//! Dim enums for D2-01-xx profiles
typedef enum
{
	//! <b>Switch to new output value</b> 0
	SWITCH_TO_NEW = 0x00,
	//! <b>Dim to new output value - fast</b> 1
	DIM_TO_NEW_FAST = 0x01,
	//! <b>Dim to new output value - medium</b> 2
	DIM_TO_NEW_MED = 0x02,
	//! <b>SDim to new output value - slow</b> 3
	DIM_TO_NEW_SLOW = 0x03,
	//! <b>Stop dimming</b> 4
	DIM_STOP = 0x04
} VLD_DIM_VALUE;

//! Error level enums for D2-01-xx profiles
typedef enum
{
	//! <b>Hardware OK</b> 0
	HARDWARE_OK = 0x00,
	//! <b>Hardware warning</b> 1
	HARDWARE_WARNING = 0x01,
	//! <b>Hardware failure</b> 2
	HARDWATE_FAIL = 0x02
} VLD_ERROR_LEVEL;

//! Default state enums for D2-01-xx profiles
typedef enum
{
	//! <b>Defaulst state OFF or 0%</b> 0
	STATE_OFF = 0x00,
	//! <b>Defaulst state ON or 100%</b> 1
	STATE_ON = 0x01,
	//! <b>Defaulst state remember previous state</b> 2
	PREV_STATE = 0x02
} VLD_DEFAULT_STATE;

//! I/O channel enums for D2-01-xx profiles
typedef enum
{
	//! <b>All output channels supported by the device</b> 0
	ALL_SUPPORTED = 0x1E,
	//! <b>Input channel (from mains only)</b> 1
	INPUT_FOR_MAINS = 0x1F
} VLD_IO_CHANNEL;

//! Pilotwire mode enums for D2-01-xx profiles
typedef enum
{
	//! <b>Off</b> 0
	PILOTWIRE_OFF = 0x00,
	//! <b>Comfort</b> 1
	PILOTWIRE_COMFORT = 0x01,
	//! <b>Eco</b> 2
	PILOTWIRE_ECO = 0x02,
	//! <b>Anti-freeze</b> 3
	PILOTWIRE_ANTI_FREEZE = 0x03,
	//! <b>Comfort 1</b> 4
	PILOTWIRE_COMFORT_1 = 0x04,
	//! <b>Comfort 2</b> 5
	PILOTWIRE_COMFORT_2 = 0x05
} VLD_PILOTWIRE_MODE;

//! External Switch/Push Button enums for D2-01-xx profiles
typedef enum
{
	//! <b>Not applicable</b> 0
	EBM_NOT_APPLICABLE = 0x00,
	//! <b>External switch</b> 1
	EBM_EXTERNAL_SWITCH = 0x01,
	//! <b>External push button</b> 2
	EBM_EXTERNAL_PUSH_BTN = 0x02,
	//! <b>Auto detect</b> 3
	EBM_AUTO_DETECT = 0x03
} VLD_EXT_BTN_CHANNEL;

class eoEEP_D201xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D201xx(uint16_t size = 10);
	virtual ~eoEEP_D201xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
