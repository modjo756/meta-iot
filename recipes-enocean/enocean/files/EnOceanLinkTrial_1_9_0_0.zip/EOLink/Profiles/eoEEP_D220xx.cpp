/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D220xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 10;
const uint8_t numOfProfiles = 0x02;
const uint8_t numOfCommands = 0x06;

const EEP_ITEM listD220xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00 DIRECTION:1
{
{ true, 0, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE}, //Operating mode
{ true, 5, 2, 0, 3, 0, 3, E_STATE, TEMP_LEVEL },	//Temperature level
{ true, 7, 1, 0, 1, 0, 1, E_DIRECTION, 0},	//Direction
{ true, 8, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, RELHUM_CONTROL},	//Humidity control
{ true, 10, 2, 0, 3, 0, 3, E_STATE, ROOM_SIZE_REFERENCE},	//Room size reference
{ true, 12, 4, 0, 15, 0, 15, E_ROOM_SIZE, 0},	//Room size reference
{ true, 16, 8, 0, 255, 0, 255, E_STATE, RELHUM_THRESHOLD},	//Humidity threshold - enum
{ true, 16, 8, 0, 100, 0, 100, S_RELHUM, 0},	//Humidity threshold - percentage
{ true, 24, 8, 0, 255, 0, 255, E_FANSPEED, 0},	//Fan speed - enum
{ true, 24, 8, 0, 100, 0, 100, S_PERCENTAGE, 0},	//Fan speed - percentage
},
//TYPE:00 DIRECTION:2
{
{ true, 0, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE}, //Operating mode
{ true, 4, 3, 0, 7, 0, 7, E_STATE, SERVICE_INFO },	//Service information
{ true, 7, 1, 0, 1, 0, 1, E_DIRECTION, 0},	//Direction
{ true, 8, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, RELHUM_CONTROL},	//Humidity control
{ true, 10, 2, 0, 3, 0, 3, E_STATE, ROOM_SIZE_REFERENCE},	//Room size reference
{ true, 12, 4, 0, 15, 0, 15, E_ROOM_SIZE, 0},	//Room size reference
{ true, 16, 8, 0, 255, 0, 255, E_STATE, RELHUM_THRESHOLD},	//Humidity threshold - enum
{ true, 16, 8, 0, 100, 0, 100, S_RELHUM, 0},	//Humidity threshold - percentage
{ true, 24, 8, 0, 255, 0, 255, E_FANSPEED, 0},	//Fan speed - enum
{ true, 24, 8, 0, 100, 0, 100, S_PERCENTAGE, 0},	//Fan speed - percentage

},
//TYPE:01 DIRECTION:1
{
{ true, 7, 1, 0, 1, 0, 1, E_DIRECTION, 0},	//Direction
{ true, 10, 2, 0, 3, 0, 3, E_STATE, ROOM_SIZE_REFERENCE},	//Room size reference
{ true, 12, 4, 0, 15, 0, 15, E_ROOM_SIZE, 0},	//Room size reference
{ true, 24, 8, 0, 255, 0, 255, E_FANSPEED, 0},	//Fan speed - enum
{ true, 24, 8, 0, 100, 0, 100, S_PERCENTAGE, 0},	//Fan speed - percentage
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:01 DIRECTION:2
{
{ true, 0, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE}, //Operating mode
{ true, 7, 1, 0, 1, 0, 1, E_DIRECTION, 0},	//Direction
{ true, 10, 2, 0, 3, 0, 3, E_STATE, ROOM_SIZE_REFERENCE},	//Room size reference
{ true, 12, 4, 0, 15, 0, 15, E_ROOM_SIZE, 0},	//Room size reference
{ true, 24, 8, 0, 255, 0, 255, E_FANSPEED, 0},	//Fan speed - enum
{ true, 24, 8, 0, 100, 0, 100, S_PERCENTAGE, 0},	//Fan speed - percentage
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:02 DIRECTION:1
{
{ true, 10, 2, 0, 3, 0, 3, E_STATE, ROOM_SIZE_REFERENCE},	//Room size reference
{ true, 12, 4, 0, 15, 0, 15, E_ROOM_SIZE, 0},	//Room size reference
{ true, 24, 8, 0, 255, 0, 255, E_FANSPEED, 0},	//Fan speed - enum
{ true, 24, 8, 0, 100, 0, 100, S_PERCENTAGE, 0},	//Fan speed - percentage
{ true, 7, 1, 0, 1, 0, 1, E_DIRECTION, 0},	//Direction
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:02 DIRECTION:2
{
{ true, 0, 4, 0, 15, 0, 15, E_CONTROLLER_MODE, OP_MODE}, //Operating mode
{ true, 10, 2, 0, 3, 0, 3, E_STATE, ROOM_SIZE_REFERENCE},	//Room size reference
{ true, 8, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, RELHUM_CONTROL},	//Humidity control
{ true, 12, 4, 0, 15, 0, 15, E_ROOM_SIZE, 0},	//Room size reference
{ true, 24, 8, 0, 255, 0, 255, E_FANSPEED, 0},	//Fan speed - enum
{ true, 24, 8, 0, 100, 0, 100, S_PERCENTAGE, 0},	//Fan speed - percentage
{ true, 7, 1, 0, 1, 0, 1, E_DIRECTION, 0},	//Direction
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
};

eoEEP_D220xx::eoEEP_D220xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x20;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(size);
	direction = 0;
}

eoEEP_D220xx::~eoEEP_D220xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D220xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() != 4)
		return NOT_SUPPORTED;

	if ((m.data[0] & 0x01) == 1)
		direction = 1;
	else
		direction = 0;

	SetType(this->type);
	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D220xx::SetType(uint8_t type)
{
	uint8_t tmpChannelCount;
	uint8_t tmpType;
	if (type > numOfProfiles)
		return NOT_SUPPORTED;

	switch (type)
	{
		case 0x00:
			tmpType = direction ? (type + 1) : type;
			break;
		case 0x01:
			tmpType = direction ? (type + 2) : (type + 1);
			break;
		case 0x02:
			tmpType = direction ? (type + 3) : (type + 2);
			break;
		default:
			return NOT_SUPPORTED;
	}

	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD220xx[tmpType][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD220xx[tmpType][tmpChannelCount].type;
			channel[channelCount].max = listD220xx[tmpType][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD220xx[tmpType][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD220xx[tmpType][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;
	this->type = type;

	return EO_OK;
}

eoReturn eoEEP_D220xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_DIRECTION:
			value =(uint8_t)(rawValue ? 1 : 0);
			break;

		case E_FANSPEED:
			if (direction == 1)
			{
				if (rawValue != 255)
					return OUT_OF_RANGE;
			}
			else
				if (rawValue < 253 || rawValue > 255)
					return OUT_OF_RANGE;

			value = (uint8_t)rawValue;
			break;

		case E_ROOM_SIZE:
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D220xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_DIRECTION:
			if (value != 0)
				direction = 1;
			else
				direction = 0;
			SetType(this->type);
			myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
			rawValue = direction;
			break;

		case E_FANSPEED:
			if (direction == 0)
			{
				if (value < 253)
					return OUT_OF_RANGE;
			}
			else
				if (value != 255)
					return OUT_OF_RANGE;
			rawValue = (uint32_t)value;
			break;

		case E_ROOM_SIZE:
			rawValue = (uint32_t)value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D220xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_RELHUM:
		case S_PERCENTAGE:
			value = (float)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D220xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_RELHUM:
		case S_PERCENTAGE:
			rawValue = (uint32_t)value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D220xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_CONTROLLER_MODE:
			switch (index)
			{
				case OP_MODE:
					if (rawValue > 1)
						if (rawValue != 15)
							return OUT_OF_RANGE;
					value = (uint8_t)rawValue;
					break;

				case RELHUM_CONTROL:
					value = (uint8_t)rawValue;
					break;

				default:
					return NOT_SUPPORTED;
			}
			break;

		case E_STATE:
			switch (index)
			{
				case TEMP_LEVEL:
				case ROOM_SIZE_REFERENCE:
				case SERVICE_INFO:
					value = (uint8_t)rawValue;
					break;
				case RELHUM_THRESHOLD:
					if (rawValue < 253)
						return OUT_OF_RANGE;
					value = (uint8_t)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D220xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_CONTROLLER_MODE:
			switch (index)
			{
				case OP_MODE:
					if (value > 1)
						if (value != 15)
							return OUT_OF_RANGE;

					rawValue = (uint32_t)value;
					break;

				case RELHUM_CONTROL:
					rawValue = (uint8_t)value;
					break;

				default:
					return NOT_SUPPORTED;
			}
			break;

		case E_STATE:
			switch (index)
			{
				case TEMP_LEVEL:
				case ROOM_SIZE_REFERENCE:
				case SERVICE_INFO:
					rawValue = (uint32_t)value;
					break;
				case RELHUM_THRESHOLD:
					if (direction == 0)
					{
						if (value < 253)
							return OUT_OF_RANGE;
					}
					else
						if(value != 255)
							return OUT_OF_RANGE;
					rawValue = (uint32_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D220xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;
	uint8_t tmpType;

	switch (this->type)
	{
		case 0x00:
			tmpType = (uint8_t)(direction ? (this->type + 1) : this->type);
			break;
		case 0x01:
			tmpType = (uint8_t)(direction ? (this->type + 2) : (this->type + 1));
			break;
		case 0x02:
			tmpType = (uint8_t)(direction ? (this->type + 3) : (this->type + 2));
			break;
		default:
			return NULL;
	}

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD220xx[tmpType][tmpChannelCount].type == type && listD220xx[tmpType][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
