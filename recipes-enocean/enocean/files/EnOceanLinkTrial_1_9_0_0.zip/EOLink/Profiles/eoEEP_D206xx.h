/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D206_H__INCLUDED_)
#define eoEEP_D206_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D206xx
 * \brief The class to handle EEP D206 profiles
 * \details Allows the user to handle EEP D206 profiles, the following profiles are available:
 * 		- D2-06-01
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in Sensor Values message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			| uint8_t | ::BURGLARY_ALARM |
 * | 1             | ::E_STATE			| uint8_t | ::PROTECTION_PLUS_ALARM |
 * | 2             | ::E_STATE			| uint8_t | ::HANDLE_POSITION |
 * | 3             | ::E_STATE			| uint8_t | ::WINDOW_STATE |
 * | 4             | ::E_STATE			| uint8_t | ::BUTTON_1 |
 * | 5             | ::E_STATE			| uint8_t | ::BUTTON_2 |
 * | 6             | ::E_STATE			| uint8_t | ::MOTION |
 * | 7             | ::E_STATE			| uint8_t | ::VACATION_MODE |
 * | 8             | ::S_TEMP			| float |  |
 * | 9             | ::S_RELHUM			| float |  |
 * | 10            | ::S_LUMINANCE		| float |  |
 * | 11            | ::S_PERCENTAGE		| float |  |
 *
 * The following channels are available in Configuration Report message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			| uint8_t | ::VACATION_MODE |
 * | 1             | ::F_ON_OFF			| uint8_t | ::HANDLE_CLICK |
 * | 2             | ::F_ON_OFF			| uint8_t | ::BATTERY_CLICK |
 * | 3             | ::S_TIME			| float | ::SENSOR_INTERVAL |
 * | 4             | ::S_TIME			| float | ::VACATION_INTERVAL |
 *
 * The following channels are available in Log Data 01 message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_COUNTER		| float | ::POWER_ONS |
 * | 1             | ::S_COUNTER		| float | ::ALARMS |
 *
 * The following channels are available in Log Data 02 message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_COUNTER		| float | ::HANDLE_CLOSED |
 * | 1             | ::S_COUNTER		| float | ::HANDLE_OPENED |
 * | 2             | ::S_COUNTER		| float | ::HANDLE_TILTED |
 *
 * The following channels are available in Log Data 03 message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_COUNTER		| float | ::WINDOW_TILTS |
 *
 * The following channels are available in Log Data 04 message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_COUNTER		| float | ::BUTTON_1 |
 * | 1             | ::S_COUNTER		| float | ::BUTTON_2 |
 *
 * The following channels are available in Control and Settings message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			| uint8_t | ::START_TRANSMISSION_CONFIG_SETTINGS |
 * | 1             | ::F_ON_OFF			| uint8_t | ::START_TRANSMISSION_LOG_DATA |
 * | 2             | ::F_ON_OFF			| uint8_t | ::VACATION_MODE |
 * | 3             | ::E_STATE			| uint8_t | ::HANDLE_CLICK |
 * | 4             | ::E_STATE			| uint8_t | ::BATTERY_CLICK |
 * | 5             | ::S_TIME			| float | ::VACATION_INTERVAL |
 * | 6             | ::S_TIME			| float | ::SENSOR_INTERVAL |
 *
 *
 */

/**
 * \file eoEEP_D206xx.h
 */

//! Index enums for D2-06-xx profiles
typedef enum
{
	//! <b>Burglary Alarm</b> 0
	BURGLARY_ALARM = 0x00,
	//! <b>Protection Plus Alarm</b> 1
	PROTECTION_PLUS_ALARM = 0x01,
	//! <b>Handle Position</b> 2
	HANDLE_POSITION = 0x02,
	//! <b>Window State</b> 3
	WINDOW_STATE = 0x03,
	//! <b>Button 1</b> 4
	BUTTON_1 = 0x04,
	//! <b>Button 2</b> 5
	BUTTON_2 = 0x05,
	//! <b>Motion</b> 6
	MOTION = 0x06,
	//! <b>Vacation Mode</b> 7
	VACATION_MODE = 0x07,
	//! <b>Handled Closed Click</b> 8
	HANDLE_CLICK = 0x08,
	//! <b>Battery Low Click</b> 9
	BATTERY_CLICK = 0x09,
	//! <b>Sensor Update Interval</b> 10
	SENSOR_INTERVAL = 0x0A,
	//! <b>Vacation Blink Interval</b> 11
	VACATION_INTERVAL = 0x0B,
	//! <b>Power Ons</b> 12
	POWER_ONS = 0x0C,
	//! <b>Alarms</b> 13
	ALARMS = 0x0D,
	//! <b>Handle Movements Closed</b> 14
	HANDLE_CLOSED = 0x0E,
	//! <b>Handle Movements Opened</b> 15
	HANDLE_OPENED = 0x0F,
	//! <b>Handle Movements Tilted</b> 16
	HANDLE_TILTED = 0x10,
	//! <b>Window Tilts</b> 17
	WINDOW_TILTS = 0x11,
	//! <b>Start Transmission of Configuration Settings</b> 18
	START_TRANSMISSION_CONFIG_SETTINGS = 0x12,
	//! <b>Start Transmission of Log Data Packets</b> 19
	START_TRANSMISSION_LOG_DATA = 0x13
} D206_INDEX_ENUM;

//! Message type enums for D2-06-xx profiles
typedef enum
{
	//! <b>Sensor Values</b> 0
	MSG_SENSOR_VALUES = 0x00,
	//! <b>Configuration Report</b> 1
	MSG_CONFIG_REPORT = 0x01,
	//! <b>Log Data 01</b> 2
	MSG_LOG_DATA_1 = 0x02,
	//! <b>Log Data 02</b> 3
	MSG_LOG_DATA_2 = 0x03,
	//! <b>Log Data 03</b> 4
	MSG_LOG_DATA_3 = 0x04,
	//! <b>Log Data 04</b> 5
	MSG_LOG_DATA_4 = 0x05,
	//! <b>Control and Settings</b> 6
	MSG_CTRL_SETTINGS = 0x06
} D206_MSG_TYPE_ENUM;

class eoEEP_D206xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D206xx(uint16_t size = 10);
	virtual ~eoEEP_D206xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
