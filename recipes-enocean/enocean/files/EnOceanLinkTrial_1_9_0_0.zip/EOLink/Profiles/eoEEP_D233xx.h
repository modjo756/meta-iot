/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D233_H__INCLUDED_)
#define eoEEP_D233_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D233xx
 * \brief The class to handle EEP D233 profiles
 * \details Allows the user to handle EEP D233 profiles, the following profiles are available:
 * 		- D2-33-00\n
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in Gateway request message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE	|::D233_REQUEST_FRAME_ENUM | ::REQUEST_FRAME |
 * | 1             | ::S_TEMP 	|float | ::EXT_TEMPERATURE |
 * \n
 *
 * The following channels are available in Sensor parameters:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF		|uint8_t | ::WINDOW_OPEN_DETECTION_STATUS |
 * | 1             | ::F_ON_OFF 	|uint8_t | ::PIR_STATUS_DETECTION |
 * | 2             | ::F_ON_OFF 	|uint8_t | ::REF_TEMP_STATUS |
 * | 3             | ::F_ON_OFF 	|uint8_t | ::COV_SENSOR |
 * | 4             | ::F_ON_OFF 	|uint8_t | ::CO_SENSOR |
 * | 5             | ::F_ON_OFF 	|uint8_t | ::CO2_SENSOR |
 * | 6             | ::F_ON_OFF 	|uint8_t | ::PARTICLES_1_SENSOR |
 * | 7             | ::F_ON_OFF 	|uint8_t | ::PARTICLES_25_SENSOR |
 * | 8             | ::F_ON_OFF 	|uint8_t | ::PARTICLES_10_SENSOR |
 * | 9             | ::F_ON_OFF 	|uint8_t | ::RAD_ACTIVITY_SENSOR |
 * | 10            | ::F_ON_OFF 	|uint8_t | ::SOUND_SENSOR |
 * | 11            | ::F_ON_OFF 	|uint8_t | ::HYGROMETRY_SENSOR |
 * | 12            | ::F_ON_OFF 	|uint8_t | ::AIR_MOVING_SENSOR |
 * | 13            | ::F_ON_OFF 	|uint8_t | ::PRESSURE_SENSOR |
 * | 14            | ::E_STATE 		|::VLD_TEMP_SCALE_ENUM | ::TEMP_SCALE_STATUS |
 * | 15            | ::E_STATE 		|::VLD_TIME_NOTATION_ENUM | ::TIME_NOTATION_STATUS |
 * | 16            | ::E_STATE 		|::D233_DISP_CONTENT | ::DISP_CONTENT_STATUS |
 * | 17            | ::F_ON_OFF 	|uint8_t | ::DEROGATION_STATUS |
 * \n
 *
 * The following channels are available in Program message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|uint8_t | ::SCHEDULED_ORDER_TYPE |
 * | 1             | ::E_DAYS	 		|::D233_ENUM_DAYS | ::DAY_TIME_END |
 * | 2             | ::S_TIME		 	|float | ::MINUTE_TIME_END  |
 * | 3             | ::S_TIME	 		|float | ::HOUR_TIME_END |
 * | 4             | ::E_DAYS	 		|::D233_ENUM_DAYS | ::DAY_TIME_START |
 * | 5             | ::S_TIME	 		|float | ::MINUTE_TIME_START |
 * | 6             | ::S_TIME	 		|float | ::HOUR_TIME_START |
 * | 7             | ::S_TEMP_ABS		| float | |
 * | 8             | ::F_ON_OFF			|uint8_t | ::CLEAR_SCHEDULE |
 * \n
 *
 * The following channels are available in Time and date message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_TIME		 	|float | ::VLD_TIME_DAY  |
 * | 1             | ::S_TIME	 		|float | ::VLD_TIME_MONTH |
 * | 2             | ::S_TIME	 		|float | ::VLD_TIME_YEAR |
 * | 3             | ::S_TIME	 		|float | ::VLD_TIME_MINUTE |
 * | 4             | ::S_TIME	 		|float | ::VLD_TIME_HOUR |
 * | 5             | ::E_DAYS	 		|::D233_ENUM_DAYS | ::DAY_TIME_START |
 * \n
 *
 * The following channels are available in Request and status message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			|::D233_REQUEST_FRAME_ENUM | ::REQUEST_FRAME |
 * | 1             | ::E_ERROR_STATE 	|::D233_ERROR_ENUMS |   |
 * | 2             | ::F_ON_OFF			|uint8_t | ::HEATING_FLAG |
 * | 3             | ::E_STATE 			|::D233_PILOT_WIRE_ENUMS | ::PILOT_WIRE_FLAG  |
 * | 4             | ::E_STATE		 	|::VLD_WINDOW_OPEN_ENUM | ::WINDOW_DETECTION_FLAG |
 * | 5             | ::E_STATE		 	|::VLD_PIR_STATUS_ENUM | ::PIR_STATUS_DETECTION |
 * | 6             | ::F_ON_OFF			|uint8_t | ::KEY_LOCK_STATUS |
 * | 7             | ::F_ON_OFF			|uint8_t | ::REF_TEMP_FLAG |
 * | 8             | ::F_ON_OFF			|uint8_t | ::DEROGATION_FLAG |
 * | 9             | ::S_TEMP	 		|float | ::INT_TEMPERATURE |
 * \n
 *
 * The following channels are available in Heater parameters message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_ENERGY	 		|float |  |
 * | 1             | ::S_TEMP	 		|float | ::DEROGATION_TEMP_SETPOINT |
 * | 2             | ::S_VALUE	 		|float | ::FIRMWARE_VERSION |
 * \n
 *
 * The following channels are available in Value of CO, COV, CO2 and sound level message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_VALUE	 		|float | ::COV_SENSOR |
 * | 1             | ::S_VALUE	 		|float | ::CO_SENSOR |
 * | 2             | ::S_VALUE	 		|float | ::CO2_SENSOR |
 * | 3             | ::S_VALUE	 		|float | ::SOUND_SENSOR |
 * \n
 *
 * The following channels are available in Value of particles and radioactivity sensors message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PARTICLES 		|float | ::PARTICLES_1_SENSOR |
 * | 1             | ::S_PARTICLES 		|float | ::PARTICLES_25_SENSOR |
 * | 2             | ::S_PARTICLES 		|float | ::PARTICLES_10_SENSOR |
 * | 3             | ::S_VALUE	 		|float | ::RADIO_ACTIVITY |
 * \n
 *
 * The following channels are available in Value of air, hygrometry, pressure and temperature sensors message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_VELOCITY 		|float |  |
 * | 1             | ::S_PRESSURE 		|float |  |
 * | 2             | ::S_PERCENTAGE		|float |  |
 * | 3             | ::S_TEMP	 		|float | ::INT_TEMPERATURE_2 |
 * \n
 */

/**
 * \file eoEEP_D233xx.h
 */

//! Command enums for D2-33-xx profiles
typedef enum
{
	//! <b>Gateway request message</b> 0
	SENSOR_REQU_MSG = 0x00,
	//! <b>Sensor parameters</b> 1
	SENSOR_PARAM = 0x01,
	//! <b>Program</b> 2
	SENSOR_PROGRAM = 0x02,
	//! <b>Time and date</b> 3
	SENSOR_TIME_DATE = 0x03,
	//! <b>Request and status</b> 8
	GATEWAY_REQ_STATUS = 0x08,
	//! <b>Heater parameters</b> 9
	GATEWAY_HEATER_PARAMS = 0x09,
	//! <b>Value of CO, COV, CO2 and sound level</b> 10
	GATEWAY_GAS_SENSOR_VALUES = 0x0A,
	//! <b>Value of particles and radioactivity sensor</b> 11
	GATEWAY_PARTICLE_SENSOR_VALUES = 0x0B,
	//! <b>Value of air, hygrometry, pressure and temperature</b> 12
	GATEWAY_ENV_SENSOR_VALUES = 0x0C,
} D233_COMMANDS;

//! Index enums for D2-33-xx profiles
typedef enum
{
	//! <b>Request frame</b> 0
	REQUEST_FRAME = 0x00,
	//! <b>External temperature</b> 1
	EXT_TEMPERATURE = 0x01,
	//! <b>Window open detection status</b> 2
	WINDOW_OPEN_DETECTION_STATUS = 0x02,
	//! <b>PIR status detection</b> 3
	PIR_STATUS_DETECTION = 0x03,
	//! <b>Reference temperature status</b> 4
	REF_TEMP_STATUS = 0x04,
	//! <b>COV sensor</b> 5
	COV_SENSOR = 0x05,
	//! <b>CO sensor</b> 6
	CO_SENSOR = 0x06,
	//! <b>CO2 sensor</b> 7
	CO2_SENSOR = 0x07,
	//! <b>Particles 1 sensor</b> 8
	PARTICLES_1_SENSOR = 0x08,
	//! <b>Particles 2.5 sensor</b> 9
	PARTICLES_25_SENSOR = 0x09,
	//! <b>Particles 10 sensor</b> 10
	PARTICLES_10_SENSOR = 0x0A,
	//! <b>Radio activity sensor</b> 11
	RAD_ACTIVITY_SENSOR = 0x0B,
	//! <b>Sound sensor</b> 12
	SOUND_SENSOR = 0x0C,
	//! <b>Hygrometry sensor</b> 13
	HYGROMETRY_SENSOR = 0x0D,
	//! <b>Air moving sensor</b> 14
	AIR_MOVING_SENSOR = 0x0E,
	//! <b>Pressure sensor</b> 15
	PRESSURE_SENSOR = 0x0F,
	//! <b>Temperature scale status</b> 16
	TEMP_SCALE_STATUS = 0x10,
	//! <b>Time notation status</b> 17
	TIME_NOTATION_STATUS = 0x11,
	//! <b>Display content status</b> 18
	DISP_CONTENT_STATUS = 0x12,
	//! <b>Derogation status</b> 19
	DEROGATION_STATUS = 0x13,
	//! <b>Scheduled order type</b> 20
	SCHEDULED_ORDER_TYPE = 0x14,
	//! <b>End time day</b> 21
	DAY_TIME_END = 0x15,
	//! <b>End time minute</b> 22
	MINUTE_TIME_END = 0x16,
	//! <b>End time hour</b> 23
	HOUR_TIME_END = 0x17,
	//! <b>Start time day</b> 24
	DAY_TIME_START = 0x18,
	//! <b>Start time minute</b> 25
	MINUTE_TIME_START = 0x19,
	//! <b>Start time hour</b> 26
	HOUR_TIME_START = 0x1A,
	//! <b>Clear schedule</b> 27
	CLEAR_SCHEDULE = 0x1B,
	//! <b>Day</b> 28
	VLD_TIME_DAY = 0x1C,
	//! <b>Month</b> 29
	VLD_TIME_MONTH = 0x1D,
	//! <b>Year</b> 30
	VLD_TIME_YEAR = 0x1E,
	//! <b>Minute</b> 31
	VLD_TIME_MINUTE = 0x1F,
	//! <b>Hour</b> 32
	VLD_TIME_HOUR = 0x20,
	//! <b>Day week</b> 33
	VLD_TIME_DAY_WEEK = 0x21,
	//! <b>Heating flag</b> 34
	HEATING_FLAG = 0x22,
	//! <b>Pilot wire flag</b> 35
	PILOT_WIRE_FLAG = 0x23,
	//! <b>Window open detection flag</b> 36
	WINDOW_DETECTION_FLAG = 0x24,
	//! <b>Key lock user status</b> 37
	KEY_LOCK_STATUS = 0x25,
	//! <b>Derogation flag</b> 38
	DEROGATION_FLAG = 0x26,
	//! <b>Internal temperature</b> 39
	INT_TEMPERATURE = 0x27,
	//! <b>Derogation temperature setpoint</b> 40
	DEROGATION_TEMP_SETPOINT = 0x28,
	//! <b>Firmware version</b> 41
	FIRMWARE_VERSION = 0x29,
	//! <b>Radio activity value</b> 42
	RADIO_ACTIVITY = 0x2A,
	//! <b>Internal temperature 2</b> 43
	INT_TEMPERATURE_2 = 0x2B,
	//! <b>Reference temperature flag</b> 44
	REF_TEMP_FLAG = 0x2C,
} VLD_D233_INDEXES;

//! Time notation status enums for D2-33-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	DISP_CONTENT_NO_CHANGE = 0x00,
	//! <b>Default</b> 1
	DISP_CONTENT_DEFAULT = 0x01,
	//! <b>Time</b> 2
	DISP_CONTENT_TIME = 0x02,
	//! <b>Room temperature (internal)</b> 3
	DISP_CONTENT_ROOM_TEMP_INT = 0x03,
	//! <b>Room temperature (external)</b> 4
	DISP_CONTENT_ROOM_TEMP_EXT = 0x04,
	//! <b>Temperature setpoint</b> 5
	DISP_CONTENT_TEMP_SETPOINT = 0x05,
	//! <b>Display off</b> 6
	DISP_CONTENT_DISP_OFF = 0x06,
} D233_DISP_CONTENT;

//! Request frame enums for D2-33-xx profiles
typedef enum
{
	//! <b>Question: external temperature</b> 0
	Q_EXT_TEMP = 0x00,
	//! <b>Question: sensor parameters</b> 1
	Q_SENSOR_PARAMS = 0x01,
	//! <b>Question: program</b> 2
	Q_PROGRAM = 0x02,
	//! <b>Question: time and date</b> 3
	Q_TIME_DATE = 0x03,
	//! <b>Information to gateway</b> 4
	INFO_GATEWAY = 0x04,
	//! <b>Question: status and flags</b> 8
	Q_STATUS_FLAGS = 0x08,
	//! <b>Question: parameters heaters</b> 9
	Q_PARAMS_HEATERS = 0x09,
	//! <b>Question: CO/Hygro/Sound</b> 10
	Q_CO_HYGRO_SOUND = 0x0A,
	//! <b>Question: sensor particle/radioactivity</b> 11
	Q_PARTICLE_RADIOACTIVITY = 0x0B,
	//! <b>Question: sensor air flow, hygrometry, pressure and temperature</b> 13
	Q_ENVIRONMENT = 0x0C,
	//! <b>Information to heater</b> 14
	INFO_HEATER = 0x0D,
	//! <b>Acknowledge frame</b> 15
	ACK_FRAME = 0x0F,
} D233_REQUEST_FRAME_ENUM;

//! Day enums for D2-33-xx profiles
typedef enum
{
	//! <b>Monday</b> 0
	DAY_MONDAY = 0x00,
	//! <b>Tuesday</b> 1
	DAY_TUESDAY = 0x01,
	//! <b>Wednesday</b> 2
	DAY_WEDNESDAY = 0x02,
	//! <b>Thursday</b> 3
	DAY_THURSDAY = 0x03,
	//! <b>Friday</b> 4
	DAY_FRIDAY = 0x04,
	//! <b>Saturday</b> 5
	DAY_SATURDAY = 0x05,
	//! <b>Sunday</b> 6
	DAY_SUNDAY = 0x06
} D233_ENUM_DAYS;

//! Error enums for D2-33-xx profiles
typedef enum
{
	//! <b>Temperature sensor is open</b> 1
	TEMP_SENSOR_OPEN = 0x01,
	//! <b>Temperature sensor is short circuit</b> 2
	TEMP_SENSOR_SHORT_CIRCUIT = 0x02,
	//! <b>Temperature measures is greater than 50 C</b> 4
	TEMP_GREATER_50 = 0x04,
	//! <b>Error between internal temp and external temp is greater than 4 C</b> 8
	INT_EXT_TEMP_GREATER_4 = 0x08
} D233_ERROR_ENUMS;

//! Pilot wire enums for D2-33-xx profiles
typedef enum
{
	//! <b>No pilot wire</b> 0
	NO_PILOT_WIRE = 0x00,
	//! <b>Pilot wire active</b> 1
	PILOT_WIRE_ACTIVE = 0x01,
	//! <b>Pilot wire - 1</b> 2
	PILOT_WIRE_1 = 0x02,
	//! <b>Pilot wire - 2</b> 3
	PILOT_WIRE_2 = 0x03
} D233_PILOT_WIRE_ENUMS;

class eoEEP_D233xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D233xx(uint16_t size = 10);
	virtual ~eoEEP_D233xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);
	virtual eoReturn SetCommand(uint8_t cmd);
	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
