/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D210_H__INCLUDED_)
#define eoEEP_D210_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D210xx
 * \brief The class to handle EEP D210 profiles
 * \details Allows the user to handle EEP D210 profiles, the following profiles are available:
 * 		- D2-10-00
 * 		- D2-10-01
 * 		- D2-10-02\n
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in General Message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			|::D210_MSG_CONTINUATION_ENUM | ::MSG_CONTINUATION |
 * | 1             | ::E_STATE			|::D210_INFO_REQUEST_ENUM | ::INFO_REQUEST_CLASS |
 * | 2             | ::E_STATE			|::D210_FEEDBACK_CLASS_ENUM | ::FEEDBACK_CLASS |
 * | 3             | ::F_ON_OFF			|::D210_GENERAL_MSG_TYPE_ENUM | ::GENERAL_MSG_TYPE |
 *
 * The following channels are available in Data Message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			|::D210_MSG_CONTINUATION_ENUM | ::MSG_CONTINUATION |
 * | 1             | ::S_RELHUM			| float |  |
 * | 2             | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::RELHUM_VALIDITY |
 * | 3             | ::S_VALUE			| float |  |
 * | 4             | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::FANSPEED_VALIDITY |
 * | 5             | ::F_ON_OFF			|::D210_FAN_SPEED_MODE_ENUM | ::FANSPEED_MODE |
 * | 6             | ::F_ON_OFF			| uint8_t | ::CUSTOM_WARNING_2 |
 * | 7             | ::F_ON_OFF			| uint8_t | ::CUSTOM_WARNING_1 |
 * | 8             | ::F_ON_OFF			| uint8_t | ::MOLD_WARNING |
 * | 9             | ::E_STATE			|::VLD_WINDOW_OPEN_ENUM | ::WINDOW_OPEN_DETECTION |
 * | 10            | ::E_STATE			|::D210_BATTERY_STATUS_ENUM | ::BATTERY_STATUS |
 * | 11            | ::F_ON_OFF			|::D210_SOLAR_POWERED_ENUM | ::SOLAR_POWERED_STATUS |
 * | 12            | ::E_STATE			|::VLD_PIR_STATUS_ENUM | ::PIR_STATUS |
 * | 13            | ::E_OCCUPANCY		|::D210_OCCUPANCY_STATUS_ENUM |  |
 * | 14            | ::E_STATE			|::D210_COOLING_HEATING_STATUS_ENUM | ::COOLING_STATUS |
 * | 15            | ::E_STATE			|::D210_COOLING_HEATING_STATUS_ENUM | ::HEATING_STATUS |
 * | 16            | ::E_CONTROLLER_MODE|::D210_ROOM_CONTROL_ENUM |  |
 * | 17            | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::TEMP_SETPOINT_VALIDITY |
 * | 18            | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::TEMP_VALIDITY |
 * | 19            | ::S_TEMP_ABS		| float | ::RECENT_TEMP_SETPOINT |
 * | 20            | ::S_TEMP			| float |  |
 *
 * The following channels are available in Configuration Message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			|::D210_MSG_CONTINUATION_ENUM | ::MSG_CONTINUATION |
 * | 1             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::PIR_LOCK |
 * | 2             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::TEMP_LOCK |
 * | 3             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::DISPLAY_LOCK |
 * | 4             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::DATE_TIME_LOCK |
 * | 5             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::TIME_PROG_LOCK |
 * | 6             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::OCCUPANCY_LOCK |
 * | 7             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::TEMP_SETPOINT_LOCK |
 * | 8             | ::F_ON_OFF			|::D210_LOCK_ENUM | ::FAN_SPEED_LOCK |
 * | 9             | ::S_TIME			| float,::D210_RADIO_COM_INTERVAL_ENUM | ::RADIO_COM_INTERVAL |
 * | 10            | ::F_ON_OFF			|::D210_LOCK_ENUM | ::KEY_LOCK |
 * | 11            | ::E_STATE			|::D210_DISPLAY_CONTENT_ENUM | ::DISPLAY_CONTENT |
 * | 12            | ::E_STATE			|::VLD_TEMP_SCALE_ENUM | ::TEMP_SCALE |
 * | 13            | ::F_ON_OFF			|::D210_DAYLIGHT_SAVE_ENUM | ::DAYLIGHT_SAVE |
 * | 14            | ::E_STATE			|::D210_TIME_NOTATION_ENUM | ::TIME_NOTATION |
 * | 15            | ::S_TIME			| float | ::TIME_CURRENT_DAY |
 * | 16            | ::S_TIME			| float | ::TIME_CURRENT_MONTH |
 * | 17            | ::S_TIME			| float | ::TIME_CURRENT_YEAR |
 * | 18            | ::S_TIME			| float | ::TIME_CURRENT_MINUTE |
 * | 19            | ::S_TIME			| float | ::TIME_CURRENT_HOUR |
 * | 20            | ::F_ON_OFF			|::D210_DATE_TIME_UPDATE_ENUM | ::DATE_TIME_UPDATE_FLAG |
 *
 * The following channels are available in Room Control Setup Message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			|::D210_MSG_CONTINUATION_ENUM | ::MSG_CONTINUATION |
 * | 1             | ::S_TEMP_ABS		| float | ::BUILDING_PROTECT_TEMP_SETPOINT |
 * | 2             | ::S_TEMP_ABS		| float | ::PRECOMFORT_TEMP_SETPOINT |
 * | 3             | ::S_TEMP_ABS		| float | ::ECONOMY_TEMP_SETPOINT |
 * | 4             | ::S_TEMP_ABS		| float | ::COMFORT_TEMP_SETPOINT |
 * | 5             | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY |
 * | 6             | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::PRECOMFORT_TEMP_SETPOINT_VALIDITY |
 * | 7             | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY |
 * | 8             | ::F_ON_OFF			|::D210_VALIDITY_FLAG_ENUM | ::COMFORT_TEMP_SETPOINT_VALIDITY |
 *
 * The following channels are available in Time Program Setup Message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			|::D210_MSG_CONTINUATION_ENUM | ::MSG_CONTINUATION |
 * | 1             | ::S_TIME			| float | ::END_TIME_MINUTE |
 * | 2             | ::S_TIME			| float | ::END_TIME_HOUR |
 * | 3             | ::S_TIME			| float | ::START_TIME_MINUTE |
 * | 4             | ::S_TIME			| float | ::START_TIME_HOUR |
 * | 5             | ::E_DAYS			| ::D210_PERIOD_ENUM |  |
 * | 6             | ::E_CONTROLLER_MODE|::D210_ROOM_CONTROL_ENUM |  |
 * | 7             | ::F_ON_OFF			|::D210_TIME_PROG_DELETION_ENUM | ::TIME_PROG_DELETION |
 * \n
 *
 */

/**
 * \file eoEEP_D210xx.h
 */

//! Index enums for D2-10-xx profiles
typedef enum
{
	//! <b>Message continuation flag</b> 0
	MSG_CONTINUATION = 0x00,
	//! <b>Information request classifier</b> 1
	INFO_REQUEST_CLASS = 0x01,
	//! <b>Feedback classifier</b> 2
	FEEDBACK_CLASS = 0x02,
	//! <b>General message typer</b> 3
	GENERAL_MSG_TYPE = 0x03,
	//! <b>Humidity validity flag</b> 4
	RELHUM_VALIDITY = 0x04,
	//! <b>Fan speed validity flag</b> 5
	FANSPEED_VALIDITY = 0x05,
	//! <b>Fan speed mode</b> 6
	FANSPEED_MODE = 0x06,
	//! <b>Custom warning 1</b> 7
	CUSTOM_WARNING_1 = 0x07,
	//! <b>Custom warning 2</b> 8
	CUSTOM_WARNING_2 = 0x08,
	//! <b>Mold warning</b> 9
	MOLD_WARNING = 0x09,
	//! <b>Window open detection</b> 10
	WINDOW_OPEN_DETECTION = 0x0A,
	//! <b>Battery status</b> 11
	BATTERY_STATUS = 0x0B,
	//! <b>Solar-powered status</b> 12
	SOLAR_POWERED_STATUS = 0x0C,
	//! <b>PIR status</b> 13
	PIR_STATUS = 0x0D,
	//! <b>Cooling operation status</b> 14
	COOLING_STATUS = 0x0E,
	//! <b>Heating operation status</b> 15
	HEATING_STATUS = 0x0F,
	//! <b>Temperature set point validity</b> 16
	TEMP_SETPOINT_VALIDITY = 0x10,
	//! <b>Temperature validity</b> 17
	TEMP_VALIDITY = 0x11,
	//! <b>PIR status lock</b> 18
	PIR_LOCK = 0x12,
	//! <b>Temperature scale lock</b> 19
	TEMP_LOCK = 0x13,
	//! <b>Display content lock</b> 20
	DISPLAY_LOCK = 0x14,
	//! <b>Date / Time lock</b> 21
	DATE_TIME_LOCK = 0x15,
	//! <b>Time program lock</b> 22
	TIME_PROG_LOCK = 0x16,
	//! <b>Occupancy lock</b> 23
	OCCUPANCY_LOCK = 0x17,
	//! <b>Temperature set point lock</b> 24
	TEMP_SETPOINT_LOCK = 0x18,
	//! <b>Fan speed lock</b> 25
	FAN_SPEED_LOCK = 0x19,
	//! <b>Radio communication interval</b> 26
	RADIO_COM_INTERVAL = 0x1A,
	//! <b>Key lock</b> 27
	KEY_LOCK = 0x1B,
	//! <b>Display content</b> 28
	DISPLAY_CONTENT = 0x1C,
	//! <b>Temperature scale</b> 29
	TEMP_SCALE = 0x1D,
	//! <b>Daylight saving time flag</b> 30
	DAYLIGHT_SAVE = 0x1E,
	//! <b>Time notation</b> 31
	TIME_NOTATION = 0x1F,
	//! <b>Day</b> 32
	TIME_CURRENT_DAY = 0x20,
	//! <b>Month</b> 33
	TIME_CURRENT_MONTH = 0x21,
	//! <b>Year</b> 34
	TIME_CURRENT_YEAR = 0x22,
	//! <b>Time minute</b> 35
	TIME_CURRENT_MINUTE = 0x23,
	//! <b>Time hour</b> 36
	TIME_CURRENT_HOUR = 0x24,
	//! <b>Day / time update</b> 37
	DATE_TIME_UPDATE_FLAG = 0x25,
	//! <b>Recent temperature</b> 38
	RECENT_TEMP_SETPOINT = 0x26,
	//! <b>Building protection temperature set point</b> 39
	BUILDING_PROTECT_TEMP_SETPOINT = 0x27,
	//! <b>Pre-comfort temperature set point</b> 40
	PRECOMFORT_TEMP_SETPOINT = 0x28,
	//! <b>Economy temperature set point</b> 41
	ECONOMY_TEMP_SETPOINT = 0x29,
	//! <b>Comfort temperature set point</b> 42
	COMFORT_TEMP_SETPOINT = 0x2A,
	//! <b>Building protection temperature set point validity</b> 43
	BUILDING_PROTECT_TEMP_SETPOINT_VALIDITY = 0x2B,
	//! <b>Pre-comfort temperature set point validity</b> 44
	PRECOMFORT_TEMP_SETPOINT_VALIDITY = 0x2C,
	//! <b>Economy temperature set point validity</b> 45
	ECONOMY_TEMP_TEMP_SETPOINT_VALIDITY = 0x2D,
	//! <b>Comfort temperature set point validity</b> 46
	COMFORT_TEMP_SETPOINT_VALIDITY = 0x2E,
	//! <b>End time minute</b> 47
	END_TIME_MINUTE = 0x2F,
	//! <b>End time hour</b> 48
	END_TIME_HOUR = 0x30,
	//! <b>Start time minute</b> 49
	START_TIME_MINUTE = 0x31,
	//! <b>Start time hour</b> 50
	START_TIME_HOUR = 0x32,
	//! <b>Time program deletion</b> 51
	TIME_PROG_DELETION = 0x33
} D210_INDEX_ENUM;

//! Message IDs for D2-10-xx profiles
typedef enum
{
	//! <b>General Message</b> 0
	GENERAL_MSG = 0x00,
	//! <b>Data Message</b> 1
	DATA_MSG = 0x01,
	//! <b>Configuration Message</b> 2
	CONFIG_MSG = 0x02,
	//! <b>Room Control Setup</b> 3
	ROOM_CONTROL_MSG = 0x03,
	//! <b>Time program Setup</b> 4
	TIME_PROG_MSG = 0x04
} D210_MESSAGE_ID_ENUM;

//! Message continuation enums for D2-10-xx profiles
typedef enum
{
	//! <b>Complete</b> 0
	MSG_COMPLETE = 0x00,
	//! <b>Incomplete</b> 1
	MSG_INCOMPLETE = 0x01,
	//! <b>Automatic message control</b> 2
	MSG_AUTO_CONTROL = 0x02
} D210_MSG_CONTINUATION_ENUM;

//! Information request classifier enums for D2-10-xx profiles
typedef enum
{
	//! <b>Acknowledge request</b> 0
	ACKNOWLEDGE_REQUEST = 0x00,
	//! <b>Data request</b> 1
	DATA_REQUEST = 0x01,
	//! <b>Configuration request</b> 2
	CONFIG_REQUEST = 0x02,
	//! <b>Room control setup request</b> 3
	ROOM_CONTROL_REQUEST = 0x03,
	//! <b>Time program request</b> 4
	TIME_PROG_REQUEST = 0x04
} D210_INFO_REQUEST_ENUM;

//! Feedback classifier enums for D2-10-xx profiles
typedef enum
{
	//! <b>Acknowledge/heartbeat</b> 0
	ACKNOWLEDGE_FEEDBACK = 0x00,
	//! <b>Telegram repetition request</b> 1
	TEL_REPETITION_FEEDBACK = 0x01,
	//! <b>Message repetition request</b> 2
	MSG_REPETITION_FEEDBACK = 0x02
} D210_FEEDBACK_CLASS_ENUM;

//! General message type enums for D2-10-xx profiles
typedef enum
{
	//! <b>Feedback</b> 0
	MSG_TYPE_FEEDBACK = 0x00,
	//! <b>Information request</b> 1
	MSG_TYPE_INFO_REQUEST = 0x01
} D210_GENERAL_MSG_TYPE_ENUM;

//! Validity flag enums for D2-10-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	VALIDITY_NO_CHANGE = 0x00,
	//! <b>Valid value</b> 1
	VALIDITY_VALID_VALUE = 0x01
} D210_VALIDITY_FLAG_ENUM;

//! Fan speed mode enums for D2-10-xx profiles
typedef enum
{
	//! <b>Central fan speed control</b> 0
	FAN_SPEED_CENTRAL_CONTROL = 0x00,
	//! <b>Individual fan speed control</b> 1
	FAN_SPEED_INDIVIDUAL_CONTROL = 0x01
} D210_FAN_SPEED_MODE_ENUM;


//! Battery status enums for D2-10-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	BATTERY_VLD_NO_CHANGE = 0x00,
	//! <b>Good</b> 1
	BATTERY_VLD_GOOD = 0x01,
	//! <b>Low</b> 2
	BATTERY_VLD_LOW = 0x02,
	//! <b>Critical</b> 3
	BATTERY_VLD_CRITICAL = 0x03
} D210_BATTERY_STATUS_ENUM;

//! Solar-powered status enums for D2-10-xx profiles
typedef enum
{
	//! <b>Solar-powered</b> 0
	SOLAR_POWERED = 0x00,
	//! <b>Not solar-powered</b> 1
	NOT_SOLAR_POWERED = 0x01
} D210_SOLAR_POWERED_ENUM;

//! Occupancy button status enums for D2-10-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	OCCUPANCY_NO_CHANGE = 0x00,
	//! <b>Button pressed and occupied</b> 1
	OCCUPANCY_PRESSED_OCCUPIED = 0x01,
	//! <b>Button pressed and unoccupied</b> 2
	OCCUPANCY_PRESSED_UNOCCUPIED = 0x02
} D210_OCCUPANCY_STATUS_ENUM;

//! Cooling/Heating operation status enums for D2-10-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	COOLING_HEATING_NO_CHANGE = 0x00,
	//! <b>On</b> 1
	COOLING_HEATING_ON = 0x01,
	//! <b>Off</b> 2
	COOLING_HEATING_OFF = 0x02,
	//! <b>Automatic</b> 3
	COOLING_HEATING_AUTO = 0x03
} D210_COOLING_HEATING_STATUS_ENUM;

//! Room control mode enums for D2-10-xx profiles
typedef enum
{
	//! <b>Comfort</b> 0
	ROOM_CONTROL_COMFORT = 0x00,
	//! <b>Economy</b> 1
	ROOM_CONTROL_ECONOMY = 0x01,
	//! <b>Pre-comfort</b> 2
	ROOM_CONTROL_PRECOMFORT = 0x02,
	//! <b>Building protection</b> 3
	ROOM_CONTROL_BUILDING_PROTECT = 0x03
} D210_ROOM_CONTROL_ENUM;

//! Lock status enums for D2-10-xx profiles
typedef enum
{
	//! <b>Lock</b> 0
	LOCKED = 0x00,
	//! <b>Unlocked</b> 1
	UNLOCKED = 0x01
} D210_LOCK_ENUM;

//! Radio communication interval enums for D2-10-xx profiles
typedef enum
{
	//! <b>No communication interval</b> 0
	RADIO_NO_INTERVAL= 0x00,
	//! <b>3 hours</b> 61
	RADIO_3_HOURS_INTERVAL = 0x3D,
	//! <b>12 hours</b> 62
	RADIO_12_HOURS_INTERVAL = 0x3E,
	//! <b>24 hours</b> 63
	RADIO_24_HOURS_INTERVAL = 0x3F
} D210_RADIO_COM_INTERVAL_ENUM;

//! Display content enums for D2-10-xx profiles
typedef enum
{
	//! <b>No change</b> 0
	DISPLAY_NO_CHANGE= 0x00,
	//! <b>Default</b> 1
	DISPLAY_DEFAULT = 0x01,
	//! <b>Time</b> 2
	DISPLAY_TIME = 0x02,
	//! <b>Room temperature (internal)</b> 3
	DISPLAY_INTERNAL_TEMP = 0x03,
	//! <b>Room temperature (external)</b> 4
	DISPLAY_EXTERNAL_TEMP = 0x04,
	//! <b>Temperature set point</b> 5
	DISPLAY_TEMP_SETPOINT = 0x05,
	//! <b>Display off</b> 6
	DISPLAY_OFF = 0x06,
	//! <b>Humidity</b> 7
	DISPLAY_HUMIDITY = 0x07
} D210_DISPLAY_CONTENT_ENUM;

//! Daylight saving time enums for D2-10-xx profiles
typedef enum
{
	//! <b>Supported</b> 0
	DAYLIGHT_SUPPORTED = 0x00,
	//! <b>Not supported</b> 1
	DAYLIGHT_NOT_SUPPORTED = 0x01
} D210_DAYLIGHT_SAVE_ENUM;

//! Day / time update enums for D2-10-xx profiles
typedef enum
{
	//! <b>No update</b> 0
	DATE_TIME_NO_UPDATE = 0x00,
	//! <b>Update</b> 1
	DATE_TIME_UPDATE = 0x01
} D210_DATE_TIME_UPDATE_ENUM;

//! Period enums for D2-10-xx profiles
typedef enum
{
	//! <b>Monday - Sunday</b> 0
	PERIOD_MONDAY_SUNDAY = 0x00,
	//! <b>Monday - Friday</b> 1
	PERIOD_MONDAY_FRIDAY = 0x01,
	//! <b>Saturday - Sunday</b> 2
	PERIOD_SATURDAY_SUNDAY = 0x02,
	//! <b>Monday</b> 3
	PERIOD_MONDAY = 0x03,
	//! <b>Tuesday</b> 4
	PERIOD_TUESDAY = 0x04,
	//! <b>Wednesday</b> 5
	PERIOD_WEDNESDAY = 0x05,
	//! <b>Thursday</b> 6
	PERIOD_THURSDAY = 0x06,
	//! <b>Friday</b> 7
	PERIOD_FRIDAY = 0x07,
	//! <b>Saturday</b> 8
	PERIOD_SATURDAY = 0x08,
	//! <b>Sunday</b> 9
	PERIOD_SUNDAY = 0x09,
	//! <b>Monday - Wednesday</b> 10
	PERIOD_MONDAY_WEDNESDAY = 0x0A,
	//! <b>Tuesday - Thursday</b> 11
	PERIOD_TUESDAY_THURSDAY = 0x0B,
	//! <b>Wednesday - Friday</b> 12
	PERIOD_WEDNESDAY_FRIDAY = 0x0C,
	//! <b>Thursday - Friday</b> 13
	PERIOD_THURSDAY_FRIDAY = 0x0D,
	//! <b>Friday - Sunday</b> 14
	PERIOD_FRIDAY_SUNDAY = 0x0E,
	//! <b>Friday - Monday</b> 15
	PERIOD_FRIDAY_MONDAY = 0x0F
} D210_PERIOD_ENUM;

//! Time program deletion enums for D2-10-xx profiles
typedef enum
{
	//! <b>No deletion</b> 0
	TIME_PROG_NO_DELETE = 0x00,
	//! <b>Deletion</b> 1
	TIME_PROG_DELETE = 0x01
} D210_TIME_PROG_DELETION_ENUM;

class eoEEP_D210xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D210xx(uint16_t size = 10);
	virtual ~eoEEP_D210xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
