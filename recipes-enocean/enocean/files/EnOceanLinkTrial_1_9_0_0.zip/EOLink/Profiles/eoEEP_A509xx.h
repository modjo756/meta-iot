/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if !defined(eoEEP_A509_H__INCLUDED_)
#define eoEEP_A509_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
/**\class eoEEP_A509xx
 * \brief The class to handle EEP a509 profiles
 * \details Allows the user to handle EEP a509 profiles, the following profiles are available:
 * 		- A5-09-01
 * 		- A5-09-02
 * 		- A5-09-04
 * 		- A5-09-05
 * 		- A5-09-06
 * 		- A5-09-07
 * 		- A5-09-08
 * 		- A5-09-09
 * 		- A5-09-0A
 * 		- A5-09-0B
 * 		- A5-09-0C
 *
 * 		\n
 * The following channels are available for 01 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC       |float |
 * | 1             | ::S_TEMP       |float |
 *
 * The following channels are available for 02 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_VOLTAGE    |float |
 * | 1             | ::S_CONC       |float |
 * | 2             | ::S_TEMP       |float |
 *
 * The following channels are available for 04 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_RELHUM     |float |
 * | 1             | ::S_CONC       |float |
 * | 2             | ::S_TEMP       |float |
 *
 * The following channels are available for 05 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC      |float |
 * | 1             | ::E_VOC       |::ENUM_VOC |
 *
 * The following channels are available for 06 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_RADON_ACTIVITY      |float |
 *
 * The following channels are available for 07 Profile:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PARTICLES|float | ::PM10 |
 * | 1             | ::S_PARTICLES|float | ::PM2_5|
 * | 2             | ::S_PARTICLES|float | ::PM1 |
 *
 * The following channels are available for 08 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC	  |float |
 *
 * The following channels are available for 09 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC	  |float |
 * | 1			   | ::F_POWERALARM | uint8_t |
 *
 * The following channels are available for 0A Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC	  |float |
 * | 1             | ::S_TEMP	  |float |
 * | 2             | ::S_VOLTAGE  |float |
 *
 * The following channels are available for 0B Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_VOLTAGE	  |float |
 * | 1             | ::S_COUNTER  |float |
 * | 2			   | ::E_UNITS	  | ::ENUM_RADIATION_UNIT |
 *
 * The following channels are available for 05 Profile:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_CONC      |float |
 * | 1             | ::E_VOC       |::ENUM_VOC |
 * | 2			   | ::E_UNITS	  | ::ENUM_CONCENTRATION_UNIT |
 */

/**
 * \file eoEEP_A509xx.h
 */
//!Particle size in A5-09-07 profile
typedef enum
{
	//! <b>Particles 10</b> 0
	PM10 = 0x00,
	//! <b>Particles 2.5</b> 1
	PM2_5 = 0x01,
	//! <b>Particles 1</b> 2
	PM1 = 0x02
} ENUM_PARTICLES_SIZE;

//!The unit of the radiation level in A5-09-0A profile
typedef enum
{
	//! <b>uSv/h</b> 0
	USV_H = 0x00,
	//! <b>Cpm</b> 1
	CPM = 0x01,
	//! <b>Bq/L</b> 2
	BQ_L = 0x02,
	//! <b>Bq/kg</b> 2
	BQ_KG = 0x03
} ENUM_RADIATION_UNIT;

//!The unit of the concentration in A5-09-0C profile
typedef enum
{
	//! <b>ppb</b> 0
	CONCENTRATION_PPB = 0x00,
	//! <b>ug/m3</b> 1
	CONCENTRATION_UGM3 = 0x01
} ENUM_CONCENTRATION_UNIT;

//!Power failure detection
typedef enum
{
	//! <b>Power failure not detected</b> 0
	NO_POWER_FAILURE = 0x00,
	//! <b>Power failure detected</b> 1
	POWER_FAILURE_DETECTED = 0x01
} ENUM_POWER_FAILURE_DETECTION;

class eoEEP_A509xx: public eoA5EEProfile
{

public:
	eoReturn SetType(uint8_t type);
	eoEEP_A509xx();
	virtual ~eoEEP_A509xx();

	eoReturn GetValue(CHANNEL_TYPE type, float &value);
	eoReturn SetValue(CHANNEL_TYPE type, float value);
	eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
};

#endif
