/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D230_H__INCLUDED_)
#define eoEEP_D230_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D230xx
 * \brief The class to handle EEP D230 profiles
 * \details Allows the user to handle EEP D230 profiles, the following profiles are available:
 * 		- D2-30-11\n
 *
 *	\note set the command before use.
 *
 * The following channels are available for Set heating controls output command:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_STATE	  		|::MSR_TIME_VALUES	 	|
 * | 1             | ::F_OPEN_CLOSED    |::MSR_CONNECTED_VALVE 	|
 * | 2             | ::S_VALUE			| float |
 * | 3             | ::F_ON_OFF			|::MSR_INIT_SEQU	|
 * | 4             | ::S_SETPOINT		|float	|
 *
 * The following channels are available for Heating controls status query command:
 *
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_VALUE			| float |
 *
 * The following channels are available for Heating controls status response command:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_ERROR_STATE	| ::MSR_ERROR_CODE | ::MSR_CHANNEL_ERROR |
 * | 1             | ::S_VALUE			| float |  |
 * | 2             | ::S_PERCENTAGE		| float |  |
 * | 3             | ::S_TEMP			| float | ::MSR_CHANNEL_RETURN_TEMP |
 *
 * If Heating channel (HCH) returns 31, the following channels are available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_ERROR_STATE	| ::MSR_ERROR_CODE_CH31 | ::MSR_CHANNEL_ERROR_HCH31 |
 * | 1             | ::S_TEMP			| float | ::MSR_CHANNEL_SUPPLY_TEMP |
 * | 2             | ::S_TEMP			| float | ::MSR_CHANNEL_RETURN_TEMP |
 *
 * The following channels are available for Set meter configuration command:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			| ::MSR_REPORT_TIME_VALUES | ::MSR_CHANNEL_REPORT_TIME |
 * | 1             | ::E_STATE			| ::MSR_METER_BUS_TYPE | ::MSR_CHANNEL_METER_TYPE |
 * | 2             | ::S_VALUE			| float | ::MSR_CHANNEL_METER_CHANNEL |
 * | 3             | ::E_UNITS			| ::MSR_METER_UNITS | ::MSR_CHANNEL_METER_1 |
 * | 4             | ::E_UNITS			| ::MSR_METER_UNITS | ::MSR_CHANNEL_METER_2 |
 *
 * The rest of the channels are depending on the BUS type (MBUS, S0, D0).
 *
 * The following channels are available if MBUS is available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_VALUE	| float | ::MSR_CHANNEL_PRIMARY_ADDR |
 *
 * The following channels are available if S0 is available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_UNITS	| ::MSR_FACTOR_PULSES | ::MSR_CHANNEL_PULSES_FACTOR |
 * | 1             | ::S_VALUE	| float | ::MSR_CHANNEL_NUM_OF_PULSES |
 * | 2             | ::S_VALUE	| float | ::MSR_CHANNEL_PRESET_VALUE |
 *
 * The following channels are available if D0 is available:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE	| ::MSR_PROTOCOL | ::MSR_CHANNEL_PROTOCOL |
 *
 * The following channels are available for Meter status query command:
 *
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_STATE			| ::MSR_METER_BUS_TYPE |
 * | 1             | ::S_VALUE			| float |
 *
 * The following channels are available for Meter reading report/status response command:
 *
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::E_STATE			| ::MSR_METER_ERROR_CODE | ::MSR_CHANNEL_METER_ERROR |
 * | 1             | ::E_STATE			| ::MSR_METER_BUS_TYPE | ::MSR_CHANNEL_METER_TYPE |
 * | 2             | ::S_VALUE			| float | ::MSR_CHANNEL_METER_CHANNEL |
 * | 3             | ::E_STATE			| ::MSR_VALUE_SELECTION | ::MSR_CHANNEL_VALUE_SELECTION |
 * | 4             | ::E_UNITS			| ::MSR_VALUE_UNITS |  |
 * | 5             | ::S_VALUE			| float | ::MSR_CHANNEL_METER_1 |
 *
 * \n
 */

/**
 * \file eoEEP_D230xx.h
 */
//! Command enums for D2-30-xx profiles
typedef enum
{
	//! <b>1</b> Set heating controls output
	MSR_SET_HEAT_CONTROLS = 0x01,
	//! <b>2</b> Heating controls status query
	MSR_HEAT_CONTROL_STATUS_QUERY = 0x02,
	//! <b>3</b> Heating controls status response
	MSR_HEAT_CONTROL_STATUS_RESPONSE = 0x03,
	//! <b>6</b> Set meter configuration
	MSR_SET_METER_CONFIGURATION = 0x06,
	//! <b>7</b> Meter status query
	MSR_METER_STATUS_QUERY = 0x07,
	//! <b>8</b> Meter reading report/status response
	MSR_METER_READING_REPORT = 0x08
}MSR_COMMANDS;

//! Channel enums
typedef enum
{
	//! <b>0</b> Supply temperature of the unit
	MSR_CHANNEL_SUPPLY_TEMP = 0x00,
	//! <b>1</b> Return temperature
	MSR_CHANNEL_RETURN_TEMP = 0x01,
	//! <b>2</b> Supply temperature
	MSR_CHANNEL_REPORT_TIME = 0x02,
	//! <b>3</b> Return temperature
	MSR_CHANNEL_METER_TYPE = 0x03,
	//! <b>4</b> Meter 1 units
	MSR_CHANNEL_METER_1 = 0x04,
	//! <b>5</b> Meter 2 units
	MSR_CHANNEL_METER_2 = 0x05,
	//! <b>6</b> Number of pulses
	MSR_CHANNEL_NUM_OF_PULSES = 0x06,
	//! <b>7</b> Preset value
	MSR_CHANNEL_PRESET_VALUE = 0x07,
	//! <b>8</b> Preset value
	MSR_CHANNEL_PROTOCOL = 0x08,
	//! <b>9</b> Factor of number of pulses
	MSR_CHANNEL_PULSES_FACTOR = 0x09,
	//! <b>10</b> Primary Address
	MSR_CHANNEL_PRIMARY_ADDR = 0x0A,
	//! <b>11</b> Error codes for Heating controls status response
	MSR_CHANNEL_ERROR = 0x0B,
	//! <b>12</b> Error codes for Heating controls status response if Heating channel is 31
	MSR_CHANNEL_ERROR_CH31 = 0x0C,
	//! Deprecated typo
	MSR_CHANNEL_ERROR_HCH31 = 0x0C,
	//! <b>13</b> Meter error code
	MSR_CHANNEL_METER_ERROR = 0x0D,
	//! <b>14</b> Meter channel index
	MSR_CHANNEL_METER_CHANNEL = 0x0E,
	//! <b>15</b> Value selection
	MSR_CHANNEL_VALUE_SELECTION = 0x0F,
	//! <b>16</b> The current common return temperature (Heating Channel=31)
	MSR_COMMON_RETURN_TEMP = 0x10
} MSR_CHANNELS;

//! Enums for PWM signal intervals
typedef enum
{
	//! <b>0</b> Local default/no change
	MSR_LOCAL_DEFAULT = 0x00,
	//! <b>1</b> 1 second
	MSR_1_SECOND = 0x01,
	//! <b>2</b> 2 seconds
	MSR_2_SECOND = 0x02,
	//! <b>3</b> 5 seconds
	MSR_5_SECOND = 0x03,
	//! <b>4</b> 10 seconds
	MSR_10_SECOND = 0x04,
	//! <b>5</b> 20 seconds
	MSR_20_SECOND = 0x05,
	//! <b>6</b> 50 seconds
	MSR_50_SECOND = 0x06,
	//! <b>7</b> 100 seconds
	MSR_100_SECOND = 0x07,
	//! <b>8</b> 200 seconds
	MSR_200_SECOND = 0x08,
	//! <b>9</b> 500 seconds
	MSR_500_SECOND = 0x09,
	//! <b>10</b> 1000 seconds
	MSR_1000_SECOND = 0x0A
} MSR_TIME_VALUES; //MSR because of the submitter

//! Enums for Minimum auto reporting intervals
typedef enum
{
	//! <b>0</b> No auto reporting
	MSR_NO_REPORT = 0x00,
	//! <b>1</b> 1 second
	MSR_1_SECOND_REPORT = 0x01,
	//! <b>2</b> 3 seconds
	MSR_3_SECOND_REPORT = 0x02,
	//! <b>3</b> 10 seconds
	MSR_10_SECOND_REPORT = 0x03,
	//! <b>4</b> 30 seconds
	MSR_30_SECOND_REPORT = 0x04,
	//! <b>5</b> 100 seconds
	MSR_100_SECOND_REPORT = 0x05,
	//! <b>6</b> 300 seconds
	MSR_300_SECOND_REPORT = 0x06,
	//! <b>7</b> 1000 seconds
	MSR_1000_SECOND_REPORT = 0x07
} MSR_REPORT_TIME_VALUES; //MSR because of the submitter

//! Enums for type of connected valve
typedef enum
{
	//! <b>0</b> Valve normally closed
	MSR_VALVE_NORM_CLOSED = 0x00,
	//! <b>1</b> Valve normally open
	MSR_VALVE_NORM_OPEN = 0x01
} MSR_CONNECTED_VALVE;

//! Enums for running init sequence
typedef enum
{
	//! <b>0</b> No action
	MSR_NO_ACTION = 0x00,
	//! <b>1</b> Run init sequence
	MSR_RUN_INIT_SEQU = 0x01
} MSR_INIT_SEQU;

//! Enums for Status/Error
typedef enum
{
	//! <b>0</b> No fault
	MSR_ERROR_NO_FAULT = 0x00,
	//! <b>1</b> General error
	MSR_ERROR_GENERAL = 0x01,
	//! <b>2</b> Init sequence running
	MSR_ERROR_INIT_SEQU_RUNNING = 0x02,
	//! <b>3</b> Channel not available
	MSR_ERROR_CHANNEL_NOT_AVAILABLE = 0x03,
	//! <b>4</b> Temperature sensor error
	MSR_ERROR_TEMP_SENSOR = 0x04,
	//! <b>5</b> Valve error
	MSR_ERROR_VALVE = 0x05,
	//! <b>6</b> Temperature sensor and Valve error
	MSR_ERROR_TEMP_SENSOR_VALVE = 0x06
} MSR_ERROR_CODE;

//! Enums for Status/Error if HCH = 31
typedef enum
{
	//! <b>0</b> No fault
	MSR_ERROR_CH31_NO_FAULT = 0x00,
	//! <b>1</b> General error
	MSR_ERROR_CH31_GENERAL = 0x01,
	//! <b>2</b> Supply temperature error
	MSR_ERROR_CH31_SUPPLY_TEMP = 0x02,
	//! <b>3</b> Return temperature error
	MSR_ERROR_CH31_RETURN_TEMP = 0x03,
	//! <b>3</b> Error on both sensors
	MSR_ERROR_CH31_SUPPLY_RETURN_TEMP = 0x04
} MSR_ERROR_CODE_CH31;

//! Enums for Status/Error
typedef enum
{
	//! <b>0</b> No fault
	MSR_METER_ERROR_NO_FAULT = 0x00,
	//! <b>1</b> General error
	MSR_METER_ERROR_GENERAL = 0x01,
	//! <b>2</b> Bus unconfigured
	MSR_METER_BUS_NO_CONFIG = 0x02,
	//! <b>3</b> Bus unconnected
	MSR_METER_BUS_NO_CONNECTION = 0x03,
	//! <b>4</b> Bus shortcut
	MSR_METER_BUS_SHORTCUT = 0x04,
	//! <b>5</b> Communication timeout
	MSR_METER_TIMEOUT = 0x05,
	//! <b>6</b> Unknown protocol or configuration mismatch
	MSR_METER_UNKNOWN_CONFIG = 0x06,
	//! <b>7</b> Bus initialisation running
	MSR_METER_BUS_INIT_RUNNING = 0x07
} MSR_METER_ERROR_CODE;

//! Enums for Meter bus type
typedef enum
{
	//! <b>1</b> MBUS
	MSR_BUS_TYPE_MBUS = 0x01,
	//! <b>2</b> S0
	MSR_BUS_TYPE_S0 = 0x02,
	//! <b>3</b> D0
	MSR_BUS_TYPE_D0 = 0x03
} MSR_METER_BUS_TYPE;

//! Enums for Meter units
typedef enum
{
	//! <b>0</b> No reading
	MSR_UNIT_NO_READING = 0x00,
	//! <b>1</b> Current value in W, accumulated value in kWh
	MSR_UNIT_CURRENT_W_ACCUM_KWH = 0x01,
	//! <b>2</b> Current value in W, accumulated value in Wh
	MSR_UNIT_CURRENT_W_ACCUM_WH = 0x02,
	//! <b>3</b> Accumulated value in kWh
	MSR_UNIT_ACCUM_KWH = 0x03,
	//! <b>4</b> Current value in m3/h, accumulated value in m3
	MSR_UNIT_CURRENT_M3_ACCUM_M3 = 0x04,
	//! <b>5</b> Current value in dm3/h, accumulated value in dm3
	MSR_UNIT_CURRENT_DM3_ACCUM_DM3 = 0x05,
	//! <b>6</b> Accumulated value in m3
	MSR_UNIT_ACCUM_M3 = 0x06,
	//! <b>7</b> Digital counter
	MSR_UNIT_DIGIT_COUNTER = 0x07
} MSR_METER_UNITS;

//! Enums for Meter units
typedef enum
{
	//! <b>0</b> Value in W
	MSR_VALUE_W = 0x00,
	//! <b>1</b> Value in Wh
	MSR_VALUE_WH = 0x01,
	//! <b>2</b> Value in kWh
	MSR_VALUE_KWH = 0x02,
	//! <b>3</b> Value in m3/h
	MSR_VALUE_M3H = 0x03,
	//! <b>3</b> Value in dm3/h
	MSR_VALUE_DM3H = 0x04,
	//! <b>5</b> Value in m3
	MSR_VALUE_M3 = 0x05,
	//! <b>6</b> Value in dm3
	MSR_VALUE_DM3 = 0x06,
	//! <b>7</b> Digital counter
	MSR_VALUE_DIGIT_COUNTER = 0x07
} MSR_VALUE_UNITS;

//! Enums for factor of number of pulses
typedef enum
{
	//! <b>0</b> 1
	MSR_FACTOR_PULSES_1 = 0x00,
	//! <b>1</b> 0.1
	MSR_FACTOR_PULSES_01 = 0x01,
	//! <b>2</b> 0.01
	MSR_FACTOR_PULSES_001 = 0x02,
	//! <b>3</b> 0.001
	MSR_FACTOR_PULSES_0001 = 0x03
} MSR_FACTOR_PULSES;

//! Enums for D0 protocol
typedef enum
{
	//! <b>0</b> Auto detect
	MSR_PROTOCOL_AUTO_DETECT = 0x00,
	//! <b>1</b> SML (Smart Message Language)
	MSR_PROTOCOL_SML = 0x01,
	//! <b>2</b> DLMS (Device Language Message Specification)
	MSR_PROTOCOL_DLMS = 0x02
} MSR_PROTOCOL;

//! Enums for Value selection
typedef enum
{
	//! <b>0</b> Meter 1, Current value
	MSR_VALUE_1_CURRENT = 0x00,
	//! <b>1</b> Meter 1, Accumulated value
	MSR_VALUE_1_ACCU = 0x01,
	//! <b>2</b> Meter 2, Current value
	MSR_VALUE_2_CURRENT = 0x02,
	//! <b>3</b> Meter 2, Accumulated value
	MSR_VALUE_2_ACCU = 0x03
} MSR_VALUE_SELECTION;

class eoEEP_D230xx: public eoD2EEProfile
{
private:
	uint8_t cmd;
	bool IsChannel31() { return ((msg.data[1] & 0x1F) == 0x1F); }
public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D230xx(uint16_t size = 10);
	virtual ~eoEEP_D230xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	virtual eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t subFlag);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
