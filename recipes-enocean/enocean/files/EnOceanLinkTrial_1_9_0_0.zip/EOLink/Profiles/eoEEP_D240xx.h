/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D240_H__INCLUDED_)
#define eoEEP_D240_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D240xx
 * \brief The class to handle EEP D240 profiles
 * \details Allows the user to handle EEP D240 profiles, the following profiles are available:
 * 		- D2-40-00
 * 		- D2-40-01\n
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in Message ID 0x00:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|::D240_DRIVING_LED_ENUM | ::DRIVING_LED |
 * | 1             | ::F_ON_OFF			|::D240_TRUE_FALSE_ENUM | ::RESPONSE_MODE |
 * | 2             | ::F_ON_OFF			|::D240_TRUE_FALSE_ENUM | ::DAYLIGH_HARVEST |
 * | 3             | ::E_OCCUPANCY		|::D240_OCCUPANCY_ENUM | |
 * | 4             | ::F_ON_OFF			|::D240_STATUS_REASON_ENUM | ::STATUS_REASON |
 * | 5             | ::S_PERCENTAGE		| float | ::DIM_LEVEL_MONO |
 *
 * The following channels are available in Message ID 0x01:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|::D240_DRIVING_LED_ENUM | ::DRIVING_LED |
 * | 1             | ::F_ON_OFF			|::D240_TRUE_FALSE_ENUM | ::RESPONSE_MODE |
 * | 2             | ::F_ON_OFF			|::D240_TRUE_FALSE_ENUM | ::DAYLIGH_HARVEST |
 * | 3             | ::E_OCCUPANCY		|::D240_OCCUPANCY_ENUM | |
 * | 4             | ::F_ON_OFF			|::D240_STATUS_REASON_ENUM | ::STATUS_REASON |
 * | 5             | ::S_PERCENTAGE		| float | ::DIM_LEVEL_RED |
 * | 5             | ::S_PERCENTAGE		| float | ::DIM_LEVEL_GREEN |
 * | 5             | ::S_PERCENTAGE		| float | ::DIM_LEVEL_BLUE |
 *
 *
 */

/**
 * \file eoEEP_D240xx.h
 */

//! Index enums for D2-40-xx profiles
typedef enum
{
	//! <b>Driving LED</b> 0
	DRIVING_LED = 0x00,
	//! <b>Demand Response Mode Active</b> 1
	RESPONSE_MODE = 0x01,
	//! <b>Daylight Harvesting Active</b> 2
	DAYLIGH_HARVEST = 0x02,
	//! <b>Status Reason</b> 3
	STATUS_REASON = 0x03,
	//! <b>LED Monocolor</b> 4
	DIM_LEVEL_MONO = 0x04,
	//! <b>LED Red</b> 5
	DIM_LEVEL_RED = 0x05,
	//! <b>LED Green</b> 6
	DIM_LEVEL_GREEN = 0x06,
	//! <b>LED Blue</b> 7
	DIM_LEVEL_BLUE = 0x07
} D240_INDEX_ENUM;

//! Driving LED enums for D2-40-xx profiles
typedef enum
{
	//! <b>Disabled</b> 0
	DRIVING_DISABLED = 0x00,
	//! <b>Enabled</b> 1
	DRIVING_ENABLED = 0x01
} D240_DRIVING_LED_ENUM;

//! True/False enums for D2-40-xx profiles
typedef enum
{
	//! <b>False</b> 0
	D240_FALSE = 0x00,
	//! <b>True</b> 1
	D240_TRUE = 0x01
} D240_TRUE_FALSE_ENUM;

//! Occupancy enums for D2-40-xx profiles
typedef enum
{
	//! <b>Not occupied</b> 0
	D240_NOT_OCCUPIED = 0x00,
	//! <b>Occupied</b> 1
	D240_OCCUPIED = 0x01,
	//! <b>Unknown</b> 2
	D240_UNKNOWN = 0x02
} D240_OCCUPANCY_ENUM;

//! Status reason enums for D2-40-xx profiles
typedef enum
{
	//! <b>Other</b> 0
	OTHER_REASON = 0x00,
	//! <b>Heartbeat</b> 1
	HEARTBEAT = 0x01
} D240_STATUS_REASON_ENUM;

class eoEEP_D240xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D240xx(uint16_t size = 4);
	virtual ~eoEEP_D240xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
