/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D211xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>
const uint8_t numOfChan = 10;
const uint8_t numOfProfiles = 0x09;
const uint8_t numOfCommands = 0x03;

const EEP_ITEM listD211xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//Message type A
{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Message type B
{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 28, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
		{ true, 31, 1, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy state
},
//Message type C
{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 2, 0, 2, 0, 2, E_STATE, TEL_TYPE }, //Telegram type
		{ true, 8, 8, 0, 255, 0, 40, S_TEMP, TEMP_NORMAL }, //Temperature
		{ true, 16, 8, 0, 250, 0, 100, S_RELHUM, 0 }, //Humidity
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 44, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
		{ true, 47, 1, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy state
}
};

const EEP_ITEM typeListD211xx [numOfProfiles][14] =
{
	//Type 0x00
	{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x01
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -10, 10, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x02
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 16, 8, 0, 250, 0, 100, S_RELHUM, 0 }, //Humidity
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x03
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 44, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x04
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 16, 8, 0, 250, 0, 100, S_RELHUM, 0 }, //Humidity
		{ true, 44, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x05
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 44, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
		{ true, 47, 1, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy state
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x06
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 16, 8, 0, 250, 0, 100, S_RELHUM, 0 }, //Humidity
		{ true, 44, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
		{ true, 47, 1, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy state
	},
	//Type 0x07
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 47, 1, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy state
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
	//Type 0x08
	{
		{ true, 4, 4, 0, 2, 0, 2, E_COMMAND, 0 }, //Message ID
		{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, SETPOINT_TYPE }, //Setpoint type
		{ true, 1, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_HEATING_SYMBOL }, //Display heating symbol
		{ true, 2, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_COOLING_SYMBOL }, //Display cooling symbol
		{ true, 3, 1, 0, 1, 0, 1, F_ON_OFF, DISPLAY_WINDOW_OPEN_SYMBOL }, //Display window open symbol
		{ true, 8, 8, 0, 255, -127, 127, S_TEMP, TEMP_CORRECTION }, //Temperature correction
		{ true, 16, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 24, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 32, 8, 15, 30, 15, 30, S_TEMP, TEMP_BASEPOINT }, //Temperature basepoint
		{ true, 40, 4, 1, 10, 1, 10, E_STATE, VALID_TEMP_CORRECTION }, //Valid temperature correction
		{ true, 24, 8, 0, 255, -127, 127, S_VALUE, 0 }, //Setpoint offset
		{ true, 16, 8, 0, 250, 0, 100, S_RELHUM, 0 }, //Humidity
		{ true, 47, 1, 0, 1, 0, 1, F_OCCUPIED, 0 }, //Occupancy state
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
	},
};

eoEEP_D211xx::eoEEP_D211xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x11;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D211xx::~eoEEP_D211xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D211xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 1 || m.GetDataLength() > 6)
		return NOT_SUPPORTED;
	if (m.RORG == RORG_VLD && SetCommand(m.data[0] & 0x0F)==EO_OK)
	{
		return eoProfile::Parse(m);
	}

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D211xx::SetType(uint8_t type)
{
	if (type > numOfProfiles && type != 0x00)
		return NOT_SUPPORTED;
	SetLength(type);
	cmd=0xFF;
	SetCommand(0);
	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D211xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommands)
		return NOT_SUPPORTED;

	msg.Clear();

	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {1, 4, 6};
	msg.SetDataLength(dataLength[cmd]);

	if(cmd==this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD211xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD211xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD211xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD211xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD211xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
	{
		return NOT_SUPPORTED;
	}

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;
	return EO_OK;
}

eoReturn eoEEP_D211xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_FANSPEED:
		case F_OCCUPIED:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D211xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_FANSPEED:
		case F_OCCUPIED:
			rawValue = (uint32_t)value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D211xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	uint8_t tempCorrectionVal = 0;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}
	switch (type)
	{
		case S_VALUE:
			if (this->GetValue(E_STATE, tempCorrectionVal, VALID_TEMP_CORRECTION) != EO_OK)
				return NOT_SUPPORTED;

			if (tempCorrectionVal == 0)
				return NOT_SUPPORTED;

			value = (float)ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, -tempCorrectionVal, tempCorrectionVal);
			break;
		case S_RELHUM:
			value = (float)ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D211xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd > 2)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_VALUE:
		{
			uint8_t tempCorrectionValue;
			if (this->GetValue(E_STATE, tempCorrectionValue, VALID_TEMP_CORRECTION) != EO_OK)
				return NOT_SUPPORTED;

			if (tempCorrectionValue == 0)
				return NOT_SUPPORTED;

			if(-tempCorrectionValue <= value || value >= tempCorrectionValue)
				rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, -tempCorrectionValue, tempCorrectionValue);
			else
				return OUT_OF_RANGE;

			break;
		}
		case S_RELHUM:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D211xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case SETPOINT_TYPE:
				case DISPLAY_HEATING_SYMBOL:
				case DISPLAY_COOLING_SYMBOL:
				case DISPLAY_WINDOW_OPEN_SYMBOL:
					value = rawValue ? 1 : 0;
					return EO_OK;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_STATE:
			switch(index)
			{
				case TEL_TYPE:
				case VALID_TEMP_CORRECTION:
					value = (uint8_t)rawValue;
					return EO_OK;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return GetValue(type, value);
	}
	return NOT_SUPPORTED;
}

eoReturn eoEEP_D211xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd > 2)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			switch (index)
			{
				case SETPOINT_TYPE:
				case DISPLAY_HEATING_SYMBOL:
				case DISPLAY_COOLING_SYMBOL:
				case DISPLAY_WINDOW_OPEN_SYMBOL:
					rawValue = (uint32_t)(value ? 1 : 0);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case E_STATE:
			switch(index)
			{
				case TEL_TYPE:
				case VALID_TEMP_CORRECTION:
					rawValue = (uint32_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return SetValue(type, value);
			break;
	}

	rawValue = (uint32_t)value;
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D211xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	uint8_t tempCorrectionVal = 0;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP:
			switch (index)
			{
				case TEMP_CORRECTION:
					if (this->GetValue(E_STATE, tempCorrectionVal, VALID_TEMP_CORRECTION) != EO_OK)
						return NOT_SUPPORTED;

					if (tempCorrectionVal == 0)
						return NOT_SUPPORTED;

					value = (float)ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, -tempCorrectionVal, tempCorrectionVal);
					break;
				case TEMP_NORMAL:
					value = (float)ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				case TEMP_BASEPOINT:
					value = (float)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_D211xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd > 2)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	uint8_t tempCorrectionVal = 0;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP:
			switch(index)
			{   //same as above in SetValue(), change the scaling automatically..
				case TEMP_CORRECTION:
					if (this->GetValue(E_STATE, tempCorrectionVal, VALID_TEMP_CORRECTION) != EO_OK)
						return NOT_SUPPORTED;

					if (tempCorrectionVal == 0)
						return NOT_SUPPORTED;

					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, -tempCorrectionVal, tempCorrectionVal);
					break;
				case TEMP_NORMAL:
					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
					break;
				case TEMP_BASEPOINT:
					rawValue = (uint32_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D211xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD211xx[this->cmd][tmpChannelCount].type == type && listD211xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D211xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD211xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD211xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD211xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD211xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD211xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
