/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

//! \file eoEEP_A512xx.h

#if  !defined(eoEEP_A512_H__INCLUDED_)
#define eoEEP_A512_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoA5EEProfile.h"
/**\class eoEEP_A512xx
 * \brief The class to handle EEP a512 Automated meter reading (AMR) profiles
 * \details Allows the user to handle EEP a512 Automated meter reading (AMR) profiles, the following profiles are available:
 * 		- A5-12-00
 * 		- A5-12-01 Electricity
 * 		- A5-12-02 Gas
 * 		- A5-12-03 Water
 * 		- A5-12-04
 * 		- A5-12-10 \n
 *
 * The following channels are available for Profile 0:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_COUNTER  |float |
 * | 1             | ::S_VOLUME	  |float |
 * | 2             | ::E_TARIFF	  |uint8_t |
 * \n
 *
 * The following channels are available for Profile 01:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:| |
 * | 0             | ::S_ENERGY   |float | |
 * | 1             | ::S_POWER	  |float | Unit is kWh |
 * | 2             | ::E_TARIFF	  |uint8_t | |
 * \n
 *
 * The following channels are available for Profile 02 and 03:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_VOLFLOW  |float |
 * | 1             | ::S_VOLUME	  |float |
 * | 2             | ::E_TARIFF	  |uint8_t |
 * \n
 *
 * The following channels are available for Profile 04:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_MASS	  |float |
 * | 1             | ::S_TEMP	  |float |
 * | 2             | ::E_STATE	  |::BATTERY_LEVEL |
 * \n
 *
 * The following channels are available for Profile 05:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_0 |
 * | 1             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_1 |
 * | 2             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_2 |
 * | 3             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_3 |
 * | 4             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_4 |
 * | 5             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_5 |
 * | 6             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_6 |
 * | 7             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_7 |
 * | 8             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_8 |
 * | 9             | ::F_ON_OFF	  |uint8_t | ::POSITION_LOCATION_9 |
 * | 10            | ::S_TEMP	  |float | |
 * | 11            | ::E_STATE	  |uint8_t | |
 * \n
 *
 * The following channels are available for Profile 10:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_AMPER_PER_HOUR   |float |
 * | 1             | ::S_CURRENT  |float |
 * | 2             | ::E_TARIFF	  |uint8_t |
 */

/**
 * \file eoEEP_A512xx.h
 */
//! Data type enums for A5-12-xx profiles
typedef enum
{
	//! <b>1 or kWh or m^3</b> 0
	CUMULATIVE = 0x00,
	//! <b>1/s or W or liter/s</b> 1
	CURRENT = 0x01
} DATA_TYPE_METER_READING;

//! Battery enums for A5-12-xx profiles
typedef enum
{
	//! <b>Battery level 100-75%</b> 0
	BATTERY_LEVEL_100_75 = 0x00,
	//! <b>Battery level 75-50%</b> 1
	BATTERY_LEVEL_75_50 = 0x01,
	//! <b>Battery level 50-25%</b> 2
	BATTERY_LEVEL_50_25 = 0x02,
	//! <b>Battery level 25-0%</b> 3
	BATTERY_LEVEL_25_0 = 0x03
} BATTERY_LEVEL;

//! Sensor position enums for A5-12-05 profiles
typedef enum
{
	//! <b>Not possessed</b> 0
	POSITION_NOT_POSSESSED = 0x00,
	//! <b>Possessed</b> 1
	POSITION_POSSESSED = 0x01
} SENSOR_POSITION_ENUM;

//! Sensor position index enums for A5-12-05 profiles
typedef enum
{
	//! <b>Location 0</b> 0
	POSITION_LOCATION_0 = 0x00,
	//! <b>Location 1</b> 1
	POSITION_LOCATION_1 = 0x01,
	//! <b>Location 2</b> 2
	POSITION_LOCATION_2 = 0x02,
	//! <b>Location 3</b> 3
	POSITION_LOCATION_3 = 0x03,
	//! <b>Location 4</b> 4
	POSITION_LOCATION_4 = 0x04,
	//! <b>Location 5</b> 5
	POSITION_LOCATION_5 = 0x05,
	//! <b>Location 6</b> 6
	POSITION_LOCATION_6 = 0x06,
	//! <b>Location 7</b> 7
	POSITION_LOCATION_7 = 0x07,
	//! <b>Location 8</b> 8
	POSITION_LOCATION_8 = 0x08,
	//! <b>Location 9</b> 9
	POSITION_LOCATION_9 = 0x09
} SENSOR_POSITION_INDEX_ENUM;

class eoEEP_A512xx: public eoA5EEProfile
{

public:
	eoReturn SetType(uint8_t type);

	eoEEP_A512xx();
	virtual ~eoEEP_A512xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);

	virtual eoChannelInfo* GetChannel(CHANNEL_TYPE type);
	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
private:
	eoReturn CalculateDivisorAndRawValue(float value, uint32_t & rawValue);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
