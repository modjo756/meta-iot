/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A520xx.h"

#include "eoChannelEnums.h"
#include <string.h>


const uint8_t numOfChan = 0x12;
const uint8_t numOfProfiles = 0x15;
//2 directions...
const EEP_ITEM listA520xx[numOfProfiles][2][numOfChan] =
{
//TYPE:01
{
//Direction 1
{
	{ true, 0, 8, 0, 100, 0, 100.0, S_SETPOINT, 0 }, //Current value
	{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, SERVICE_ON }, //Service on
	{ true, 9, 1, 0, 1, 0, 1, F_ON_OFF, ENERGY_INPUT }, //Energy input
	{ true, 10, 1, 0, 1, 0, 1, F_ON_OFF, ENERGY_STORAGE }, //Energy storage
	{ true, 11, 1, 0, 1, 0, 1, F_ON_OFF, BATTERY_CAPACITY }, //Battery capacity
	{ true, 12, 1, 0, 1, 0, 1, F_ON_OFF, CONTACT_COVER }, //Contact cover
	{ true, 13, 1, 0, 1, 0, 1, F_ON_OFF, TEMPERATURE_FAIL }, //Failure temperature sensor
	{ true, 14, 1, 0, 1, 0, 1, F_ON_OFF, WINDOW_DETECTION }, //Detection window
	{ true, 15, 1, 0, 1, 0, 1, F_ON_OFF, ACTUATOR_OBSTRUCTED }, //Actuator obstructed
	{ true, 16, 8, 0, 255, 0, 40.0, S_TEMP, 0 }, //Temperature
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:01 Direction 2
	{
	{ true, 0, 8, 0, 100, 0, 100.0, S_SETPOINT, 0 }, //Current value
	{ true, 0, 8, 0, 255, 0, 40, S_TEMP_ABS, 0 }, //Temperature setpoint
	{ true, 8, 8, 255, 0, 0, 40, S_TEMP, 0 }, //Temperature
	{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, RUN_INTI_SEQ }, //Run init
	{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, LIFT_SET }, //Lift set
	{ true, 18, 1, 0, 1, 0, 1, F_ON_OFF, VALVE_OPEN }, //Valve open
	{ true, 19, 1, 0, 1, 0, 1, F_ON_OFF, VALVE_CLOSED }, //Valve closed
	{ true, 20, 1, 0, 1, 0, 1, F_ON_OFF, SUMMER_BIT }, //Summer bit
	{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, SET_POINT_SELECTION }, //Set point selection
	{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, SET_POINT_INVERSE }, //Set point inverse
	{ true, 23, 1, 0, 1, 0, 1, F_ON_OFF, SELECT_FUNCTION },  //Select Function
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }
	}
},
//TYPE:02
{
	{
	{ true, 0, 8, 0, 100, 0, 100.0, S_PERCENTAGE, 0 }, //Current value
	{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, SET_POINT_INVERSE }, //Set point inverse
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
	//TYPE:02 Direction 2
	{
	{ true, 0, 8, 0, 100, 0, 100.0, S_SETPOINT, 0 }, //Current value
	{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, SET_POINT_INVERSE }, //Set point inverse
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } }
},
//TYPE:03 Direction 1
{
	{
	{ true, 0, 8, 0, 100, 0, 100.0, S_SETPOINT, 0 }, //Current value
	{ true, 16, 8, 0, 255, 0, 40, S_TEMP, 0 }, //Temperature
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
	//TYPE:03 Direction 2
	{
	{ true, 0, 8, 0, 100, 0, 100.0, S_SETPOINT, 0 }, //Current value
	{ true, 0, 8, 0, 255, 0, 40, S_TEMP_ABS, 0 }, //Temperature setpoint
	{ true, 8, 8, 255, 0, 0, 40, S_TEMP, 0 }, //Temperature
	{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, SET_POINT_SELECTION }, //Setpoint selection
	{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, SET_POINT_INVERSE }, //Setpoint inverse
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } }
},
//TYPE:04 Direction 1
	{
	{
	{ true,	  0,  8, 0, 100, 0, 100.0, S_PERCENTAGE, 0 }, //Current position
	{ true,	  8,  8, 0, 255, 20, 80.0, S_TEMP, FEED_TEMP }, //Feed temperature
	{ true,	  8,  8, 0, 255, 10, 30.0, S_TEMP_ABS, 0 }, //Temperature Set Point
	{ true,	  16,  8, 0, 255, 10, 30.0, S_TEMP, CURRENT_TEMP }, //Current room temperature value
	{ true,	  16,  8, 0, 255, 0, 255.0, E_ERROR_STATE, 0 }, //Failure code
	{ true,	  24,  1, 0, 1, 0, 1, F_ON_OFF, MEASUREMENT_STATUS }, //Measurement status
	{ true,	  25,  1, 0, 1, 0, 1, F_ON_OFF, STATUS_REQUEST }, //Status request
	{ true,	  29,  1, 0, 1, 0, 1, F_ON_OFF, BUTTON_LOCK }, //Button lock status
	{ true,	  30,  1, 0, 1, 0, 1, F_ON_OFF, TEMP_SELECTION }, //Temperature selection
	{ true,	  31,  1, 0, 1, 0, 1, F_ON_OFF, FAILURE }, //Failure
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//TYPE:04 Direction 2
	{
	{ true,	  0,  8, 0, 100, 0, 100.0, S_PERCENTAGE, 0 }, //Valve position
	{ true,	  8,  8, 0, 255, 10, 30.0, S_TEMP_ABS, 0 }, //Temperature Set Point
	{ true,	  17, 1, 0, 1, 0, 1, F_ON_OFF, MEASUREMENT_CONTROL }, //Measurement control
	{ true,	  18, 6, 0, 63, 0, 63, E_STATE, WAKEUP_CYCLE }, //Wake-up cycle
	{ true,	  26, 2, 0, 3, 0, 3, E_STATE, DISPLAY_ORIENTATION }, //Display orientation
	{ true,	  29,  1, 0, 1, 0, 1, F_ON_OFF, BUTTON_LOCK }, //Button lock control
	{ true,	  30, 2, 0, 3, 0, 3, E_COMMAND, 0 }, //Service command
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 05 Direction 1
{
	{
	{ true,	0, 3, 0, 5, 0, 5, E_FANSPEED, 0 }, //Actual speed setting
	{ true,	3, 3, 0, 7, 0, 7, E_STATE, 0 }, //Actual timer setting
	{ true,	11, 1, 0, 1, 0, 1, F_ON_OFF, NODE_LOW_BATTERY }, //Low battery
	{ true,	12, 1, 0, 1, 0, 1, F_ON_OFF, NODE_EXT_COMM_ERROR }, //External communication error
	{ true,	13, 1, 0, 1, 0, 1, F_ON_OFF, INTERNAL_SENSOR_ERROR }, //Internal sensor error
	{ true,	14, 1, 0, 1, 0, 1, F_ON_OFF, FAN_SPEED_ERROR }, //Fan speed error
	{ true,	15, 1, 0, 1, 0, 1, F_ON_OFF, GENERAL_ERROR }, //Unit has an error
	{ true,	16, 8, 0, 255, 0, 255, S_PERCENTAGE, 0 }, //Filter condition
	{ true,	24, 1, 0, 1, 0, 1, F_ON_OFF, AUTO_SPEED_SUPPORT }, //Auto speed supported
	{ true,	25, 1, 0, 1, 0, 1, F_ON_OFF, SUMMER_BYPASS }, //Bypass active
	{ true,	26, 1, 0, 1, 0, 1, F_ON_OFF, FROST_PROTECTION_ACTIVE }, //Frost protection
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	},
	//TYPE: 05 Direction 2
	{
	{ true,	0, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Actual speed setting
	{ true,	3, 5, 0, 29, 0, 29, E_STATE, 0 }, //Actual timer setting
	{ true,	24, 1, 0, 1, 0, 1, F_ON_OFF, RESET_ERROR }, //Reset error
	{ true,	25, 1, 0, 1, 0, 1, F_ON_OFF, RESET_FILTER_TIMER }, //Reset filter timer
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES }
	}
},
//TYPE: 06 Direction 1 - not used
{
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//TYPE: 06 Direction 2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 07
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 08
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 09
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 0xA
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 0xB
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 0xC
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 0xD
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 0xE
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE: 0xF
{
	//Direction 1 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } },
	//Direction2 - not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, S_RES } }
},
//TYPE:10 Direction 1
{
	{
	{ true, 0, 8, 0, 32, 0, 32, E_CONTROLLER_MODE, 0 }, //Mode
	{ true, 8, 4, 0, 14, 0, 14, E_END_POS, 0 }, //Vane position
	{ true, 12, 4, 0, 14, 0, 14, E_FANSPEED, 0 }, //Fan speed
	{ true, 16, 8, 0, 255, 0, 255, S_SETPOINT, 0 }, //Setpoint
	{ true, 29, 2, 0, 4, 0, 4, E_OCCUPANCY, 0 }, //Occupancy
	{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, ON_OFF }, //On/Off
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
	//TYPE:10 Direction 2
	{
	{ true, 0, 8, 0, 32, 0, 32, E_CONTROLLER_MODE, 0 }, //Mode
	{ true, 8, 4, 0, 14, 0, 14, E_END_POS, 0 }, //Vane position
	{ true, 12, 4, 0, 14, 0, 14, E_FANSPEED, 0 }, //Fan speed
	{ true, 16, 8, 0, 255, 0, 255, S_SETPOINT, 0 }, //Setpoint
	{ true, 29, 2, 0, 4, 0, 4, E_OCCUPANCY, 0 }, //Occupancy
	{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, ON_OFF }, //On/Off
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } }
},

//TYPE:11 Direction 1
	{
	{
	{ true, 23, 1, 0, 1, 0, 1, F_ON_OFF, EXTERNAL_DISABLEMENT }, //External disablement
	{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, DISABLE_REMOTE_CONTROL }, //Disable remote controller
	{ true, 30, 1, 0, 1, 0, 1, F_OPEN_CLOSED, 0 }, //Window contact
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
	//TYPE:11 Direction 2
	{
	{ true, 0, 16, 0, 65535, 0, 65535, S_ERROR_CODE, 0 }, //Error code
	{ true, 20, 1, 0, 1, 0, 1, F_ON_OFF, OTHER_DISABLEMENT }, //Other disablement
	{ true, 21, 1, 0, 1, 0, 1, F_ON_OFF, WINDOW_DISABLEMENT }, //Window contact disablement
	{ true, 22, 1, 0, 1, 0, 1, F_ON_OFF, KEYCARD_DISABLEMENT }, //Key card disablement
	{ true, 23, 1, 0, 1, 0, 1, F_ON_OFF, EXTERNAL_DISABLEMENT }, //External disablement
	{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, DISABLE_REMOTE_CONTROL }, //Remote controller disablement
	{ true, 30, 1, 0, 1, 0, 1, F_OPEN_CLOSED, 0 }, //Window contact
	{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, ALARM_STATE }, //Alarm state
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //Direction
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } }
},
//TYPE:12 Direction 1
{
	{
	{ true, 0, 8, 0, 100, 0, 100.0, S_PERCENTAGE, 0 }, //Control variable override
	{ true, 8, 8, 0, 255, 0, 255, E_FANSPEED, 0 }, //Fan speed
	{ true, 16, 8, 255, 0, -10.0, 10.0, S_SETPOINT, 0 }, //Setpoint shift
	{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, FAN_OVERRIDE }, //Fan override
	{ true, 25, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Controller mode
	{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CONTROLLER_STATE }, //Controller state
	{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, ENERGY_HOLDOFF }, //Energy hold-off
	{ true, 30, 2, 0, 3, 0, 3, E_OCCUPANCY, 0 }, //Occupancy
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
	//TYPE:12 Direction 2 Not used
	{
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
	{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } }
},
};

eoEEP_A520xx::eoEEP_A520xx() : outMessage(4)
{
	channel = new eoEEPChannelInfo[numOfChan];
	outChannels = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;
	outChannelCount=0;
	rorg = RORG_4BS;
	func = 0x20;
	direction = eoController;
}

eoEEP_A520xx::~eoEEP_A520xx()
{
	if(channel!=NULL)
		delete[] channel;
	if(outChannels!=NULL)
		delete[] outChannels;
	channel=NULL;
	outChannels = NULL;
}
eoReturn eoEEP_A520xx::SetChannels(SIMPLE_DIRECTION direction,uint8_t type)
{
	channelCount = 0;
	outChannelCount = 0;
	uint8_t tmpChannelCount;
	uint8_t receiveDirection= direction == eoController ? 0 : 1 ;
	uint8_t sendDirection= direction == eoController ? 1 : 0 ;
	uint8_t typeInList=type-1;
	//Special case 0x12 unidirectional...
	if(type==0x12)
	{
		receiveDirection = 0;
		sendDirection = 0;
	}
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA520xx[typeInList][receiveDirection][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA520xx[typeInList][receiveDirection][tmpChannelCount].type;
			channel[channelCount].max = listA520xx[typeInList][receiveDirection][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA520xx[typeInList][receiveDirection][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA520xx[typeInList][receiveDirection][tmpChannelCount];
			channelCount++;
		}
	}
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA520xx[typeInList][sendDirection][tmpChannelCount].exist)
		{
			outChannels[outChannelCount].type = listA520xx[typeInList][sendDirection][tmpChannelCount].type;
			outChannels[outChannelCount].max = listA520xx[typeInList][sendDirection][tmpChannelCount].scaleMax;
			outChannels[outChannelCount].min = listA520xx[typeInList][sendDirection][tmpChannelCount].scaleMin;
			outChannels[outChannelCount].eepItem = &listA520xx[typeInList][sendDirection][tmpChannelCount];
			outChannelCount++;
		}
	}
	if(channelCount == 0)
		return NOT_SUPPORTED;
	return EO_OK;
}
eoReturn eoEEP_A520xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;

	if(SetChannels(direction,type)!=EO_OK)
	{
		//Reset to old one...
		SetChannels(direction,this->type);
		return NOT_SUPPORTED;
	}
	this->type = type;

	return EO_OK;
}

eoReturn eoEEP_A520xx::SetDirection(HVCA_DIRECTION direction)
{
	if(direction==HVCA_DIRECTION_1)
		return SetDirection(eoActuator);
	else if(direction==HVCA_DIRECTION_2)
		return SetDirection(eoController);
	else
		return NOT_SUPPORTED;
}
eoReturn eoEEP_A520xx::SetDirection(SIMPLE_DIRECTION direction)
{
	if(SetChannels(direction,type)!=EO_OK)
	{
		//Reset to old one...
		SetChannels(this->direction ,type);
		return NOT_SUPPORTED;
	}
	this->direction = direction;
	return EO_OK;
}

void eoEEP_A520xx::ClearValues()
{
	outMessage.Clear();
	msg.Clear();
}

eoChannelInfo* eoEEP_A520xx::GetOutChannel(CHANNEL_TYPE type, uint8_t subType)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < outChannelCount;
			tmpChannelCount++)
	{
		if (outChannels[tmpChannelCount].eepItem->type == type && outChannels[tmpChannelCount].eepItem->index == subType)
			return &outChannels[tmpChannelCount];
	}

	return NULL;
}

eoChannelInfo* eoEEP_A520xx::GetOutChannel(CHANNEL_TYPE type)
{
	uint8_t tmpChanCnt;
	for (tmpChanCnt = 0; tmpChanCnt < outChannelCount; tmpChanCnt++)
	{
		if (outChannels[tmpChanCnt].type == type)
			return (eoChannelInfo*) &outChannels[tmpChanCnt];
	}
	return NULL;
}

eoChannelInfo* eoEEP_A520xx::GetOutChannel(uint8_t channelNumber)
{
	eoChannelInfo* retChannel = NULL;
	if (channelNumber < outChannelCount)
		retChannel = (eoChannelInfo*) (&outChannels[channelNumber]);
	return retChannel;
}

eoReturn eoEEP_A520xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetOutChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_END_POS:
			if (value < 7 || value > 10)
				return OUT_OF_RANGE;
			rawValue = value;
			break;
		case E_CONTROLLER_MODE:
			if (value < 21 || value > 30)
				return OUT_OF_RANGE;
			rawValue = value;
			break;
		case E_FANSPEED:
		case E_OCCUPANCY:
		case E_COMMAND:
		case E_STATE:
			rawValue = value;
			break;
			//Deprecated function!
		case E_DIRECTION:
			return SetDirection((HVCA_DIRECTION) value);
			break;
		case E_ERROR_STATE:
			switch(value)
			{
				case MEASUREMENT_ERROR:
				case BATTERY_EMPTY:
				case FROST_PROTECTION:
				case BLOCKED_VALVE:
				case END_POINT_DETECTION:
				case NOT_TEACHED_IN:
				case NO_RESPONSE_FROM_CONTROLLER:
				case TEACH_IN_ERROR:
				case NO_VALVE:
					rawValue = 1;
					SetRawValue(outMessage, rawValue, 31, (uint8_t)1);
					rawValue = value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(outMessage, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoReturn eoEEP_A520xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_END_POS:
		case E_CONTROLLER_MODE:
		case E_FANSPEED:
		case E_OCCUPANCY:
		case E_COMMAND:
		case E_STATE:
			value = (uint8_t)rawValue;
			break;
		case E_ERROR_STATE:
			if ((msg.data[3] & 0x01) != 0x01)
				return NOT_SUPPORTED;
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A520xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetOutChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{

		case S_TEMP:
		case S_PERCENTAGE:
		case S_ERROR_CODE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_SETPOINT:
			if ((this->type == 0x01 || this->type==0x03) && direction == eoController)
				//Clear SetPoint Flag
				outMessage.data[2] &= ~0x04;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TEMP_ABS:
			if ((this->type == 0x01 || this->type==0x03) && direction == eoController)
				//Set setpoint flag...
				outMessage.data[2] |= 0x04;
			if(this->type== 0x04 && direction == eoActuator)
				outMessage.data[3] |= 0x02;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(outMessage, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoReturn eoEEP_A520xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//Check if is supported
	switch (type)
	{
		case S_TEMP_ABS:
			if((this->type==0x01|| this->type==0x03) && direction==eoActuator && (msg.data[2]&0x04)==0x00)
				return NOT_SUPPORTED;
			if(this->type==0x04 && direction==eoController && (msg.data[3]&0x02)==0x00)
				return NOT_SUPPORTED;
			break;
		case S_SETPOINT:
			if((this->type==0x01|| this->type==0x03) && direction==eoActuator && (msg.data[2]&0x04)==0x04)
				return NOT_SUPPORTED;
			break;

		case S_TEMP:
		case S_ERROR_CODE:
		case S_PERCENTAGE:
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}


	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoEEP_A520xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetOutChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
		case F_OPEN_CLOSED:
			rawValue = value ? 1 : 0;
			break;
		case E_STATE:
			rawValue = value;
			break;
		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(outMessage, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoReturn eoEEP_A520xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
		case F_OPEN_CLOSED:
			value = rawValue ? 1 : 0;
			break;
		case E_STATE:
			value = rawValue;
			break;
		default:
			return GetValue(type, value);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A520xx::Create(eoMessage &m)
{
	if (outMessage.GetMaxLength() < 4)
		return OUT_OF_RANGE;

	outMessage.RORG = RORG_4BS;
	outMessage.data[3] |= 0x08;

	return outMessage.copyTo(m);
}

eoReturn eoEEP_A520xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetOutChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP:
			switch(index)
			{
				case FEED_TEMP:
					// Setting DB0.1 to 0
					rawValue = 0;
					SetRawValue(msg, rawValue,(uint16_t)30,(uint8_t)1);
					break;
				case CURRENT_TEMP:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return SetValue(type, value);
			break;
	}
	rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	SetRawValue(outMessage, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A520xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP:
			switch(index)
			{
				case FEED_TEMP:
					if (((msg.data[3] >> 1) & 0x01) != 0x00)
						return NOT_SUPPORTED;
					break;
				case CURRENT_TEMP:
					if ((msg.data[3] & 0x01) != 0x00)
						return NOT_SUPPORTED;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return GetValue(type, value);
	}

	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoChannelInfo* eoEEP_A520xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < channelCount;
			tmpChannelCount++)
	{
		if (channel[tmpChannelCount].eepItem->type == type && channel[tmpChannelCount].eepItem->index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
