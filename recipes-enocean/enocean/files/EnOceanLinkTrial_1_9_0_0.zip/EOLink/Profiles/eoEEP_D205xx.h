/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D205_H__INCLUDED_)
#define eoEEP_D205_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D205xx
 * \brief The class to handle EEP D205 profiles
 * \details Allows the user to handle EEP D205 profiles, the following profiles are available:
 * 		- D2-05-00
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in Go to Position and Angle message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PERCENTAGE		| float | ::CUR_VER_POSITION |
 * | 1             | ::S_PERCENTAGE		| float | ::CUR_ROT_ANGLE |
 * | 2             | ::E_END_POS		|::D205_REPOSITIONING_ENUM |  |
 * | 3             | ::E_STATE			|::D205_LOCK_MODE_ENUM |  |
 * | 4             | ::E_IO_CHANNEL		| uint8_t |  |
 *
 * The following channels are available in Stop message:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_IO_CHANNEL		| uint8_t |
 *
 * The following channels are available in Query Position and Angle message:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_IO_CHANNEL		| uint8_t |
 *
 * The following channels are available in Reply Position and Angle message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_PERCENTAGE		| float | ::CUR_VER_POSITION |
 * | 1             | ::S_PERCENTAGE		| float | ::CUR_ROT_ANGLE |
 * | 2             | ::E_STATE			|::D205_LOCK_MODE_ENUM |  |
 * | 3             | ::E_IO_CHANNEL		| uint8_t |  |
 *
 * The following channels are available in Go to Position and Angle message:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::S_TIME			| float | ::SET_VER_DURATION |
 * | 1             | ::S_TIME			| float | ::SET_VER_DURATION |
 * | 2             | ::E_STATE			|::D205_AET_ALARM_ENUM |  |
 * | 3             | ::E_IO_CHANNEL		| uint8_t |  |
 *
 *
 */

/**
 * \file eoEEP_D205xx.h
 */

//! Index enums for D2-05-xx profiles
typedef enum
{
	//! <b>Current vertical position flag</b> 0
	CUR_VER_POSITION = 0x00,
	//! <b>Current rotation angle flag</b> 1
	CUR_ROT_ANGLE = 0x01,
	//! <b>Set vertical duration flag</b> 2
	SET_VER_DURATION = 0x02,
	//! <b>Set rotation duration flag</b> 3
	SET_ROT_DURATION = 0x03
} D205_INDEX_ENUM;

//! Message IDs for D2-05-xx profiles
typedef enum
{
	//! <b>Goto command</b> 1
	GOTO_MSG = 0x01,
	//! <b>Stop command</b> 2
	STOP_MSG = 0x02,
	//! <b>Query command</b> 3
	QUERY_MSG = 0x03,
	//! <b>Reply command</b> 4
	REPLY_MSG = 0x04,
	//! <b>Set parameters command</b> 5
	SET_PARAM_MSG = 0x05
} D205_MESSAGE_ID_ENUM;

//! Repositioning enums for D2-05-xx profiles
typedef enum
{
	//! <b>Go directly to POS/ANG</b> 0
	REPOS_DIRECT_POS_ANG = 0x00,
	//! <b>Go up(0%) then to POS/ANG</b> 1
	REPOS_UP_POS_ANG = 0x01,
	//! <b>Go down(100%) then to POS/ANG</b> 2
	REPOS_DOWN_POS_ANG = 0x02
} D205_REPOSITIONING_ENUM;

//! Locking mode enums for D2-05-xx profiles
typedef enum
{
	//! <b>Do not change / normal</b> 0
	LOCK_NORMAL = 0x00,
	//! <b>Set blockage mode / blockage mode</b> 1
	LOCK_BLOCKAGE = 0x01,
	//! <b>Set alarm mode / alarm mode</b> 2
	LOCK_ALARM = 0x02,
	//! <b>Deblockage / - </b> 7
	LOCK_DEBLOCKAGE = 0x07
} D205_LOCK_MODE_ENUM;

//! Set alarm action enums for D2-05-xx profiles
typedef enum
{
	//! <b>No action</b> 0
	ALARM_NO_ACTION = 0x00,
	//! <b>Immediate stop</b> 1
	ALARM_IMMEDIATE_STOP = 0x01,
	//! <b>Go up (0%)</b> 2
	ALARM_UP = 0x02,
	//! <b>Go down (100%)</b> 3
	ALARM_DOWN = 0x03,
	//! <b>Deblockage / - </b> 7
	ALARM_NO_CHANGE = 0x07
} D205_AET_ALARM_ENUM;

class eoEEP_D205xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D205xx(uint16_t size = 10);
	virtual ~eoEEP_D205xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
