/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D230xx.h"

#include "eoChannelEnums.h"
#include <string.h>

const uint8_t numOfChan = 11;
const uint8_t numOfProfiles = 0x07;
const uint8_t numOfCommmands = 0x09;

const EEP_ITEM listD230xx[numOfCommmands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:01
{
{ true, 0, 4, 0, 16, 0, 16, E_STATE, 0 }, //PWM signal interval
{ true, 10, 1, 0, 1, 0, 1, F_OPEN_CLOSED, 0 }, //Valve type
{ true, 11, 5, 0, 31, 0, 31, S_VALUE, 0 }, //Heating channel
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, 0 }, //Run init sequence
{ true, 17, 7, 0, 100, 0, 100.0, S_SETPOINT, 0 }, //Valve setpoint
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:02
{
{ true, 11, 5, 0, 31, 0, 31, S_VALUE, 0 }, //Heating channel
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:03
{
{ true, 8, 3, 0, 7, 0, 7, E_ERROR_STATE, MSR_CHANNEL_ERROR }, //Status/Error
{ true, 11, 5, 0, 31, 0, 31, S_VALUE, 0 }, //Heating channel
{ true, 17, 7, 0, 100, 0, 100.0, S_PERCENTAGE, 0 }, //Valve position
{ true, 24, 8, 0, 180, 0, 90.0, S_TEMP, MSR_CHANNEL_RETURN_TEMP }, //Return temperature
{ true, 8, 3, 0, 4, 0, 4, E_ERROR_STATE, MSR_CHANNEL_ERROR_CH31 }, //Status/Error if HCH=31
{ true, 16, 8, 0, 180, 0, 90.0, S_TEMP, MSR_CHANNEL_SUPPLY_TEMP }, //Supply temperature
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ true, 24, 8, 0, 180, 0, 90.0, S_TEMP, MSR_COMMON_RETURN_TEMP }, //Return temperature
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:04
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:05
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:06
{
{ true, 0, 4, 0, 7, 0, 7, E_STATE, MSR_CHANNEL_REPORT_TIME }, //Reporting times
{ true, 9, 2, 0, 3, 0, 3, E_STATE, MSR_CHANNEL_METER_TYPE }, //Meter bus type
{ true, 11, 5, 0, 30, 0, 30, S_VALUE, 0 }, //Meter channel index
{ true, 18, 3, 0, 7, 0, 7, E_UNITS, MSR_CHANNEL_METER_1 }, //Units for meter 1
{ true, 21, 3, 0, 7, 0, 7, E_UNITS, MSR_CHANNEL_METER_2 }, //Units for meter 2
{ true, 24, 8, 1, 250, 1, 250, S_VALUE, MSR_CHANNEL_PRIMARY_ADDR }, //Primary address
{ true, 24, 2, 0, 3, 0, 3, E_UNITS, MSR_CHANNEL_PULSES_FACTOR }, //Factor of numer of pulses
{ true, 26, 14, 0, 16383, 0, 16383, S_VALUE, MSR_CHANNEL_NUM_OF_PULSES }, //Number of pulses
{ true, 40, 32, 0, 4294967295u, 0, 4294967295.0f, S_VALUE, MSR_CHANNEL_PRESET_VALUE }, //Preset value
{ true, 24, 8, 0, 2, 0, 2, E_STATE, MSR_CHANNEL_PROTOCOL }, //Channel protocol
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
},
//COMMAND:07
{
{ true, 9, 2, 0, 3, 0, 3, E_STATE, 0 }, //Meter bus type
{ true, 11, 5, 0, 31, 0, 31, S_VALUE, 0 }, //Meter channel index
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:08
{
{ true, 1, 3, 0, 7, 0, 7, E_STATE, MSR_CHANNEL_METER_ERROR }, //Meter channel status / error
{ true, 9, 2, 0, 3, 0, 3, E_STATE, MSR_CHANNEL_METER_TYPE }, //Meter bus type
{ true, 11, 5, 0, 30, 0, 30, S_VALUE, MSR_CHANNEL_METER_CHANNEL }, //Meter channel index
{ true, 19, 2, 0, 3, 0, 3, E_STATE, MSR_CHANNEL_VALUE_SELECTION }, //Meter channel index
{ true, 21, 3, 0, 7, 0, 7, E_UNITS, 0 }, //Meter bus type
{ true, 24, 32, 0, 4294967295u, 0, 4294967295.0f, S_VALUE, MSR_CHANNEL_METER_1 }, //Meter channel index,
{ true, 4, 4, 0, 4, 0, 4, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
};

eoEEP_D230xx::eoEEP_D230xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x30;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D230xx::~eoEEP_D230xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_D230xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 2 || m.GetDataLength() > 9)
		return NOT_SUPPORTED;

	if(SetCommand(m.data[0] & 0x0F)!=EO_OK)
		return NOT_SUPPORTED;

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D230xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;

	SetCommand((uint8_t)1);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D230xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommmands||cmd==0 || cmd == 0x04 || cmd == 0x05)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	msg.Clear();
	SetRawValue(msg, rawValue, 4, 4);
	const uint8_t dataLength [] = {0, 3, 2, 4, 0, 0, 9, 2, 7};
	msg.SetDataLength(dataLength[cmd]);
	if(cmd==this->cmd )
		return EO_OK;

	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD230xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD230xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD230xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD230xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD230xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if ( cmd == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	// Set the proper message length depending on the command type
	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D230xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_STATE:
		case E_UNITS:
		case F_OPEN_CLOSED:
		case F_ON_OFF:
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D230xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}
	if (this->cmd == 0 || this->cmd > 8)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE;

	switch (type)
	{
		case E_STATE:
		case E_UNITS:
		case F_OPEN_CLOSED:
		case F_ON_OFF:
			rawValue = value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D230xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
			if(cmd==0x03 && IsChannel31())
				return NOT_SUPPORTED;
			break;
		case S_VALUE:
		case S_SETPOINT:
			break;

		default:
			return NOT_SUPPORTED;
	}
	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoEEP_D230xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd == 0 || this->cmd > 8)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_VALUE:
			rawValue = (uint32_t)value;
			break;
		case S_PERCENTAGE:
		case S_SETPOINT:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D230xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{

		case E_STATE:
			if(cmd==0x06)
			{
				switch((msg.data[1]&0x60)>>5)
				{
					default:
						return NOT_SUPPORTED;
					case 01:
					{
						if(index == MSR_CHANNEL_PROTOCOL)
							return NOT_SUPPORTED;
						break;
					}
					case 02:
						if(index == MSR_CHANNEL_PROTOCOL)
							return NOT_SUPPORTED;
						break;
					case 03:
						break;

				}
			}
			value = (uint8_t)rawValue;
			break;
		case E_ERROR_STATE:
			if (index == MSR_CHANNEL_ERROR_CH31)
			{
				float tmpVal = 0;
				this->GetValue(S_VALUE, tmpVal);

				if (tmpVal != 31)
					return NOT_SUPPORTED;
			}

			value = (uint8_t)rawValue;
			break;
		case E_UNITS:
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D230xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd == 0 || this->cmd > 8)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{

		case E_ERROR_STATE:
			if (index == MSR_CHANNEL_ERROR_CH31)
				this->SetValue(S_VALUE, (float)31);

			rawValue = (uint32_t)value;
			break;
		case E_STATE:
		case E_UNITS:
			rawValue = (uint32_t)value;
			break;

		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D230xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	//Only channel in this profile is the Occupied channel, thats why we only check against NULL
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	switch (type)
	{
		case S_TEMP:
			if (cmd != 0x03)
				return NOT_SUPPORTED;

			if((index == MSR_CHANNEL_SUPPLY_TEMP || index == MSR_COMMON_RETURN_TEMP) &&
				!IsChannel31())
				return NOT_SUPPORTED;
			break;
		case S_VALUE:
			if(cmd==0x06)
			{
				switch((msg.data[1]&0x60)>>5)
				{
					default:
						return NOT_SUPPORTED;
					case 01:
					{
						if(index==MSR_CHANNEL_NUM_OF_PULSES||index == MSR_CHANNEL_PRESET_VALUE)
							return NOT_SUPPORTED;
						break;
					}
					case 02:
						if(index==MSR_CHANNEL_PRIMARY_ADDR)
							return NOT_SUPPORTED;
						break;
					case 03:
						if(index==MSR_CHANNEL_PRIMARY_ADDR||index==MSR_CHANNEL_NUM_OF_PULSES||index == MSR_CHANNEL_PRESET_VALUE)
							return NOT_SUPPORTED;
						break;

				}
			}
			break;

		default:
			//return GetValue(type, value);
			return NOT_SUPPORTED;
	}
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}


	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	return EO_OK;
}

eoReturn eoEEP_D230xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd == 0 || this->cmd > 8)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP:
			if (index == MSR_CHANNEL_SUPPLY_TEMP ||
				index == MSR_COMMON_RETURN_TEMP) 
				this->SetValue(S_VALUE, (float)31);
			else if (IsChannel31()) //If the channel is 31, MSR_CHANNEL_RETURN_TEMP is not supported
				return NOT_SUPPORTED;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_VALUE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D230xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD230xx[this->cmd][tmpChannelCount].type == type && listD230xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
