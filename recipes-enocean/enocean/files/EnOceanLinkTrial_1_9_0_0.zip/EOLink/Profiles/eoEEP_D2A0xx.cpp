/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D2A0xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 2;
const uint8_t numOfProfiles = 0x01;
//2 Directions..
const EEP_ITEM listD2A0xx[numOfProfiles][2][numOfChan] =
{
		{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:01 oldDirection:1
{
	{ true, 6, 2, 0, 3, 0, 3, E_STATE, 0}, //Valve status
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //oldDirection
	},
	//TYPE:01 oldDirection:2
	{
	{ true, 6, 2, 0, 3, 0, 3, E_STATE, 0}, //Valve request status
	{ true, 0, 0, 0, 1, 0, 1, E_DIRECTION, 0 }, //oldDirection
	},
}
};

eoEEP_D2A0xx::eoEEP_D2A0xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	outChannels = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;
	outChannelCount=0;

	this->rorg = RORG_VLD;
	this->func = 0xA0;
	outMessage.RORG = RORG_VLD;
	outMessage.SetDataLength(size);
	msg.RORG = RORG_VLD;
	msg.SetDataLength(size);
	oldDirection = VALVE_TO_CONTROLLER;
}

eoEEP_D2A0xx::~eoEEP_D2A0xx()
{
	if(channel!=NULL)
		delete[] channel;
	if(outChannels!=NULL)
		delete[] outChannels;
	channel=NULL;
	outChannels = NULL;
}


eoReturn eoEEP_D2A0xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() != 1)
		return NOT_SUPPORTED;

	SetType(this->type);
	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}
eoReturn eoEEP_D2A0xx::SetChannels(SIMPLE_DIRECTION direction,uint8_t type)
{
	channelCount = 0;
	outChannelCount = 0;
	uint8_t tmpChannelCount;
	uint8_t receiveDirection= direction == eoController ? 0 : 1 ;
	uint8_t sendDirection= direction == eoController ? 1 : 0 ;
	uint8_t typeInList=type-1;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD2A0xx[typeInList][receiveDirection][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD2A0xx[typeInList][receiveDirection][tmpChannelCount].type;
			channel[channelCount].max = listD2A0xx[typeInList][receiveDirection][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD2A0xx[typeInList][receiveDirection][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD2A0xx[typeInList][receiveDirection][tmpChannelCount];
			channelCount++;
		}
	}
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD2A0xx[typeInList][sendDirection][tmpChannelCount].exist)
		{
			outChannels[outChannelCount].type = listD2A0xx[typeInList][sendDirection][tmpChannelCount].type;
			outChannels[outChannelCount].max = listD2A0xx[typeInList][sendDirection][tmpChannelCount].scaleMax;
			outChannels[outChannelCount].min = listD2A0xx[typeInList][sendDirection][tmpChannelCount].scaleMin;
			outChannels[outChannelCount].eepItem = &listD2A0xx[typeInList][sendDirection][tmpChannelCount];
			outChannelCount++;
		}
	}
	if(channelCount == 0)
		return NOT_SUPPORTED;
	return EO_OK;
}
eoReturn eoEEP_D2A0xx::SetType(uint8_t type)
{
	if (type > numOfProfiles || type == 0x00)
		return NOT_SUPPORTED;

	if(SetChannels(direction,type)!=EO_OK)
	{
		//Reset to old one...
		SetChannels(direction,this->type);
		return NOT_SUPPORTED;
	}
	this->type = type;

	return EO_OK;
}


eoReturn eoEEP_D2A0xx::SetDirection(SIMPLE_DIRECTION direction)
{
	if(SetChannels(direction,type)!=EO_OK)
	{
		//Reset to old one...
		SetChannels(this->direction ,type);
		return NOT_SUPPORTED;
	}
	this->direction = direction;
	return EO_OK;
}

void eoEEP_D2A0xx::ClearValues()
{
	outMessage.Clear();
	msg.Clear();
}


eoChannelInfo* eoEEP_D2A0xx::GetOutChannel(CHANNEL_TYPE type)
{
	uint8_t tmpChanCnt;
	for (tmpChanCnt = 0; tmpChanCnt < outChannelCount; tmpChanCnt++)
	{
		if (outChannels[tmpChanCnt].type == type)
			return (eoChannelInfo*) &outChannels[tmpChanCnt];
	}
	return NULL;
}

eoChannelInfo* eoEEP_D2A0xx::GetOutChannel(uint8_t channelNumber)
{
	eoChannelInfo* retChannel = NULL;
	if (channelNumber < outChannelCount)
		retChannel = (eoChannelInfo*) (&outChannels[channelNumber]);
	return retChannel;
}


eoReturn eoEEP_D2A0xx::SetDirection(VALVE_DIRECTION oldDirection)
{
	if(oldDirection==VALVE_TO_CONTROLLER)
		return SetDirection(eoActuator);
	else if(oldDirection==CONTROLLER_TO_VALVE)
		return SetDirection(eoController);
	else
		return NOT_SUPPORTED;
}

eoReturn eoEEP_D2A0xx::Create(eoMessage &m)
{
	outMessage.RORG = rorg;
	return outMessage.copyTo(m);
}

eoReturn eoEEP_D2A0xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_STATE:
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D2A0xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetOutChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_STATE:
			rawValue = (uint32_t)value;
			break;

		case E_DIRECTION:
			return SetDirection((VALVE_DIRECTION)value);
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(outMessage, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}
