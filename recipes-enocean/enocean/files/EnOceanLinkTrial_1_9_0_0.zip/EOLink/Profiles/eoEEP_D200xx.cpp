/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D200xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 26;
const uint8_t numOfProfiles = 0x01;
const uint8_t numOfCommands = 0x06;

const EEP_ITEM listD200xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:01
{
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, RCP_CONFIG_VALID }, //Configuration Valid
{ true, 11, 5, 0, 31, 0, 31, E_USER_ACTION, 0 }, //User Action
{ true, 5, 3, 0, 5, 0, 5, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:02
{
{ true, 0, 1, 0, 1, 0, 1, F_ON_OFF, RCP_FAN_MANUAL }, //Fan manual
{ true, 1, 3, 0, 4, 0, 4, E_FANSPEED, 0 }, //Fan SPEED
{ true, 4, 1, 0, 1, 0, 1, F_ON_OFF, RCP_MORE_DATA }, //More data
{ true, 8, 3, 0, 3, 0, 3, E_PRESENCE, 0 }, //Presence
{ true, 16, 16, 0, 4000, 0, 40, S_TEMP, RCP_ROOM_TEMPERATURE_C }, //Temperature
{ true, 16, 16, 0, 4000, 32, 104, S_TEMP, RCP_ROOM_TEMPERATURE_F }, //Temperature
{ true, 16, 16, 0, 4000, 0, 40, S_TEMP, RCP_NOMINAL_TEMPERATURE_C }, //Temperature
{ true, 16, 16, 0, 4000, 32, 104, S_TEMP, RCP_NOMINAL_TEMPERATURE_F }, //Temperature
{ true, 16, 16, 0, 4000, 0, 40, S_TEMP_ABS, RCP_DELTA_TEMP_SETPOINT_C }, //Temperature
{ true, 16, 16, 0, 4000, 32, 104, S_TEMP_ABS, RCP_DELTA_TEMP_SETPOINT_F }, //Temperature
{ true, 16, 16, 0, 4000, 0, 40, S_TEMP_ABS, RCP_DELTA_TEMP_GRAPHIC }, //Temperature
{ true, 16, 16, 0, 2359, 0, 2359, S_TIME, RCP_TIME_24_HOURS }, //Time hours
{ true, 16, 16, 0, 1159, 0, 1159, S_TIME, RCP_TIME_AM_HOURS }, //Time hours
{ true, 16, 16, 0, 1159, 0, 1159, S_TIME, RCP_TIME_PM_HOURS }, //Time hours
{ true, 16, 16, 0101, 3112, 0101, 3112, S_TIME, RCP_TIME_DAY_MONTH }, //Time date
{ true, 16, 16, 0101, 1231, 0101, 1231, S_TIME, RCP_TIME_MONTH_DAY }, //Time date
{ true, 16, 16, 0, 9999, 0, 9999, S_LUMINANCE, 0 }, //Luminance
{ true, 16, 16, 0, 10000, 0, 100, S_PERCENTAGE, 0 }, //Percentage
{ true, 16, 16, 0, 9999, 0, 9999, S_CONC, 0 }, //Concentration
{ true, 16, 16, 0, 10000, 0, 100, S_RELHUM, 0 }, //Relative humidity
{ true, 35, 1, 0, 1, 0, 1, F_ON_OFF, RCP_USER_NOTIFICATION }, //User notification
{ true, 36, 1, 0, 1, 0, 1, F_OPEN_CLOSED, 0 }, //Window
{ true, 37, 1, 0, 1, 0, 1, F_ON_OFF, RCP_DEW_POINT }, //Dew point
{ true, 38, 1, 0, 1, 0, 1, F_ON_OFF, RCP_COOLING }, //Cooling
{ true, 39, 1, 0, 1, 0, 1, F_ON_OFF, RCP_HEATING }, //Heating
{ true, 5, 3, 0, 5, 0, 5, E_COMMAND, 0 }, //Command ID
},
//COMMAND:03
{
{ true, 1, 3, 0, 5, 0, 5, E_FANSPEED, 0 }, //Fan speed
{ true, 8, 3, 0, 3, 0, 3, E_PRESENCE, 0 }, //Presence
{ true, 16, 16, 0, (uint32_t)2540, -12.7F, 12.7F, S_TEMP_ABS, 0 }, //Temperature set point
{ true, 5, 3, 0, 5, 0, 5, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:04
{
{ true, 8, 8, 0, 4000, 0, 40, S_TEMP, 0 }, //Temperature
{ true, 5, 3, 0, 5, 0, 5, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:05
{
{ true, 4, 1, 0, 1, 0, 1, F_ON_OFF, RCP_MORE_DATA }, //More data
{ true, 9, 7, 0, 127, 0, 12.7, S_SETPOINT, RCP_SETPOINT_RANGE_LIMIT }, //Setpoint range limit
{ true, 17, 7, 0, 127, 0, 127, S_SETPOINT, RCP_SETPOINT_STEPS }, //Setpoint steps
{ true, 24, 4, 0, 60, 0, 600, S_TIME, RCP_TEMP_MEASUREMENT_TIMING }, //Temperature measurement timing
{ true, 32, 3, 0, 7, 0, 7, E_PRESENCE, 0 }, //Presence
{ true, 35, 3, 0, 7, 0, 7, E_FANSPEED, 0 }, //Fan speed
{ true, 40, 4, 0, 15, 0, 3, S_TEMP_ABS, 0 }, //Temperature setpoint
{ true, 45, 3, 0, 7, 0, 70, S_TIME, RCP_KEEP_ALIVE_TIME }, //Keep alive timing
{ true, 5, 3, 0, 5, 0, 5, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, }, };

eoEEP_D200xx::eoEEP_D200xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x00;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D200xx::~eoEEP_D200xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D200xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 2 || m.GetDataLength() > 6)
		return NOT_SUPPORTED;

	SetCommand(m.data[0] & 0x07);

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D200xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	SetCommand(1);

	if (type == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D200xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommands||cmd==0)
		return NOT_SUPPORTED;

	msg.Clear();

	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {0, 2, 5, 4, 3, 6};
	msg.SetDataLength(dataLength[cmd]);

	if(cmd==this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD200xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD200xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD200xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD200xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD200xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D200xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
		case F_OPEN_CLOSED:
			value = rawValue ? 1 : 0;
			break;

		case E_USER_ACTION:
			switch (rawValue)
			{
				case PRESENCE:
				case TEMP_DOWN:
				case TEMP_UP:
				case FAN:
					value = (uint8_t)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;

		case E_PRESENCE:
			if (this->cmd == 0x05)
				value = (uint8_t)rawValue;
			else
			{
				switch (rawValue)
				{
					case NO_CHANGE:
					case PRESENT:
					case NOT_PRESENT:
					case NIGHT_TIME:
						value = (uint8_t)rawValue;
						break;
					default:
						return NOT_SUPPORTED;
						break;
				}
			}
			break;

		case E_FANSPEED:
			if (this->cmd != 0x05)
				if (rawValue > 5)
					return NOT_SUPPORTED;
			value = (uint8_t)rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D200xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
		case F_OPEN_CLOSED:
			rawValue = value ? 1 : 0;
			break;

		case E_USER_ACTION:
			switch (value)
			{
				case PRESENCE:
				case TEMP_DOWN:
				case TEMP_UP:
				case FAN:
					rawValue = value;
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;

		case E_PRESENCE:
			if (this->cmd == 0x05)
				rawValue = value;
			else
			{
				switch (value)
				{
					case NO_CHANGE:
					case PRESENT:
					case NOT_PRESENT:
					case NIGHT_TIME:
						rawValue = value;
						break;
					default:
						return NOT_SUPPORTED;
						break;
				}
			}
			break;

		case E_FANSPEED:
			if (this->cmd != 0x05)
				if (value > 5)
					return NOT_SUPPORTED;
			rawValue = value;
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D200xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP_ABS:
			if ((this->cmd == 0x03) && ((msg.data[1] & 0x1F) != 0x05))
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_TIME:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_TEMP:
			if (this->cmd != 0x04 || ((msg.data[0] & 0xF0) != 0x00))
				return NOT_SUPPORTED;

			GetRawValue(msg, tmpRawValue, (uint16_t)20, (uint8_t)4);
			rawValue = ((tmpRawValue << 8) & 0x0F00) | rawValue;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_PERCENTAGE:
			if ((msg.data[1] & 0x1F) != 0x0E)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_LUMINANCE:
			if ((msg.data[1] & 0x1F) != 0x0D)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_CONC:
			if ((msg.data[1] & 0x1F) != 0x0F)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_RELHUM:
			if ((msg.data[1] & 0x1F) != 0x10)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D200xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd == 0 || this->cmd > 5)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP_ABS:
			if (this->cmd == 0x03)
			{
				msg.data[1] &= 0xE0;
				msg.data[1] |= 0x05;
			}
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_TIME:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_TEMP:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

			if (this->cmd == 0x04)
			{
				msg.data[2] = 0x00;

				uint32_t tmpRawValue = (rawValue >> 8) & 0xF;
				SetRawValue(msg, tmpRawValue, (uint16_t)20, (uint8_t)4);
				tmpRawValue = rawValue & 0xFF;
				SetRawValue(msg, tmpRawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
			}
			break;

		case S_LUMINANCE:
			msg.data[1] &= 0xE0;
			msg.data[1] |= 0x0D;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_PERCENTAGE:
			msg.data[1] &= 0xE0;
			msg.data[1] |= 0x0E;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_CONC:
			msg.data[1] &= 0xE0;
			msg.data[1] |= 0x0F;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_RELHUM:
			msg.data[1] &= 0xE0;
			msg.data[1] |= 0x10;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D200xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;

		default:
			return GetValue(type, value);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_D200xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	if (this->cmd == 0 || this->cmd > 5)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;

		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D200xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue, tmpRawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TEMP:
			switch (index)
			{
				case RCP_ROOM_TEMPERATURE_C:
					if ((msg.data[1] & 0x1F) != 0x01)
						return NOT_SUPPORTED;
					break;
				case RCP_ROOM_TEMPERATURE_F:
					if ((msg.data[1] & 0x1F) != 0x02)
						return NOT_SUPPORTED;
					break;
				case RCP_NOMINAL_TEMPERATURE_C:
					if ((msg.data[1] & 0x1F) != 0x03)
						return NOT_SUPPORTED;
					break;
				case RCP_NOMINAL_TEMPERATURE_F:
					if ((msg.data[1] & 0x1F) != 0x04)
						return NOT_SUPPORTED;
					break;
				default:
					return GetValue(type, value);
					break;
			}
			break;

		case S_TEMP_ABS:
			switch (index)
			{
				case RCP_DELTA_TEMP_SETPOINT_C:
					if ((msg.data[1] & 0x1F) != 0x05)
						return NOT_SUPPORTED;
					break;
				case RCP_DELTA_TEMP_SETPOINT_F:
					if ((msg.data[1] & 0x1F) != 0x06)
						return NOT_SUPPORTED;
					break;
				case RCP_DELTA_TEMP_GRAPHIC:
					if ((msg.data[1] & 0x1F) != 0x07)
						return NOT_SUPPORTED;
					break;
				default:
					return GetValue(type, value);
					break;
			}
			break;

		case S_SETPOINT://do nothing?
			break;

		case S_TIME:
			switch (index)
			{
				case RCP_TIME_24_HOURS:
					if ((msg.data[1] & 0x1F) != 0x08)
						return NOT_SUPPORTED;
					break;
				case RCP_TIME_AM_HOURS:
					if ((msg.data[1] & 0x1F) != 0x09)
						return NOT_SUPPORTED;
					break;
				case RCP_TIME_PM_HOURS:
					if ((msg.data[1] & 0x1F) != 0x0A)
						return NOT_SUPPORTED;
					break;
				case RCP_TIME_DAY_MONTH:
					if ((msg.data[1] & 0x1F) != 0x0B)
						return NOT_SUPPORTED;
					break;
				case RCP_TIME_MONTH_DAY:
					if ((msg.data[1] & 0x1F) != 0x0C)
						return NOT_SUPPORTED;
					break;
				case RCP_TEMP_MEASUREMENT_TIMING:
					GetRawValue(msg, tmpRawValue, (uint8_t)38, (uint8_t)2);

					rawValue = ((tmpRawValue << 4) & 0x30) | rawValue;
					break;
				case RCP_KEEP_ALIVE_TIME:
					break;
				default:
					return GetValue(type, value);
					break;
			}
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	switch (index)
	{
		case RCP_ROOM_TEMPERATURE_F:
		case RCP_NOMINAL_TEMPERATURE_F:
		case RCP_DELTA_TEMP_SETPOINT_F:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, (float)0, (float)40);
			eoConverter::celsiusToFahrenheit(value);
			break;
		default:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_D200xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TEMP:
			switch (index)
			{
				case RCP_ROOM_TEMPERATURE_C:
				case RCP_NOMINAL_TEMPERATURE_C:
					rawValue = index - 0x0B;
					SetRawValue(msg, rawValue,11, 5);
					break;

				case RCP_ROOM_TEMPERATURE_F:
				case RCP_NOMINAL_TEMPERATURE_F:
					rawValue = index - 0x0B;
					SetRawValue(msg, rawValue,11, 5);
					eoConverter::fahrenheitToCelsius(value);

					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, (float)0, (float)40);
					SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

					return EO_OK;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;

		case S_TEMP_ABS:
			switch (index)
			{
				case RCP_DELTA_TEMP_SETPOINT_F:
					rawValue = index - 0x0B;
					SetRawValue(msg, rawValue,11, 5);
					eoConverter::fahrenheitToCelsius(value);

					rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, (float)0, (float)40);
					SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

					return EO_OK;
				case RCP_DELTA_TEMP_SETPOINT_C:
				case RCP_DELTA_TEMP_GRAPHIC:
					rawValue = index - 0x0B;
					SetRawValue(msg, rawValue,11, 5);
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;

		case S_SETPOINT:
			break;

		case S_TIME:
			switch (index)
			{
				case RCP_TIME_24_HOURS:
				case RCP_TIME_AM_HOURS:
				case RCP_TIME_PM_HOURS:
				case RCP_TIME_DAY_MONTH:
				case RCP_TIME_MONTH_DAY:
					rawValue = index - 0x0B;
					SetRawValue(msg, rawValue,11, 5);
					break;
				case RCP_TEMP_MEASUREMENT_TIMING:
				case RCP_KEEP_ALIVE_TIME:
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;

		default:
			return NOT_SUPPORTED;
	}

	if (type == S_TIME && index == RCP_TEMP_MEASUREMENT_TIMING)
	{
		rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

		uint32_t tmpRawValue = (rawValue >> 4) & 0x03;
		SetRawValue(msg, tmpRawValue, (uint16_t)38, (uint8_t)2);
		tmpRawValue = rawValue & 0x0F;
		SetRawValue(msg, tmpRawValue, (uint16_t)24, (uint8_t)4);
	}
	else
	{
		rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	}

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D200xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD200xx[this->cmd][tmpChannelCount].type == type && listD200xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
