/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A509xx.h"

#include "eoChannelEnums.h"
#include <string.h>
#include <math.h>
/*
 * Some internal informations CHANNEL 0= Humidity and CHANNEL 1 = Temperature
 */

const uint8_t numOfChan = 4;
const uint8_t numOfProfiles = 0x0D;
const EEP_ITEM listA509xx[numOfProfiles][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:01
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:02
{
{ true, 0, 8, 0, 255, 0, 5.1F, S_VOLTAGE, 0 }, //Voltage
{ true, 8, 8, 0, 255, 0, 1020, S_CONC, 0 }, //Concentration
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },  //Temperature
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:03
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:04
{
{ true, 0, 8, 0, 200, 0, 100, S_RELHUM, 0 }, //Humidity
{ true, 8, 8, 0, 255, 0, 2550, S_CONC, 0 }, //Concentration
{ true, 16, 8, 0, 255, 0, 51.0, S_TEMP, 0 },  //Temperature
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:05
{
{ true, 0, 16, 0, 65535, 0, 65535, S_CONC, 0 }, //Concentration
{ true, 16, 8, 0, 255, 0, 255, E_VOC, 0 }, //VOC_ID
{ false, 16, 8, 0, 255, 0, 51.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:06
{
{ true, 0, 10, 0, 1023, 0, 1023.F, S_RADON_ACTIVITY, 0 }, //Radon Activity
{ false, 16, 8, 0, 255, 0, 2550.F, S_RES, 0 },
{ false, 16, 8, 0, 255, 0, 51.F, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0F, 00.0, S_RES, 0 },
},
//TYPE:07
{
{ true, 0, 9, 0, 511, 0, 511, S_PARTICLES, PM10 }, //Particles
{ true, 9, 9, 0, 511, 0, 511, S_PARTICLES, PM2_5 },
{ true, 18, 9, 0, 511, 0, 511, S_PARTICLES, PM1 },
{ false, 16, 8, 255, 0, -40.0F, 00.0, S_RES, 0 },
},
//TYPE:08
{
{ true,  16, 8, 0, 255, 0, 2000, S_CONC, 0 }, //Particles
{ false, 16, 8, 0, 255, 0, 2550, S_RES, 0 },
{ false, 16, 8, 0, 255, 0, 51.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0F, 00.0, S_RES, 0 },
},
//TYPE:09
{
{ true,  16, 8, 0, 255, 0, 2000, S_CONC, 0 }, //Particles
{ true,  29, 1, 0, 	 1, 0,    1, F_POWERALARM, 0 },
{ false, 16, 8, 0, 255, 0, 51.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0F, 00.0, S_RES, 0 },
},
//TYPE:0A
{
{ true,  0, 16, 0, 65535, 0, 65535, S_CONC, 0 }, //Concentration
{ true,  16, 8, 0, 255, -20.0F, 60.0F, S_TEMP, 0 }, //Temperature
{ true, 24, 4, 0, 15, 2.0F, 5.0F, S_VOLTAGE, 0 }, //Voltage
{ false, 16, 8, 255, 0, -40.0F, 00.0, S_RES, 0 },
},
//TYPE:0B
{
{ true, 0, 4, 0, 15, 2.0F, 5.0F, S_VOLTAGE, 0 }, //Voltage
{ true,  8, 16, 0, 65535, 0,655350000.0F, S_COUNTER, 0 }, //Counter
{ true, 29, 2, 0, 3, 0, 3, E_UNITS, 0 }, //Unit
{ false, 16, 8, 255, 0, -40.0F, 00.0, S_RES, 0 },
},
//TYPE:0C
{
{ true, 0, 16, 0, 65535, 0, 65535, S_CONC, 0 }, //Concentration
{ true, 16, 8, 0, 255, 0, 255, E_VOC, 0 }, //VOC_ID
{ true, 29, 1, 0, 1, 0, 1, E_UNITS, 0 }, //Unit
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
}
};

eoEEP_A509xx::eoEEP_A509xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	rorg = RORG_4BS;
	func = 0x09;
}

eoEEP_A509xx::~eoEEP_A509xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_A509xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;
	if (type > numOfProfiles || type < 2)
		return NOT_SUPPORTED;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA509xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA509xx[type][tmpChannelCount].type;
			channel[channelCount].max = listA509xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA509xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA509xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (type == 0 || type == 1 ||channelCount == 0)
		return NOT_SUPPORTED;
	this->type = type;

	return EO_OK;
}

eoReturn eoEEP_A509xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range
	/* TOBI oh yeah spaghetti code :D (all this points are not really to do if it works,
	 * just nice to have
	 * so ... perhaps add a bool ala "bool callBaseSetValue=true;"
	 * and in the case of S_VOLTAGE set it to false
	 * the last line could be then
	 * if(callBaseSetValue)
	 * 		return eoA5EEProfile::SetValue(type, value);
	 * 	else
	 * 		return SetRawValue...
	*/
	switch (type)
	{
		case S_TEMP:
			msg.data[3] |= 0x02;
			return eoA5EEProfile::SetValue(type, value);
			break;
		case S_RELHUM:
			msg.data[3] |= 0x04;
			return eoA5EEProfile::SetValue(type, value);
		case S_CONC:
		case S_RADON_ACTIVITY:
			if (this->type == 0x05 ||
				this->type == 0x0C)
			{
				uint32_t scaleMultiplier=0;
				if (value < 655.35)
				{
					rawValue = (uint32_t)(value * 100);
					scaleMultiplier=0;
				}
				else if (value < 6553.5)
				{
					rawValue = (uint32_t)(value * 10);
					scaleMultiplier = 0x01;
				}
				else if (value < 65535)
				{
					rawValue = (uint32_t)value;
					scaleMultiplier = 0x02;
				}
				else if (value < 655350)
				{
					rawValue = (uint32_t)(value / 10);
					scaleMultiplier = 0x03;
				}
				else
					return OUT_OF_RANGE;
				SetRawValue(msg, scaleMultiplier,30,2);
				SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
			}
			else
				return eoA5EEProfile::SetValue(type, value);
			break;

		case S_VOLTAGE:
			if (this->type == 0x0A || this->type == 0x0B)
				msg.data[3] |= 0x01;

			return eoA5EEProfile::SetValue(type, value);
			break;

		case S_COUNTER:
		{
			uint32_t scaleMultiplier=0;
			if (value <= 0.65535)
			{
				rawValue = (uint32_t)(value * 1000);
				scaleMultiplier=0;
			}
			else if (value <= 6.5535)
			{
				rawValue = (uint32_t)(value * 100);
				scaleMultiplier = 1;
			}
			else if (value <= 65.535)
			{
				rawValue = (uint32_t)(value * 10);
				scaleMultiplier = 2;
			}
			else if (value <= 655.35)
			{
				rawValue = (uint32_t)value;
				scaleMultiplier = 3;
			}
			else if (value <= 6553.5)
			{
				rawValue = (uint32_t)(value / 10);
				scaleMultiplier = 4;
			}
			else if (value <= 65535)
			{
				rawValue = (uint32_t)(value / 100);
				scaleMultiplier = 5;
			}
			else if (value <= 655350)
			{
				rawValue = (uint32_t)(value / 1000);
				scaleMultiplier = 6;
			}
			else if (value <= 6553500)
			{
				rawValue = (uint32_t)(value / 10000);
				scaleMultiplier = 7;
			}
			else if (value <= 65530000)
			{
				rawValue = (uint32_t)(value / 100000);
				scaleMultiplier = 8;
			}
			else
				return OUT_OF_RANGE;
			SetRawValue(msg, scaleMultiplier, 24, 4);
			SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
			break;
		}
		default:
			return NOT_SUPPORTED;
			break;

	}
	return EO_OK;
}

eoReturn eoEEP_A509xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	//SEE EEP SPEC
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	if (type == S_TEMP && ((msg.data[3] & 0x02) != 0x02))
		return NOT_SUPPORTED;
	if (type == S_RELHUM && ((msg.data[3] & 0x04) != 0x04))
		return NOT_SUPPORTED;

	switch (type)
	{
		case S_TEMP:
		case S_RELHUM:
		case S_RADON_ACTIVITY:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_CONC:
			if (this->type == 0x05 ||
				this->type == 0x0C)
			{
				switch (msg.data[3] & 0x03)
				{
					case 0:
						value = (float)(rawValue * 0.01);
						break;
					case 1:
						value = (float)(rawValue * 0.1);
						break;
					case 2:
						value = (float)(rawValue);
						break;
					case 3:
						value = (float)(rawValue * 10);
						break;
				}
			}
			else
				value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_VOLTAGE:
			if (this->type == 0x0A || this->type == 0x0B)
			{
				if ((msg.data[3] & 0x01) != 0x01)
					return NOT_SUPPORTED;
			}
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_COUNTER:
			switch ((msg.data[3] & 0xF0) >> 4)
			{
				case 0:
					value = (float)(rawValue * 0.001);
					break;
				case 1:
					value = (float)(rawValue * 0.01);
					break;
				case 2:
					value = (float)(rawValue * 0.1);
					break;
				case 3:
					value = (float)(rawValue);
					break;
				case 4:
					value = (float)(rawValue * 10);
					break;
				case 5:
					value = (float)(rawValue * 100);
					break;
				case 6:
					value = (float)(rawValue * 1000);
					break;
				case 7:
					value = (float)(rawValue * 10000);
					break;
				case 8:
					value = ((float)rawValue * 100000);
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;

		default:
			return NOT_SUPPORTED;
	}
	return EO_OK;
}

eoReturn eoEEP_A509xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

	return EO_OK;
}

eoReturn eoEEP_A509xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK;
}

eoReturn eoEEP_A509xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_VOC:
		case F_POWERALARM:
		case E_UNITS:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_A509xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_VOC:
		case F_POWERALARM:
		case E_UNITS:
			rawValue = value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK;
}

eoChannelInfo* eoEEP_A509xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan;
			tmpChannelCount++)
	{
		if (listA509xx[this->type][tmpChannelCount].type == type && listA509xx[this->type][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
