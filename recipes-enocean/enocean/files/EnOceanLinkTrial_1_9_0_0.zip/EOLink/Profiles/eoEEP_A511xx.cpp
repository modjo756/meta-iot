/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A511xx.h"

#include "eoChannelEnums.h"
#include <string.h>

const uint8_t numOfChan = 11;
const uint8_t numOfProfiles = 0x06;

const EEP_ITEM listA511xx[numOfProfiles][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//tobi add index number
		//TYPE:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:01
{
{ true, 0, 8, 0, 255, 0, 510, S_LUMINANCE, 0 }, //Light
{ true, 8, 8, 0, 255, 0, 255, S_LUMINANCE_ABS, 0 }, //Set point for light
{ true, 16, 8, 0, 255, 0, 255, S_DIMMING, 0 }, //Dimming
{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, CS_REPEATER }, //Repeater
{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, CS_POWER_RELAY_TIMER }, //Power relay timer
{ true, 26, 1, 0, 1, 0, 1, F_ON_OFF, CS_DAYLIGHT_HARVEST }, //Day/night harvesting
{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CS_DIMMING }, //Dimming
{ true, 29, 1, 0, 1, 0, 1, F_OPEN_CLOSED, 0 }, //Magnet control
{ true, 30, 1, 0, 1, 0, 1, F_BTN_PRESS, 0 }, //Occupancy
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, CS_POWER_RELAY }, //Power relay
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:02
{
{ true, 0, 8, 0, 255, 0, 100, S_SETPOINT, 0 }, //Control variable
{ true, 8, 8, 0, 255, 0, 255, E_FANSPEED, 0 }, //Fan speed
{ true, 16, 8, 0, 255, 0, 51.2F, S_TEMP_ABS, 0 }, //Set point for temperature
{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, CS_ALARM }, //Alarm
{ true, 25, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Controller mode
{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CS_CONTROLLER_STATE }, //Controller state
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, CS_ENERGY_HOLDOFF }, //Energy hold-off
{ true, 30, 2, 0, 3, 0, 3, E_OCCUPANCY, 0 }, //Occupancy
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:03
{
{ true, 0, 8, 0, 100, 0, 100, S_SETPOINT, 0 }, //Blind/shutter position
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, CS_ANGLE_SIGN }, //Angle sign
{ true, 9, 7, 0, 90, 0, 180, S_ANGLE, 0 }, //Angle
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, CS_POSITION_VALUE }, //Position value flag
{ true, 17, 1, 0, 1, 0, 1, F_ON_OFF, CS_ANGLE_VALUE }, //Angle value flag
{ true, 18, 2, 0, 3, 0, 3, E_ERROR_STATE, 0 }, //Error state
{ true, 20, 2, 0, 3, 0, 3, E_END_POS, 0 }, //End position
{ true, 22, 2, 0, 3, 0, 3, E_STATE, 0 }, //Status
{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, CS_SETVICE_MODE }, //Service mode
{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, CS_MODE_OF_POSITION }, //Mode of the position
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:04
{
{ true, 0, 8, 0, 255, 0, 255, S_RGB, CS_RGB_RED }, //RGB Red
{ true, 8, 8, 0, 255, 0, 255, S_RGB, CS_RGB_GREEN }, //RGB Green
{ true, 16, 8, 0, 255, 0, 255, S_RGB, CS_RGB_BLUE }, //RGB Blue
{ true, 0, 8, 0, 255, 0, 255, S_DIMMING, 0 }, //Dim value
{ true, 8, 16, 0, 65535, 0, 65535, S_TIME, 0 }, //Lamp operating hours
{ true, 0, 16, 0, 65535, 0, 65535, S_VALUE, 0 }, //Energy metering value
{ true, 16, 8, 0, 11, 0, 11, E_UNITS, 0 }, //Units
{ true, 24, 1, 0, 1, 0, 1, F_ON_OFF, CS_SETVICE_MODE }, //Service mode
{ true, 25, 1, 0, 1, 0, 1, F_ON_OFF, CS_OPERATING_HOURS }, //Operating hours
{ true, 26, 2, 0, 3, 0, 3, E_ERROR_STATE, 0 }, //Error state
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, CS_STATUS } //Status
},
//TYPE:05
{
{ true, 25, 3, 1, 4, 1, 4, E_CONTROLLER_MODE, 0 }, //Working mode
{ true, 30, 2, 0, 3, 0, 3, E_STATE, 0 }, //Relay status
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
}
};

eoEEP_A511xx::eoEEP_A511xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_4BS;
	this->func = 0x11;

}

eoEEP_A511xx::~eoEEP_A511xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_A511xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA511xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA511xx[type][tmpChannelCount].type;
			channel[channelCount].max = listA511xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA511xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA511xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (type == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_A511xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range
	//TOBI: rawValue=ScaleToRAW could be used only once in the code
	switch (type)
	{
		case S_LUMINANCE:
		case S_LUMINANCE_ABS:
		case S_SETPOINT:
		case S_TEMP_ABS:
		case S_DIMMING:
		case S_TIME:
		case S_ANGLE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_VALUE:
			msg.data[3] |= 0x04;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A511xx::GetValue(CHANNEL_TYPE type, float &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}
	//TOBI review: same we could use value=ScaleFromRaw only once before the return
	switch (type)
	{
		case S_LUMINANCE:
		case S_LUMINANCE_ABS:
		case S_SETPOINT:
		case S_TEMP_ABS:
		case S_ANGLE:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_VALUE:
			if ((msg.data[3] & 0x06) != 0x04)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_DIMMING:
			if (this->type == 0x04)
				if ((msg.data[3] & 0x06) != 0)
					return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_TIME:
			if ((msg.data[3] & 0x06) != 0)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A511xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_OPEN_CLOSED:
		case F_BTN_PRESS:
			rawValue = value ? 0 : 1;
			break;
		case E_FANSPEED:
			switch (value)
			{
				case STAGE_0_MANUAL:
					rawValue = 0x00;
					break;
				case STAGE_1_MANUAL:
					rawValue = 0x01;
					break;
				case STAGE_2_MANUAL:
					rawValue = 0x02;
					break;
				case STAGE_3_MANUAL:
					rawValue = 0x03;
					break;
				case STAGE_0_AUTO:
					rawValue = 0x10;
					break;
				case STAGE_1_AUTO:
					rawValue = 0x11;
					break;
				case STAGE_2_AUTO:
					rawValue = 0x12;
					break;
				case STAGE_3_AUTO:
					rawValue = 0x13;
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;
		case E_CONTROLLER_MODE:
			if (value == 0)
				return NOT_SUPPORTED;
			rawValue = value;
			break;
		case E_OCCUPANCY:
		case E_ERROR_STATE:
		case E_END_POS:
		case E_STATE:
		case E_UNITS:
			rawValue = value;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A511xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_OPEN_CLOSED:
		case F_BTN_PRESS:
			value = rawValue ? 0 : 1;
			break;
		case E_FANSPEED:
			switch (rawValue)
			{
				case 0x00:
					value = STAGE_0_MANUAL;
					break;
				case 0x01:
					value = STAGE_1_MANUAL;
					break;
				case 0x02:
					value = STAGE_2_MANUAL;
					break;
				case 0x03:
					value = STAGE_3_MANUAL;
					break;
				case 0x10:
					value = STAGE_0_AUTO;
					break;
				case 0x11:
					value = STAGE_1_AUTO;
					break;
				case 0x12:
					value = STAGE_2_AUTO;
					break;
				case 0x13:
					value = STAGE_3_AUTO;
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;
		case E_CONTROLLER_MODE:
			if (rawValue == 0)
				return NOT_SUPPORTED;
			value = (uint8_t)rawValue;
			break;
		case E_OCCUPANCY:
		case E_ERROR_STATE:
		case E_END_POS:
		case E_UNITS:
		case E_STATE:
			value = (uint8_t)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A511xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan;
	switch (type)
	{
		case F_ON_OFF:
			myChan = (eoEEPChannelInfo *) GetChannel(type, index);
			break;
		default:
			return GetValue(type, value);
			break;
	}

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_A511xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan;
	switch (type)
	{
		case F_ON_OFF:
			myChan = (eoEEPChannelInfo *) GetChannel(type, index);
			break;
		default:
			return SetValue(type, value);
			break;
	}

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoReturn eoEEP_A511xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_RGB:
			if ((msg.data[3] & 0x06) != 0x02)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return SetValue(type, value);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A511xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_RGB:
			msg.data[3] |= 0x02;
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoChannelInfo* eoEEP_A511xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA511xx[this->type][tmpChannelCount].type == type && listA511xx[this->type][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
