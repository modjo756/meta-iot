/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A538xx.h"

#include "eoChannelEnums.h"
#include <string.h>

const uint16_t numOfChan = 20;
const uint16_t numOfProfiles = 0x0A;
const EEP_ITEM listA538xx[numOfProfiles][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//COMMAND:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//COMMAND:01
{
{ true, 8, 16, 0, 65535, 0, 6553.5, S_TIME, 0 }, //Time
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, CC_LOCK_UNLOCK }, //Lock/Unlock
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, CC_DELAY_DURATION }, //Delay/Duration
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, CC_SWITCHING_COMMAND }, //Delay/Duration
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:02
{
{ true, 8, 8, 0, 255, 0, 100, S_DIMMING, 0 }, //Dimming value
{ true, 16, 8, 0, 255, 0, 255, S_TIME, 0 }, //Time
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, CC_DIMMING_RANGE }, //Dimming range
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, CC_STORE_FINAL_VAL }, //Store final value
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, CC_SWITCHING_COMMAND }, //Delay/Duration
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:03
{
{ true, 16, 8, 0, 255, -12.7F, 12.8F, S_SETPOINT, 0 }, //Setpoint
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:04
{
{ true, 16, 8, 0, 255, 0, 51.2F, S_TEMP_ABS, 0 }, //Temperature setpoint
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:05
{
{ true, 16, 8, 0, 255, 0, 100, S_SETPOINT, 0 }, //Temperature setpoint
{ true, 25, 2, 0, 3, 0, 3, E_CONTROLLER_MODE, 0 }, //Controller mode
{ true, 27, 1, 0, 1, 0, 1, F_ON_OFF, CC_CONTROLLER_STATE }, //Controller state
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, CC_ENERGY_HOLDOFF }, //Energy hold-off
{ true, 30, 2, 0, 3, 0, 3, E_OCCUPANCY, 0 }, //Occupancy
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:06
{
{ true, 16, 8, 0, 255, 0, 255, E_FANSPEED, 0 }, //Fanspeed
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:07
{
{ true, 8, 8, 0, 255, 0, 100, S_PERCENTAGE, CC_BLIND_POSITION }, //Blind position
{ true, 17, 7, 0, 90, 0, 180, S_ANGLE, CC_ANGLE_BLIND_POSITION }, //Blind angle
{ true, 8, 8, 0, 255, 0, 255, S_TIME, CC_BLIND_OPEN_POSITION }, //Blind open position
{ true, 16, 8, 0, 255, 0, 25.5F, S_TIME, CC_BLIND_OPEN_ANGLE }, //Blind open angle
{ true, 8, 8, 0, 255, 0, 255, S_TIME, CC_BLIND_CLOSE_POSITION }, //Blind close position
{ true, 16, 8, 0, 255, 0, 25.5F, S_TIME, CC_BLIND_CLOSE_ANGLE }, //Blind close angle
{ true, 8, 8, 0, 255, 0, 255, S_TIME, CC_RUNTIME_OPEN }, //Runtime value to close
{ true, 16, 8, 0, 255, 0, 255, S_TIME, CC_RUNTIME_CLOSE }, //Runtime value to open
{ true, 8, 8, 0, 255, 0, 25.5, S_TIME, CC_SUNBLIND_REVERSION }, //Sunblind reversion time
{ true, 8, 8, 0, 255, 0, 100, S_PERCENTAGE, CC_SET_MIN_POSITION }, //Set minimum position
{ true, 16, 8, 0, 255, 0, 100, S_PERCENTAGE, CC_SET_MAX_POSITION }, //Set maximum position
{ true, 9, 7, 0, 90, 0, 180, S_ANGLE, CC_FULLY_SHUT_ANGLE }, //Fully shut angle
{ true, 17, 7, 0, 90, 0, 180, S_ANGLE, CC_FULLY_OPEN_ANGLE }, //Fully open angle
{ true, 8, 8, 0, 1, 0, 1, F_ON_OFF, CC_POSITION_LOGIC }, //Position logic
{ true, 24, 4, 0, 11, 0, 11, E_USER_ACTION, 0 }, //Function
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, CC_SEND_STATUS }, //Status flag
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, CC_POS_ANGLE_FLAG }, //Position and angle flag
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, CC_SERVICE_MODE }, //Service mode flag
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:08
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }, },
//COMMAND:09
{
{ true, 8, 16, 0, 65535, 0, 65535, S_TIME, CC_UP_RAMPING_TIME }, //Up ramping time
{ true, 8, 16, 0, 65535, 0, 65535, S_TIME, CC_DOWN_RAMPING_TIME }, //Down ramping time
{ true, 0, 8, 0, 255, 0, 255, S_DIMMING, CC_DIMMING_VALUE }, //Dimming value
{ true, 8, 16, 0, 65535, 0, 65535, S_TIME, CC_SET_RAMPING_TIME }, //Set ramping time
{ true, 0, 8, 0, 255, 0, 255, S_RGB, CC_RGB_RED }, //Red
{ true, 8, 8, 0, 255, 0, 255, S_RGB, CC_RGB_GREEN }, //Green
{ true, 16, 8, 0, 255, 0, 255, S_RGB, CC_RGB_BLUE }, //Blue
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, CC_SCENE_FUNCTION }, //Scene function
{ true, 20, 4, 0, 15, 0, 15, S_VALUE, CC_SCENE_NUMBER }, //Scene number
{ true, 0, 8, 0, 255, 0, 255, S_DIMMING, CC_MIN_DIM_VALUE }, //Minimum dimming value
{ true, 8, 8, 0, 255, 0, 255, S_DIMMING, CC_MAX_DIM_VALUE }, //Maximum dimming value
{ true, 0, 16, 0, 65535, 0, 65535, S_TIME, CC_LAMP_OPERATING_HOUR }, //Lamp operating hours
{ true, 16, 8, 0, 3, 0, 3, E_STATE, 0 }, //Locking local operations
{ true, 0, 16, 0, 65535, 0, 65535, S_VALUE, CC_ENERGY_METERING_VALUE }, //Energy metering value
{ true, 16, 8, 0, 11, 0, 11, E_UNITS, 0 }, //Energy metering unit
{ true, 24, 4, 0, 11, 0, 11, E_USER_ACTION, 0 }, //Function
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, CC_SEND_STATUS }, //Send status flag
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, CC_STORE_FINAL_VAL }, //Store final value
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, CC_SERVICE_MODE }, //Service mode flag
{ true, 0, 8, 1, 7, 1, 7, E_COMMAND, 0 }, //Command ID
}, };

eoEEP_A538xx::eoEEP_A538xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	rorg = RORG_4BS;
	func = 0x38;
	cmd = 0;
}

eoEEP_A538xx::~eoEEP_A538xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_A538xx::Parse(const eoMessage &m)
{
	if (Is4BSData(m))
	{
		SetCommand(m.data[0]);
		return eoProfile::Parse(m);
	}

	return NOT_SUPPORTED;
}

eoReturn eoEEP_A538xx::SetType(uint8_t type)
{
	if (type != 8 && type != 9)
		return NOT_SUPPORTED;

	if (type == 0x09)
		SetCommand(0x09);
	else
		SetCommand(1);

	this->type = type;
	if (type == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	

	return EO_OK;
}

eoReturn eoEEP_A538xx::SetCommand(uint8_t cmd)
{
	if (cmd > numOfProfiles||cmd==0)
		return OUT_OF_RANGE;

	uint8_t tmpChannelCount;
	channelCount = 0;
	msg.Clear();
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA538xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA538xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listA538xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA538xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA538xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->cmd = cmd;

	//Set the raw value in the last Step, otherwise we will override it!
	if (this->type != 0x09)
	{
		uint32_t rawValue = cmd;
		SetRawValue(msg, rawValue, 0, 8);
	}
	
	return EO_OK;
}

eoReturn eoEEP_A538xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_TIME:
		case S_SETPOINT:
		case S_TEMP_ABS:
		case S_DIMMING:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK;
}

eoReturn eoEEP_A538xx::GetValue(CHANNEL_TYPE type, float &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_SETPOINT:
		case S_TEMP_ABS:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_TIME:
			if (!(this->cmd == 0x01 || this->cmd == 0x02))
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_DIMMING:
			if (this->cmd != 0x02)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A538xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		if (value == 8)
			return NOT_SUPPORTED;
		return SetCommand(value);
	}

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_FANSPEED:
		case E_CONTROLLER_MODE:
		case E_OCCUPANCY:
		case E_USER_ACTION:
			rawValue = value;
			break;

		case E_STATE:
			msg.data[3] |= 0xB0;
			rawValue = value;
			break;

		case E_UNITS:
			msg.data[3] |= 0xC0;
			rawValue = value;
			break;

		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;

		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A538xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_FANSPEED:
		case E_CONTROLLER_MODE:
		case E_OCCUPANCY:
		case E_USER_ACTION:
			value = (uint8_t)rawValue;
			break;

		case E_STATE:
			if ((msg.data[3] & 0xF0) != 0xB0)
				return NOT_SUPPORTED;
			value = rawValue;
			break;

		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;

		case E_UNITS:
			if ((msg.data[3] & 0xF0) != 0xC0)
				return NOT_SUPPORTED;
			value = rawValue;
			break;

		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_A538xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			if (index == CC_POSITION_LOGIC)
				msg.data[3] |= 0xA0;
			rawValue = value ? 1 : 0;
			break;

		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A538xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			if (index == CC_POSITION_LOGIC)
				if ((msg.data[3] & 0xF0) != 0xA0)
					return NOT_SUPPORTED;
			value = rawValue ? 1 : 0;
			break;
		default:
			return GetValue(type, value);
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A538xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	uint32_t rawValue;
	float tmpValue = 0.0;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	switch (type)
	{
		case S_TIME:
			if (myChan->min > value || myChan->max < value)
				return OUT_OF_RANGE; // out of range
			switch (index)
			{
				case CC_BLIND_OPEN_POSITION:
				case CC_BLIND_OPEN_ANGLE:
					msg.data[3] |= 0x50;
					break;

				case CC_BLIND_CLOSE_POSITION:
				case CC_BLIND_CLOSE_ANGLE:
					msg.data[3] |= 0x60;
					break;
				case CC_RUNTIME_OPEN:
				case CC_RUNTIME_CLOSE:
					msg.data[3] |= 0x70;
					break;

				case CC_SUNBLIND_REVERSION:
					msg.data[3] |= 0x80;
					break;

				case CC_UP_RAMPING_TIME:
					msg.data[3] |= 0x30;
					break;

				case CC_DOWN_RAMPING_TIME:
					msg.data[3] |= 0x40;
					break;

				case CC_SET_RAMPING_TIME:
					msg.data[3] |= 0x60;
					break;

				default:
					return NOT_SUPPORTED;
					break;
			}

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_DIMMING:
			if (myChan->min > value || myChan->max < value)
				return OUT_OF_RANGE; // out of range

			switch (index)
			{
				case CC_DIMMING_VALUE:
					msg.data[3] |= 0x60;
					break;

				case CC_MIN_DIM_VALUE:
				case CC_MAX_DIM_VALUE:
					msg.data[3] |= 0x90;
					break;

				default:
					return SetValue(type, value);
					break;
			}

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_PERCENTAGE:
			if (myChan->min > value || myChan->max < value)
				return OUT_OF_RANGE; // out of range

			switch (index)
			{
				case CC_BLIND_POSITION:
					msg.data[3] |= 0x40;
					break;

				case CC_SET_MIN_POSITION:
				case CC_SET_MAX_POSITION:
					msg.data[3] |= 0x90;
					break;

				default:
					return NOT_SUPPORTED;
					break;
			}

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_ANGLE:
			switch (index)
			{
				case CC_FULLY_SHUT_ANGLE:
					if (value < 0)
					{
						msg.data[1] |= 0x80;
						tmpValue = -value;
					}
					else
						tmpValue = value;
					msg.data[3] |= 0xA0;
					break;

				case CC_FULLY_OPEN_ANGLE:
					if (value < 0)
					{
						msg.data[2] |= 0x80;
						tmpValue = -value;
					}
					else
						tmpValue = value;
					msg.data[3] |= 0xA0;
					break;

				case CC_ANGLE_BLIND_POSITION:
					if (value < 0)
					{
						msg.data[2] |= 0x80;
						tmpValue = -value;
					}
					else
						tmpValue = value;
					msg.data[3] |= 0x40;
					break;

				default:
					return NOT_SUPPORTED;
					break;
			}

			if (myChan->min > tmpValue || myChan->max < tmpValue)
				return OUT_OF_RANGE; // out of range

			rawValue = ScaleToRAW(tmpValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_RGB:

			switch (index)
			{
				case CC_RGB_RED:
				case CC_RGB_GREEN:
				case CC_RGB_BLUE:
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}

			if (myChan->min > value || myChan->max < value)
				return OUT_OF_RANGE; // out of range

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_VALUE:
			switch (index)
			{
				case CC_SCENE_NUMBER:
					msg.data[3] |= 0x80;
					break;

				case CC_ENERGY_METERING_VALUE:
					msg.data[3] |= 0xC0;
					break;

				default:
					return NOT_SUPPORTED;
					break;
			}

			if (myChan->min > value || myChan->max < value)
				return OUT_OF_RANGE; // out of range

			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A538xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_TIME:
			switch (index)
			{
				case CC_BLIND_OPEN_POSITION:
				case CC_BLIND_OPEN_ANGLE:
					if ((msg.data[3] & 0xF0) != 0x50)
						return NOT_SUPPORTED;
					break;

				case CC_BLIND_CLOSE_POSITION:
				case CC_BLIND_CLOSE_ANGLE:
					if ((msg.data[3] & 0xF0) != 0x60)
						return NOT_SUPPORTED;
					break;
				case CC_RUNTIME_OPEN:
				case CC_RUNTIME_CLOSE:
					if ((msg.data[3] & 0xF0) != 0x70)
						return NOT_SUPPORTED;
					break;

				case CC_SUNBLIND_REVERSION:
					if ((msg.data[3] & 0xF0) != 0x80)
						return NOT_SUPPORTED;
					break;

				case CC_UP_RAMPING_TIME:
					if ((msg.data[3] & 0xF0) != 0x30)
						return NOT_SUPPORTED;
					break;

				case CC_DOWN_RAMPING_TIME:
					if ((msg.data[3] & 0xF0) != 0x40)
						return NOT_SUPPORTED;
					break;

				case CC_SET_RAMPING_TIME:
					if ((msg.data[3] & 0xF0) != 0x60)
						return NOT_SUPPORTED;
					break;

				default:
					return NOT_SUPPORTED;
					break;
			}
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

			break;

		case S_RGB:
			if ((msg.data[3] & 0xF0) != 0x70)
				return NOT_SUPPORTED;
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_DIMMING:

			switch (index)
			{
				case CC_DIMMING_VALUE:
					if ((msg.data[3] & 0xF0) != 0x60)
						return NOT_SUPPORTED;
					break;

				case CC_MIN_DIM_VALUE:
				case CC_MAX_DIM_VALUE:
					if ((msg.data[3] & 0xF0) != 0x90)
						return NOT_SUPPORTED;
					break;

				default:
					return GetValue(type, value);

			}

			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_PERCENTAGE:
			switch (index)
			{
				case CC_BLIND_POSITION:
					if ((msg.data[3] & 0xF0) != 0x40)
						return NOT_SUPPORTED;
					break;

				case CC_SET_MIN_POSITION:
				case CC_SET_MAX_POSITION:
					if ((msg.data[3] & 0xF0) != 0x90)
						return NOT_SUPPORTED;
					break;

				default:
					return NOT_SUPPORTED;
			}

			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;

		case S_ANGLE:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			switch (index)
			{
				case CC_FULLY_SHUT_ANGLE:
					if ((msg.data[3] & 0xF0) != 0xA0)
						return NOT_SUPPORTED;
					if ((msg.data[1] & 0x80) == 0x80)
						value = -value;
					break;

				case CC_FULLY_OPEN_ANGLE:
					if ((msg.data[3] & 0xF0) != 0xA0)
						return NOT_SUPPORTED;
					if ((msg.data[2] & 0x80) == 0x80)
						value = -value;
					break;

				case CC_ANGLE_BLIND_POSITION:
					if ((msg.data[3] & 0xF0) != 0x40)
						return NOT_SUPPORTED;
					if ((msg.data[2] & 0x80) == 0x80)
						value = -value;
					break;
				default:
					return NOT_SUPPORTED;
					break;
			}
			break;

		case S_VALUE:
			switch (index)
			{
				case CC_SCENE_NUMBER:
					if ((msg.data[3] & 0xF0) != 0x80)
						return NOT_SUPPORTED;
					break;

				case CC_ENERGY_METERING_VALUE:
					if ((msg.data[3] & 0xF0) != 0xC0)
						return NOT_SUPPORTED;
					break;

				default:
					return NOT_SUPPORTED;
			}
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);

			break;

		default:
			return GetValue(type, value);
	}

	return EO_OK;
}

eoChannelInfo* eoEEP_A538xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA538xx[this->cmd][tmpChannelCount].type == type && listA538xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
