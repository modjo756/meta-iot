/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D2A0_H__INCLUDED_)
#define eoEEP_D2A0_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
#include "eoISimpleBidirectionalProfile.h"
/**\class eoEEP_D2A0xx
 * \brief The class to handle EEP D2A0 profiles
 * \details Allows the user to handle EEP DA20 profiles, the following profiles are available:
 * 		- D2-A0-01\n
 * DIRECTION-1 = Transmit mode: Message from the actuator to the controller
 * DIRECTION-2 = Receive mode: Commands from the controller to the actuator
 *
 * \note In Old EnOcean Link Version the direction could be set with E_DIRECTION, it is recommended with the new version to use
 * after initializing the profile the SetDirection Function to set once the direction of the profile. The Profile interprets then
 * the received data always as direction y and transmit data always with the direction x.
 *
 * The following channels are available for direction to controller:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_STATE			|::VALVE_STATUS |
 *
 * The following channels are available for direction to valve:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_STATE			|::VALVE_REQUEST |
 * \n
 */

/**
 * \file eoEEP_D2A0xx.h
 */
//! Valve status enums for D2-A0-xx profiles
typedef enum
{
	//! <b>Closed</b> 1
	VALVE_STATUS_CLOSED = 0x01,
	//! <b>Opened</b> 2
	VALVE_STATUS_OPENED = 0x02
} VALVE_STATUS;

//! Valve status request enums for D2-A0-xx profiles
typedef enum
{
	//! <b>Request feedback</b> 0
	VALVE_REQUEST_FEEDBACK = 0x00,
	//! <b>Request closing</b> 1
	VALVE_REQUEST_CLOSE = 0x01,
	//! <b>Request opening</b> 2
	VALVE_REQUEST_OPEN = 0x02,
	//! <b>Request closing</b> 3
	VALVE_REQUEST_CLOSE_2 = 0x03
} VALVE_REQUEST;

//! Valve direction enums for D2-A0-xx profiles
typedef enum
{
	//! <b>Water valve to the controller</b> 0
	VALVE_TO_CONTROLLER = 0x00,
	//! <b>Controller to the water valve</b> 1
	CONTROLLER_TO_VALVE = 0x01
} VALVE_DIRECTION;

class eoEEP_D2A0xx: public eoD2EEProfile,  public eoISimpleBidirectionalProfile
{
private:
	VALVE_DIRECTION oldDirection;
	eoMessage outMessage;
	eoEEPChannelInfo *outChannels;
	uint8_t outChannelCount;
	//internal helper tries to set the channel for Direction and type
	eoReturn SetChannels(SIMPLE_DIRECTION direction,uint8_t type);
public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D2A0xx(uint16_t size = 1);
	virtual ~eoEEP_D2A0xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);

	/**
	 * Sets and checks if the specified direction is supported
	 * @param direction
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	eoReturn SetDirection(VALVE_DIRECTION direction);
	virtual eoReturn Create(eoMessage &m);

	virtual eoChannelInfo* GetOutChannel(CHANNEL_TYPE type);
	virtual eoChannelInfo* GetOutChannel(uint8_t channelNumber);
	virtual eoReturn SetDirection(SIMPLE_DIRECTION directionToSet);

	virtual void ClearValues();
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
