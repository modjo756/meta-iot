/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D211_H__INCLUDED_)
#define eoEEP_D211_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D211xx
 * \brief The class to handle EEP D211 profiles
 * \details Allows the user to handle EEP D211 profiles, the following profiles are available:
 * 		- D2-11-01
 * 		- D2-11-02
 * 		- D2-11-03
 * 		- D2-11-04
 * 		- D2-11-05
 * 		- D2-11-06
 * 		- D2-11-07
 * 		- D2-11-08\n
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in Message Type A:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|::D211_SETPOINT_TYPE_ENUM | ::SETPOINT_TYPE |
 *\n
 *
 * The following channels are available in Message Type B:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|::D211_SETPOINT_TYPE_ENUM | ::SETPOINT_TYPE |
 * | 1             | ::F_ON_OFF			|uint8_t | ::DISPLAY_HEATING_SYMBOL |
 * | 2             | ::F_ON_OFF			|uint8_t | ::DISPLAY_COOLING_SYMBOL |
 * | 3             | ::F_ON_OFF			|uint8_t | ::DISPLAY_WINDOW_OPEN_SYMBOL |
 * | 4             | ::S_TEMP			|float | ::TEMP_CORRECTION |
 * | 5             | ::S_TEMP			|float | ::TEMP_BASEPOINT |
 * | 6             | ::E_STATE			|::D211_TEMP_CORRECTION_ENUM | ::VALID_TEMP_CORRECTION |
 * | 7             | ::E_FANSPEED		|uint8_t |  |
 * | 8             | ::F_OCCUPIED		|::D211_TEMP_CORRECTION_ENUM |  |
 *\n
 *
 * The following channels are available in Message Type C:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|::D211_SETPOINT_TYPE_ENUM | ::SETPOINT_TYPE |
 * | 1             | ::E_STATE			|::D211_TEL_TYPE_ENUM | ::TEL_TYPE |
 * | 2             | ::S_TEMP			|float | ::TEMP_NORMAL |
 * | 3             | ::S_RELHUM			|float |  |
 * | 4             | ::S_VALUE			|float |  |
 * | 5             | ::S_TEMP			|float | ::TEMP_BASEPOINT |
 * | 6             | ::E_STATE			|::D211_TEMP_CORRECTION_ENUM | ::VALID_TEMP_CORRECTION |
 * | 7             | ::E_FANSPEED		|uint8_t |  |
 * | 8             | ::F_OCCUPIED		|::D211_TEMP_CORRECTION_ENUM |  |
 *
 */

/**
 * \file eoEEP_D210xx.h
 */

//! Index enums for D2-11-xx profiles
typedef enum
{
	//! <b>Setpoint Type</b> 0
	SETPOINT_TYPE = 0x00,
	//! <b>Display heating symbol</b> 1
	DISPLAY_HEATING_SYMBOL = 0x01,
	//! <b>Display cooling symbol</b> 2
	DISPLAY_COOLING_SYMBOL = 0x02,
	//! <b>Display window open symbol</b> 3
	DISPLAY_WINDOW_OPEN_SYMBOL = 0x03,
	//! <b>Temperature correction</b> 4
	TEMP_CORRECTION = 0x04,
	//! <b>Temperature basepoint</b> 5
	TEMP_BASEPOINT = 0x05,
	//! <b>Valid temperature correction</b> 6
	VALID_TEMP_CORRECTION = 0x06,
	//! <b>Telegram type</b> 7
	TEL_TYPE = 0x07,
	//! <b>Temperature</b> 8
	TEMP_NORMAL = 0x08
} D211_INDEX_ENUM;

//! Message IDs for D2-11-xx profiles
typedef enum
{
	//! <b>Message Type A</b> 0
	MSG_TYPE_A = 0x00,
	//! <b>Message Type B</b> 1
	MSG_TYPE_B = 0x01,
	//! <b>Message Type C</b> 2
	MSG_TYP_C = 0x02
} D211_MESSAGE_ID_ENUM;

//! Setpoint type enums for D2-11-xx profiles
typedef enum
{
	//! <b>Temperature correction</b> 0
	SETPOINT_TEMP_CORRECTION = 0x00,
	//! <b>Temperature setpoint</b> 1
	SETPOINT_TEMP_SETPOINT = 0x01
} D211_SETPOINT_TYPE_ENUM;

//! Valid temperature correction enums for D2-11-xx profiles
typedef enum
{
	//! <b>-1 ... +1 K</b> 1
	TEMP_CORRECTION_1 = 0x01,
	//! <b>-2 ... +2 K</b> 2
	TEMP_CORRECTION_2 = 0x02,
	//! <b>-3 ... +3 K</b> 3
	TEMP_CORRECTION_3 = 0x03,
	//! <b>-4 ... +4 K</b> 4
	TEMP_CORRECTION_4 = 0x04,
	//! <b>-5 ... +5 K</b> 5
	TEMP_CORRECTION_5 = 0x05,
	//! <b>-6 ... +6 K</b> 6
	TEMP_CORRECTION_6 = 0x06,
	//! <b>-7 ... +7 K</b> 7
	TEMP_CORRECTION_7 = 0x07,
	//! <b>-8 ... +8 K</b> 8
	TEMP_CORRECTION_8 = 0x08,
	//! <b>-9 ... +9 K</b> 9
	TEMP_CORRECTION_9 = 0x09,
	//! <b>-10 ... +10 K</b> 10
	TEMP_CORRECTION_10 = 0x0A
} D211_TEMP_CORRECTION_ENUM;

//! Telegram type enums for D2-11-xx profiles
typedef enum
{
	//! <b>Hearbeat</b> 0
	TEL_HEARBEAT = 0x00,
	//! <b>Change of temperature or humidity value</b> 1
	TEL_TEMP_RELHUM_CHANGE = 0x01,
	//! <b>Used caused parameters change</b> 2
	TEL_USER_CHANGE = 0x02
} D211_TEL_TYPE_ENUM;

class eoEEP_D211xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D211xx(uint16_t size = 10);
	virtual ~eoEEP_D211xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);

	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
	/**
	 * Sets the channels and length
	 * @param type
	 * @return ::eoReturn EO_OK or NOT_SUPPORTED
	 */
	virtual eoReturn SetLength (uint8_t type);
	virtual eoReturn SetCommand(uint8_t cmd);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
