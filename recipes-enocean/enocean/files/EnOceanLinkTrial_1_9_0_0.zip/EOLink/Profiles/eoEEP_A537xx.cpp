/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A537xx.h"

#include "eoChannelEnums.h"
#include <string.h>
/*
 * Some internal informations CHANNEL 0= Humidity and CHANNEL 1 = Temperature
 */
const uint16_t numOfChan = 8;
const uint16_t numOfProfiles = 0x02;
const EEP_ITEM listA537xx[numOfProfiles][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00
{
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 } },
//TYPE:01
{
{ true, 0, 8, 0, 255, 0, 255, S_SETPOINT, 0 }, //Setpoint
{ true, 8, 1, 0, 1, 0, 1, F_ON_OFF, ABS_REL_POWER }, //Absolute/relative power
{ true, 9, 7, 0, 100, 0, 100, S_PERCENTAGE, 0 }, //Power usage
{ true, 16, 8, 1, 255, 15, 3825, S_TIME, 0 }, //Timeout settings
{ true, 24, 4, 0, 15, 0, 15, S_VALUE, 0 }, //DR Level
{ true, 29, 1, 0, 1, 0, 1, F_ON_OFF, RAND_START_DELAY }, //Random start delay
{ true, 30, 1, 0, 1, 0, 1, F_ON_OFF, RAND_END_DELAY }, //Randomized end delay
{ true, 31, 1, 0, 1, 0, 1, F_ON_OFF, MAX_MIN_POWER } //Max/Min power
},
};

eoEEP_A537xx::eoEEP_A537xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	rorg = RORG_4BS;
	func = 0x37;

}

eoEEP_A537xx::~eoEEP_A537xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_A537xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;
	//TOBI REVIEW: added this line here otherwise we go out of array
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA537xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA537xx[type][tmpChannelCount].type;
			channel[channelCount].max = listA537xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA537xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA537xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	this->type = type;
	if ( type == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}

eoReturn eoEEP_A537xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
		case S_SETPOINT:
		case S_TIME:
		case S_VALUE:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A537xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
		case S_SETPOINT:
		case S_TIME:
		case S_VALUE:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A537xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A537xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}

eoReturn eoEEP_A537xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value ? 1 : 0;
			break;

		default:
			return SetValue(type, value);
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A537xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo *) GetChannel(type, index);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue ? 1 : 0;
			break;
		default:
			return GetValue(type, value);
			break;
	}

	return EO_OK;
}

eoChannelInfo* eoEEP_A537xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA537xx[this->type][tmpChannelCount].type == type && listA537xx[this->type][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
