/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_D205xx.h"

#include "eoChannelEnums.h"
#include "eoConverter.h"
#include <string.h>

const uint8_t numOfChan = 6;
const uint8_t numOfProfiles = 0x01;
const uint8_t numOfCommands = 0x06;

const EEP_ITEM listD205xx[numOfCommands][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
{
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Go to Position and Angle message
{
		{ true, 28, 4, 1, 5, 1, 5, E_COMMAND, 0 }, //Message ID
		{ true, 1, 7, 0, 127, 0, 127, S_PERCENTAGE, CUR_VER_POSITION }, //Position
		{ true, 9, 7, 0, 127, 0, 127, S_PERCENTAGE, CUR_ROT_ANGLE }, //Angle
		{ true, 17, 3, 0, 2, 0, 2, E_END_POS, 0 }, //Repositioning
		{ true, 21, 3, 0, 7, 0, 7, E_STATE, 0 }, //Locking modes
		{ true, 24, 4, 0, 0, 0, 0, E_IO_CHANNEL, 0 } //Channel
},
//Stop message
{
		{ true, 4, 4, 0, 15, 0, 15, E_COMMAND, 0 }, //Message ID
		{ true, 24, 4, 0, 0, 0, 0, E_IO_CHANNEL, 0 }, //Channel
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Query Position and Angle message
{
		{ true, 4, 4, 0, 15, 0, 15, E_COMMAND, 0 }, //Message ID
		{ true, 24, 4, 0, 0, 0, 0, E_IO_CHANNEL, 0 }, //Channel
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Reply Position and Angle message
{
		{ true, 28, 4, 0, 15, 0, 15, E_COMMAND, 0 }, //Message ID
		{ true, 1, 7, 0, 127, 0, 127, S_PERCENTAGE, CUR_VER_POSITION }, //Position
		{ true, 9, 7, 0, 127, 0, 127, S_PERCENTAGE, CUR_ROT_ANGLE }, //Angle
		{ true, 21, 3, 0, 7, 0, 7, E_STATE, 0 }, //Locking modes
		{ true, 24, 4, 0, 0, 0, 0, E_IO_CHANNEL, 0 }, //Channel
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
},
//Set Parameters message
{
		{ true, 36, 4, 0, 15, 0, 15, E_COMMAND, 0 }, //Message ID
		{ true, 1, 15, 500, 32767, 5000, 300000, S_TIME, SET_VER_DURATION }, //Set vertical
		{ true, 16, 8, 0, 255, 10, 2540, S_TIME, SET_ROT_DURATION }, //Set rotation
		{ true, 29, 3, 0, 7, 0, 7, E_STATE, 0 }, //Set alarm action
		{ true, 32, 4, 0, 0, 0, 0, E_IO_CHANNEL, 0 }, //Channel
		{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 }
}
};

const EEP_ITEM typeListD205xx [numOfProfiles][8] =
{
	//Type 0x00
	{
		{ true, 0, 3, 0, 4, 0, 4, E_COMMAND, 0 }, //Message ID
		{ true, 1, 7, 0, 127, 0, 127, S_PERCENTAGE, CUR_VER_POSITION }, //Position
		{ true, 9, 7, 0, 127, 0, 127, S_PERCENTAGE, CUR_ROT_ANGLE }, //Angle
		{ true, 17, 3, 0, 2, 0, 2, E_END_POS, 0 }, //Repositioning
		{ true, 21, 3, 0, 7, 0, 7, E_STATE, 0 }, //Locking modes
		{ true, 24, 4, 0, 0, 0, 0, E_IO_CHANNEL, 0 }, //Channel
		{ true, 1, 15, 500, 32767, 5000, 300000, S_TIME, SET_VER_DURATION }, //Set vertical
		{ true, 16, 8, 0, 255, 10, 2540, S_TIME, SET_ROT_DURATION } //Set rotation
	}
};

eoEEP_D205xx::eoEEP_D205xx(uint16_t size) :
		eoD2EEProfile(size)
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	this->rorg = RORG_VLD;
	this->func = 0x05;
	msg.RORG = RORG_VLD;
	msg.SetDataLength(0);
	cmd = 0;
}

eoEEP_D205xx::~eoEEP_D205xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}


eoReturn eoEEP_D205xx::Parse(const eoMessage &m)
{
	if (m.GetDataLength() < 1 || m.GetDataLength() > 5)
		return NOT_SUPPORTED;

	SetCommand(m.data[m.dataLength - 1] & 0x0F);

	if (m.RORG == RORG_VLD)
		return eoProfile::Parse(m);

	return NOT_SUPPORTED;

}

eoReturn eoEEP_D205xx::SetType(uint8_t type)
{
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	SetLength(type);

	if (channelCount == 0)
		return NOT_SUPPORTED;

	this->type = type;
	return EO_OK;
}

eoReturn eoEEP_D205xx::SetCommand(uint8_t cmd)
{
	uint8_t tmpChannelCount;
	if(cmd>=numOfCommands || cmd == 0)
		return NOT_SUPPORTED;

	msg.Clear();

	// Set the proper message length depending on the command type
	const uint8_t dataLength [] = {0, 4, 1, 1, 4, 5};
	msg.SetDataLength(dataLength[cmd]);

	if(cmd==this->cmd )
	{
		uint32_t rawValue = cmd;
		eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
		SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
		return EO_OK;
	}

	channelCount = 0;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD205xx[cmd][tmpChannelCount].exist)
		{
			channel[channelCount].type = listD205xx[cmd][tmpChannelCount].type;
			channel[channelCount].max = listD205xx[cmd][tmpChannelCount].scaleMax;
			channel[channelCount].min = listD205xx[cmd][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listD205xx[cmd][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	uint32_t rawValue = cmd;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(E_COMMAND);
	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	this->cmd = cmd;

	return EO_OK;
}

eoReturn eoEEP_D205xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case E_STATE:
			switch(this->cmd)
			{
				case GOTO_MSG:
					if (rawValue > LOCK_ALARM && rawValue != LOCK_DEBLOCKAGE)
						return OUT_OF_RANGE;
					break;
				case REPLY_MSG:
					if (rawValue > LOCK_ALARM)
						return OUT_OF_RANGE;
					break;
				case SET_PARAM_MSG:
					if (rawValue > ALARM_DOWN && rawValue != ALARM_NO_CHANGE)
						return OUT_OF_RANGE;
					break;
				default:
					return NOT_SUPPORTED;
			}
			value = (uint8_t) rawValue;
			break;
		case E_END_POS:
			if (rawValue > REPOS_DOWN_POS_ANG)
				return OUT_OF_RANGE;
			value = (uint8_t) rawValue;
			break;
		case E_IO_CHANNEL:
			value = (uint8_t) rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D205xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	if (type == E_COMMAND)
	{
		this->ClearValues();
		return SetCommand(value);
	}

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case E_STATE:
			switch(this->cmd)
			{
				case GOTO_MSG:
					if (value > LOCK_ALARM && value != LOCK_DEBLOCKAGE)
						return OUT_OF_RANGE;
					break;
				case REPLY_MSG:
					if (value > LOCK_ALARM)
						return OUT_OF_RANGE;
					break;
				case SET_PARAM_MSG:
					if (value > ALARM_DOWN && value != ALARM_NO_CHANGE)
						return OUT_OF_RANGE;
					break;
				default:
					return NOT_SUPPORTED;
			}
			rawValue = (uint32_t) value;
			break;
		case E_END_POS:
			if (value > REPOS_DOWN_POS_ANG)
				return OUT_OF_RANGE;
			rawValue = (uint32_t) value;
			break;
		case E_IO_CHANNEL:
			rawValue = (uint32_t) value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D205xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}
	switch (type)
	{
		case S_PERCENTAGE:
			if (rawValue > 100 && rawValue != 127)
				return OUT_OF_RANGE;
			value = (float)rawValue;
			break;
		case S_TIME:
			if (rawValue > 30000 && rawValue != 32767)
					return OUT_OF_RANGE;
			value = (float)rawValue;
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D205xx::SetValue(CHANNEL_TYPE type, float value)
{
	if (this->cmd > 5 || this->cmd < 1)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
			if (value > 100 && value != 127)
				return OUT_OF_RANGE;
			rawValue = (uint32_t)value;
			break;
		case S_TIME:
			if (value > 30000 && value != 32767)
					return OUT_OF_RANGE;
			rawValue = (uint32_t)value;
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_D205xx::GetValue(CHANNEL_TYPE type, float &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;

	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_PERCENTAGE:
			switch (index)
			{
				case CUR_VER_POSITION:
				case CUR_ROT_ANGLE:
					if (rawValue > 100 && rawValue != 127)
						return OUT_OF_RANGE;
					value = (float)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_TIME:
			switch (index)
			{
				case SET_VER_DURATION:
				case SET_ROT_DURATION:
					if (rawValue > 30000 && rawValue != 32767)
							return OUT_OF_RANGE;
					value = (float)rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_D205xx::SetValue(CHANNEL_TYPE type, float value, uint8_t index)
{
	if (this->cmd > 5 || this->cmd < 1)
		return NOT_SUPPORTED;

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) GetChannel(type, index);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_PERCENTAGE:
			switch (index)
			{
				case CUR_VER_POSITION:
				case CUR_ROT_ANGLE:
					if (value > 100 && value != 127)
						return OUT_OF_RANGE;
					rawValue = (uint32_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		case S_TIME:
			switch (index)
			{
				case SET_VER_DURATION:
				case SET_ROT_DURATION:
					if (value > 30000 && value != 32767)
							return OUT_OF_RANGE;
					rawValue = (uint32_t)value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoChannelInfo* eoEEP_D205xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listD205xx[this->cmd][tmpChannelCount].type == type && listD205xx[this->cmd][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}

eoReturn eoEEP_D205xx::SetLength(uint8_t type)
{
	uint8_t tmpChannelCount;
	channelCount = 0;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (typeListD205xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = typeListD205xx[type][tmpChannelCount].type;
			channel[channelCount].max = typeListD205xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = typeListD205xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &typeListD205xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	if (channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}
