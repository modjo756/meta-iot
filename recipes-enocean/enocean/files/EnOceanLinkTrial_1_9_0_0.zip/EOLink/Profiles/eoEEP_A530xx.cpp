/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#include "eoEEP_A530xx.h"

#include "eoChannelEnums.h"
#include <string.h>
/*
 * Some internal informations CHANNEL 0= Humidity and CHANNEL 1 = Temperature
 */
const uint8_t numOfChan = 7;
const uint8_t numOfProfiles = 0x07;
const EEP_ITEM listA530xx[numOfProfiles][numOfChan] =
{
// exist	,bitoffs,bitsize,rangeMin,rangeMax,scaleMin, scaleMax,type;
//TYPE:00
{
//Temperature
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:01
{
{ true, 16, 8, 0, 255, 0.0, 255, F_OPEN_CLOSED, 0 }, //Input state
{ true, 8, 8, 0, 255, 0.0, 255, S_VOLTAGE, 0 }, //Battery status
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:02
{
{ true, 31, 1, 0, 1, 0.0, 1, F_OPEN_CLOSED, 0 }, //Input state
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:03
{
{ true,  8, 8, 255, 0, 0.0, 40.0, S_TEMP, 0 }, //Temperature
{ true, 19, 1, 0, 1, 0, 1, F_HIGH_LOW, STATUS_WAKE }, //Value of wake signal
{ true, 20, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_3 }, //Digital input 3
{ true, 21, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_2 }, //Digital input 2
{ true, 22, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_1 }, //Digital input 1
{ true, 23, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_0 }, //Digital input 0
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:04
{
{ true, 16, 8, 0, 255, 0.0, 255, S_VALUE, 0 }, //Digital value
{ true, 29, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_2 }, //Digital input 2
{ true, 30, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_1 }, //Digital input 1
{ true, 31, 1, 0, 1, 0, 1, F_HIGH_LOW, DIGITAL_IN_0 }, //Digital input 0
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:05
{
{ true, 8, 8, 0, 255, 0.0, 3.3, S_VOLTAGE, 0 }, //Supply voltage
{ true, 16, 1, 0, 1, 0, 1, F_ON_OFF, 0 }, //Signal type
{ true, 17, 7, 0, 127, 0, 127, S_COUNTER, 0 }, //Index of signals
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
{ false, 16, 8, 255, 0, -40.0, 00.0, S_RES, 0 },
},
//TYPE:06
{
{ true, 0, 4, 0, 9, 0, 9, E_KEY_DATA, KEY_DATA_1 }, //Digital value
{ true, 4, 4, 0, 9, 0, 9, E_KEY_DATA, KEY_DATA_2 }, //Digital value
{ true, 8, 4, 0, 9, 0, 9, E_KEY_DATA, KEY_DATA_3 }, //Digital value
{ true, 12, 4, 0, 9, 0, 9, E_KEY_DATA, KEY_DATA_4 }, //Digital value
{ true, 16, 4, 0, 9, 0, 9, E_KEY_DATA, KEY_DATA_5 }, //Digital value
{ true, 20, 4, 0, 9, 0, 9, E_KEY_DATA, KEY_DATA_6 }, //Digital value
{ true, 24, 4, 0, 15, 2.0, 5.0, S_VOLTAGE, 0 }, //Supply voltage
},
};

eoEEP_A530xx::eoEEP_A530xx()
{
	channel = new eoEEPChannelInfo[numOfChan];
	channelCount = 0;

	rorg = RORG_4BS;
	func = 0x30;

}

eoEEP_A530xx::~eoEEP_A530xx()
{
	if(channel!=NULL)
		delete[] channel;
	channel=NULL;
}

eoReturn eoEEP_A530xx::SetType(uint8_t type)
{
	channelCount = 0;
	uint8_t tmpChannelCount;
	//TOBI REVIEW: added this line here otherwise we go out of array
	if (type > numOfProfiles)
		return NOT_SUPPORTED;
	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA530xx[type][tmpChannelCount].exist)
		{
			channel[channelCount].type = listA530xx[type][tmpChannelCount].type;
			channel[channelCount].max = listA530xx[type][tmpChannelCount].scaleMax;
			channel[channelCount].min = listA530xx[type][tmpChannelCount].scaleMin;
			channel[channelCount].eepItem = &listA530xx[type][tmpChannelCount];
			channelCount++;
		}
	}

	this->type = type;
	if (type == 0 || channelCount == 0)
		return NOT_SUPPORTED;

	return EO_OK;
}

eoReturn eoEEP_A530xx::SetValue(CHANNEL_TYPE type, float value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case S_VOLTAGE:
			if (this->type == 0x01)
			{
				if (!value)
					rawValue = 60;
				else
					rawValue = 190;
			}
			else
				rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TEMP:
		case S_VALUE:
		case S_COUNTER:
			rawValue = ScaleToRAW(value, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	};

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);

	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A530xx::GetValue(CHANNEL_TYPE type, float &value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case S_VOLTAGE:
			if (this->type == 0x01)
			{
				if (rawValue < 121)
					value = BATTERY_LOW;
				else
					value = BATTERY_EO_OK;
			}
			else
				value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		case S_TEMP:
		case S_VALUE:
		case S_COUNTER:
			value = ScaleFromRAW(rawValue, myChan->eepItem->rangeMin, myChan->eepItem->rangeMax, myChan->min, myChan->max);
			break;
		default:
			return NOT_SUPPORTED;
	};

	return EO_OK;
}

eoReturn eoEEP_A530xx::GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan;
	switch (type)
	{
		case F_HIGH_LOW:
		case E_KEY_DATA:
			myChan = (eoEEPChannelInfo *) GetChannel(type, index);
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_HIGH_LOW:
			value = rawValue ? 1 : 0;
			break;
		case E_KEY_DATA:
			switch (index)
			{
				case KEY_DATA_1:
				case KEY_DATA_2:
				case KEY_DATA_3:
				case KEY_DATA_4:
				case KEY_DATA_5:
				case KEY_DATA_6:
					value = rawValue;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
	}

	return EO_OK;
}

eoReturn eoEEP_A530xx::SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan;
	switch (type)
	{
		case F_HIGH_LOW:
		case E_KEY_DATA:
			myChan = (eoEEPChannelInfo *) GetChannel(type, index);
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_HIGH_LOW:
			rawValue = value ? 1 : 0;
			break;
		case E_KEY_DATA:
			switch (index)
			{
				case KEY_DATA_1:
				case KEY_DATA_2:
				case KEY_DATA_3:
				case KEY_DATA_4:
				case KEY_DATA_5:
				case KEY_DATA_6:
					rawValue = value;
					break;
				default:
					return NOT_SUPPORTED;
			}
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK;
}

eoReturn eoEEP_A530xx::SetValue(CHANNEL_TYPE type, uint8_t value)
{
	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);
	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (myChan->min > value || myChan->max < value)
		return OUT_OF_RANGE; // out of range

	switch (type)
	{
		case F_ON_OFF:
			rawValue = value;
			break;
		case F_OPEN_CLOSED:
			if (channel->max == 255)
			{
				if (!value)
					rawValue = 98;
				else
					rawValue = 226;
			}
			else
				rawValue = value ? 0 : 1;
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	SetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize);
	return EO_OK; //EO_OK;
}

eoReturn eoEEP_A530xx::GetValue(CHANNEL_TYPE type, uint8_t &value)
{

	uint32_t rawValue;
	eoEEPChannelInfo* myChan = (eoEEPChannelInfo*) eoEEProfile::GetChannel(type);

	if (myChan == NULL)
		return NOT_SUPPORTED;

	if (GetRawValue(msg, rawValue, myChan->eepItem->bitoffs, (uint8_t)myChan->eepItem->bitsize) != EO_OK)
		return NOT_SUPPORTED;
	//General Range check
	if (myChan->eepItem->rangeMin > myChan->eepItem->rangeMax)
	{
		if (myChan->eepItem->rangeMin < rawValue || myChan->eepItem->rangeMax > rawValue)
			return OUT_OF_RANGE;
	}
	else
	{
		if (myChan->eepItem->rangeMin > rawValue || myChan->eepItem->rangeMax < rawValue)
			return OUT_OF_RANGE;
	}

	switch (type)
	{
		case F_ON_OFF:
			value = rawValue;
			break;
		case F_OPEN_CLOSED:
			if (channel->max == 255)
			{
				if (rawValue < 196)
					value = 0;
				else
					value = 1;
			}
			else
			{
				value = (rawValue ? 0 : 1);
			}
			break;
		default:
			return NOT_SUPPORTED;
			break;
	}

	return EO_OK;
}


eoChannelInfo* eoEEP_A530xx::GetChannel(CHANNEL_TYPE type, uint8_t index)
{
	uint8_t tmpChannelCount;

	for (tmpChannelCount = 0; tmpChannelCount < numOfChan; tmpChannelCount++)
	{
		if (listA530xx[this->type][tmpChannelCount].type == type && listA530xx[this->type][tmpChannelCount].index == index)
			return &channel[tmpChannelCount];
	}

	return NULL;
}
