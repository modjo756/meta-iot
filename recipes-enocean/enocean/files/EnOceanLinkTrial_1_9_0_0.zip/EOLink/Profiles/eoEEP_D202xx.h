/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING, 
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR 
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE, 
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR 
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT 
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#if  !defined(eoEEP_D202_H__INCLUDED_)
#define eoEEP_D202_H__INCLUDED_
/** \ingroup eepProfiles
 *  @{
 */
#include "eoD2EEProfile.h"
/**\class eoEEP_D202xx
 * \brief The class to handle EEP D202 profiles
 * \details Allows the user to handle EEP D202 profiles, the following profiles are available:
 * 		- D2-02-00
 * 		- D2-02-01
 * 		- D2-02-02\n
 *
 * 	NOTE: set the command ID before using the profile.
 *
 * The following channels are available in Sensor measurement:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::S_TEMP		|float |
 * | 1             | ::S_LUMINANCE 	|float |
 * | 2             | ::F_OCCUPIED	|uint8_t |
 * | 3             | ::E_STATE		|::VLD_SMOKE_DETECTION_ENUM |
 * \n
 *
 * The following channels are available in Sensor test/trigger:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF		|uint8_t | Self-test, ::VLD_SELF_TEST |
 * | 1             | ::F_ON_OFF 	|uint8_t | Trigger alarm, ::VLD_TRIGGER_ALARM |
 * \n
 *
 * The following channels are available in Actuator set measurement:
 * | Channel Index | Channel Type | Type | Comment |
 * |:-------------:|:------------:|:----:|:-------:|
 * | 0             | ::F_ON_OFF			|uint8_t | Report measurement, ::VLD_REPORT_MEASUREMENT |
 * | 1             | ::S_TEMP_ABS 		|float |  |
 * | 2             | ::S_LUMINANCE_ABS 	|float |   |
 * | 3             | ::S_TIME	 		|float | Maximum time between two subsequent Actuator, ::VLD_MAX_TIME |
 * | 4             | ::S_TIME	 		|float | Minimum time between two subsequent Actuator, ::VLD_MIN_TIME |
 * \n
 *
 * The following channels are available in Sensor measurement query:
 * | Channel Index | Channel Type | Type |
 * |:-------------:|:------------:|:----:|
 * | 0             | ::E_STATE		|::VLD_QUERY_STATUS |
 * \n
 */

/**
 * \file eoEEP_D202xx.h
 */
//! Command enums for D2-02-xx profiles
typedef enum
{
	//! <b>Sensor Measurement</b> 1
	SENSOR_MEASUREMENT = 0x01,
	//! <b>Sensor Test/Trigger</b> 2
	SENSOR_TEST_TRIGGER = 0x02,
	//! <b>Actuator Set Measurement</b> 3
	ACTUATOR_SET = 0x03,
	//! <b>Sensor Measurementuery</b> 4
	SENSOR_QUERY = 0x04
} VLD_COMMANDS;

//! Index enums for D2-02-xx profiles
typedef enum
{
	//! <b>Self-test</b> 0
	VLD_SELF_TEST = 0x00,
	//! <b>Trigger alarm</b> 1
	VLD_TRIGGER_ALARM = 0x01,
	//! <b>Report measurement</b> 2
	VLD_REPORT_MEASUREMENT = 0x02,
	//! <b>Maximum time between two subsequent actuator</b> 3
	VLD_MAX_TIME = 0x03,
	//! <b>Minimum time between two subsequent actuator</b> 4
	VLD_MIN_TIME = 0x04,
	//! <b>Smoke detection</b> 5
	VLD_SMOKE_DETECTION = 0x05,
	//! <b>Query</b> 6
	VLD_QUERY = 0x06
} VLD_INDEXS;

//! Smoke detection enums for D2-02-xx profiles
typedef enum
{
	//! <b>No smoke detected</b> 0
	NO_SMOKE = 0x00,
	//! <b>Smoke detected via ionization chamber</b> 1
	SMOKE_IONIZATION = 0x01,
	//! <b>Smoke detected via optical chamber</b> 2
	SMOKE_OPTICAL = 0x02,
	//! <b>Smoke detected via both chamber</b> 3
	SMOKE_BOTH = 0x03
} VLD_SMOKE_DETECTION_ENUM;

//! Query enums for D2-02-xx profiles
typedef enum
{
	//! <b>Query temperature</b> 0
	QUERY_TEMP = 0x00,
	//! <b>Query illuminaion</b> 1
	QUERY_LUMINANCE = 0x01,
	//! <b>Query occupancy</b> 2
	QUERY_OCCUPANCY = 0x02,
	//! <b>Query smoke</b> 3
	QUERY_SMOPKE = 0x03
} VLD_QUERY_STATUS;

class eoEEP_D202xx: public eoD2EEProfile
{
private:
	uint8_t cmd;

public:
	eoReturn SetType(uint8_t type);
	eoReturn Parse(const eoMessage &msg);
	/**
	 * Constructor with message size
	 * @param size
	 */
	eoEEP_D202xx(uint16_t size = 10);
	virtual ~eoEEP_D202xx();
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value);
	virtual eoReturn GetValue(CHANNEL_TYPE type, uint8_t &value, uint8_t index);
	virtual eoReturn GetValue(CHANNEL_TYPE type, float &value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value);
	virtual eoReturn SetValue(CHANNEL_TYPE type, uint8_t value, uint8_t index);
	virtual eoReturn SetValue(CHANNEL_TYPE type, float value, uint8_t index);
	virtual eoReturn SetCommand(uint8_t cmd);
	eoChannelInfo* GetChannel(CHANNEL_TYPE type, uint8_t index);
};
/** @}*/

#endif // !defined(EA_259BDE62_FE41_490e_8B3E_427A72922C4A__INCLUDED_)
