#include <stdint.h>
#include <vector>
#include "eoIWatcher.h"

eoIWatcher::eoIWatcher()
{
	type=0;
}

eoIWatcher::~eoIWatcher()
{
}


uint32_t eoIWatcher::CheckSecurity(eoDevice const * const device,eoTelegram const &msg)
{
	return 0;
}

uint8_t eoIWatcher::Serialize(eoArchive &arch)
{
	if (!arch.isStoring)
	{
		arch & "type" & type;
	}
	return EO_OK;
}

