/******************************************************************************
 DISCLAIMER

 THIS SOFTWARE PRODUCT ("SOFTWARE") IS PROPRIETARY TO ENOCEAN GMBH, OBERHACHING,
 GERMANY (THE "OWNER") AND IS PROTECTED BY COPYRIGHT AND INTERNATIONAL TREATIES OR
 PROTECTED AS TRADE SECRET OR AS OTHER INTELLECTUAL PROPERTY RIGHT. ALL RIGHTS, TITLE AND
 INTEREST IN AND TO THE SOFTWARE, INCLUDING ANY COPYRIGHT, TRADE SECRET OR ANY OTHER 
 INTELLECTUAL PROPERTY EMBODIED IN THE SOFTWARE, AND ANY RIGHTS TO REPRODUCE,
 DISTRIBUTE, MODIFY, DISPLAY OR OTHERWISE USE THE SOFTWARE SHALL EXCLUSIVELY VEST IN THE
 OWNER. ANY UNAUTHORIZED REPRODUCTION, DISTRIBUTION, MODIFICATION, DISPLAY OR OTHER
 USE OF THE SOFTWARE WITHOUT THE EXPLICIT PERMISSION OF OWNER IS PROHIBITED AND WILL 
 CONSTITUTE AN INFRINGEMENT OF THE OWNER'S RIGHT AND MAY BE SUBJECT TO CIVIL OR
 CRIMINAL SANCTION.

 THIS SOFTWARE IS PROVIDED BY THE OWNER "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN PARTICULAR, THE OWNER DOES NOT WARRANT
 THAT THE SOFTWARE SHALL BE ERROR FREE AND WORKS WITHOUT INTERRUPTION.

 IN NO EVENT SHALL THE OWNER BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#ifdef WIN32
#include "eoWin32PacketStream.h"
#include <string.h>
#include <fcntl.h>
//#include <unistd.h>
#include <stdio.h>
#include <errno.h>

#define BDR_ESP3 B57600

eoWin32PacketStream::eoWin32PacketStream()
{
	fd = -1;
	curByte = 0;
	numBytes = 0;
	portOpen = 0;
}

eoWin32PacketStream::~eoWin32PacketStream()
{
	Close();
}

void eoWin32PacketStream::Close()
{
	PurgeComm(portOpen, PURGE_TXCLEAR | PURGE_RXCLEAR);
	CloseHandle(portOpen);
	portOpen = NULL;
}

eoReturn eoWin32PacketStream::Open(const char * port)
{
	//! Create file
	portOpen = CreateFileA(port,
			GENERIC_READ | GENERIC_WRITE,
			0,
			NULL,
			OPEN_EXISTING,
			0,
			0);

	if(portOpen == INVALID_HANDLE_VALUE)
	{
		return NOT_SUPPORTED;
	}

	if (!GetCommState(portOpen, &DCBParam))
	{
		error = GetLastError();
		return NOT_SUPPORTED;
	}

	DCBParam.BaudRate = 56700;
	DCBParam.ByteSize = 8;
	DCBParam.StopBits = ONESTOPBIT;

	DCBParam.Parity	 = NOPARITY;
	DCBParam.fParity = (DCBParam.Parity == NOPARITY) ? FALSE:TRUE;

	DCBParam.fOutxCtsFlow = false;
	DCBParam.fOutxDsrFlow = false;

	DCBParam.fDtrControl = DTR_CONTROL_DISABLE;
	DCBParam.fRtsControl = RTS_CONTROL_DISABLE;

	if (! SetCommState(portOpen, &DCBParam) )
	{
		error = GetLastError();
		return NOT_SUPPORTED;
	}

	m_Comtimeout.ReadIntervalTimeout		 = 1;
	m_Comtimeout.ReadTotalTimeoutMultiplier	 = 0;
	m_Comtimeout.ReadTotalTimeoutConstant	 = 100; //100;
	m_Comtimeout.WriteTotalTimeoutMultiplier = 0;
	m_Comtimeout.WriteTotalTimeoutConstant	 = 100; //100;

	if (!SetCommTimeouts(portOpen, &m_Comtimeout))
	{
		return EO_ERROR;
	}

	//prepare port such way that we can also monitor EV_RXFLAG and use WaitCom
	if (!SetCommMask(portOpen, EV_RXFLAG))
	{
		return NOT_SUPPORTED;
	}

	PurgeComm(portOpen, PURGE_TXCLEAR | PURGE_RXCLEAR);

	return EO_OK;
}

eoReturn eoWin32PacketStream::ReceiveByte(uint8_t* u8RxByte)
{
	DWORD NumberOfBytesRead = 0;

	if (!ReadFile(portOpen, u8RxByte, 1, &NumberOfBytesRead, NULL))
		return EO_ERROR;

	//check how many bytes did we received, common for both overlapped and nonoverlapped
	if(1 != NumberOfBytesRead)
		return EO_ERROR;
	return EO_OK;
}

eoReturn eoWin32PacketStream::SendByte(uint8_t u8TxByte)
{
	DWORD NumberOfBytesWritten = 0;

	if (!WriteFile(portOpen, &u8TxByte, 1, &NumberOfBytesWritten, NULL))
	{
		error = GetLastError();
		return EO_ERROR;
	}


	//get all the writes away from the port
	FlushFileBuffers(portOpen);

	if (NumberOfBytesWritten != 1)
	{
		error = GetLastError();
		return EO_ERROR;
	}

	return EO_OK;
}
#else
#warning "The WIN32 is not definied, eoWin32PacketStream only gets compiled using the WIN32 define"
#endif
