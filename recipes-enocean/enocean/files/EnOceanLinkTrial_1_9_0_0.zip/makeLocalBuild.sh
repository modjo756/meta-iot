#!/bin/sh
echo "Creates the EnOcean Link library locally and compiles the Examples,Tutorials."
cd ./EOLink/
sh ReleaseLib.sh
cd ../Tutorial/
sh Tutorial.sh
cd ../examples/
sh ./Examples.sh
