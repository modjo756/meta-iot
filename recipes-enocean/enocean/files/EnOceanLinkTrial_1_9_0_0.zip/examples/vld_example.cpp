/*
 File: vld_example.cpp
 brief: Example Program which uses UTE teach in

 */
#define SER_PORT "/dev/ttyUSB0"//! the Serial Port Device
#include "./eoLink.h"

#include <stdio.h>

int vld_example() {
	eoGateway gateway; //= eoGateway();

	//adding eoIDFilter to the gateWay
	if (gateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return -1;
	}

	uint16_t recv;

	gateway.LearnMode=true;
	while(1)
	{
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = gateway.Receive();
		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)
		if (recv & RECV_TEACHIN)
		{
			//Print out the Message to stdout
			eoDebug::Print(gateway.telegram);
			//If the TeachIN process was successfull and we got a Profile print out the Message!
			eoProfile *profile = gateway.device->GetProfile();
			if(profile!=NULL)
			{
				printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", gateway.device->ID, profile->rorg, profile->func, profile->type );

				for (int i = 0; i<profile->GetChannelCount(); i++)
				{
					printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
				}
			}

			//If incoming telegram is UTE telegram
			if (gateway.telegram.RORG == RORG_UTE)
			{
				//Creating the UTE response depending on the incoming teachIN telegram
				eoMessage response = eoMessage(7);
				UTE_EEP_TEACH_IN_QUERY uteQuery = gateway.TeachInModule->GetUTEQuery();
				eoUTEHelper::CreateUTEResponseFromQuery(uteQuery, response, TEACH_IN_ACCEPTED, UTE_DIRECTION_BIDIRECTIONAL);
				response.destinationID = gateway.telegram.sourceID;
				gateway.Send(response);
			}
		}
	}

	return 0;
}

int vld_sendExample()
{
	eoGateway gateway;

	//adding eoIDFilter to the gateWay
	eoIDFilter* myFilter = new eoIDFilter();
	gateway.filter=myFilter;

	if (gateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return -1;
	}

	printf("EnOcean-Link Gateway VLD send example\n");

	eoMessage msg(255);
	eoProfile * prof = new eoProfile();
	prof = eoProfileFactory::CreateProfile(0xD2,0x01,0x08);

	if (prof == NULL)
		return -1;

	// Starting with setting the command
	prof->SetValue(E_COMMAND, (uint8_t)ACTUATOR_SET_OUTPUT);
	// Setting the values of the specified command
	prof->SetValue(E_DIM_VALUE, (uint8_t)DIM_TO_NEW_FAST);
	prof->SetValue(E_IO_CHANNEL, (uint8_t)0x10);
	prof->SetValue(S_PERCENTAGE, (float)0x5A);

	prof->Create(msg);
	gateway.Send(msg);

	printf("Set output\n");

	// Sending Actuator Status Query
	prof->SetValue(E_COMMAND, (uint8_t)ACTUATOR_STATUS_QUERY);
	prof->SetValue(E_IO_CHANNEL, (uint8_t)0x1F);

	prof->Create(msg);
	gateway.Send(msg);

	printf("Sent query\n");

	// Waiting for a response
	while(1)
	{
		uint16_t recv = gateway.Receive();
		if (recv & RECV_PACKET)
		{
			if (gateway.packet.data[0] == 0xD2 && (gateway.packet.data[1] & 0x0F) == ACTUATOR_STATUS_RESPONSE)
				break;
		}
	}

	// Parsing the received value
	uint8_t val;
	prof->GetValue(E_ERROR_STATE, val);
	if (val != HARDWARE_OK)
	{
		printf("Hardware error!\n");
		return -1;
	}
	printf("Hardware is fine\n");

	// Sending measurement response
	prof->SetValue(E_COMMAND, (uint8_t)ACTUATOR_MEASUREMENT_RESPONSE);
	// Setting the values of the specified command
	prof->SetValue(S_ENERGY, (float)123456, ENERGY_WH);
	prof->SetValue(E_IO_CHANNEL, (uint8_t)0x1F);

	prof->Create(msg);
	gateway.Send(msg);
	return 0;
}

