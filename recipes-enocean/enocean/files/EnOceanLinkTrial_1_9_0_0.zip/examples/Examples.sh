#!/bin/bash
make distclean
mkdir Examples
cd Examples/
../configure LDFLAGS="-static"
if [ "$?" -eq "0" ]; then
	echo "Starting Make process"
else
	echo "Configure failed!"
	exit $?
fi
make clean
make 
if [ "$?" -eq "0" ]; then
        echo "Make Examples was sucessfull"
else
        exit $?
fi
