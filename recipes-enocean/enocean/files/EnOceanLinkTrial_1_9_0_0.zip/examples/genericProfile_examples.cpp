/*
 File: genericProfile_example.cpp

 Example Program which creates a generic Profile, with some Channels.
 */
#include "./eoLink.h"

#include <stdio.h>
#define SER_PORT "/dev/ttyUSB0"//this has to be changed accordingly to your pc/embedded system
void genericProfileExamples() {
	eoMessage msg(511);
	/*In the first step we create a new GenericProfile class, as
	 * Generic Profile messages can be quite big so we reserve a big internal message space
	 */
	eoGenericProfile *gpProf = new eoGenericProfile(64);
	if (gpProf == NULL) {
		printf("Unable to create GenericProfile");
		return;
	}
	printf("Created a new GP, trying to add some Channels\n");
	//Adding some inbound channels
	//These channels are not supported in SetValue function as they are inbound channels!
	//now we add some Temperature Channels
	if (gpProf->AddChannel(S_TEMP, GP_RES_8BIT, 40, 0, GP_SCAL_1, GP_SCAL_1,
			VAL_CURR) != EO_OK) {
		printf("Failed to add the first Temperature Channel");
		return;
	}
	if (gpProf->AddChannel(S_TEMP, GP_RES_16BIT, 20, -20, GP_SCAL_1, GP_SCAL_1,
			VAL_CURR) != EO_OK) {
		printf("Failed to add the second Temperature Channel");
		return;
	}
	//and a Flag CHannel
	if (gpProf->AddChannel(F_GENALARM, VAL_CURR) != EO_OK) {
		printf("Failed to add the Alarm Flag Channel");
		return;
	}
	//now we just print the Channel Information again
	for (int i = 0; i < gpProf->GetChannelCount(); i++) {
		printf("%s %.2f ... %.2f %s\n", gpProf->GetChannel(i)->ToString(NAME),
				gpProf->GetChannel(i)->min, gpProf->GetChannel(i)->max,
				gpProf->GetChannel(i)->ToString(UNIT));
	}
	//We now add the outbound channels
	//add a temperature channel
	if (gpProf->AddChannelOut(S_TEMP, GP_RES_8BIT, 30, -10, GP_SCAL_1,
			GP_SCAL_1, VAL_CURR) != EO_OK) {
		printf("Failed to add the first Temperature Channel");
		return;
	}
	//and an On/Off Flag CHannel
	if (gpProf->AddChannelOut(F_ON_OFF, VAL_CURR) != EO_OK) {
		printf("Failed to add the On/Off Flag Channel");
		return;
	}
	//now we just print the Channel Information again
	for (int i = 0; i < gpProf->GetChannelCountOut(); i++) {
		printf("%s %.2f ... %.2f %s\n", gpProf->GetChannel(i)->ToString(NAME),
				gpProf->GetChannel(i)->min, gpProf->GetChannel(i)->max,
				gpProf->GetChannel(i)->ToString(UNIT));
	}

	//afterwards we can create a TeachIN message
	if (gpProf->CreateTeachIN(msg) != EO_OK) {
		printf("Teach IN creation failed");
		return;
	}
	eoDebug::Print(msg);
	//Clear Values and set Message to rigth type
	gpProf->ClearValues();

	//Set the values for the outbound channels
	gpProf->SetValue(S_TEMP, (float) 20);
	gpProf->SetValue(F_ON_OFF, (uint8_t) 1);

	//now we have a prepares message with the flags
	gpProf->Create(msg);

	eoDebug::Print(msg);
}

void genericProfileWorkingExamples() {
	/*
	 * This example is a working example for receiving GP teach in and to create a bidirectional communication
	 */
	eoGateway gateway;
	eoMessage msg(512);
	uint16_t recv;

	if (gateway.Open(SER_PORT) != EO_OK) {
		printf("Failed to open USB300\n");
		return;
	}

	printf("EnOcean-Link Gateway\n");

	//Activate LearnMode
	gateway.LearnMode = true;
	while (1)
	{
		//eoGateway is normally in LearnMode, to unset LearnMode, set LearnMode to false
		//gateway.LearnMode=false;
		recv = gateway.Receive();
		if ((recv & RECV_TEACHIN)) {
			eoProfile *profile = gateway.device->GetProfile();

			profile->rorg == 0x0B && profile->func,
					profile->type ?
							profile->rorg, profile->func, profile->type :
							printf(
									"Device %08X Learned-In EEP: %02X-%02X-%02X\n",
									gateway.device->ID, profile->rorg,
									profile->func, profile->type);

			for (int i = 0; i < profile->GetChannelCount(); i++) {
				printf("%s %.2f ... %.2f %s\n",
						profile->GetChannel(i)->ToString(NAME),
						profile->GetChannel(i)->min,
						profile->GetChannel(i)->max,
						profile->GetChannel(i)->ToString(UNIT));
			}

			/**************** ONLY FOR CHANNEL REJECTION ******************/
			//check if it is bidirectional and want to reject channel
			if ((gateway.telegram.data[1] >> 4 & 1) == 0x01) {
				//If you want to reject any channels
				//Note: if you reject any channel, those channels will not be parsed!
				for (int i = 0; i < profile->GetChannelCount(); i++) {
					if (profile->GetChannel(i)->type == S_TEMP)
						((eoGPChannelInfo*) profile->GetChannel(i))->SetRejected(
								1);
				}
			}
			/**************** ONLY FOR CHANNEL REJECTION END ******************/

			//reply is always necessary even if it is a unidirectional device
			gateway.TeachInModule->CreateGPResponse(msg, 0x7FF,
					gateway.message.sourceID, RESP_REJECTED_CHANNELS, profile);
			gateway.Send(msg);

			/****************** ONLY IF THERE ARE ANY REJECTED CHANNELS **********************/
			//the device should reply in 500ms if it does not accept teach in
			uint32_t timer = eoTimer::GetTickCount() + 500;
			uint32_t limit = eoTimer::GetTickCount();
			gateway.LearnMode = false;

			while (timer > limit) {
				limit = eoTimer::GetTickCount();
				recv = gateway.Receive();
				if (recv & RECV_PROFILE) {
					printf("Device did not accept teach in request!");
					break;
				}
			}
			/**************** ONLY IF THERE ARE ANY REJECTED CHANNELS END ********************/

			break;

		}
	}
	while (1) {
		recv = gateway.Receive();
		if (recv & RECV_PROFILE) {
			printf("Device %08X\n", gateway.device->ID);
			eoProfile *profile = gateway.device->GetProfile();

			float f;
			uint8_t t;
			for (int i = 0; i < profile->GetChannelCount(); i++) {
				//get the channel value if it is a float
				if (profile->GetValue(profile->GetChannel(i)->type, f) == EO_OK)
					printf("%s %.2f %s\n",
							profile->GetChannel(i)->ToString(NAME), f,
							profile->GetChannel(i)->ToString(UNIT));
				//get the channel value if it is an uint
				if (profile->GetValue(profile->GetChannel(i)->type, t) == EO_OK)
					printf("%s %u \n", profile->GetChannel(i)->ToString(NAME),
							t);
			}
			//Set values for the outbound channels
			profile->SetValue(F_ON_OFF, (uint8_t) 1);
			profile->Create(msg);
			gateway.Send(msg);
		}
	}

	gateway.Close();
}
