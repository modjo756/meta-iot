/*
 File: Gateway_SubtypeExample.cpp

Example Program which opens a connection to the connected device, and handles received packages.

 */
#define SER_PORT "/dev/ttyUSB1"

#include "./eoLink.h"

#include <stdio.h>
#include <list>
#include <algorithm>
//Testing main.c
void gatewaySubtypeExample()
{
	eoGateway gateway;
	uint16_t recv;

	if (gateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return ;
	}

	printf("EnOcean-Link Gateway\n");

	//we set now the automatic RPS-Teach-IN information
	gateway.TeachInModule->SetRPS(0x02,0x01);
	//Activate LearnMode
	gateway.LearnMode=true;
	while (1)
	{
		//eoGateway is normally in LearnMode, to unset LearnMode, set LearnMode to false
		//gateway.LearnMode=false;
		recv = gateway.Receive();

		if (recv & RECV_TELEGRAM_ERP2)
		{
			eoDebug::Print(gateway.telegramERP2);
		}
		else if (recv & RECV_TELEGRAM)
		{
			eoDebug::Print(gateway.telegram);
		}
		else if (recv & RECV_PACKET)
		{
				eoDebug::Print(gateway.packet);
		}

		if ((recv & RECV_TEACHIN))
		{
			eoProfile *profile = gateway.device->GetProfile();
			printf("Device %08X Learned-In EEP: %02X-%02X-%02X\n", gateway.device->ID, profile->rorg, profile->func, profile->type );

			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				printf("%s %.2f ... %.2f %s\n", profile->GetChannel(i)->ToString(NAME), profile->GetChannel(i)->min, profile->GetChannel(i)->max, profile->GetChannel(i)->ToString(UNIT));
			}

		}

		if (recv & RECV_PROFILE)
		{
			printf("Device %08X\n", gateway.device->ID);
			eoProfile *profile = gateway.device->GetProfile();

			float f;
			uint8_t c;
			std::list <CHANNEL_TYPE> typeList;
			for (int i = 0; i<profile->GetChannelCount(); i++)
			{
				//Check if the found channel has been before
				if (typeList.end() != std::find(typeList.begin(), typeList.end(), profile->GetChannel(i)->type))
					continue;
				 std::vector< eoEEPChannelInfo * > subTypes;
				profile->GetSubTypeChannel(profile->GetChannel(i)->type,subTypes);
				//Loop through the subtype channels
				for (std::vector< eoEEPChannelInfo * >::iterator it=subTypes.begin();it<subTypes.end();it++)
				{
					//Find the channel with subtype
					eoEEPChannelInfo*  chan = *it;
					if (profile->GetValue(chan->eepItem->type,f,chan->eepItem->index) == EO_OK)
						printf("%s %.2f %s\n", chan->ToString(NAME),f,chan->ToString(UNIT));
					if (profile->GetValue(chan->eepItem->type,c,chan->eepItem->index) == EO_OK)
						printf("%s %u \n", chan->ToString(NAME),c);
				}
				//Save it so not checking the same channel more than once
				typeList.push_back(profile->GetChannel(i)->type);
			}

		}

	}

}

