/**
 @file: Security.cpp
 @brief: Security examples

 Different examples Explaining the usage of the eoSecurity functionality.

 */
#define SER_PORT "/dev/ttyUSB0"//! the Serial Port Device
#include "./eoLink.h"

#include <stdio.h>
const uint8_t pskVector[16] ={0x54,0x6F,0x62,0x69,0x20,0x52,0x6F,0x63,0x6B,0x74,0x20,0x50,0x53,0x4B,0x21,0x00};
const uint8_t keyVector[16] ={0x45,0x6E,0x4F,0x63,0x65,0x61,0x6E,0x20,0x47,0x6D,0x62,0x48,0x2E,0x31,0x33,0x00};

/**
 * This function simulates an secured PTM
 */
void securedPTM()
{
	eoGateway myGateway;
	eoSerialCommand cmd(&myGateway);
	//Destination ID is the broadcoast ID
	const uint32_t destID=0xFFFFFFFF;
	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return ;
	}
	else
	{
		printf("EnOcean-Link Gateway\n");
	}
	//Read Sw and HW version of the device
	CO_RD_VERSION_RESPONSE version;
	if (cmd.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return ;
	}
	//Preparing the security Information we add an outgoing device
	myGateway.deviceManager->Add(destID);
	eoDevice &myDevice=*(myGateway.deviceManager->Get(destID));
	//we get the Outgoing eoSecureInfo and set the security Paramters
	eoSecureInfo &devOut = myDevice.secOut;
	/* We want to sent data using the AES128 standard with a 3byte CMAC using 2bytes RollingCode.
	 * The rolling code will not be sent
	*/
	devOut.SLF=SLF_DATA_ENC_VAES128|SLF_MAC_3BYTE|SLF_RLC_ALGO_16BIT;
	/* To sent secure messages we need to set a key, the size of the key and the rollingCode.	 */
	memcpy(devOut.key,keyVector,sizeof(keyVector));
	devOut.keySize=16;

	devOut.rollingCode=0x3E2D;
	/* We set the Teach Information that this telegram is sent by a PTM pressing the ROCKERA buttons */
	devOut.teachInInfo=TEACH_INFO_PTM|TEACH_INFO_PTM_ROCKERA;

	/* */
	eoMessage TeachInMessage(30);
	TeachInMessage.destinationID=destID;

	if(myGateway.security.CreateTeachIn(TeachInMessage,myDevice)==EO_OK)
	{
		printf("Sending TeachIn Message \n");
		eoDebug::Print(TeachInMessage);
		myGateway.Send(TeachInMessage);
	}
	else
	{
		printf("Could not encrypt TeachIn message: %d \n",myGateway.security.GetLastError());
	}
	eoMessage unsecureMsg(1);
	eoMessage secureMsg(14);
	unsecureMsg.destinationID=destID;

	eoProfile* securePTM=eoProfileFactory::CreateProfile(0xD2,0x03,0x00);
	securePTM->SetValue(E_ROCKER_B,(uint8_t)0);
	securePTM->SetValue(E_ROCKER_A,(uint8_t)0);
	securePTM->SetValue(E_ENERGYBOW,(uint8_t)1);
	securePTM->Create(unsecureMsg);
	eoDebug::Print(unsecureMsg);
	//The secure PTM does not encapsulate its real RORG, so we've to change it
	unsecureMsg.RORG=RORG_SECD;
	if(myGateway.security.Encrypt(unsecureMsg,secureMsg,myDevice)==EO_OK)
	{
		printf("Sending Encrypted Message\n");
		eoDebug::Print(secureMsg);
		myGateway.Send(secureMsg);
	}
	else
	{
		printf("Could not encrypt Message: %d \n",myGateway.security.GetLastError());
	}
	securePTM->SetValue(E_ROCKER_B,(uint8_t)0);
	securePTM->SetValue(E_ROCKER_A,(uint8_t)1);
	securePTM->SetValue(E_ENERGYBOW,(uint8_t)0);
	securePTM->Create(unsecureMsg);
	eoDebug::Print(unsecureMsg);
	//The secure PTM does not encapsulate its real RORG, so we've to change it
	unsecureMsg.RORG=RORG_SECD;
	if(myGateway.security.Encrypt(unsecureMsg,secureMsg,myDevice)==EO_OK)
	{
		printf("Sending Encrypted Message\n");
		eoDebug::Print(secureMsg);
		myGateway.Send(secureMsg);
	}
	else
	{
		printf("Could not encrypt Message: %d \n",myGateway.security.GetLastError());
	}
	delete securePTM;
	return;
}

/**
 * This function simulates an STM with PSK (00,01,02...15)
 */

void securedSTM()
{
	eoGateway myGateway;
	eoSerialCommand cmd(&myGateway);
	//Destination ID is the broadcoast ID
	const uint32_t destID=0xFFFFFFFF;
	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return ;
	}
	else
	{
		printf("EnOcean-Link Gateway\n");
	}
	//Read Sw and HW version of the device
	CO_RD_VERSION_RESPONSE version;
	if (cmd.ReadVersion(version) == EO_OK)
	{
		printf("%s %i.%i.%i.%i, ID:0x%08X on %s\n",
								   version.appDescription,
								   version.appVersion[0], version.appVersion[1], version.appVersion[2], version.appVersion[3],
								   version.chipID,
								   SER_PORT);
	}
	//Failed to read the version of the device
	else
	{
		printf("Failed to retrieve USB300 version\n");
		return ;
	}
	//Preparing the security Information we add an outgoing device
	myGateway.deviceManager->Add(destID);
	eoDevice &myDevice=*(myGateway.deviceManager->Get(destID));
	//we get the Outgoing eoSecureInfo and set the security Paramters
	eoSecureInfo &devOut = myDevice.secOut;
	/* We want to sent data using the AES128 standard with a 3byte CMAC using 3bytes RollingCode.
	 * The rolling code will not be sent
	*/
	devOut.SLF=SLF_DATA_ENC_VAES128|SLF_MAC_3BYTE|SLF_RLC_ALGO_24BIT;
	/* To sent secure messages we need to set a key, the size of the key and the rollingCode.	 */
	memcpy(devOut.key,keyVector,sizeof(keyVector));
	memcpy(devOut.psk,pskVector,sizeof(pskVector));

	devOut.keySize=16;
	devOut.rollingCode=0xC0FFEE;
	/* We set the Teach Information that this telegram uses a psk */
	devOut.teachInInfo=TEACH_INFO_PSK;

	/* */
	eoMessage TeachInMessage(30);
	TeachInMessage.destinationID=destID;

	if(myGateway.security.CreateTeachIn(TeachInMessage,myDevice)==EO_OK)
	{
		printf("Sending TeachIn Message \n");
		eoDebug::Print(TeachInMessage);
		myGateway.Send(TeachInMessage);
	}
	else
	{
		printf("Could not encrypt TeachIn message: %d \n",myGateway.security.GetLastError());
	}
	eoMessage unsecureMsg(4);
	eoMessage secureMsg(32);
	unsecureMsg.destinationID=destID;

	eoProfile* secureSTM=eoProfileFactory::CreateProfile(0xA5,0x02,0x04);
	secureSTM->CreateTeachIN(unsecureMsg);
	eoDebug::Print(unsecureMsg);
	//sent an encrypted eep teach in
	if(myGateway.security.Encrypt(unsecureMsg,secureMsg,myDevice)==EO_OK)
	{
		printf("Sending Encrypted Message\n");
		eoDebug::Print(secureMsg);
		myGateway.Send(secureMsg);
	}
	else
	{
		printf("Could not encrypt Message: %d \n",myGateway.security.GetLastError());
	}
	//Now sent a few temperatures fast
	for(int temp=-10;temp<30;temp+=5)
	{
		secureSTM->SetValue(S_TEMP,(float)temp);
		secureSTM->Create(unsecureMsg);
		eoDebug::Print(unsecureMsg);

		if(myGateway.security.Encrypt(unsecureMsg,secureMsg,myDevice)==EO_OK)
		{
			printf("Sending Encrypted Message\n");
			eoDebug::Print(secureMsg);
			myGateway.Send(secureMsg);
		}
		else
		{
			printf("Could not encrypt Message: %d \n",myGateway.security.GetLastError());
		}
	}
	delete secureSTM;
	return;
}
