/*
 File: commands_example.cpp
brief
Example Program which uses eoCommonCommand to set and receive settings from the tcm300 module

 */
#define SER_PORT "/dev/ttyUSB0"//! the Serial Port Device
#include "./eoLink.h"

#include <stdio.h>

void smartACK_example() {
	eoGateway gateway; //= eoGateway();

	//adding eoIDFilter to the gateWay
	if (gateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return;
	}

	uint16_t recv;
	eoSerialCommand serial (&gateway);

	//Set the USB to SmartACK learn
	if (serial.SmartAckWriteLearnMode(true, SA_EL_SIMPLE, 0xffffffff) != EO_OK)
	{
		printf ("Failed to set SmartACK learn mode");
		return;
	}

	//Creating the structure for the SmartACK even confirm learn packet
	serial.SmartAckWriteLearnMode(true, SA_EL_SIMPLE, 0xffffffff);

	SA_CONFIRM_LEARN_REQUEST request;

	while(1)
	{
		//the Gateway::Receive() Functions returns different flags, depending on the Packet we got
		recv = gateway.Receive();
		//as we're in LearnMode currently we only want to process Teach_IN Telegrams(as specified in EEP)

		if (recv & RECV_PACKET)
		{
			if (serial.EventSmartAckConfirmLearn(request) == EO_OK)
			{
				eoReturn ret = serial.SmartAckConfirmLearn(0x100, SA_LEARN_IN);
				eoTimer::Sleep(500);
				if (ret != EO_OK)
					printf("bad");
				else
				{
					eoDevice * device;
					eoProfile * profile;

					device = gateway.deviceManager->Add(request.smartAckID);
					profile = eoProfileFactory::CreateProfile(request.eep[0], request.eep[1], request.eep[2]);
					if(profile != NULL)
						device->SetProfile(request.eep[0], request.eep[1], request.eep[2]);

					SA_RD_LEARNEDCLIENTS_RESPONSE learned[10];
					uint8_t max;
					if (serial.SmartAckLearnedClients(learned, &max, (uint8_t)10) == EO_OK)
					{
						for(uint8_t i = 0 ; i < max ; i++)
							printf("Learned Smart Ack device: %08X \n", learned[i].clientID);
						break;
					}
				}
			}
		}
	}
	//stop lrn mdoe
	serial.SmartAckWriteLearnMode(false, SA_EL_SIMPLE,0xFFFFFFFF);

	//send data telegram to device
	eoMessage msg = eoMessage(14);
	msg.RORG = 0xa5;
	msg.data[0] = 0xAB;
	msg.data[1] = 0x00;
	msg.data[2] = 0x00;
	msg.data[3] = 0xCD;
	msg.SetDataLength(4, false);
	msg.destinationID = request.smartAckID;

	gateway.Send(msg);

	return;
}

