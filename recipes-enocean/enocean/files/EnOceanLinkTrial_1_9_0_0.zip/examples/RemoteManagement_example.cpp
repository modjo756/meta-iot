/*
 File: Gateway_example.cpp

Example Program which opens a connection to the connected device, and handles received packages.

 */
#define SER_PORT "/dev/ttyUSB0"

#include "./eoLink.h"
#include <stdio.h>

//Testing main.c
void remanExample()
{
	//First a Gateway and a storageManager will be definied
	eoGateway myGateway;

	printf("Opening Connection to USB300 \n");
	if (myGateway.Open(SER_PORT)!=EO_OK)
	{
		printf("Failed to open USB300\n");
		return;
	}
	printf("EnOcean-Link Gateway LearnMode\n");
	//adding a dBm Filter as learnFilter
	eodBmFilter *  learnFilter = new eodBmFilter();
	myGateway.learnFilter = learnFilter;
	learnFilter->maxdBm=-0;
	learnFilter->mindBm=-60;

	//the eoIDFilter will allow our Gateway application to filter all the unwanted Telegrams
	eoIDFilter * myFilter = new eoIDFilter();
	myGateway.filter=myFilter;

	//recv stores the return Value of the Gateway
	uint16_t recv;
	//create reman module
	eoRemoteManager reman = eoRemoteManager(&myGateway);
	//create a query id
	QUERY_ID query;

	//send query ID
	reman.QueryID(query);

	uint32_t learnTime=eoTimer::GetTickCount()+3000;
	uint32_t time=eoTimer::GetTickCount();

	//gather query ID responses for 3 seconds
	while(learnTime>time)
	{
		time=eoTimer::GetTickCount();
		recv = myGateway.Receive();
		//check if reman answer telegramm
		if (recv & RECV_REMAN)
		{

			eoDebug::Print(myGateway.reManMessage);
			if(reman.ParseQueryIDAnswer(query) == EO_OK)
			{
				printf("Query ID Answer received!\n");
				myFilter->Add(myGateway.reManMessage.sourceID);
				;
			}

		}
	}

	if(myGateway.reManMessage.sourceID == 0)
	{
		printf("No remote device responding!");
		return;
	}
	//select one id - last one
	uint32_t remanID = myGateway.reManMessage.sourceID;
	//query function commands
	reman.QueryFunction(remanID);

	//wait for the response
	QUERY_FUNCTION_RESPONSE myQueryFunctionResponse[10];
	uint8_t responseCount = 0;
	while(1)
		{

			recv = myGateway.Receive();
			//check if reman answer telegramm
			if (recv & RECV_REMAN)
			{
				eoDebug::Print(myGateway.reManMessage);
				if(reman.ParseQueryFunctionAnswer(&myQueryFunctionResponse[0],(uint8_t)10,responseCount)==EO_OK)
				{
					printf("Supporting functions:\n");
					for(uint8_t i = 0;i<responseCount;i++)
					{
						printf("function number: %X\n",myQueryFunctionResponse[i].functionNum);
					}
					break;
				}

			}
		}
	//set the reman security code
	reman.SetCode(0x1,remanID);
	//wait because the code is written into flash
	eoTimer::Sleep(1000);
	//query the stauts of last function call
	reman.QueryStatus(remanID);

	QUERY_STATUS_RESPONSE myQueryStatusResponse;

	while(1)
		{

			recv = myGateway.Receive();
			//check if reman answer telegramm
			if (recv & RECV_REMAN)
			{
				eoDebug::Print(myGateway.reManMessage);
				if(reman.ParseQueryStatusAnswer(myQueryStatusResponse)==EO_OK)
				{
					printf("Status response:\n");
					printf("Last Function called: %X\n",myQueryStatusResponse.lastFunc);
					printf("Code set: %X\n",myQueryStatusResponse.codeSetFlag);
					break;
				}

			}
		}
	//lock the device
	reman.Lock(0x1,remanID);

	reman.Ping(remanID);
	PING_RESPONSE myPingResponse;

	while(1)
		{

			recv = myGateway.Receive();
			//check if reman answer telegramm
			if (recv & RECV_REMAN)
			{
				eoDebug::Print(myGateway.reManMessage);
				if(reman.ParsePingAnswer(myPingResponse)==EO_OK)
				{
					printf("Ping response received:\n");
					printf("dBm Value from device: %i \n",(int)myPingResponse.rssi);
					break;
				}

			}
		}


	printf("Example finished!:\n");
	return;

}


