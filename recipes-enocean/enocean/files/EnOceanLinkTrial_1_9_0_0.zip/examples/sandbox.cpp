/*
 * main.cpp
 *
 *  Created on: 27.06.2012
 *      Author: tobias
 */

#include <stdio.h>
#include "examples.h"

int main(  int argc, const char* argv[]  )
{
	commands_example();
	deviceManagerExample();
	gatewayExample();
	gatewaySubtypeExample();
	gatewayFitleredExample();
	linuxPacketStreamExample();
	profileExamples();
	ptmExample();

	PacketStreamExample();
	remanExample();
	genericProfileExamples();

	smartACK_example();
	securedSTM();
	securedPTM();
	storageExample();
	vld_example();
	return 0;

}
