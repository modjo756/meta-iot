/*
 * examples.h
 *
 *  Created on: 27.06.2012
 *      Author: tobias
 */

#ifndef EXAMPLES_H_
#define EXAMPLES_H_

int commands_example();
void deviceManagerExample();
void linuxPacketStreamExample();
void PacketStreamExample();
void profileExamples();
void gatewayExample();
void storageExample();
void gatewayFitleredExample();
void gatewaySubtypeExample();
void raspPiGatewayFitleredExample();
void genericProfileExamples();
void remanExample();
void ptmExample();
void vld_example();
void vld_sendExample();
void smartACK_example();
void securedPTM();
void securedSTM();
#endif /* EXAMPLES_H_ */
